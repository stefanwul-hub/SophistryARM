
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0000b122(int param_1)

{
  char cVar1;
  char *pcVar2;
  undefined4 uVar3;
  uint uVar4;
  char *pcVar5;
  
  if (param_1 != 0) {
    if ((cRam003d3f09 == '\0') && (cRam003d3f09 = 1, iRam003d3ee8 != 0)) {
      func_0x000424ac(iRam003d3ee8,param_1);
    }
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  pcVar2 = "GNFree(0)";
  if (cRam003d3ef8 == '\0') {
    uVar4 = 0xffffffff;
    pcVar5 = pcVar2;
    do {
      if (uVar4 == 0) break;
      uVar4 = uVar4 - 1;
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    uVar4 = ~uVar4 - 1;
    if (uVar4 < 0x2000) {
      pcVar2 = (char *)FUN_0000aecc(uVar4 * 3 + 0x400);
      _vsprintf(pcVar2,"GNFree(0)",&stack0x00000008);
    }
    if (piRam003d3f0c == (int *)0x0) {
      uVar3 = __Znwm(0x38);
      func_0x0006f04a(uVar3);
      piRam003d3f0c = (int *)FUN_0002dfa6(uVar3);
    }
    (**(code **)(*piRam003d3f0c + 0x1a4))(piRam003d3f0c);
    _puts(pcVar2);
    (**(code **)(*piRam003d3f0c + 0x1ac))(piRam003d3f0c);
    if (uVar4 < 0x2000) {
      if (pcVar2 != (char *)0x0) {
        if (cRam003d3f09 == '\0') {
          cRam003d3f09 = 1;
          if (iRam003d3ee8 != 0) {
            func_0x000424ac(iRam003d3ee8,pcVar2);
          }
          cRam003d3f09 = '\0';
        }
        _free(pcVar2);
        return;
      }
      FUN_0000ab14("GNFree(0)");
    }
  }
  return;
}


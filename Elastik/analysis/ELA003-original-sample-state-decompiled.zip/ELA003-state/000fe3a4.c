
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000fe3a4(undefined4 param_1,int *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  
  puVar1 = (undefined4 *)__Znwm(0x40);
  func_0x000a0a60(puVar1);
  *puVar1 = &UNK_0037eb88;
  puVar1[7] = 0;
  puVar1[8] = 0;
  puVar1[9] = 0;
  puVar1[10] = 0;
  puVar1[0xb] = 1;
  puVar1[0xc] = 0;
  puVar1[0xd] = 1;
  *(undefined1 *)(puVar1 + 0xe) = 0;
  *(undefined1 *)((int)puVar1 + 0x39) = 0;
  *(undefined1 *)((int)puVar1 + 0x3a) = 1;
  *(undefined1 *)((int)puVar1 + 0x3b) = 0;
  *(undefined1 *)(puVar1 + 0xf) = 1;
  *(undefined1 *)((int)puVar1 + 0x3d) = 0;
  piVar2 = (int *)FUN_0002dfa6(puVar1);
  iVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
  piVar2 = *(int **)(iVar3 + 0x24);
  if (param_2 != piVar2) {
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0x44))(piVar2);
    }
    *(int **)(iVar3 + 0x24) = param_2;
    if (param_2 != (int *)0x0) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
  }
  *(undefined4 *)(iVar3 + 0x30) = 0;
  *(undefined4 *)(iVar3 + 0x34) = 1;
  func_0x000fc7bc(iVar3,param_1);
  return iVar3;
}


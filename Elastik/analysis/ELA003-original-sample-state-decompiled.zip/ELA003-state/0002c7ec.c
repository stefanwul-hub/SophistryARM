
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002c7ec(int param_1,int *param_2)

{
  code *pcVar1;
  char cVar2;
  undefined1 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  int iVar18;
  
  if (iRam003d400c == 0) {
    uVar4 = FUN_00033b90("12");
    uVar6 = FUN_00033b90("11");
    uVar7 = FUN_00033b90("10");
    uVar8 = FUN_00033b90("9");
    uVar9 = FUN_00033b90("8");
    uVar10 = FUN_00033b90("7");
    uVar11 = FUN_00033b90("6");
    uVar12 = FUN_00033b90("5");
    uVar13 = FUN_00033b90("4");
    uVar14 = FUN_00033b90("3");
    uVar15 = FUN_00033b90("2");
    uVar16 = FUN_00033b90("1");
    uVar17 = FUN_00033b90("0");
    iRam003d400c = FUN_0002c732(uVar17,uVar16,uVar15,uVar14,uVar13,uVar12,uVar11,uVar10,uVar9,uVar8,
                                uVar7,uVar6,uVar4,0);
  }
  FUN_0002e11c(param_1,param_2);
  cVar2 = (**(code **)(*param_2 + 0x1b0))(param_2);
  if (cVar2 == '\0') {
    pcVar1 = *(code **)(*param_2 + 0x270);
    uVar4 = FUN_00033b90("GNList");
    iVar5 = (*pcVar1)(param_2,uVar4);
    if (1 < iVar5) {
      uVar3 = (**(code **)(*param_2 + 0x1e4))(param_2);
      *(undefined1 *)(param_1 + 0x18) = uVar3;
    }
    if (iVar5 < 3) {
      iVar5 = (**(code **)(*param_2 + 0x1ec))(param_2);
      FUN_0002a14a(param_1,iVar5);
    }
    else {
      uVar3 = (**(code **)(*param_2 + 0x1e4))(param_2);
      *(undefined1 *)(param_1 + 0x19) = uVar3;
      iVar5 = (**(code **)(*param_2 + 0x1ec))(param_2);
      FUN_0002a14a(param_1,iVar5);
    }
    if (0 < iVar5) {
      iVar18 = 0;
      do {
        uVar4 = (**(code **)(*param_2 + 0x208))(param_2);
        FUN_0002bb40(param_1,uVar4);
        iVar18 = iVar18 + 1;
      } while (iVar5 != iVar18);
      return;
    }
  }
  else {
    pcVar1 = *(code **)(*param_2 + 0x248);
    uVar4 = FUN_00033b90("count");
    iVar5 = (*pcVar1)(param_2,uVar4);
    FUN_0002a14a(param_1,iVar5);
    if (0 < iVar5) {
      iVar18 = 0;
      do {
        while (pcVar1 = *(code **)(*param_2 + 0x260), 0xc < iVar18) {
          uVar4 = FUN_0003dd2a("%i",iVar18);
          uVar4 = (*pcVar1)(param_2,uVar4);
          FUN_0002bb40(param_1,uVar4);
          iVar18 = iVar18 + 1;
          if (iVar5 == iVar18) {
            return;
          }
        }
        uVar4 = FUN_0002a364(iRam003d400c,iVar18);
        uVar4 = (*pcVar1)(param_2,uVar4);
        FUN_0002bb40(param_1,uVar4);
        iVar18 = iVar18 + 1;
      } while (iVar5 != iVar18);
    }
  }
  return;
}


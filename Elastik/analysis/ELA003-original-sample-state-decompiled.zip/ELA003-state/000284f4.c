
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000284f4(int *param_1,int *param_2)

{
  code *pcVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iStack_28;
  int iStack_24;
  int iStack_20;
  
  iVar3 = (**(code **)(*param_2 + 0x1ec))(param_2);
  param_1[4] = iVar3;
  if (iVar3 == 0) {
    iStack_24 = 0;
  }
  else {
    iStack_24 = (**(code **)(*param_2 + 0x1ec))(param_2);
  }
  uVar4 = (**(code **)(*param_2 + 0x1ec))(param_2);
  (**(code **)(*param_1 + 0x1a4))(param_1,uVar4);
  FUN_00027b4e(param_1);
  pcVar1 = *(code **)(*param_2 + 0x20c);
  if (param_1[6] == 0) {
    if (param_1[3] != 0) {
      iStack_28 = FUN_0000ae24(param_1[3]);
      iVar3 = param_1[6];
      goto joined_r0x00028604;
    }
    iStack_28 = 0;
  }
  else {
    iStack_28 = param_1[7];
  }
  iVar3 = param_1[6];
joined_r0x00028604:
  if (iVar3 == 0) {
    if (param_1[3] == 0) {
      FUN_0000ab14("GNData::bytes(). Data object doesn\'t have alloced memory yet.");
      iVar3 = 0;
    }
    else {
      iVar3 = **(int **)(param_1[3] + 0xc);
    }
  }
  (*pcVar1)(param_2,iVar3,iStack_28);
  iVar3 = param_1[4];
  if ((iVar3 != 0) && (iStack_24 == 1)) {
    if (param_1[6] == 0) {
      if (param_1[3] == 0) {
        iStack_20 = 0;
      }
      else {
        iStack_20 = FUN_0000ae24(param_1[3]);
      }
    }
    else {
      iStack_20 = param_1[7];
    }
    iVar2 = param_1[6];
    if (iVar2 == 0) {
      if (param_1[3] == 0) {
        FUN_0000ab14("GNData::bytes(). Data object doesn\'t have alloced memory yet.");
        iVar2 = 0;
      }
      else {
        iVar2 = **(int **)(param_1[3] + 0xc);
      }
    }
    func_0x0000a978(iVar2,iStack_20,iVar3);
  }
  if ((param_1[6] == 0) && (iVar3 = param_1[3], iVar3 != 0)) {
    if (iVar3 == 0) {
      func_0x0000acae("GNMemoryHandle is nil.");
    }
    iVar2 = *(int *)(iVar3 + 8) + -1;
    *(int *)(iVar3 + 8) = iVar2;
    if (iVar2 == 0) {
      if (iRam003d3ef0 == 0) {
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      func_0x0004313e(iRam003d3ef0,iVar3);
      iRam003d3ef4 = iRam003d3ef4 + 1;
    }
    return;
  }
  return;
}


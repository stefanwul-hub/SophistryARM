
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00035a8a(int param_1,int *param_2)

{
  char cVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  char *pcVar6;
  int iStack_30;
  undefined2 auStack_1e [7];
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x10f,uVar3,"this != 0");
  }
  iStack_30 = *(int *)(param_1 + 0x14);
  if (iStack_30 == -1) {
    if (*(char **)(param_1 + 0xc) == (char *)0x0) {
      iStack_30 = 0;
    }
    else {
      uVar5 = 0xffffffff;
      pcVar6 = *(char **)(param_1 + 0xc);
      do {
        if (uVar5 == 0) break;
        uVar5 = uVar5 - 1;
        cVar1 = *pcVar6;
        pcVar6 = pcVar6 + 1;
      } while (cVar1 != '\0');
      iStack_30 = ~uVar5 - 1;
    }
  }
  pcVar2 = *(code **)(*param_2 + 0x274);
  uVar3 = FUN_00033b90("GNString");
  (*pcVar2)(param_2,uVar3,3);
  if (*(int *)(param_1 + 0x14) != -1) {
    if (cRam003d4044 == '\0') {
      auStack_1e[0] = 0xfeff;
      if (*(int *)(param_1 + 0x14) == -1) {
        FUN_000358be(param_1);
      }
      if (*(int *)(param_1 + 0x10) == 0) {
        uVar3 = func_0x0000a930(
                               "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                               );
        uVar4 = FUN_00033b90("GNAssertionException");
        FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0xbd,uVar3,"_uniChars");
      }
      (**(code **)(*param_2 + 0x1bc))(param_2,5);
      (**(code **)(*param_2 + 0x1e0))(param_2,auStack_1e,2);
      (**(code **)(*param_2 + 0x1e0))(param_2,*(undefined4 *)(param_1 + 0x10),iStack_30 * 2 + 2);
      (**(code **)(*param_2 + 0x1b4))(param_2,(int)*(char *)(param_1 + 0x18));
      return;
    }
    if (*(int *)(param_1 + 0xc) == 0) {
      FUN_000340ba(param_1);
    }
    if (*(int *)(param_1 + 0xc) == 0) {
      uVar3 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                             );
      uVar4 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0xaf,uVar3,"_chars");
    }
  }
  (**(code **)(*param_2 + 0x1bc))(param_2,0);
  if (iStack_30 != 0) {
    (**(code **)(*param_2 + 0x1e0))(param_2,*(undefined4 *)(param_1 + 0xc),iStack_30 + 1);
    (**(code **)(*param_2 + 0x1b4))(param_2,(int)*(char *)(param_1 + 0x18));
    return;
  }
  (**(code **)(*param_2 + 0x1e0))(param_2,&UNK_00364b02,1);
  (**(code **)(*param_2 + 0x1b4))(param_2,(int)*(char *)(param_1 + 0x18));
  return;
}


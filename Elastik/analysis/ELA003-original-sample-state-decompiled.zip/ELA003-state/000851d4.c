
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000851d4(int param_1,int *param_2)

{
  char cVar1;
  code *pcVar2;
  undefined4 uVar3;
  
  pcVar2 = *(code **)(*param_2 + 0x274);
  uVar3 = FUN_00033b90("GNNumber");
  (*pcVar2)(param_2,uVar3,2);
  (**(code **)(*param_2 + 0x1b8))(param_2,(int)*(char *)(param_1 + 0x10));
  if (*(char *)(param_1 + 0x10) == 'f') {
    (**(code **)(*param_2 + 0x1c0))(param_2,**(undefined4 **)(param_1 + 0xc));
    cVar1 = *(char *)(param_1 + 0x10);
  }
  else {
    cVar1 = *(char *)(param_1 + 0x10);
  }
  if (cVar1 == 'd') {
    (**(code **)(*param_2 + 0x1c4))(param_2,**(undefined8 **)(param_1 + 0xc));
    cVar1 = *(char *)(param_1 + 0x10);
  }
  else {
    cVar1 = *(char *)(param_1 + 0x10);
  }
  if (cVar1 == 'l') {
    (**(code **)(*param_2 + 0x1c8))
              (param_2,**(undefined4 **)(param_1 + 0xc),(*(undefined4 **)(param_1 + 0xc))[1]);
  }
  if (*(char *)(param_1 + 0x10) == 'i') {
    (**(code **)(*param_2 + 0x1bc))(param_2,*(undefined4 *)(param_1 + 0xc));
  }
  if (*(char *)(param_1 + 0x10) != 'b') {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00085277. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_2 + 0x1b4))();
  return;
}


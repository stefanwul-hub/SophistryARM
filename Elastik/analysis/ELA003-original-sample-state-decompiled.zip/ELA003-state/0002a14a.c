
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002a14a(int *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  if ((0 < param_2) && (iVar2 = param_1[5], iVar2 < param_2)) {
    cVar1 = func_0x000318d4();
    if (cVar1 != '\0') {
      iVar3 = (**(code **)(*param_1 + 8))(param_1);
      *(int *)(iVar3 + 0x70) = *(int *)(iVar3 + 0x70) + iVar2 * -4;
    }
    iVar2 = 8;
    if (7 < param_2) {
      iVar2 = param_2;
    }
    param_1[5] = iVar2;
    iVar2 = func_0x0000a4c4(param_1[3],iVar2 << 2);
    param_1[3] = iVar2;
    if (iVar2 == 0) {
      uVar4 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                             );
      uVar5 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x128,uVar4,"_dataPtr");
    }
    cVar1 = func_0x000318d4();
    if (cVar1 != '\0') {
      iVar2 = (**(code **)(*param_1 + 8))(param_1);
      *(int *)(iVar2 + 0x70) = *(int *)(iVar2 + 0x70) + param_1[5] * 4;
      return;
    }
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00020c18(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (*(int *)(param_1 + 0x2c) == 0) {
    uVar1 = __Znwm(0x24);
    func_0x00041414(uVar1);
    uVar1 = FUN_0002dfa6(uVar1);
    *(undefined4 *)(param_1 + 0x2c) = uVar1;
    func_0x000416b2(uVar1,0);
    func_0x00041774(*(undefined4 *)(param_1 + 0x2c),0xc);
    param_1 = *(int *)(param_1 + 0x2c);
  }
  else {
    param_1 = *(int *)(param_1 + 0x2c);
  }
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0xca,uVar1,"this != 0");
  }
  if (param_2 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0xca,uVar1,"anElement");
  }
  if (param_1 != 0) {
    func_0x00042dcc(param_1,param_2,*(undefined4 *)(param_1 + 0x10));
    return;
  }
  uVar1 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                         );
  uVar2 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0xaf,uVar1,"this != 0");
  func_0x00042dcc(0,param_2,mach_header_00000000.ncmds);
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_001000ae(char param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  uVar3 = FUN_0003dd2a("%c",(int)param_1);
  if (iRam003d45f4 == 0) {
    uVar2 = __Znwm(0x18);
    FUN_000630b6(uVar2);
    iRam003d45f4 = FUN_0002dfa6(uVar2);
    iVar1 = FUN_00064626(iRam003d45f4,uVar3);
  }
  else {
    iVar1 = FUN_00064626(iRam003d45f4,uVar3);
  }
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = func_0x000ffec4(uVar3,uVar3);
  FUN_00066284(iRam003d45f4,iVar1,uVar3);
  return iVar1;
}


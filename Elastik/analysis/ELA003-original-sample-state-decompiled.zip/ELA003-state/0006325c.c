
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0006325c(int param_1,int *param_2)

{
  int *piVar1;
  code *pcVar2;
  char cVar3;
  undefined4 uVar4;
  
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 == (int *)0x0) {
    *(undefined4 *)(param_1 + 0xc) = 0;
    piVar1 = *(int **)(param_1 + 0x10);
  }
  else {
    (**(code **)(*piVar1 + 0x44))(piVar1);
    *(undefined4 *)(param_1 + 0xc) = 0;
    piVar1 = *(int **)(param_1 + 0x10);
  }
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x44))(piVar1);
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  cVar3 = (**(code **)(*param_2 + 0x1b0))(param_2);
  if (cVar3 == '\0') {
    uVar4 = (**(code **)(*param_2 + 0x208))(param_2);
    *(undefined4 *)(param_1 + 0xc) = uVar4;
    uVar4 = (**(code **)(*param_2 + 0x208))(param_2);
    *(undefined4 *)(param_1 + 0x10) = uVar4;
  }
  else {
    pcVar2 = *(code **)(*param_2 + 0x260);
    uVar4 = FUN_00033b90("keys");
    uVar4 = (*pcVar2)(param_2,uVar4);
    *(undefined4 *)(param_1 + 0xc) = uVar4;
    pcVar2 = *(code **)(*param_2 + 0x260);
    uVar4 = FUN_00033b90("objects");
    uVar4 = (*pcVar2)(param_2,uVar4);
    *(undefined4 *)(param_1 + 0x10) = uVar4;
  }
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x40))(piVar1);
  }
  piVar1 = *(int **)(param_1 + 0x10);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x40))(piVar1);
  }
  return;
}


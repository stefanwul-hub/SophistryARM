000fe4d8  55  PUSH EBP
000fe4d9  89e5  MOV EBP,ESP
000fe4db  57  PUSH EDI
000fe4dc  56  PUSH ESI
000fe4dd  53  PUSH EBX
000fe4de  83ec3c  SUB ESP,0x3c
000fe4e1  e8366b1e00  CALL 0x002e501c
000fe4e6  c745e000000000  MOV dword ptr [EBP + -0x20],0x0
000fe4ed  c745e400000000  MOV dword ptr [EBP + -0x1c],0x0
000fe4f4  c745d800000000  MOV dword ptr [EBP + -0x28],0x0
000fe4fb  c745dc00000000  MOV dword ptr [EBP + -0x24],0x0
000fe502  c745d000000000  MOV dword ptr [EBP + -0x30],0x0
000fe509  c745d400000000  MOV dword ptr [EBP + -0x2c],0x0
000fe510  c7042440000000  MOV dword ptr [ESP],0x40
000fe517  e889bb2d00  CALL 0x003da0a5
000fe51c  89c7  MOV EDI,EAX
000fe51e  890424  MOV dword ptr [ESP],EAX
000fe521  e83a25faff  CALL 0x000a0a60
000fe526  8d83a2062800  LEA EAX,[EBX + 0x2806a2]
000fe52c  8907  MOV dword ptr [EDI],EAX
000fe52e  c7471c00000000  MOV dword ptr [EDI + 0x1c],0x0
000fe535  c7472000000000  MOV dword ptr [EDI + 0x20],0x0
000fe53c  c7472400000000  MOV dword ptr [EDI + 0x24],0x0
000fe543  c745e401000000  MOV dword ptr [EBP + -0x1c],0x1
000fe54a  c745e000000000  MOV dword ptr [EBP + -0x20],0x0
000fe551  8b45e0  MOV EAX,dword ptr [EBP + -0x20]
000fe554  8b55e4  MOV EDX,dword ptr [EBP + -0x1c]
000fe557  894728  MOV dword ptr [EDI + 0x28],EAX
000fe55a  89572c  MOV dword ptr [EDI + 0x2c],EDX
000fe55d  c745dc01000000  MOV dword ptr [EBP + -0x24],0x1
000fe564  c745d800000000  MOV dword ptr [EBP + -0x28],0x0
000fe56b  8b45d8  MOV EAX,dword ptr [EBP + -0x28]
000fe56e  8b55dc  MOV EDX,dword ptr [EBP + -0x24]
000fe571  894730  MOV dword ptr [EDI + 0x30],EAX
000fe574  895734  MOV dword ptr [EDI + 0x34],EDX
000fe577  c6473800  MOV byte ptr [EDI + 0x38],0x0
000fe57b  c6473900  MOV byte ptr [EDI + 0x39],0x0
000fe57f  c6473a01  MOV byte ptr [EDI + 0x3a],0x1
000fe583  c6473b00  MOV byte ptr [EDI + 0x3b],0x0
000fe587  c6473c01  MOV byte ptr [EDI + 0x3c],0x1
000fe58b  c6473d00  MOV byte ptr [EDI + 0x3d],0x0
000fe58f  893c24  MOV dword ptr [ESP],EDI
000fe592  e80ffaf2ff  CALL 0x0002dfa6
000fe597  8b10  MOV EDX,dword ptr [EAX]
000fe599  890424  MOV dword ptr [ESP],EAX
000fe59c  ff5248  CALL dword ptr [EDX + 0x48]
000fe59f  89c6  MOV ESI,EAX
000fe5a1  8b5024  MOV EDX,dword ptr [EAX + 0x24]
000fe5a4  39550c  CMP dword ptr [EBP + 0xc],EDX
000fe5a7  741e  JZ 0x000fe5c7
000fe5a9  85d2  TEST EDX,EDX
000fe5ab  7408  JZ 0x000fe5b5
000fe5ad  8b02  MOV EAX,dword ptr [EDX]
000fe5af  891424  MOV dword ptr [ESP],EDX
000fe5b2  ff5044  CALL dword ptr [EAX + 0x44]
000fe5b5  8b550c  MOV EDX,dword ptr [EBP + 0xc]
000fe5b8  895624  MOV dword ptr [ESI + 0x24],EDX
000fe5bb  85d2  TEST EDX,EDX
000fe5bd  7408  JZ 0x000fe5c7
000fe5bf  8b02  MOV EAX,dword ptr [EDX]
000fe5c1  891424  MOV dword ptr [ESP],EDX
000fe5c4  ff5040  CALL dword ptr [EAX + 0x40]
000fe5c7  c745d4ffffff0f  MOV dword ptr [EBP + -0x2c],0xfffffff
000fe5ce  c745d000000000  MOV dword ptr [EBP + -0x30],0x0
000fe5d5  8b45d0  MOV EAX,dword ptr [EBP + -0x30]
000fe5d8  8b55d4  MOV EDX,dword ptr [EBP + -0x2c]
000fe5db  894630  MOV dword ptr [ESI + 0x30],EAX
000fe5de  895634  MOV dword ptr [ESI + 0x34],EDX
000fe5e1  8b4508  MOV EAX,dword ptr [EBP + 0x8]
000fe5e4  89442404  MOV dword ptr [ESP + 0x4],EAX
000fe5e8  893424  MOV dword ptr [ESP],ESI
000fe5eb  e8cce1ffff  CALL 0x000fc7bc
000fe5f0  89f0  MOV EAX,ESI
000fe5f2  83c43c  ADD ESP,0x3c
000fe5f5  5b  POP EBX
000fe5f6  5e  POP ESI
000fe5f7  5f  POP EDI
000fe5f8  5d  POP EBP
000fe5f9  c3  RET

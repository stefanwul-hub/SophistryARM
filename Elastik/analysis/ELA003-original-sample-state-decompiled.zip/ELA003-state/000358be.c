
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000358be(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  char *pcVar6;
  int iStack_20;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x7c1,uVar2,"this != 0");
  }
  if (*(int *)(param_1 + 0x14) == -1) {
    iStack_20 = *(int *)(param_1 + 0x14);
  }
  else {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x7c1,uVar2,"_uniCharLength == -1");
    iStack_20 = *(int *)(param_1 + 0x14);
  }
  if (iStack_20 == -1) {
    pcVar6 = *(char **)(param_1 + 0xc);
    uVar5 = 0xffffffff;
    if (pcVar6 == (char *)0x0) {
      iStack_20 = 0;
      iVar4 = 0;
      goto LAB_0003594c;
    }
    do {
      if (uVar5 == 0) break;
      uVar5 = uVar5 - 1;
      cVar1 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar1 != '\0');
    iStack_20 = ~uVar5 - 1;
  }
  if (iStack_20 < 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x7c3,uVar2,"l >= 0");
  }
  iVar4 = iStack_20 << 2;
LAB_0003594c:
  uVar2 = FUN_0000aecc(iVar4 + 4);
  *(undefined4 *)(param_1 + 0x10) = uVar2;
  FUN_00189376(*(undefined4 *)(param_1 + 0xc),uVar2,0,iStack_20);
  *(undefined2 *)(*(int *)(param_1 + 0x10) + iStack_20 * 2) = 0;
  *(int *)(param_1 + 0x14) = iStack_20;
  return;
}


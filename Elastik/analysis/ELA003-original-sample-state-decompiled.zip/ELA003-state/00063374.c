
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00063374(int param_1,int *param_2)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  
  cVar2 = (**(code **)(*param_2 + 0x1ac))(param_2);
  if (cVar2 != '\0') {
    pcVar1 = *(code **)(*param_2 + 0x234);
    uVar3 = FUN_00033b90("keys");
    (*pcVar1)(param_2,*(undefined4 *)(param_1 + 0xc),uVar3);
    pcVar1 = *(code **)(*param_2 + 0x234);
    uVar3 = FUN_00033b90("objects");
    (*pcVar1)(param_2,*(undefined4 *)(param_1 + 0x10),uVar3);
    return;
  }
  (**(code **)(*param_2 + 0x1d8))(param_2,*(undefined4 *)(param_1 + 0xc));
                    /* WARNING: Could not recover jumptable at 0x00063424. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_2 + 0x1d8))();
  return;
}


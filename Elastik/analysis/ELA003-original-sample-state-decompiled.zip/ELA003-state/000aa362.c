
void FUN_000aa362(undefined4 param_1,undefined4 param_2)

{
  func_0x000aa204(param_1,param_2,0);
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00189376(byte *param_1,ushort *param_2,undefined *param_3,int param_4)

{
  ushort *puVar1;
  byte bVar2;
  char cVar3;
  byte bVar4;
  ushort uVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  byte *pbVar11;
  uint uVar12;
  undefined *puVar13;
  byte *pbVar14;
  int iVar15;
  byte *pbStack_3c;
  int iStack_38;
  ushort uStack_26;
  byte *pbStack_24;
  int iStack_20;
  
  switch(param_3) {
  case (undefined *)0x0:
    pbStack_3c = (byte *)0x366b20;
    break;
  case (undefined *)0x1:
    pbStack_3c = (byte *)0x3668a0;
    break;
  case (undefined *)0x2:
    pbStack_3c = (byte *)0x366600;
    break;
  case (undefined *)0x3:
    pbStack_3c = (byte *)0x366380;
    break;
  case (undefined *)0x4:
    pbStack_3c = (byte *)0x366300;
    break;
  default:
    pbStack_3c = (byte *)0x0;
  }
  if (param_3 == &UNK_0000270f) {
    uVar9 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStringEncoding.cpp"
                           );
    uVar10 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar10,"Assertion failed in line %d of %s: %s.",0x157,uVar9,
                 "sourceEncoding != GNStringEncodingUndefined");
  }
  else {
    if (param_3 == (undefined *)0x3e9) {
      uVar9 = func_0x00033482();
      switch(uVar9) {
      case 0:
        pbStack_24 = (byte *)0x366b20;
        break;
      case 1:
        pbStack_24 = (byte *)0x3668a0;
        break;
      case 2:
        pbStack_24 = (byte *)0x366600;
        break;
      case 3:
        pbStack_24 = (byte *)0x366380;
        break;
      case 4:
        pbStack_24 = (byte *)0x366300;
        break;
      default:
        pbStack_24 = (byte *)0x0;
      }
      if (param_4 < 1) {
        iStack_20 = 0;
      }
      else {
        bVar4 = *param_1;
        param_1 = param_1 + 1;
        iStack_20 = 1;
        iVar8 = param_4 + -1;
        if (bVar4 == 0x25) goto LAB_00189794;
LAB_00189717:
        iVar15 = iVar8;
        if ((byte)(bVar4 - 0x20) < 0x5f) goto LAB_00189805;
LAB_00189723:
        if (pbStack_24 != (byte *)0x0) {
          bVar2 = *pbStack_24;
          pbVar14 = pbStack_24;
          pbVar11 = pbStack_24;
          while (bVar2 != 0) {
            if (bVar4 == bVar2) {
              uVar5 = *(ushort *)(pbVar14 + 2);
              goto LAB_00189766;
            }
            pbVar11 = pbVar11 + 4;
            pbVar14 = pbVar14 + 4;
            bVar2 = *pbVar11;
          }
        }
        uVar5 = 0xfffd;
LAB_00189766:
        *param_2 = uVar5;
        param_2 = param_2 + 1;
        if (0 < iVar15) {
          do {
            bVar4 = *param_1;
            param_1 = param_1 + 1;
            iStack_20 = iStack_20 + 1;
            iVar8 = iVar15 + -1;
            param_4 = iVar15;
            if (bVar4 != 0x25) goto LAB_00189717;
LAB_00189794:
            iVar15 = iVar8;
            if (iVar15 < 2) {
              uVar9 = func_0x0000a930(
                                     "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStringEncoding.cpp"
                                     );
              uVar10 = FUN_00033b90("GNAssertionException");
              FUN_0000bfd6(uVar10,"Assertion failed in line %d of %s: %s.",0x165,uVar9,
                           "byteLength > 1");
            }
            bVar4 = param_1[1];
            bVar2 = *param_1;
            if (((((byte)(bVar2 - 0x30) < 10) || ((byte)(bVar2 + 0x9f) < 6)) ||
                ((byte)(bVar2 + 0xbf) < 6)) &&
               ((((byte)(bVar4 - 0x30) < 10 || ((byte)(bVar4 + 0x9f) < 6)) ||
                ((byte)(bVar4 + 0xbf) < 6)))) {
              if ((byte)(bVar2 - 0x30) < 10) {
                cVar3 = bVar2 - 0x30;
              }
              else if (((byte)(bVar2 + 0xbf) < 6) || ((byte)(bVar2 + 0x9f) < 6)) {
                cVar3 = bVar2 - 0x37;
              }
              else {
                cVar3 = '\0';
              }
              if ((byte)(bVar4 - 0x30) < 10) {
                bVar4 = bVar4 - 0x30;
              }
              else if (((byte)(bVar4 + 0xbf) < 6) || ((byte)(bVar4 + 0x9f) < 6)) {
                bVar4 = bVar4 - 0x37;
              }
              else {
                bVar4 = 0;
              }
              bVar4 = bVar4 | cVar3 << 4;
              param_1 = param_1 + 2;
              iVar15 = param_4 + -3;
              if (0x5e < (byte)(bVar4 - 0x20)) goto LAB_00189723;
            }
            else {
              bVar4 = 0x25;
            }
LAB_00189805:
            *param_2 = (ushort)bVar4;
            param_2 = param_2 + 1;
            if (iVar15 < 1) break;
          } while( true );
        }
      }
      *param_2 = 0;
      return iStack_20;
    }
    if (param_3 == (undefined *)0x3e8) {
      pbVar14 = param_1 + param_4;
      puVar1 = param_2 + param_4;
      if (param_1 < pbVar14) {
        uVar12 = (uint)*param_1;
        uStack_26 = (ushort)(char)(&UNK_00365140)[uVar12];
        uVar6 = (uint)uStack_26;
        if (pbVar14 <= param_1 + uVar6) {
          return 0;
        }
        iStack_20 = 0;
        do {
          uVar7 = uVar6 + 1;
          pbVar11 = param_1 + uVar7;
          bVar4 = (byte)uVar12;
          if (uVar7 == 2) {
LAB_001896a7:
            bVar2 = pbVar11[-1];
            if (0xbf < bVar2) {
              return 0;
            }
            if (bVar4 == 0xf0) {
              if (bVar2 < 0x90) {
                return 0;
              }
            }
            else if (bVar4 == 0xf4) {
              if (0x8f < bVar2) {
                return 0;
              }
            }
            else if (bVar4 == 0xe0) {
              if (bVar2 < 0xa0) {
                return 0;
              }
            }
            else if (-1 < (char)bVar2) {
              return 0;
            }
          }
          else {
            if (2 < uVar7) {
              if (uVar7 != 3) {
                if (uVar7 != 4) {
                  return 0;
                }
                pbVar11 = param_1 + 3;
                if (-1 < (char)param_1[3]) {
                  return 0;
                }
                if (0xbf < param_1[3]) {
                  return 0;
                }
              }
              pbVar11 = pbVar11 + -1;
              if (-1 < (char)*pbVar11) {
                return 0;
              }
              if (0xbf < *pbVar11) {
                return 0;
              }
              goto LAB_001896a7;
            }
            if (uVar7 != 1) {
              return 0;
            }
          }
          if ((byte)(bVar4 + 0x80) < 0x42) {
            return 0;
          }
          if (0xf4 < bVar4) {
            return 0;
          }
          if (uStack_26 == 1) {
            iVar8 = 0;
LAB_001899a8:
            bVar4 = *param_1;
            param_1 = param_1 + 1;
            iVar8 = (iVar8 + (uint)bVar4) * 0x40;
LAB_00189998:
            iVar8 = iVar8 + (uint)*param_1;
            param_1 = param_1 + 1;
          }
          else {
            if (uStack_26 == 0) {
              iVar8 = 0;
              goto LAB_00189998;
            }
            if (uStack_26 == 2) {
              iVar8 = 0;
LAB_001899b7:
              bVar4 = *param_1;
              param_1 = param_1 + 1;
              iVar8 = (iVar8 + (uint)bVar4) * 0x40;
              goto LAB_001899a8;
            }
            if (uStack_26 == 3) {
              param_1 = param_1 + 1;
              iVar8 = uVar12 << 6;
              goto LAB_001899b7;
            }
            iVar8 = 0;
          }
          puVar13 = (undefined *)(iVar8 - *(int *)(&UNK_00365128 + uVar6 * 4));
          if (puVar1 <= param_2) {
            return 0;
          }
          if (puVar13 < (undefined *)0x10000) {
            *param_2 = (ushort)puVar13;
            param_2 = param_2 + 1;
            iStack_20 = iStack_20 + 1;
          }
          else if (puVar13 < &UNK_00110000) {
            if (puVar1 <= param_2 + 1) {
              return 0;
            }
            *param_2 = (short)((uint)(puVar13 + -0x10000) >> 10) + 0xd800;
            param_2[1] = ((ushort)(puVar13 + -0x10000) & 0x3ff) + 0xdc00;
            param_2 = param_2 + 2;
            iStack_20 = iStack_20 + 2;
          }
          else {
            *param_2 = 0xfffd;
            param_2 = param_2 + 1;
            iStack_20 = iStack_20 + 1;
          }
          if (pbVar14 <= param_1) goto LAB_00189597;
          uVar12 = (uint)*param_1;
          uStack_26 = (ushort)(char)(&UNK_00365140)[uVar12];
          uVar6 = (uint)uStack_26;
          if (pbVar14 <= param_1 + uVar6) {
            return 0;
          }
        } while( true );
      }
      iStack_20 = 0;
LAB_00189597:
      *param_2 = 0;
      return iStack_20;
    }
  }
  if (param_4 < 1) {
    iStack_20 = 0;
  }
  else {
    iStack_38 = 0;
    do {
      bVar4 = *param_1;
      if ((byte)(bVar4 - 0x20) < 0x5f) {
        *param_2 = (ushort)bVar4;
      }
      else {
        if (pbStack_3c != (byte *)0x0) {
          bVar2 = *pbStack_3c;
          pbVar14 = pbStack_3c;
          pbVar11 = pbStack_3c;
          while (bVar2 != 0) {
            if (bVar4 == bVar2) {
              uVar5 = *(ushort *)(pbVar14 + 2);
              goto LAB_00189437;
            }
            pbVar11 = pbVar11 + 4;
            pbVar14 = pbVar14 + 4;
            bVar2 = *pbVar11;
          }
        }
        uVar5 = 0xfffd;
LAB_00189437:
        *param_2 = uVar5;
      }
      param_2 = param_2 + 1;
      iStack_38 = iStack_38 + 1;
      param_1 = param_1 + 1;
    } while (param_4 != iStack_38);
    iStack_20 = param_4;
  }
  *param_2 = 0;
  return iStack_20;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00034c02(int param_1,int *param_2)

{
  code *pcVar1;
  undefined1 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  int iStack_34;
  uint uStack_24;
  short asStack_1e [7];
  
  pcVar1 = *(code **)(*param_2 + 0x270);
  uVar3 = FUN_00033b90("GNString");
  iVar4 = (*pcVar1)(param_2,uVar3);
  if (iVar4 < 2) {
    uVar3 = (**(code **)(*param_2 + 0x210))(param_2,&uStack_24);
    *(undefined4 *)(param_1 + 0xc) = uVar3;
    *(undefined1 *)(param_1 + 0x18) = 1;
    uVar2 = (**(code **)(*param_2 + 0x1e4))(param_2);
    *(undefined1 *)(param_1 + 0x18) = uVar2;
    return;
  }
  iVar4 = (**(code **)(*param_2 + 0x1ec))(param_2);
  if (iVar4 == 0) {
    uVar3 = (**(code **)(*param_2 + 0x210))(param_2,&uStack_24);
    *(undefined4 *)(param_1 + 0xc) = uVar3;
    *(undefined1 *)(param_1 + 0x18) = 1;
    uVar2 = (**(code **)(*param_2 + 0x1e4))(param_2);
    *(undefined1 *)(param_1 + 0x18) = uVar2;
    return;
  }
  if (iVar4 == 5) {
    (**(code **)(*param_2 + 0x20c))(param_2,asStack_1e,2);
    iVar4 = (**(code **)(*param_2 + 0x210))(param_2,&uStack_24);
    *(int *)(param_1 + 0x10) = iVar4;
    uStack_24 = (uStack_24 >> 1) - 1;
    if ((asStack_1e[0] == -2) && (0 < (int)uStack_24)) {
      iStack_34 = 0;
      do {
        func_0x0000a824(iVar4);
        iStack_34 = iStack_34 + 1;
        iVar4 = iVar4 + 2;
      } while (iStack_34 < (int)uStack_24);
    }
    *(uint *)(param_1 + 0x14) = uStack_24;
    if (*(int *)(param_1 + 0xc) != 0) {
      FUN_0000b122(*(int *)(param_1 + 0xc));
    }
    *(undefined4 *)(param_1 + 0xc) = 0;
    *(undefined1 *)(param_1 + 0x18) = 1;
    uVar2 = (**(code **)(*param_2 + 0x1e4))(param_2);
    *(undefined1 *)(param_1 + 0x18) = uVar2;
    return;
  }
  uVar3 = (**(code **)(*param_2 + 0x210))(param_2,&uStack_24);
  uStack_24 = uStack_24 - 1;
  uVar5 = FUN_0000aecc(uStack_24 * 4 + 4);
  *(undefined4 *)(param_1 + 0x10) = uVar5;
  uStack_24 = FUN_00189376(uVar3,uVar5,iVar4,uStack_24);
  *(undefined2 *)(*(int *)(param_1 + 0x10) + uStack_24 * 2) = 0;
  *(uint *)(param_1 + 0x14) = uStack_24;
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_0000b122(*(int *)(param_1 + 0xc));
  }
  *(undefined4 *)(param_1 + 0xc) = 0;
  FUN_0000b122(uVar3);
  *(undefined1 *)(param_1 + 0x18) = 1;
  uVar2 = (**(code **)(*param_2 + 0x1e4))(param_2);
  *(undefined1 *)(param_1 + 0x18) = uVar2;
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000204a2(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNClassDescription.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x28a,uVar1,"this != 0");
  }
  if (param_2 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNClassDescription.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x28a,uVar1,"relationship");
  }
  if (*(int *)(param_1 + 0x24) == 0) {
    uVar1 = __Znwm(0x20);
    FUN_00029d44(uVar1);
    uVar1 = FUN_0002dfa6(uVar1);
    *(undefined4 *)(param_1 + 0x24) = uVar1;
    FUN_0002bb40(*(undefined4 *)(param_1 + 0x24),param_2);
  }
  else {
    FUN_0002bb40(*(undefined4 *)(param_1 + 0x24),param_2);
  }
  *(int *)(param_2 + 0x14) = param_1;
  return;
}


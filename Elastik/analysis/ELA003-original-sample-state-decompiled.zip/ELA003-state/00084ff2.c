
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00084ff2(int param_1,int *param_2)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  float *pfVar5;
  double *pdVar6;
  undefined8 *puVar7;
  longdouble lVar8;
  undefined8 uVar9;
  
  pcVar1 = *(code **)(*param_2 + 0x270);
  uVar3 = FUN_00033b90("GNNumber");
  iVar4 = (*pcVar1)(param_2,uVar3);
  cVar2 = (**(code **)(*param_2 + 0x1e8))(param_2);
  *(char *)(param_1 + 0x10) = cVar2;
  if (iVar4 < 2) {
    if (cVar2 == 'f') {
      uVar3 = FUN_0000aecc(4);
      *(undefined4 *)(param_1 + 0xc) = uVar3;
      (**(code **)(*param_2 + 0x20c))(param_2,uVar3,4);
    }
    if (*(char *)(param_1 + 0x10) == 'd') {
      uVar3 = FUN_0000aecc(8);
      *(undefined4 *)(param_1 + 0xc) = uVar3;
      (**(code **)(*param_2 + 0x20c))(param_2,uVar3,8);
    }
    if (*(char *)(param_1 + 0x10) == 'l') {
      uVar3 = FUN_0000aecc(8);
      *(undefined4 *)(param_1 + 0xc) = uVar3;
      (**(code **)(*param_2 + 0x20c))(param_2,uVar3,8);
    }
    goto LAB_0008505b;
  }
  if (cVar2 == 'f') {
    pfVar5 = (float *)FUN_0000aecc(4);
    *(float **)(param_1 + 0xc) = pfVar5;
    lVar8 = (longdouble)(**(code **)(*param_2 + 0x1f0))(param_2);
    *pfVar5 = (float)lVar8;
    if (*(char *)(param_1 + 0x10) == 'd') goto LAB_0008511b;
LAB_0008504f:
    cVar2 = *(char *)(param_1 + 0x10);
  }
  else {
    if (*(char *)(param_1 + 0x10) != 'd') goto LAB_0008504f;
LAB_0008511b:
    pdVar6 = (double *)FUN_0000aecc(8);
    *(double **)(param_1 + 0xc) = pdVar6;
    lVar8 = (longdouble)(**(code **)(*param_2 + 500))(param_2);
    *pdVar6 = (double)lVar8;
    cVar2 = *(char *)(param_1 + 0x10);
  }
  if (cVar2 == 'l') {
    puVar7 = (undefined8 *)FUN_0000aecc(8);
    *(undefined8 **)(param_1 + 0xc) = puVar7;
    uVar9 = (**(code **)(*param_2 + 0x1f8))(param_2);
    *puVar7 = uVar9;
  }
LAB_0008505b:
  if (*(char *)(param_1 + 0x10) == 'i') {
    uVar3 = (**(code **)(*param_2 + 0x1ec))(param_2);
    *(undefined4 *)(param_1 + 0xc) = uVar3;
  }
  if (*(char *)(param_1 + 0x10) != 'b') {
    return;
  }
  cVar2 = (**(code **)(*param_2 + 0x1e4))(param_2);
  *(int *)(param_1 + 0xc) = (int)cVar2;
  return;
}


000fe3a4  55  PUSH EBP
000fe3a5  89e5  MOV EBP,ESP
000fe3a7  57  PUSH EDI
000fe3a8  56  PUSH ESI
000fe3a9  53  PUSH EBX
000fe3aa  83ec3c  SUB ESP,0x3c
000fe3ad  e86a6c1e00  CALL 0x002e501c
000fe3b2  c745e000000000  MOV dword ptr [EBP + -0x20],0x0
000fe3b9  c745e400000000  MOV dword ptr [EBP + -0x1c],0x0
000fe3c0  c745d800000000  MOV dword ptr [EBP + -0x28],0x0
000fe3c7  c745dc00000000  MOV dword ptr [EBP + -0x24],0x0
000fe3ce  c745d000000000  MOV dword ptr [EBP + -0x30],0x0
000fe3d5  c745d400000000  MOV dword ptr [EBP + -0x2c],0x0
000fe3dc  c7042440000000  MOV dword ptr [ESP],0x40
000fe3e3  e8bdbc2d00  CALL 0x003da0a5
000fe3e8  89c7  MOV EDI,EAX
000fe3ea  890424  MOV dword ptr [ESP],EAX
000fe3ed  e86e26faff  CALL 0x000a0a60
000fe3f2  8d83d6072800  LEA EAX,[EBX + 0x2807d6]
000fe3f8  8907  MOV dword ptr [EDI],EAX
000fe3fa  c7471c00000000  MOV dword ptr [EDI + 0x1c],0x0
000fe401  c7472000000000  MOV dword ptr [EDI + 0x20],0x0
000fe408  c7472400000000  MOV dword ptr [EDI + 0x24],0x0
000fe40f  c745e401000000  MOV dword ptr [EBP + -0x1c],0x1
000fe416  c745e000000000  MOV dword ptr [EBP + -0x20],0x0
000fe41d  8b45e0  MOV EAX,dword ptr [EBP + -0x20]
000fe420  8b55e4  MOV EDX,dword ptr [EBP + -0x1c]
000fe423  894728  MOV dword ptr [EDI + 0x28],EAX
000fe426  89572c  MOV dword ptr [EDI + 0x2c],EDX
000fe429  c745dc01000000  MOV dword ptr [EBP + -0x24],0x1
000fe430  c745d800000000  MOV dword ptr [EBP + -0x28],0x0
000fe437  8b45d8  MOV EAX,dword ptr [EBP + -0x28]
000fe43a  8b55dc  MOV EDX,dword ptr [EBP + -0x24]
000fe43d  894730  MOV dword ptr [EDI + 0x30],EAX
000fe440  895734  MOV dword ptr [EDI + 0x34],EDX
000fe443  c6473800  MOV byte ptr [EDI + 0x38],0x0
000fe447  c6473900  MOV byte ptr [EDI + 0x39],0x0
000fe44b  c6473a01  MOV byte ptr [EDI + 0x3a],0x1
000fe44f  c6473b00  MOV byte ptr [EDI + 0x3b],0x0
000fe453  c6473c01  MOV byte ptr [EDI + 0x3c],0x1
000fe457  c6473d00  MOV byte ptr [EDI + 0x3d],0x0
000fe45b  893c24  MOV dword ptr [ESP],EDI
000fe45e  e843fbf2ff  CALL 0x0002dfa6
000fe463  8b10  MOV EDX,dword ptr [EAX]
000fe465  890424  MOV dword ptr [ESP],EAX
000fe468  ff5248  CALL dword ptr [EDX + 0x48]
000fe46b  89c6  MOV ESI,EAX
000fe46d  8b5024  MOV EDX,dword ptr [EAX + 0x24]
000fe470  39550c  CMP dword ptr [EBP + 0xc],EDX
000fe473  741e  JZ 0x000fe493
000fe475  85d2  TEST EDX,EDX
000fe477  7408  JZ 0x000fe481
000fe479  8b02  MOV EAX,dword ptr [EDX]
000fe47b  891424  MOV dword ptr [ESP],EDX
000fe47e  ff5044  CALL dword ptr [EAX + 0x44]
000fe481  8b550c  MOV EDX,dword ptr [EBP + 0xc]
000fe484  895624  MOV dword ptr [ESI + 0x24],EDX
000fe487  85d2  TEST EDX,EDX
000fe489  7408  JZ 0x000fe493
000fe48b  8b02  MOV EAX,dword ptr [EDX]
000fe48d  891424  MOV dword ptr [ESP],EDX
000fe490  ff5040  CALL dword ptr [EAX + 0x40]
000fe493  c745d401000000  MOV dword ptr [EBP + -0x2c],0x1
000fe49a  c745d000000000  MOV dword ptr [EBP + -0x30],0x0
000fe4a1  8b45d0  MOV EAX,dword ptr [EBP + -0x30]
000fe4a4  8b55d4  MOV EDX,dword ptr [EBP + -0x2c]
000fe4a7  894630  MOV dword ptr [ESI + 0x30],EAX
000fe4aa  895634  MOV dword ptr [ESI + 0x34],EDX
000fe4ad  8b4508  MOV EAX,dword ptr [EBP + 0x8]
000fe4b0  89442404  MOV dword ptr [ESP + 0x4],EAX
000fe4b4  893424  MOV dword ptr [ESP],ESI
000fe4b7  e800e3ffff  CALL 0x000fc7bc
000fe4bc  89f0  MOV EAX,ESI
000fe4be  83c43c  ADD ESP,0x3c
000fe4c1  5b  POP EBX
000fe4c2  5e  POP ESI
000fe4c3  5f  POP EDI
000fe4c4  5d  POP EBP
000fe4c5  c3  RET

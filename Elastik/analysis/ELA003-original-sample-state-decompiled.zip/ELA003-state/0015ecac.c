
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0015ecac(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  
  if (iRam003d47d4 != 0) {
    return iRam003d47d4;
  }
  uVar1 = FUN_00033b90("GNObject");
  uVar2 = FUN_00033b90("ETProgram");
  iVar3 = FUN_0001fe74(uVar2,&UNK_001601f0,uVar1);
  uStack_28 = 0xc;
  uStack_24 = 1;
  iRam003d47d4 = iVar3;
  uStack_20 = FUN_00033b90("_autoselect");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_001000ae(0x62);
  uVar2 = FUN_00033b90("_autoselect");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000aa362(uVar2,uVar1);
  FUN_0002035a(iVar3,uVar1);
  uStack_28 = 0x18;
  uStack_24 = 4;
  uStack_20 = FUN_00033b90("_automapMode");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_001000ae(0x69);
  uVar2 = FUN_00033b90("_automapMode");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000aa362(uVar2,uVar1);
  FUN_0002035a(iVar3,uVar1);
  uStack_28 = 0x30;
  uStack_24 = 4;
  uStack_20 = FUN_00033b90("_algorithm");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_001000ae(0x69);
  uVar2 = FUN_00033b90("_algorithm");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000aa362(uVar2,uVar1);
  FUN_0002035a(iVar3,uVar1);
  uStack_28 = 0x34;
  uStack_24 = 4;
  uStack_20 = FUN_00033b90("_formattedTempo");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_00033b90("GNString");
  uVar1 = FUN_00100532(uVar1);
  uVar2 = FUN_00033b90("_formattedTempo");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000aa362(uVar2,uVar1);
  FUN_0002035a(iVar3,uVar1);
  uStack_28 = 0x1c;
  uStack_24 = 4;
  uStack_20 = FUN_00033b90("_keyMappings");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_00033b90("GNList");
  uVar2 = FUN_00033b90("_keyMappings");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000fe4d8(uVar2,uVar1);
  FUN_000204a2(iVar3,uVar1);
  uStack_28 = 0x20;
  uStack_24 = 4;
  uStack_20 = FUN_00033b90("_automationParameters");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_00033b90("ETAutomationParameter");
  uVar2 = FUN_00033b90("_automationParameters");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000fe4d8(uVar2,uVar1);
  FUN_000204a2(iVar3,uVar1);
  uStack_28 = 0x38;
  uStack_24 = 1;
  uStack_20 = FUN_00033b90("_syncUserTempoToFileTempo");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_001000ae(0x69);
  uVar2 = FUN_00033b90("_syncUserTempoToFileTempo");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000aa362(uVar2,uVar1);
  FUN_0002035a(iVar3,uVar1);
  return iRam003d47d4;
}


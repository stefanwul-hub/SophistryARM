
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00029f66(int param_1,int *param_2)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iStack_20;
  
  FUN_0002e182(param_1,param_2);
  cVar2 = (**(code **)(*param_2 + 0x1ac))(param_2);
  if (cVar2 == '\0') {
    pcVar1 = *(code **)(*param_2 + 0x274);
    uVar3 = FUN_00033b90("GNList");
    (*pcVar1)(param_2,uVar3,3);
    (**(code **)(*param_2 + 0x1b4))(param_2,(int)*(char *)(param_1 + 0x18));
    (**(code **)(*param_2 + 0x1b4))(param_2,(int)*(char *)(param_1 + 0x19));
    (**(code **)(*param_2 + 0x1bc))(param_2,*(undefined4 *)(param_1 + 0x10));
    if (0 < *(int *)(param_1 + 0x10)) {
      iVar4 = 0;
      do {
        (**(code **)(*param_2 + 0x1d8))
                  (param_2,*(undefined4 *)(*(int *)(param_1 + 0xc) + iVar4 * 4));
        iVar4 = iVar4 + 1;
      } while (iVar4 < *(int *)(param_1 + 0x10));
      return;
    }
  }
  else {
    pcVar1 = *(code **)(*param_2 + 0x21c);
    uVar3 = FUN_00033b90("count");
    (*pcVar1)(param_2,*(undefined4 *)(param_1 + 0x10),uVar3);
    if (0 < *(int *)(param_1 + 0x10)) {
      iStack_20 = 0;
      do {
        pcVar1 = *(code **)(*param_2 + 0x234);
        uVar3 = FUN_0003dd2a("%i",iStack_20);
        (*pcVar1)(param_2,*(undefined4 *)(*(int *)(param_1 + 0xc) + iStack_20 * 4),uVar3);
        iStack_20 = iStack_20 + 1;
      } while (iStack_20 < *(int *)(param_1 + 0x10));
      return;
    }
  }
  return;
}


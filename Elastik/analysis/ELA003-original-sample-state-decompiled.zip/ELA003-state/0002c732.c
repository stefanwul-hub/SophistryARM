
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0002c732(int param_1)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int *piStack_20;
  
  puVar2 = (undefined4 *)__Znwm(0x20);
  func_0x0002dc66(puVar2);
  *puVar2 = &UNK_0036e8e8;
  puVar2[3] = 0;
  puVar2[4] = 0;
  puVar2[5] = 0;
  *(undefined1 *)(puVar2 + 6) = 0;
  *(undefined1 *)((int)puVar2 + 0x19) = 0;
  puVar2[7] = 0;
  uVar3 = FUN_0002dfa6(puVar2);
  piStack_20 = (int *)&stack0x00000008;
  if (param_1 == 0) {
    return uVar3;
  }
  do {
    FUN_0002bb40(uVar3,param_1);
    param_1 = *piStack_20;
    while( true ) {
      if (param_1 == 0) {
        return uVar3;
      }
      piStack_20 = piStack_20 + 1;
      cVar1 = func_0x0002e058(param_1);
      if (cVar1 != '\0') break;
      param_1 = *piStack_20;
    }
  } while( true );
}


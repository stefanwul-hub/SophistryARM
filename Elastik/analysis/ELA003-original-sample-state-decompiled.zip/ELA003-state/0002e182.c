
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002e182(int *param_1,int *param_2)

{
  char cVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 uVar4;
  
  cVar1 = (**(code **)(*param_2 + 0x1ac))(param_2);
  if (cVar1 != '\0') {
    cVar1 = (**(code **)(*param_1 + 0x164))(param_1);
    if (cVar1 != '\0') {
      (**(code **)(*param_1 + 0x188))(param_1,param_2);
      uVar4 = FUN_00033b90("GNCodingDoneSignal");
      puVar2 = (undefined4 *)__Znwm(0x18);
      func_0x0002dc66(puVar2);
      *puVar2 = &UNK_0036ce88;
      puVar2[3] = 0;
      puVar2[4] = 0;
      puVar2[5] = 0;
      piVar3 = (int *)FUN_0002dfa6(puVar2);
      piVar3 = (int *)(**(code **)(*piVar3 + 0x48))(piVar3);
      (**(code **)(*piVar3 + 0x1a4))(piVar3,uVar4,0,0);
                    /* WARNING: Could not recover jumptable at 0x0000bfc1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 0x1a8))();
      return;
    }
  }
  return;
}


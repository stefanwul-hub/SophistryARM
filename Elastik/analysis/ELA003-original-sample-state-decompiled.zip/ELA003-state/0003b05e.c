
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0003b05e(int param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  char *pcVar6;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x10f,uVar2,"this != 0");
  }
  iVar5 = *(int *)(param_1 + 0x14);
  if (iVar5 == -1) {
    if (*(char **)(param_1 + 0xc) == (char *)0x0) {
      iVar5 = 0;
    }
    else {
      uVar4 = 0xffffffff;
      pcVar6 = *(char **)(param_1 + 0xc);
      do {
        if (uVar4 == 0) break;
        uVar4 = uVar4 - 1;
        cVar1 = *pcVar6;
        pcVar6 = pcVar6 + 1;
      } while (cVar1 != '\0');
      iVar5 = ~uVar4 - 1;
    }
  }
  func_0x0003a042(param_1,param_2,iVar5 - param_2);
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00100532(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  if (iRam003d45f8 == 0) {
    uVar2 = __Znwm(0x18);
    FUN_000630b6(uVar2);
    iRam003d45f8 = FUN_0002dfa6(uVar2);
    iVar1 = FUN_00064626(iRam003d45f8,param_1);
  }
  else {
    iVar1 = FUN_00064626(iRam003d45f8,param_1);
  }
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = func_0x001003f6(param_1,param_1);
  FUN_00066284(iRam003d45f8,iVar1,param_1);
  return iVar1;
}


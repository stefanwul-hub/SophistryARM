001afb00  55  PUSH EBP
001afb01  89e5  MOV EBP,ESP
001afb03  57  PUSH EDI
001afb04  56  PUSH ESI
001afb05  53  PUSH EBX
001afb06  83ec3c  SUB ESP,0x3c
001afb09  e80e551300  CALL 0x002e501c
001afb0e  8b7d1c  MOV EDI,dword ptr [EBP + 0x1c]
001afb11  f20f104520  MOVSD XMM0,qword ptr [EBP + 0x20]
001afb16  f20f1145e0  MOVSD qword ptr [EBP + -0x20],XMM0
001afb1b  f20f104528  MOVSD XMM0,qword ptr [EBP + 0x28]
001afb20  f20f1145d8  MOVSD qword ptr [EBP + -0x28],XMM0
001afb25  0fbe833a4f2200  MOVSX EAX,byte ptr [EBX + 0x224f3a]
001afb2c  89442414  MOV dword ptr [ESP + 0x14],EAX
001afb30  897c2410  MOV dword ptr [ESP + 0x10],EDI
001afb34  8b4518  MOV EAX,dword ptr [EBP + 0x18]
001afb37  8944240c  MOV dword ptr [ESP + 0xc],EAX
001afb3b  8b4514  MOV EAX,dword ptr [EBP + 0x14]
001afb3e  89442408  MOV dword ptr [ESP + 0x8],EAX
001afb42  8b4510  MOV EAX,dword ptr [EBP + 0x10]
001afb45  89442404  MOV dword ptr [ESP + 0x4],EAX
001afb49  8b5508  MOV EDX,dword ptr [EBP + 0x8]
001afb4c  891424  MOV dword ptr [ESP],EDX
001afb4f  e88ef9ffff  CALL 0x001af4e2
001afb54  89c6  MOV ESI,EAX
001afb56  80bb3a4f220000  CMP byte ptr [EBX + 0x224f3a],0x0
001afb5d  7533  JNZ 0x001afb92
001afb5f  f20f1045d8  MOVSD XMM0,qword ptr [EBP + -0x28]
001afb64  f20f11442418  MOVSD qword ptr [ESP + 0x18],XMM0
001afb6a  f20f1045e0  MOVSD XMM0,qword ptr [EBP + -0x20]
001afb6f  f20f11442410  MOVSD qword ptr [ESP + 0x10],XMM0
001afb75  897c240c  MOV dword ptr [ESP + 0xc],EDI
001afb79  8b4518  MOV EAX,dword ptr [EBP + 0x18]
001afb7c  89442408  MOV dword ptr [ESP + 0x8],EAX
001afb80  8b550c  MOV EDX,dword ptr [EBP + 0xc]
001afb83  89542404  MOV dword ptr [ESP + 0x4],EDX
001afb87  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001afb8a  890424  MOV dword ptr [ESP],EAX
001afb8d  e85ef1ffff  CALL 0x001aecf0
001afb92  89f2  MOV EDX,ESI
001afb94  0fbec2  MOVSX EAX,DL
001afb97  83c43c  ADD ESP,0x3c
001afb9a  5b  POP EBX
001afb9b  5e  POP ESI
001afb9c  5f  POP EDI
001afb9d  5d  POP EBP
001afb9e  c3  RET

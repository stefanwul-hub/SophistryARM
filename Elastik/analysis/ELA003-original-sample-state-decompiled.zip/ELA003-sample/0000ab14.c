
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0000ab14(char *param_1)

{
  char cVar1;
  char *pcVar2;
  undefined4 uVar3;
  uint uVar4;
  
  if (cRam003d3ef8 == '\0') {
    uVar4 = 0xffffffff;
    pcVar2 = param_1;
    do {
      if (uVar4 == 0) break;
      uVar4 = uVar4 - 1;
      cVar1 = *pcVar2;
      pcVar2 = pcVar2 + 1;
    } while (cVar1 != '\0');
    uVar4 = ~uVar4 - 1;
    if (uVar4 < 0x2000) {
      pcVar2 = (char *)FUN_0000aecc(uVar4 * 3 + 0x400);
      _vsprintf(pcVar2,param_1,&stack0x00000008);
      param_1 = pcVar2;
    }
    if (piRam003d3f0c == (int *)0x0) {
      uVar3 = __Znwm(0x38);
      func_0x0006f04a(uVar3);
      piRam003d3f0c = (int *)FUN_0002dfa6(uVar3);
    }
    (**(code **)(*piRam003d3f0c + 0x1a4))(piRam003d3f0c);
    _puts(param_1);
    (**(code **)(*piRam003d3f0c + 0x1ac))(piRam003d3f0c);
    if (uVar4 < 0x2000) {
      if (param_1 != (char *)0x0) {
        if (cRam003d3f09 == '\0') {
          cRam003d3f09 = 1;
          if (iRam003d3ee8 != 0) {
            func_0x000424ac(iRam003d3ee8,param_1);
          }
          cRam003d3f09 = '\0';
        }
        _free(param_1);
        return;
      }
      FUN_0000ab14("GNFree(0)");
    }
  }
  return;
}


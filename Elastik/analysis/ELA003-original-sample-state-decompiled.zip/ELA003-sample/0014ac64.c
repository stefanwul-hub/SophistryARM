
int FUN_0014ac64(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x8c) != 0) {
    iVar1 = func_0x001f0b58(*(int *)(param_1 + 0x8c));
    if (iVar1 != 0) {
      if ((*(int *)(iVar1 + 0x24) == 0) && (*(int **)(iVar1 + 0x54) != (int *)0x0)) {
                    /* WARNING: Could not recover jumptable at 0x001ab7e0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        iVar1 = (**(code **)(**(int **)(iVar1 + 0x54) + 0x1bc))();
        return iVar1;
      }
      return *(int *)(iVar1 + 0x24);
    }
  }
  return 0;
}


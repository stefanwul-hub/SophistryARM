
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00152664(int param_1,float *param_2,int param_3,int param_4,int param_5,undefined4 *param_6,
                int *param_7)

{
  int iVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  float *pfVar10;
  float *pfVar11;
  int iVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  int iStack_28;
  
  func_0x0014a466(*(undefined4 *)(param_1 + 0x98));
  if (param_7 == (int *)0x0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/Elastik/Projects/XCode/../../Source/ETInstrumentVoice.cpp"
                           );
    uVar9 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar9,"Assertion failed in line %d of %s: %s.",0x2a0,uVar4,"readedRange");
  }
  iVar8 = *(int *)(param_1 + 0x9c);
  iVar12 = *(int *)(param_1 + 0xa0);
  if (*(int *)(param_1 + 0x98) == 0) {
    return -1;
  }
  uVar4 = func_0x0014a466(*(int *)(param_1 + 0x98));
  iVar5 = func_0x00149f34(*(undefined4 *)(param_1 + 0x98));
  if (iVar5 != *(int *)(param_1 + 0xb0)) {
    *(int *)(param_1 + 0xb0) = iVar5;
  }
  iVar6 = FUN_0014ac64(*(undefined4 *)(param_1 + 0x98));
  iVar7 = param_4;
  if (iVar5 == 0) {
    if (iVar12 < 0x65) {
      iStack_28 = FUN_0014ac64(*(undefined4 *)(param_1 + 0x98));
      iStack_28 = iStack_28 - (100 - iVar12);
    }
    else {
      iStack_28 = iVar12 + -100;
    }
  }
  else {
    if (iVar8 < 0x65) {
      iStack_28 = FUN_0014ac64(*(undefined4 *)(param_1 + 0x98));
      iStack_28 = iStack_28 - (100 - iVar8);
    }
    else {
      iStack_28 = iVar8 + -100;
    }
    if ((0 < iVar5) && (*(int *)(param_1 + 0x98) != 0)) {
      iVar1 = *(int *)(param_1 + 0x9c);
      iVar2 = *(int *)(param_1 + 0xa0);
      if (iVar1 < iVar2) {
LAB_00152baa:
        iVar7 = (param_4 - param_5) + 1;
        if (iVar7 < iVar1) {
          param_5 = (param_4 - iVar1) + 1;
          iVar7 = iVar1;
        }
      }
      else if (iVar2 < iVar1) {
        if (iVar2 < param_4) {
          if (iVar1 <= param_4) goto LAB_00152baa;
        }
        else {
          iVar7 = (param_4 - param_5) + 1;
          if (iVar7 < 0) {
            param_5 = param_4 + 1;
            iVar7 = 0;
          }
        }
      }
      else {
        uVar9 = FUN_00033b90("GNInternalInconsistencyException");
        FUN_0000bfd6(uVar9,
                     "ETInstrumentVoice::getBackwardNextChunkStartSample failed -> startSample == stopSample"
                    );
      }
    }
  }
  *param_7 = iVar7;
  param_7[1] = param_5;
  if (iVar8 < iVar12) {
LAB_0015290f:
    if (iVar12 + 1 < iVar7 + param_5) {
      param_7[1] = (iVar12 - iVar7) + 1;
    }
  }
  else if (iVar12 < iVar8) {
    if (iVar7 <= iVar12) goto LAB_0015290f;
    if ((iVar8 <= iVar7) && (iVar6 < iVar7 + param_5)) {
      param_7[1] = iVar6 - iVar7;
    }
  }
  cVar3 = FUN_001f0c92(uVar4,param_2,param_3,*param_7,param_7[1],DOUBLE_00364740,DOUBLE_00364740);
  if (cVar3 == '\0') {
    FUN_0000ab14("getSamplesOfChannelForRange failed");
  }
  if ((*(char *)(param_1 + 0x128) != '\0') && (param_3 != 0)) {
    FUN_0000ab14("readed:%d %d-%d %d",iVar5,*param_7,*param_7 + -1 + param_7[1],param_7[1]);
  }
  if (param_6 != (undefined4 *)0x0) {
    uVar4 = FUN_0015197c(param_1,*param_7,param_7[1],iVar5);
    *param_6 = uVar4;
  }
  if (iVar5 != 0) {
    iVar8 = param_7[1] / 2;
    if ((-1 < iVar8) && (0 < iVar8)) {
      pfVar10 = param_2 + param_7[1];
      iVar12 = 1;
      while( true ) {
        fVar14 = param_2[iVar12 + -1];
        param_2[iVar12 + -1] = pfVar10[-1];
        pfVar10[-1] = fVar14;
        pfVar10 = pfVar10 + -1;
        if (iVar8 < iVar12) break;
        iVar12 = iVar12 + 1;
      }
    }
  }
  pfVar10 = (float *)(param_1 + 0x110 + param_3 * 0xc);
  fVar14 = pfVar10[2];
  if (fVar14 != 0.0) {
    fVar15 = pfVar10[1];
    if (param_7[1] < 1) {
      iVar8 = 0;
    }
    else {
      iVar8 = 0;
      pfVar11 = param_2;
      do {
        fVar13 = fVar14 + pfVar10[1];
        pfVar10[1] = fVar13;
        if ((fVar14 <= 0.0) || (fVar13 < *pfVar10)) {
          if ((fVar14 < 0.0) && (fVar14 = *pfVar10, fVar13 <= fVar14)) goto LAB_00152903;
        }
        else {
          fVar14 = *pfVar10;
LAB_00152903:
          pfVar10[1] = fVar14;
          pfVar10[2] = 0.0;
        }
        *pfVar11 = *pfVar11 * pfVar10[1];
        fVar14 = pfVar10[2];
        if (fVar14 == 0.0) break;
        iVar8 = iVar8 + 1;
        pfVar11 = pfVar11 + 1;
      } while (iVar8 < param_7[1]);
    }
    if ((*(char *)(param_1 + 0x128) != '\0') && (param_3 != 0)) {
      FUN_0000ab14("fade in from:%f to:%f from sample:%d to sample:%d",(double)fVar15,
                   (double)pfVar10[1],*param_7,iVar8 + *param_7);
    }
  }
  iVar8 = param_3 * 0xc + 0xf0 + param_1;
  pfVar10 = (float *)(iVar8 + 8);
  iVar12 = func_0x0014a1f4(*(undefined4 *)(param_1 + 0x98));
  if (iVar12 == 0) {
    if ((((iStack_28 < *param_7) || (*param_7 + param_7[1] <= iStack_28)) ||
        (*(float *)(iVar8 + 0x10) != 0.0)) || (NAN(*(float *)(iVar8 + 0x10)))) goto LAB_00152972;
    iVar12 = iStack_28 - *param_7;
    iVar5 = param_3 * 0xc + param_1;
    *(undefined4 *)(iVar5 + 0x100) = 0xbc23d70a;
    *(undefined4 *)(iVar5 + 0xfc) = 0x3f800000;
    *(undefined4 *)(iVar5 + 0xf8) = 0;
    if ((*(char *)(param_1 + 0x128) != '\0') && (param_3 != 0)) {
      FUN_0000ab14("fade out from:%f to:%f from sample:%d to sample:%d",
                   (double)*(float *)(iVar8 + 0xc),(double)*(float *)(iVar8 + 8),iVar12 + *param_7,
                   *param_7 + param_7[1] + -1);
    }
  }
  else {
LAB_00152972:
    iVar12 = 0;
  }
  iVar5 = func_0x0014a1f4(*(undefined4 *)(param_1 + 0x98));
  if ((iVar5 == 0) || ((*(int *)(param_1 + 0xa0) == iVar6 + -1 && (*(int *)(param_1 + 0x9c) == 0))))
  {
LAB_001529de:
    if (*(float *)(iVar8 + 0x10) == 0.0) goto LAB_001529c5;
  }
  else if ((*(float *)(iVar8 + 0x10) == 0.0) && (!NAN(*(float *)(iVar8 + 0x10)))) {
    if ((iStack_28 < *param_7) || (param_7[1] + *param_7 <= iStack_28)) goto LAB_001529c5;
    iVar12 = iStack_28 - *param_7;
    iVar5 = param_1 + param_3 * 0xc;
    *(undefined4 *)(iVar5 + 0x100) = 0xbc23d70a;
    *(undefined4 *)(iVar5 + 0xfc) = 0x3f800000;
    *(undefined4 *)(iVar5 + 0xf8) = 0;
    if ((*(char *)(param_1 + 0x128) != '\0') && (param_3 != 0)) {
      FUN_0000ab14("fade out from:%f to:%f from sample:%d to sample:%d",
                   (double)*(float *)(iVar8 + 0xc),(double)*pfVar10,iVar12 + *param_7,
                   *param_7 + param_7[1] + -1);
    }
    goto LAB_001529de;
  }
  param_2 = param_2 + iVar12;
  if (iVar12 < param_7[1]) {
    fVar14 = *(float *)(iVar8 + 0x10);
    do {
      fVar15 = fVar14 + *(float *)(iVar8 + 0xc);
      *(float *)(iVar8 + 0xc) = fVar15;
      if ((fVar14 <= 0.0) || (fVar15 < *pfVar10)) {
        if ((fVar14 < 0.0) && (fVar14 = *pfVar10, fVar15 <= fVar14)) goto LAB_00152a2e;
      }
      else {
        fVar14 = *pfVar10;
LAB_00152a2e:
        *(float *)(iVar8 + 0xc) = fVar14;
        *(undefined4 *)(iVar8 + 0x10) = 0;
      }
      if (param_3 == 0) {
        do {
          *param_2 = *param_2 * *(float *)(iVar8 + 0xc);
          fVar14 = *(float *)(iVar8 + 0x10);
          if (fVar14 == 0.0) {
            if ((*(char *)(param_1 + 0x91) == '\0') || (param_7[1] <= iVar12 + 1))
            goto LAB_001529c5;
          }
          else if (param_7[1] <= iVar12 + 1) goto LAB_001529c5;
          iVar12 = iVar12 + 1;
          param_2 = param_2 + 1;
        } while (fVar14 == 0.0);
      }
      else {
        do {
          fVar14 = *param_2;
          fVar15 = fVar14 * *(float *)(iVar8 + 0xc);
          *param_2 = fVar15;
          if (*(char *)(param_1 + 0x128) != '\0') {
            FUN_0000ab14("channel:%d %d %f * %f = %f",param_3,iVar12,(double)fVar14,
                         (double)*(float *)(iVar8 + 0xc),(double)fVar15);
          }
          fVar14 = *(float *)(iVar8 + 0x10);
          if (((fVar14 == 0.0) && (!NAN(fVar14))) && (*(char *)(param_1 + 0x91) == '\0'))
          goto LAB_001529c5;
          param_2 = param_2 + 1;
          iVar12 = iVar12 + 1;
          if (param_7[1] <= iVar12) goto LAB_001529c5;
        } while (fVar14 == 0.0);
      }
    } while( true );
  }
LAB_001529c5:
  return param_7[1];
}



int FUN_001f0c92(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5,undefined8 param_6,undefined8 param_7)

{
  char cVar1;
  
  cVar1 = FUN_001afb00(*(undefined4 *)(param_1 + 0xc),param_1,param_2,param_3,param_4,param_5,
                       param_6,param_7);
  return (int)cVar1;
}


001f0c92  55  PUSH EBP
001f0c93  89e5  MOV EBP,ESP
001f0c95  83ec38  SUB ESP,0x38
001f0c98  8b5508  MOV EDX,dword ptr [EBP + 0x8]
001f0c9b  f20f104524  MOVSD XMM0,qword ptr [EBP + 0x24]
001f0ca0  f20f11442420  MOVSD qword ptr [ESP + 0x20],XMM0
001f0ca6  f20f10451c  MOVSD XMM0,qword ptr [EBP + 0x1c]
001f0cab  f20f11442418  MOVSD qword ptr [ESP + 0x18],XMM0
001f0cb1  8b4518  MOV EAX,dword ptr [EBP + 0x18]
001f0cb4  89442414  MOV dword ptr [ESP + 0x14],EAX
001f0cb8  8b4514  MOV EAX,dword ptr [EBP + 0x14]
001f0cbb  89442410  MOV dword ptr [ESP + 0x10],EAX
001f0cbf  8b4510  MOV EAX,dword ptr [EBP + 0x10]
001f0cc2  8944240c  MOV dword ptr [ESP + 0xc],EAX
001f0cc6  8b450c  MOV EAX,dword ptr [EBP + 0xc]
001f0cc9  89442408  MOV dword ptr [ESP + 0x8],EAX
001f0ccd  89542404  MOV dword ptr [ESP + 0x4],EDX
001f0cd1  8b420c  MOV EAX,dword ptr [EDX + 0xc]
001f0cd4  890424  MOV dword ptr [ESP],EAX
001f0cd7  e824eefbff  CALL 0x001afb00
001f0cdc  0fbec0  MOVSX EAX,AL
001f0cdf  c9  LEAVE
001f0ce0  c3  RET

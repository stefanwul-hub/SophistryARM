
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0015197c(int param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  if (*(int *)(param_1 + 0x98) == 0) {
    uVar5 = func_0x0000a930(
                           "/Volumes/CeleSVN/Elastik/Projects/XCode/../../Source/ETInstrumentVoice.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x112,uVar5,"_keyMapping");
  }
  iVar4 = FUN_0014ac64(*(undefined4 *)(param_1 + 0x98));
  if (param_4 != 0) {
    iVar1 = param_2 + -1;
    iVar2 = *(int *)(param_1 + 0x9c);
    iVar3 = *(int *)(param_1 + 0xa0);
    if (iVar3 <= iVar2) {
      if (iVar2 <= iVar3) {
        return iVar1;
      }
      if (param_2 < iVar2) {
        if (iVar3 < param_2) {
          return iVar1;
        }
        if (-1 < iVar1) {
          return iVar1;
        }
        return iVar4 + -1;
      }
    }
    if (iVar2 <= iVar1) {
      return iVar1;
    }
    return iVar3;
  }
  param_3 = param_3 + param_2;
  iVar1 = *(int *)(param_1 + 0x9c);
  iVar2 = *(int *)(param_1 + 0xa0);
  if (iVar2 <= iVar1) {
    if (iVar1 <= iVar2) {
      return param_3;
    }
    if (iVar2 < param_2) {
      if (param_2 < iVar1) {
        return param_3;
      }
      iVar4 = param_3 - (iVar4 + -1);
      if (iVar4 < 1) {
        return param_3;
      }
      return iVar4 + -1;
    }
  }
  if (param_3 - iVar2 < 1) {
    return param_3;
  }
  return iVar1 + -1 + (param_3 - iVar2);
}


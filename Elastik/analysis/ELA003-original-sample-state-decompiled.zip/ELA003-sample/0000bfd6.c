
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0000bfd6(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  uVar1 = __Znwm(0x20);
  func_0x000332e2(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  uVar1 = (**(code **)(*piVar2 + 0x48))(piVar2);
  uVar3 = func_0x00039354(param_2);
  func_0x0003d480(uVar1,uVar3,&stack0x0000000c);
  func_0x00034b8e(uVar1);
  puVar4 = (undefined4 *)__Znwm(0x18);
  func_0x0002dc66(puVar4);
  *puVar4 = &UNK_0036ce88;
  puVar4[3] = 0;
  puVar4[4] = 0;
  puVar4[5] = 0;
  piVar2 = (int *)FUN_0002dfa6(puVar4);
  piVar2 = (int *)(**(code **)(*piVar2 + 0x48))(piVar2);
  (**(code **)(*piVar2 + 0x1a4))(piVar2,param_1,uVar1,0);
  (**(code **)(*piVar2 + 0x1a8))(piVar2);
  return;
}


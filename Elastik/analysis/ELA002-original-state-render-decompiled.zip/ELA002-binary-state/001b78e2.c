
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001b78e2(int *param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 == (int *)0x0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x71,uVar3,"this != 0");
  }
  if ((param_2 != 0) && (iVar1 = FUN_000278d6(param_2), iVar1 != 0)) {
    iVar1 = (**(code **)(*param_1 + 0x2a4))(param_1);
    if (iVar1 != 0) {
      piVar2 = (int *)(**(code **)(*param_1 + 0x2a4))(param_1);
      param_2 = (**(code **)(*piVar2 + 0x1a8))(piVar2,param_2);
    }
    uVar3 = __Znwm(0x1c);
    FUN_00162ba6(uVar3);
    uVar3 = FUN_0002dfa6(uVar3);
    piVar2 = (int *)FUN_00162e16(uVar3,param_2);
    if (piVar2 != (int *)0x0) {
      uVar3 = (**(code **)(*param_1 + 0x2ac))(param_1,piVar2);
      (**(code **)(*piVar2 + 0x44))(piVar2);
      return uVar3;
    }
  }
  return 0;
}


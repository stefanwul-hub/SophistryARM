
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001b92b4(int param_1)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 uVar6;
  char *pcVar7;
  int iStack_34;
  int iStack_30;
  undefined4 uStack_24;
  int aiStack_20 [4];
  
  if (param_1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x262,uVar4,"this != 0");
  }
  if (*(int *)(param_1 + 0x24) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x262,uVar4,"_stream");
  }
  if (*(int *)(param_1 + 0x18) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x262,uVar4,"_objects");
  }
  cVar2 = func_0x00163006(*(undefined4 *)(param_1 + 0x24),aiStack_20);
  *(char *)(param_1 + 0x28) = cVar2;
  if (cVar2 == '\0') {
    return 0;
  }
  if (0 < aiStack_20[0]) {
    iStack_34 = 0;
    do {
      cVar2 = func_0x00163006(*(undefined4 *)(param_1 + 0x24),&uStack_24);
      *(char *)(param_1 + 0x28) = cVar2;
      if (cVar2 == '\0') {
        return 0;
      }
      iVar3 = func_0x001b91c6(param_1,uStack_24);
      if (iVar3 == 0) {
        uVar4 = func_0x0000a930(
                               "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                               );
        uVar6 = FUN_00033b90("GNAssertionException");
        FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x268,uVar4,
                     "_classDescriptionForClassNumber(numberOfClassDescription)");
      }
      uVar4 = func_0x001b91c6(param_1,uStack_24);
      piVar5 = (int *)FUN_0001fdb0(uVar4);
      (**(code **)(*piVar5 + 0x54))(piVar5,param_1);
      FUN_0002bb40(*(undefined4 *)(param_1 + 0x18),piVar5);
      (**(code **)(*piVar5 + 0x44))(piVar5);
      iStack_34 = iStack_34 + 1;
    } while (iStack_34 < aiStack_20[0]);
    if (0 < aiStack_20[0]) {
      iStack_30 = 0;
      do {
        if ((*(char *)(param_1 + 0x30) != '\0') && (iStack_30 % (aiStack_20[0] / 100 + 1) == 0)) {
          piVar5 = (int *)func_0x0006d8fe();
          pcVar1 = *(code **)(*piVar5 + 0x1ac);
          uVar4 = FUN_00033b90("progress");
          uVar6 = func_0x00085a2c((float)iStack_30 / (float)aiStack_20[0]);
          uVar4 = FUN_00066996(uVar6,uVar4,0);
          uVar6 = FUN_00033b90("GNCodingProgressNotification");
          (*pcVar1)(piVar5,uVar6,param_1,uVar4,3);
        }
        piVar5 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0x18),iStack_30);
        (**(code **)(*piVar5 + 0x6c))(piVar5,param_1);
        if (*(char *)(param_1 + 0x28) == '\0') {
          uVar4 = (**(code **)(*piVar5 + 8))(piVar5);
          iVar3 = func_0x0001f4dc(uVar4);
          if (iVar3 == 0) {
            pcVar7 = "";
          }
          else {
            uVar4 = (**(code **)(*piVar5 + 8))(piVar5);
            uVar4 = func_0x0001f4dc(uVar4);
            pcVar7 = (char *)func_0x00034962(uVar4);
          }
          FUN_0000ab14("Decoding %s failed.",pcVar7);
          return 0;
        }
        (**(code **)(*piVar5 + 8))(piVar5);
        iStack_30 = iStack_30 + 1;
      } while (iStack_30 < aiStack_20[0]);
    }
  }
  return 1;
}


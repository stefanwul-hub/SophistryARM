
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00162fc2(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if (*(int *)(param_1 + 0x14) == 0) {
    return;
  }
  func_0x00027bec(*(int *)(param_1 + 0x14));
  (**(code **)(**(int **)(param_1 + 0x14) + 0x1a4))
            (*(int **)(param_1 + 0x14),*(undefined4 *)(param_1 + 0x10));
  iVar1 = *(int *)(param_1 + 0x14);
  if (iVar1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNData.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x154,uVar3,"this != 0");
  }
  if ((*(int *)(iVar1 + 0x18) == 0) && (*(int *)(iVar1 + 0xc) != 0)) {
    if (*(char *)(iVar1 + 0x15) != '\0') {
      uVar3 = func_0x0017ddd4();
      func_0x0017e446(uVar3,iVar1);
    }
    iVar1 = *(int *)(iVar1 + 0xc);
    if (iVar1 == 0) {
      func_0x0000acae("GNMemoryHandle is nil.");
    }
    if (*(int *)(iVar1 + 8) == 0) {
      _HLockHi(*(undefined4 *)(iVar1 + 0xc));
    }
    *(int *)(iVar1 + 8) = *(int *)(iVar1 + 8) + 1;
    return;
  }
  return;
}


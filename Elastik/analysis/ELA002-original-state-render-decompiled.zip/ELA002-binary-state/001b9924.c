
int FUN_001b9924(int *param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  
  if (param_2 != 0) {
    uVar2 = __Znwm(0x1c);
    FUN_00162ba6(uVar2);
    piVar3 = (int *)FUN_0002dfa6(uVar2);
    uVar2 = (**(code **)(*piVar3 + 0x48))(piVar3);
    FUN_00162e16(uVar2,param_2);
    cVar1 = (**(code **)(*param_1 + 0x2d0))(param_1,uVar2);
    return (int)cVar1;
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_001b5af0(int *param_1,int *param_2,int param_3)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x7a,uVar2,"this != 0");
  }
  if (param_2 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x7a,uVar2,"anObject != 0");
  }
  *(undefined1 *)(param_1 + 0xb) = 1;
  param_1[9] = (int)param_2;
  if (param_2 != (int *)0x0) {
    (**(code **)(*param_2 + 0x40))(param_2);
  }
  (**(code **)(*param_1 + 0x2b8))(param_1);
  if ((char)param_1[0xb] != '\0') {
    param_1[10] = param_3;
    (**(code **)(*param_1 + 700))(param_1);
    if ((char)param_1[0xb] != '\0') {
      (**(code **)(*param_1 + 0x2c0))(param_1);
      if ((char)param_1[0xb] != '\0') {
        FUN_00162fc2(param_1[10]);
      }
      piVar1 = (int *)param_1[6];
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x44))(piVar1);
      }
      param_1[6] = 0;
    }
    piVar1 = (int *)param_1[7];
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    param_1[7] = 0;
  }
  piVar1 = (int *)param_1[9];
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x44))(piVar1);
  }
  param_1[9] = 0;
  return (int)(char)param_1[0xb];
}


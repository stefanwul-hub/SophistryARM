
int * FUN_001ba042(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  
  *(int **)(param_1 + 0x24) = param_2;
  if (param_2 != (int *)0x0) {
    (**(code **)(*param_2 + 0x40))(param_2);
  }
  *(undefined1 *)(param_1 + 0x28) = 1;
  uVar3 = __Znwm(0x20);
  FUN_00029d44(uVar3);
  uVar3 = FUN_0002dfa6(uVar3);
  *(undefined4 *)(param_1 + 0x1c) = uVar3;
  uVar3 = __Znwm(0x18);
  FUN_000630b6(uVar3);
  uVar3 = FUN_0002dfa6(uVar3);
  *(undefined4 *)(param_1 + 0x2c) = uVar3;
  uVar3 = __Znwm(0x20);
  FUN_00029d44(uVar3);
  uVar3 = FUN_0002dfa6(uVar3);
  *(undefined4 *)(param_1 + 0x18) = uVar3;
  cVar2 = FUN_001b9d96(param_1);
  if (((cVar2 != '\0') && (cVar2 = FUN_001b92b4(param_1), cVar2 != '\0')) &&
     (iVar4 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x18)), iVar4 != 0)) {
    piVar5 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0x18),0);
    if (piVar5 != (int *)0x0) {
      (**(code **)(*piVar5 + 0x40))(piVar5);
      (**(code **)(*piVar5 + 0x48))(piVar5);
    }
    piVar1 = *(int **)(param_1 + 0x24);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(undefined4 *)(param_1 + 0x24) = 0;
    cVar2 = FUN_001b9624(param_1);
    if ((cVar2 != '\0') && (cVar2 = FUN_001b7a00(param_1), cVar2 != '\0')) {
      piVar1 = *(int **)(param_1 + 0x2c);
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x44))(piVar1);
      }
      *(undefined4 *)(param_1 + 0x2c) = 0;
      piVar1 = *(int **)(param_1 + 0x18);
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x44))(piVar1);
      }
      *(undefined4 *)(param_1 + 0x18) = 0;
      piVar1 = *(int **)(param_1 + 0x1c);
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x44))(piVar1);
      }
      *(undefined4 *)(param_1 + 0x1c) = 0;
      return piVar5;
    }
  }
  return (int *)0x0;
}


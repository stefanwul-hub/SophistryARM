
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001b7a00(int param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x2a0,uVar3,"this != 0");
  }
  if (*(int *)(param_1 + 0x18) == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x2a0,uVar3,"_objects");
  }
  iVar1 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x18));
  if (0 < iVar1) {
    iVar5 = 0;
    do {
      piVar2 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0x18),iVar5);
      (**(code **)(*piVar2 + 0x7c))(piVar2,param_1);
      if (*(char *)(param_1 + 0x28) == '\0') {
        return 0;
      }
      iVar5 = iVar5 + 1;
    } while (iVar1 != iVar5);
  }
  return 1;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001b9d96(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  int iStack_30;
  undefined4 uStack_2c;
  undefined1 auStack_28 [4];
  int iStack_24;
  undefined1 auStack_20 [16];
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x245,uVar2,"this != 0");
  }
  if (*(int *)(param_1 + 0x24) == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x245,uVar2,"_stream");
  }
  if (*(int *)(param_1 + 0x1c) == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x245,uVar2,"_classDescriptions");
  }
  cVar1 = func_0x00163006(*(undefined4 *)(param_1 + 0x24),auStack_20);
  *(char *)(param_1 + 0x28) = cVar1;
  if (cVar1 != '\0') {
    cVar1 = func_0x00163006(*(undefined4 *)(param_1 + 0x24),&iStack_24);
    *(char *)(param_1 + 0x28) = cVar1;
    if (cVar1 != '\0') {
      if (0 < iStack_24) {
        iStack_30 = 0;
        do {
          uVar2 = __Znwm(0x20);
          func_0x000332e2(uVar2);
          piVar3 = (int *)FUN_0002dfa6(uVar2);
          cVar1 = func_0x00163006(*(undefined4 *)(param_1 + 0x24),auStack_28);
          *(char *)(param_1 + 0x28) = cVar1;
          if (cVar1 == '\0') {
            return 0;
          }
          cVar1 = func_0x00163006(*(undefined4 *)(param_1 + 0x24),&uStack_2c);
          *(char *)(param_1 + 0x28) = cVar1;
          if (cVar1 == '\0') {
            return 0;
          }
          cVar1 = func_0x0016375e(*(undefined4 *)(param_1 + 0x24),piVar3);
          *(char *)(param_1 + 0x28) = cVar1;
          if (cVar1 == '\0') {
            return 0;
          }
          if ((*(int *)(param_1 + 0x34) != 0) &&
             (cVar1 = FUN_00064024(*(int *)(param_1 + 0x34),piVar3), cVar1 != '\0')) {
            piVar3 = (int *)FUN_00064626(*(undefined4 *)(param_1 + 0x34),piVar3);
          }
          uVar2 = __Znwm(0x78);
          func_0x0001ed00(uVar2);
          uVar2 = FUN_0002dfa6(uVar2);
          func_0x0001f518(uVar2,piVar3);
          func_0x0001f9fa(uVar2,uStack_2c);
          FUN_0002bb40(*(undefined4 *)(param_1 + 0x1c),uVar2);
          if (piVar3 != (int *)0x0) {
            (**(code **)(*piVar3 + 0x44))(piVar3);
          }
          iStack_30 = iStack_30 + 1;
        } while (iStack_30 < iStack_24);
      }
      return 1;
    }
  }
  return 0;
}


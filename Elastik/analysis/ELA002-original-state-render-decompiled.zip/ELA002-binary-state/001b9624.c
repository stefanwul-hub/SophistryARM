
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001b9624(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  
  if (param_1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x288,uVar4,"this != 0");
  }
  if (*(int *)(param_1 + 0x18) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x288,uVar4,"_objects");
  }
  if (*(int *)(param_1 + 0x2c) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x288,uVar4,"_replacementDict");
  }
  iVar1 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x18));
  if (0 < iVar1) {
    iVar6 = 0;
    do {
      piVar2 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0x18),iVar6);
      (**(code **)(*piVar2 + 0x78))(piVar2,param_1);
      if (*(char *)(param_1 + 0x28) == '\0') {
        return 0;
      }
      iVar6 = iVar6 + 1;
    } while (iVar1 != iVar6);
  }
  iVar1 = func_0x00063426(*(undefined4 *)(param_1 + 0x2c));
  if (iVar1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x293,uVar4,"replacedObjects");
  }
  for (iVar6 = 0; iVar3 = FUN_00029ddc(iVar1), iVar6 < iVar3; iVar6 = iVar6 + 1) {
    uVar4 = FUN_0002a364(iVar1,iVar6);
    func_0x0002aaae(*(undefined4 *)(param_1 + 0x18),uVar4);
  }
  for (iVar6 = 0; iVar3 = FUN_00029ddc(iVar1), iVar6 < iVar3; iVar6 = iVar6 + 1) {
    uVar4 = FUN_0002a364(iVar1,iVar6);
    uVar4 = FUN_00064626(*(undefined4 *)(param_1 + 0x2c),uVar4);
    FUN_0002bb40(*(undefined4 *)(param_1 + 0x18),uVar4);
  }
  return 1;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00162e16(int param_1,int *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x3a,uVar1,"this != 0");
  }
  if (param_2 == (int *)0x0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x3a,uVar1,"data");
  }
  *(int **)(param_1 + 0x14) = param_2;
  if (param_2 != (int *)0x0) {
    (**(code **)(*param_2 + 0x40))(param_2);
    *(undefined4 *)(param_1 + 0x10) = 0;
    func_0x00027b4e(*(undefined4 *)(param_1 + 0x14));
    return param_1;
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  func_0x00027b4e(0);
  return param_1;
}


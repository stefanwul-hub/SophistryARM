
void FUN_0001cafe(int *param_1)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longdouble lVar6;
  
  cVar2 = (**(code **)(*(int *)param_1[0x1a] + 0x1a8))((int *)param_1[0x1a]);
  if (cVar2 != '\0') {
    iVar3 = FUN_00029ddc(param_1[0x19]);
    if (iVar3 != 0) {
      if (param_1[0x18] == 0) {
        iVar3 = FUN_00029ddc(param_1[0x19]);
        iVar3 = iVar3 + -1;
        if (-1 < iVar3) {
          do {
            uVar4 = FUN_0002a364(param_1[0x19],iVar3);
            cVar2 = FUN_000623a4(uVar4);
            if (cVar2 != '\0') {
              pcVar1 = *(code **)(*param_1 + 0x2a4);
              uVar5 = FUN_00062422(uVar4);
              lVar6 = (longdouble)FUN_000624e4(uVar4);
              (*pcVar1)(param_1,(float)lVar6,uVar5);
            }
            iVar3 = iVar3 + -1;
          } while (iVar3 != -1);
        }
        FUN_0002ad82(param_1[0x19]);
      }
      else {
        FUN_0002b2e6(param_1[0x19],param_1[0x18],0);
      }
    }
    (**(code **)(*(int *)param_1[0x1a] + 0x1ac))((int *)param_1[0x1a]);
  }
  if (param_1[0x18] != 0) {
    iVar3 = FUN_00029ddc(param_1[0x18]);
    iVar3 = iVar3 + -1;
    if (-1 < iVar3) {
      do {
        while( true ) {
          uVar4 = FUN_0002a364(param_1[0x18],iVar3);
          cVar2 = FUN_000623a4(uVar4);
          if (cVar2 == '\0') break;
          pcVar1 = *(code **)(*param_1 + 0x2a4);
          uVar5 = FUN_00062422(uVar4);
          lVar6 = (longdouble)FUN_000624e4(uVar4);
          (*pcVar1)(param_1,(float)lVar6,uVar5);
          FUN_0002a62c(param_1[0x18],iVar3);
          iVar3 = iVar3 + -1;
          if (iVar3 == -1) {
            return;
          }
        }
        iVar3 = iVar3 + -1;
      } while (iVar3 != -1);
    }
  }
  return;
}


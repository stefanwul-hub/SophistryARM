
int * FUN_00065022(undefined4 param_1)

{
  undefined4 uVar1;
  int *piVar2;
  
  uVar1 = __Znwm(0x20);
  func_0x0002765e(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  func_0x000647a8(param_1,piVar2,param_1,0);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x48))(piVar2);
  }
  return piVar2;
}


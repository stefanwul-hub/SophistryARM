
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002b2e6(int param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x10) == 0) {
    return;
  }
  if (param_3 == 0) {
    if (*(char *)(param_1 + 0x18) == *(char *)(param_2 + 0x18)) goto LAB_0002b366;
  }
  else {
    uVar1 = FUN_00033b90("GNNotImplementedException");
    FUN_0000bfd6(uVar1,"Function %s not implemented yet in %s.","transferObjectsToListAtIndex",
                 "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp");
    if (*(char *)(param_1 + 0x18) == *(char *)(param_2 + 0x18)) goto LAB_0002b366;
  }
  uVar1 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                         );
  uVar2 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x34f,uVar1,
               "_retainingDisabled == targetList->_retainingDisabled");
LAB_0002b366:
  FUN_0002a14a(param_2,*(int *)(param_1 + 0x10) + *(int *)(param_2 + 0x10));
  iVar3 = *(int *)(param_2 + 0x10) + *(int *)(param_1 + 0x10);
  *(int *)(param_2 + 0x10) = iVar3;
  _memmove(*(int *)(param_2 + 0xc) + *(int *)(param_1 + 0x10) * 4,*(int *)(param_2 + 0xc),iVar3 * 4)
  ;
  _memcpy(*(undefined4 *)(param_2 + 0xc),*(undefined4 *)(param_1 + 0xc),
          *(int *)(param_1 + 0x10) << 2);
  *(undefined4 *)(param_1 + 0x10) = 0;
  return;
}


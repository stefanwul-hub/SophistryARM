
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00121a50(int param_1,int *param_2,int param_3)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int *piVar7;
  int *piVar8;
  uint uVar9;
  int iVar10;
  char *pcVar11;
  int iStack_14;
  
  iVar10 = param_3;
  iVar3 = (int)param_2;
  if (((param_2 == (int *)0x0) || (param_3 == 0)) ||
     (cVar1 = FUN_00064024(*(undefined4 *)(param_1 + 0x28),param_2), cVar1 == '\0')) {
    return;
  }
  piVar8 = (int *)FUN_00064626(*(undefined4 *)(param_1 + 0x28),iVar3);
  iVar3 = *(int *)(param_1 + 0x28);
  param_2 = piVar8;
  param_3 = iVar10;
  if (iVar3 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xfe,uVar4,"this != 0");
  }
  if (*(int *)(iVar3 + 0xc) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xfe,uVar4,"_keys");
  }
  if (*(int *)(iVar3 + 0x10) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xfe,uVar4,"_objects");
  }
  if (iVar10 == 0) {
    func_0x0000acae("GNDictionary: key is 0");
  }
  if ((piVar8 == (int *)0x0) && (cVar1 = func_0x000639f0(iVar3), cVar1 == '\0')) {
    pcVar2 = "Attempt to insert 0 as an object into a dictionary";
    if (cRam003d3ef8 == '\0') {
      uVar9 = 0xffffffff;
      pcVar11 = pcVar2;
      do {
        if (uVar9 == 0) break;
        uVar9 = uVar9 - 1;
        cVar1 = *pcVar11;
        pcVar11 = pcVar11 + 1;
      } while (cVar1 != '\0');
      cVar1 = ~uVar9 - 1 < 0x2000;
      if ((bool)cVar1) {
        pcVar2 = (char *)FUN_0000aecc((~uVar9 - 1) * 3 + 0x400);
        _vsprintf(pcVar2,"Attempt to insert 0 as an object into a dictionary",&param_2);
      }
      if (piRam003d3f0c == (int *)0x0) {
        uVar4 = __Znwm(0x38);
        func_0x0006f04a(uVar4);
        piRam003d3f0c = (int *)FUN_0002dfa6(uVar4);
      }
      (**(code **)(*piRam003d3f0c + 0x1a4))(piRam003d3f0c);
      _puts(pcVar2);
      (**(code **)(*piRam003d3f0c + 0x1ac))(piRam003d3f0c);
      if (cVar1 != '\0') {
        if (pcVar2 != (char *)0x0) {
          if (cRam003d3f09 == '\0') {
            cRam003d3f09 = 1;
            if (iRam003d3ee8 != 0) {
              func_0x000424ac(iRam003d3ee8,pcVar2);
            }
            cRam003d3f09 = '\0';
          }
          _free(pcVar2);
          return;
        }
        FUN_0000ab14("GNFree(0)");
      }
    }
    return;
  }
  if (*(int *)(iVar3 + 0x14) == 0) {
    iVar6 = func_0x0002a9ba(*(undefined4 *)(iVar3 + 0xc),iVar10);
  }
  else {
    iVar6 = func_0x0006440e(iVar3,iVar10);
  }
  if (iVar6 != -1) {
    piVar7 = (int *)FUN_0002a364(*(undefined4 *)(iVar3 + 0x10),iVar6);
    if (piVar8 == piVar7) {
      return;
    }
    FUN_0002a62c(*(undefined4 *)(iVar3 + 0x10),iVar6);
    piVar7 = *(int **)(iVar3 + 0x10);
    param_2 = piVar8;
    param_3 = iVar6;
    if (piVar7 == (int *)0x0) {
      uVar4 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                             );
      uVar5 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x18c,uVar4,"this != 0");
    }
    if ((param_2 == (int *)0x0) && (*(char *)((int)piVar7 + 0x19) == '\0')) {
      uVar4 = (**(code **)(*piVar7 + 0xc))(piVar7);
      uVar4 = func_0x00034962(uVar4);
      func_0x0000acae("GNList::insertObjectAtIndex(): Cannot insert nil object into %s.",uVar4);
    }
    if ((piVar7[4] < param_3) || (param_3 < 0)) {
      uVar4 = (**(code **)(*piVar7 + 0xc))(piVar7);
      uVar4 = func_0x00034962(uVar4);
      func_0x0000acae("GNList::insertObjectAtIndex(): Index %i out of range of %s.",param_3,uVar4);
      iVar3 = piVar7[4] + 1;
      piVar7[4] = iVar3;
    }
    else {
      iVar3 = piVar7[4] + 1;
      piVar7[4] = iVar3;
    }
    iVar10 = iVar3 * 0x10 + 1;
    if (iVar10 < 0) {
      iVar10 = iVar3 * 0x10 + 0x10;
    }
    FUN_0002a14a(piVar7,iVar10 >> 4);
    iVar3 = piVar7[4] + -1;
    if (param_3 < iVar3) {
      iVar10 = iVar3 * 4;
      do {
        *(undefined4 *)(iVar10 + piVar7[3]) = ((undefined4 *)(iVar10 + piVar7[3]))[-1];
        iVar3 = iVar3 + -1;
        iVar10 = iVar10 + -4;
      } while (param_3 < iVar3);
    }
    *(int **)(piVar7[3] + param_3 * 4) = param_2;
    if (((char)piVar7[6] == '\0') && (param_2 != (int *)0x0)) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
    return;
  }
  FUN_0002bb40(*(undefined4 *)(iVar3 + 0xc),iVar10);
  FUN_0002bb40(*(undefined4 *)(iVar3 + 0x10),piVar8);
  iVar10 = FUN_00029ddc(*(undefined4 *)(iVar3 + 0xc));
  param_2 = (int *)(iVar10 + -1);
  if (*(int *)(iVar3 + 0x14) != 0) {
    piVar8 = (int *)func_0x000427b6(*(int *)(iVar3 + 0x14));
    iVar10 = FUN_00041be2(*(undefined4 *)(iVar3 + 0x14));
    piVar7 = (int *)FUN_0002a364(*(undefined4 *)(iVar3 + 0xc),param_2);
    iStack_14 = (**(code **)(*piVar7 + 0x90))(piVar7);
    if (iVar10 < 1) {
code_r0x00066056:
      func_0x00042ffe(*(undefined4 *)(iVar3 + 0x14),&iStack_14);
      return;
    }
    if (*piVar8 == iStack_14 || *piVar8 - iStack_14 < 0) {
      iVar6 = 0;
      do {
        piVar8 = piVar8 + 2;
        iVar6 = iVar6 + 1;
        if (iVar10 == iVar6) goto code_r0x00066056;
      } while (*piVar8 == iStack_14 || *piVar8 - iStack_14 < 0);
    }
    else {
      iVar6 = 0;
    }
    func_0x00042dcc(*(undefined4 *)(iVar3 + 0x14),&iStack_14,iVar6);
  }
  return;
}


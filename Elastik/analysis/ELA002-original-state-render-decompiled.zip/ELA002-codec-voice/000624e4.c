
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

longdouble FUN_000624e4(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNAudioProcessorEvent.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x65,uVar1,"this != 0");
  }
  if (*(int *)(param_1 + 0x14) != -1) {
    return (longdouble)*(float *)(param_1 + 0x18);
  }
  uVar1 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNAudioProcessorEvent.cpp"
                         );
  uVar2 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x65,uVar1,"_parameterIndex != -1");
  return (longdouble)*(float *)(param_1 + 0x18);
}


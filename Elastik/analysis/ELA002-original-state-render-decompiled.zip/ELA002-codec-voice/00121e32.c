
void FUN_00121e32(int *param_1,undefined4 param_2)

{
  code *UNRECOVERED_JUMPTABLE;
  
  UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0x2ac);
  FUN_00121cd4(param_2);
                    /* WARNING: Could not recover jumptable at 0x00121e5e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)();
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_000657ea(undefined4 param_1)

{
  undefined4 uVar1;
  int *piVar2;
  int *piVar3;
  
  uVar1 = __Znwm(0x20);
  func_0x0002765e(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  uVar1 = __Znwm(0x24);
  func_0x0017e50c(uVar1);
  piVar3 = (int *)FUN_0002dfa6(uVar1);
  func_0x0017f84e(piVar3,piVar2);
  uVar1 = func_0x0003dd2a("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<plist version=\"1.0\">\n");
  uVar1 = func_0x00036060(uVar1,1000);
  func_0x001803a0(piVar3,uVar1);
  func_0x0006508c(param_1,piVar3,param_1,0);
  uVar1 = func_0x0003dd2a("</plist>\n");
  uVar1 = func_0x00036060(uVar1,1000);
  func_0x001803a0(piVar3,uVar1);
  (**(code **)(*piVar3 + 0x1a4))(piVar3);
  (**(code **)(*piVar3 + 0x44))(piVar3);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x48))(piVar2);
  }
  return piVar2;
}


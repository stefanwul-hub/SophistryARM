
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001551e8(int *param_1,int param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  
  if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNKeyValueArchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x152,uVar2,"this != 0");
  }
  if (param_2 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNKeyValueArchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x152,uVar2,"data");
  }
  uVar2 = __Znwm(0x34);
  FUN_00120f0e(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  pcVar1 = *(code **)(*piVar3 + 0x2a0);
  uVar2 = (**(code **)(*param_1 + 0x2a4))(param_1);
  (*pcVar1)(piVar3,uVar2);
  uVar2 = (**(code **)(*piVar3 + 0x29c))(piVar3,param_2);
  (**(code **)(*piVar3 + 0x44))(piVar3);
  return uVar2;
}


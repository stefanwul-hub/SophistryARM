
int FUN_00064024(int param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = func_0x0002abb6(*(undefined4 *)(param_1 + 0xc),param_2);
  return (int)cVar1;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002a62c(int *param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  
  if (param_1 == (int *)0x0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x1f1,uVar3,"this != 0");
  }
  if ((param_1[4] <= param_2) || (param_2 < 0)) {
    uVar3 = (**(code **)(*param_1 + 0xc))(param_1);
    uVar3 = func_0x00034962(uVar3);
    func_0x0000acae("GNList::removeObjectAtIndex(): Index %i out of range of %s.",param_2,uVar3);
  }
  iVar5 = param_2 * 4;
  iVar6 = param_1[3];
  piVar1 = *(int **)(iVar6 + iVar5);
  iVar2 = param_1[4] + -1;
  if (param_2 < iVar2) {
    while( true ) {
      *(undefined4 *)(iVar5 + iVar6) = ((undefined4 *)(iVar5 + iVar6))[1];
      param_2 = param_2 + 1;
      iVar2 = param_1[4] + -1;
      iVar5 = iVar5 + 4;
      if (iVar2 <= param_2) break;
      iVar6 = param_1[3];
    }
  }
  param_1[4] = iVar2;
  if (((char)param_1[6] == '\0') && (piVar1 != (int *)0x0)) {
                    /* WARNING: Could not recover jumptable at 0x0002a6b4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar1 + 0x44))();
    return;
  }
  return;
}


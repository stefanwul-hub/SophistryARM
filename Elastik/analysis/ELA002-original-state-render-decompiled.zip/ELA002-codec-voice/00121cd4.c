
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00121cd4(int *param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  char *pcVar5;
  
  if (param_1 != (int *)0x0) {
    if (cRam00366064 == '\0') {
      if (iRam003d46dc == 0) {
        uVar3 = __Znwm(0x18);
        FUN_000630b6(uVar3);
        iRam003d46dc = FUN_0002dfa6(uVar3);
      }
      iVar2 = FUN_00064626(iRam003d46dc,param_1);
      if (iVar2 != 0) {
        return iVar2;
      }
    }
    uVar3 = __Znwm(0x38);
    func_0x001b7682(uVar3);
    piVar4 = (int *)FUN_0002dfa6(uVar3);
    piVar4 = (int *)(**(code **)(*piVar4 + 0x48))(piVar4);
    cVar1 = (**(code **)(*piVar4 + 0x2cc))(piVar4,param_1);
    if (((cVar1 != '\0') && (iVar2 = (**(code **)(*piVar4 + 0x2a8))(piVar4,param_1), iVar2 != 0)) ||
       (iVar2 = func_0x0006739a(param_1), iVar2 != 0)) {
      if (cRam00366064 != '\0') {
        return iVar2;
      }
      FUN_00066284(iRam003d46dc,iVar2,param_1);
      return iVar2;
    }
    iVar2 = (**(code **)(*param_1 + 0x1bc))(param_1);
    if (iVar2 == 0) {
      pcVar5 = "";
    }
    else {
      uVar3 = (**(code **)(*param_1 + 0x1bc))(param_1);
      pcVar5 = (char *)func_0x00034962(uVar3);
    }
    FUN_0000ab14("GNKeyValueUnarchiver: parsing XML from %s failed.",pcVar5);
  }
  return 0;
}


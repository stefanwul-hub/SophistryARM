
longdouble FUN_0015f258(int param_1)

{
  return (longdouble)*(double *)(param_1 + 0x10);
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0001b7f8(int *param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  longdouble lVar4;
  
  if ((param_1[0x56] != 0) && ((char)param_1[0x57] == '\0')) {
    *(undefined1 *)(param_1 + 0x57) = 1;
    (**(code **)(*(int *)param_1[0x56] + 0x27c))(param_1[0x56],param_2,param_3,param_4);
    *(undefined1 *)(param_1 + 0x57) = 0;
    return;
  }
  FUN_00156134(param_1,param_2,param_3,param_4);
  if (param_1[0x55] != 0) {
    param_1[0x54] = param_1[0x54] + param_4;
  }
  iVar2 = (**(code **)(*param_1 + 0x29c))(param_1);
  if ((iVar2 != 0) && (cVar1 = func_0x0005b5d2(iVar2), cVar1 != '\0')) {
    lVar4 = (longdouble)FUN_0005b2ea(iVar2);
    lVar4 = (longdouble)_floor((double)lVar4 * DOUBLE_00364738);
    if ((double)lVar4 / DOUBLE_00364738 != *(double *)(param_1 + 0x51)) {
      *(double *)(param_1 + 0x51) = (double)lVar4 / DOUBLE_00364738;
      if (param_1[0x1e] != 0) {
        *(undefined1 *)((int)param_1 + 0x7f) = 1;
        iVar2 = FUN_00029ddc(param_1[0x1e]);
        iVar2 = iVar2 + -1;
        if (-1 < iVar2) {
          do {
            iVar3 = func_0x0002ba14(param_1[0x1e],iVar2);
            if (iVar3 != 0) {
              func_0x00041e1c(iVar3,&stack0xfffffff0,2);
            }
            iVar2 = iVar2 + -1;
          } while (iVar2 != -1);
        }
        *(undefined1 *)((int)param_1 + 0x7f) = 0;
      }
      return;
    }
  }
  return;
}


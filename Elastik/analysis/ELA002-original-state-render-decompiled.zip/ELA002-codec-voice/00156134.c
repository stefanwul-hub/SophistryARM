
void FUN_00156134(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  int iStack_10;
  
  func_0x00151062(param_1,param_2,param_3,param_4);
  if (*(char *)(param_1 + 0x44) != '\0') {
    func_0x0001c8ba(param_1);
    uVar2 = func_0x0001ce36(param_1);
    func_0x001627b8(param_3,0x44,param_4,uVar2);
    iStack_10 = 0;
    while( true ) {
      iVar3 = FUN_00029ddc(*(undefined4 *)(param_1 + 0xac));
      if (iVar3 <= iStack_10) break;
      piVar4 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0xac),iStack_10);
      cVar1 = (**(code **)(*piVar4 + 0x36c))(piVar4);
      if (cVar1 == '\0') {
LAB_0015625f:
        iStack_10 = iStack_10 + 1;
      }
      else {
        if (*(char *)(param_1 + 0xb8) != '\0') {
          iVar3 = piVar4[0x25];
          uVar2 = func_0x0001ce36(param_1);
          func_0x001627b8(iVar3,0x44,param_4,uVar2);
          (**(code **)(*piVar4 + 0x27c))(piVar4,iVar3,iVar3,param_4);
          uVar2 = func_0x0001ce36(param_1);
          func_0x00161700(param_3,iVar3,0x44,param_4,uVar2);
          goto LAB_0015625f;
        }
        (**(code **)(*piVar4 + 0x27c))(piVar4,param_2,param_3,param_4);
        iStack_10 = iStack_10 + 1;
      }
    }
  }
  return;
}


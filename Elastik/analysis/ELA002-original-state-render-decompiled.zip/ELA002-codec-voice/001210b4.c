
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_001210b4(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  char *pcVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  char *pcVar9;
  char *pcVar10;
  char *pcVar11;
  bool bVar12;
  undefined *apuStack_70 [13];
  char cStack_3c;
  undefined4 uStack_38;
  char *pcStack_34;
  int iStack_30;
  int *piStack_2c;
  int iStack_28;
  int iStack_24;
  
  piStack_2c = (int *)0x38;
  iStack_30 = 0x1210ce;
  uVar5 = __Znwm();
  iStack_30 = 0x1210d8;
  piStack_2c = (int *)uVar5;
  func_0x001b7682();
  iStack_30 = 0x1210e0;
  piStack_2c = (int *)uVar5;
  piStack_2c = (int *)FUN_0002dfa6();
  iStack_30 = 0x1210e8;
  piVar6 = (int *)(**(code **)(*piStack_2c + 0x48))();
  iStack_28 = param_1;
  iStack_30 = 0x1210fc;
  piStack_2c = piVar6;
  cVar1 = (**(code **)(*piVar6 + 0x2c8))();
  if (cVar1 != '\0') {
    iStack_28 = param_1;
    iStack_30 = 0x121112;
    piStack_2c = piVar6;
    iVar7 = (**(code **)(*piVar6 + 0x29c))();
    if (iVar7 != 0) {
      return iVar7;
    }
  }
  if (param_1 == 0) {
    return 0;
  }
  cVar1 = func_0x001a4e18(param_1);
  if (cVar1 != '\0') {
    iVar7 = func_0x001a5f6c(param_1);
    return iVar7;
  }
  iVar7 = func_0x000278d6(param_1);
  iVar7 = FUN_0000aecc(iVar7 + 1);
  if (iVar7 == 0) {
    FUN_0000ab14("XML Parser out of memory");
    iVar3 = 0;
    goto code_r0x00067216;
  }
  func_0x001a32fa(apuStack_70);
  func_0x00027b4e(param_1);
  uVar5 = func_0x000278d6(param_1);
  uVar2 = func_0x00027abc(param_1);
  _memcpy(iVar7,uVar2,uVar5);
  func_0x00027bec(param_1);
  iVar3 = func_0x000278d6(param_1);
  *(undefined1 *)(iVar7 + iVar3) = 0;
  func_0x0019cbaa(apuStack_70,iVar7,0,0);
  if (cStack_3c == '\0') {
    iVar3 = func_0x001a143a(apuStack_70,"plist");
    if ((iVar3 == 0) || (iVar3 = func_0x0019f0dc(iVar3), iVar3 == 0)) goto code_r0x000671d6;
    bVar12 = *(int *)(iVar3 + 0x24) == 0;
    if (bVar12) {
      pcVar4 = "";
    }
    else {
      pcVar4 = *(char **)(iVar3 + 0x20);
    }
    iVar8 = 5;
    pcVar10 = "dict";
    do {
      pcVar9 = pcVar4;
      pcVar11 = pcVar10;
      if (iVar8 == 0) break;
      iVar8 = iVar8 + -1;
      pcVar11 = pcVar10 + 1;
      pcVar9 = pcVar4 + 1;
      bVar12 = *pcVar4 == *pcVar10;
      pcVar4 = pcVar9;
      pcVar10 = pcVar11;
    } while (bVar12);
    iVar8 = 0;
    if (!bVar12) {
      iVar8 = (uint)(byte)pcVar9[-1] - (uint)(byte)pcVar11[-1];
    }
    if (iVar8 != 0) goto code_r0x000671d6;
    iVar3 = func_0x00066e46(iVar3);
  }
  else {
    pcVar4 = pcStack_34;
    if (iStack_30 == 0) {
      pcVar4 = "";
    }
    FUN_0000ab14("XML Parser Error ID %d Row %d - %s",uStack_38,iStack_24 + 1,pcVar4);
code_r0x000671d6:
    iVar3 = 0;
  }
  apuStack_70[0] = PTR_DAT_003db032 + 8;
  if (pcStack_34 != (char *)0x0) {
    func_0x0000b122(pcStack_34);
  }
  pcStack_34 = (char *)0x0;
  iStack_30 = 0;
  piStack_2c = (int *)0x0;
  func_0x0019fd2c(apuStack_70);
code_r0x00067216:
  func_0x0000b122(iVar7);
  return iVar3;
}



void FUN_00154216(int *param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  iVar1 = (**(code **)(*param_1 + 0x298))(param_1,param_2);
  if (iVar1 != 0) {
    FUN_00029686(iVar1,param_3);
  }
  return;
}


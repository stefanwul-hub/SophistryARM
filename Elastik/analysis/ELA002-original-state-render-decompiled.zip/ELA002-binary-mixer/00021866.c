
undefined4 FUN_00021866(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  
  if (*(int *)(param_1 + 0x3c) != 0) {
    return *(undefined4 *)(param_1 + 0x3c);
  }
  uVar2 = __Znwm(0x20);
  FUN_00029d44(uVar2);
  uVar2 = FUN_0002dfa6(uVar2);
  *(undefined4 *)(param_1 + 0x3c) = uVar2;
  uVar2 = func_0x000217c0(param_1);
  iVar5 = 0;
  while( true ) {
    iVar3 = FUN_00029ddc(uVar2);
    if (iVar3 <= iVar5) break;
    uVar4 = FUN_0002a364(uVar2,iVar5);
    cVar1 = func_0x000a0cd0(uVar4);
    if (cVar1 == '\0') {
      uVar4 = func_0x000a0cc4(uVar4);
      FUN_0002bb40(*(undefined4 *)(param_1 + 0x3c),uVar4);
    }
    iVar5 = iVar5 + 1;
  }
  return *(undefined4 *)(param_1 + 0x3c);
}


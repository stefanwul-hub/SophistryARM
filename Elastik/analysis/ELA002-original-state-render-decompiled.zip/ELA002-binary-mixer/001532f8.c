
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_001532f8(int *param_1,undefined4 param_2,int param_3,int *param_4)

{
  char cVar1;
  undefined1 uVar2;
  int *piVar3;
  int iVar4;
  float *pfVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  float *pfVar9;
  undefined4 *puVar10;
  longdouble lVar11;
  float fVar12;
  float fVar13;
  int iStack_5c;
  int iStack_54;
  int iStack_50;
  int *piStack_40;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 auStack_28 [8];
  int aiStack_20 [4];
  
  aiStack_20[0] = 0;
  if (*(char *)((int)param_1 + 0x92) == '\0') {
    return param_1;
  }
  if (param_1[0x26] == 0) {
    return (int *)0x0;
  }
  piVar3 = (int *)func_0x0014a4a0(param_1[0x26]);
  if ((char)piVar3 != '\0') {
    return piVar3;
  }
  iVar4 = func_0x0014a466(param_1[0x26]);
  if (iVar4 == 0) {
    return (int *)0x0;
  }
  iVar4 = func_0x001f0b58(iVar4);
  if (iVar4 == 0) {
    return (int *)0x0;
  }
  iStack_5c = func_0x0001c8ba(param_1);
  iVar4 = func_0x0014aaa2(param_1[0x26]);
  iVar8 = (iVar4 * 2) % iStack_5c;
  iVar4 = func_0x0001c8ba(param_1);
  if (2 < iVar4) {
    iVar4 = 2;
  }
  if ((iVar4 < iStack_5c) && (iVar4 = func_0x0001c8ba(param_1), iStack_5c = 2, iVar4 < 3)) {
    iStack_5c = iVar4;
  }
  if (param_1[0x22] == -1) {
    iStack_54 = 0;
  }
  else {
    uVar6 = func_0x00149f7c(param_1[0x26]);
    cVar1 = func_0x0015f8e4(uVar6);
    if ((cVar1 != '\0') && (iVar4 = func_0x0001b99e(param_1[0x20]), iVar4 != 0)) {
      iVar7 = func_0x0001b9ac(param_1[0x20]);
      piVar3 = (int *)((iVar7 + (int)param_4) / iVar4);
      iVar4 = (iVar7 + (int)param_4) % iVar4;
      if ((int)param_4 < iVar4) {
        if (0 < iStack_5c) {
          puVar10 = (undefined4 *)(param_3 + iVar8 * 4);
          iVar4 = 0;
          do {
            piVar3 = (int *)_memset(*puVar10,0,param_1[0x22] << 2);
            iVar4 = iVar4 + 1;
            puVar10 = puVar10 + 1;
          } while (iStack_5c != iVar4);
        }
        param_1[0x22] = 0;
        return piVar3;
      }
      param_1[0x22] = (int)param_4 - iVar4;
    }
    if ((param_1[0x22] != 0) && (0 < iStack_5c)) {
      puVar10 = (undefined4 *)(param_3 + iVar8 * 4);
      iVar4 = 0;
      do {
        _memset(*puVar10,0,param_1[0x22] << 2);
        iVar4 = iVar4 + 1;
        puVar10 = puVar10 + 1;
      } while (iStack_5c != iVar4);
    }
    iStack_54 = param_1[0x22];
    param_1[0x22] = -1;
  }
  if (*(char *)((int)param_1 + 0x91) == '\0') {
    func_0x0014a576(param_1[0x26],1);
  }
  FUN_0014ac64(param_1[0x26]);
  if (iStack_54 < (int)param_4) {
    iStack_50 = 0;
    do {
      if (0 < iStack_5c) {
        piStack_40 = (int *)(param_3 + iVar8 * 4);
        iVar4 = 0;
        do {
          iStack_50 = FUN_00152664(param_1,iStack_54 * 4 + *piStack_40,iVar4,param_1[0x2d],
                                   (int)param_4 - iStack_54,aiStack_20,auStack_28);
          pfVar9 = (float *)(param_1 + iVar4 * 3 + 0x32);
          lVar11 = (longdouble)func_0x00149f40(param_1[0x26]);
          fVar12 = (float)lVar11;
          iVar7 = func_0x0014a3b6(param_1[0x26]);
          if (iVar4 == iVar7) {
            lVar11 = (longdouble)func_0x0014a352(param_1[0x26]);
            fVar12 = fVar12 * (float)lVar11;
          }
          param_1[iVar4 * 3 + 0x32] = (int)fVar12;
          param_1[iVar4 * 3 + 0x34] =
               (int)((fVar12 - (float)param_1[iVar4 * 3 + 0x33]) / FLOAT_00365d1c);
          pfVar5 = (float *)(iStack_54 * 4 + *piStack_40);
          if (0 < iStack_50) {
            iVar7 = 0;
LAB_00153791:
            do {
              fVar12 = (float)param_1[iVar4 * 3 + 0x34];
              if (fVar12 != 0.0) {
                fVar13 = fVar12 + (float)param_1[iVar4 * 3 + 0x33];
                param_1[iVar4 * 3 + 0x33] = (int)fVar13;
                if ((fVar12 <= 0.0) || (fVar13 < *pfVar9)) {
                  if (0.0 <= fVar12) goto LAB_00153779;
                  fVar12 = *pfVar9;
                  if (fVar12 < fVar13) {
                    *pfVar5 = *pfVar5 * (float)param_1[iVar4 * 3 + 0x33];
                    pfVar5 = pfVar5 + 1;
                    iVar7 = iVar7 + 1;
                    if (iVar7 == iStack_50) break;
                    goto LAB_00153791;
                  }
                }
                else {
                  fVar12 = *pfVar9;
                }
                param_1[iVar4 * 3 + 0x33] = (int)fVar12;
                param_1[iVar4 * 3 + 0x34] = 0;
              }
LAB_00153779:
              *pfVar5 = *pfVar5 * (float)param_1[iVar4 * 3 + 0x33];
              pfVar5 = pfVar5 + 1;
              iVar7 = iVar7 + 1;
            } while (iVar7 != iStack_50);
          }
          iVar4 = iVar4 + 1;
          piStack_40 = piStack_40 + 1;
        } while (iStack_5c != iVar4);
      }
      param_1[0x2d] = aiStack_20[0];
      iStack_54 = iStack_54 + iStack_50;
      func_0x0014a53e(param_1[0x26],aiStack_20[0]);
      lVar11 = (longdouble)func_0x0000a8fe();
      func_0x0014a558(param_1[0x26],(double)lVar11);
      iVar4 = func_0x00149f34(param_1[0x26]);
      if (((iVar4 == 0) && (param_1[0x2d] == param_1[0x27])) ||
         ((iVar4 = func_0x00149f34(param_1[0x26]), iVar4 != 0 && (param_1[0x2d] == param_1[0x28]))))
      {
        if ((char)param_1[0x4a] != '\0') {
          FUN_0000ab14("loop end detected");
        }
        iVar4 = func_0x0014a1f4(param_1[0x26]);
        if (iVar4 == 0) {
          *(undefined1 *)((int)param_1 + 0x91) = 1;
          break;
        }
        iVar4 = param_1[0x27];
        iVar7 = FUN_0014acc6(param_1[0x26]);
        if ((iVar4 == iVar7) &&
           (iVar4 = param_1[0x28], iVar7 = FUN_0014ad0a(param_1[0x26]), iVar4 == iVar7)) {
          if (param_1[0x27] != 0) {
            iVar4 = func_0x0001c8ba(param_1);
            if (iVar4 < 3) {
              if (iVar4 < 1) goto LAB_0015348f;
            }
            else {
              iVar4 = 2;
            }
            iVar7 = 0;
            piVar3 = param_1;
            do {
              piVar3[0x46] = 0x3c23d70a;
              piVar3[0x45] = 0;
              piVar3[0x44] = 0x3f800000;
              iVar7 = iVar7 + 1;
              piVar3 = piVar3 + 3;
            } while (iVar4 != iVar7);
          }
        }
        else {
          FUN_00152472(param_1);
        }
      }
LAB_0015348f:
    } while (iStack_54 < (int)param_4);
  }
  cVar1 = func_0x0014a1a8(param_1[0x26]);
  if (cVar1 == '\0') {
    param_1[0x2b] = -1;
    piVar3 = param_1;
    goto LAB_001534c1;
  }
  lVar11 = (longdouble)func_0x00149f4c(param_1[0x26]);
  lVar11 = (longdouble)_pow(0,0x40000000,(double)((float)lVar11 * FLOAT_00365cd4));
  fVar12 = (float)((double)lVar11 * DOUBLE_00364820);
  uStack_30 = *(undefined4 *)(param_3 + iVar8 * 4);
  uStack_2c = *(undefined4 *)(param_3 + 4 + iVar8 * 4);
  iVar4 = func_0x0014a18e(param_1[0x26]);
  if (iVar4 != param_1[0x2b]) {
    piVar3 = (int *)param_1[0x2e];
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x24c))(piVar3);
    }
    piVar3 = (int *)param_1[0x2f];
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x24c))(piVar3);
    }
    piVar3 = (int *)param_1[0x30];
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x24c))(piVar3);
    }
    piVar3 = (int *)param_1[0x31];
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x24c))(piVar3);
    }
  }
  iVar4 = func_0x0014a18e(param_1[0x26]);
  if (iVar4 == 0) {
    iVar4 = func_0x00149f1a(param_1[0x26]);
    func_0x001f2cea(param_1[0x2f],iVar4 + 1);
    func_0x001f306c(param_1[0x2f],fVar12);
    lVar11 = (longdouble)func_0x0014a14e(param_1[0x26]);
    func_0x001f3094(param_1[0x2f],(float)lVar11);
    func_0x001f30de(param_1[0x2f],*(undefined4 *)(param_1[0x26] + 0xc));
    func_0x001f3122(param_1[0x2f],*(undefined4 *)(param_1[0x26] + 0x10));
    func_0x001f3162(param_1[0x2f],*(undefined4 *)(param_1[0x26] + 0x14));
    piVar3 = (int *)param_1[0x2f];
LAB_00153b70:
    (**(code **)(*piVar3 + 0x27c))(piVar3,&uStack_30,&uStack_30,param_4);
  }
  else {
    iVar4 = func_0x0014a18e(param_1[0x26]);
    if (iVar4 == 1) {
      iVar4 = func_0x00149f1a(param_1[0x26]);
      func_0x001f2cea(param_1[0x2e],iVar4 + 1);
      func_0x001f306c(param_1[0x2e],fVar12);
      lVar11 = (longdouble)func_0x0014a14e(param_1[0x26]);
      func_0x001f3094(param_1[0x2e],(float)lVar11);
      func_0x001f30de(param_1[0x2e],*(undefined4 *)(param_1[0x26] + 0xc));
      func_0x001f3122(param_1[0x2e],*(undefined4 *)(param_1[0x26] + 0x10));
      func_0x001f3162(param_1[0x2e],*(undefined4 *)(param_1[0x26] + 0x14));
      piVar3 = (int *)param_1[0x2e];
      goto LAB_00153b70;
    }
    iVar4 = func_0x0014a18e(param_1[0x26]);
    if (iVar4 == 2) {
      iVar4 = func_0x00149f1a(param_1[0x26]);
      func_0x001f2cea(param_1[0x30],iVar4 + 1);
      func_0x001f306c(param_1[0x30],fVar12);
      lVar11 = (longdouble)func_0x0014a14e(param_1[0x26]);
      func_0x001f3094(param_1[0x30],(float)lVar11);
      piVar3 = (int *)param_1[0x30];
      goto LAB_00153b70;
    }
    iVar4 = func_0x0014a18e(param_1[0x26]);
    if (iVar4 == 3) {
      iVar4 = func_0x00149f1a(param_1[0x26]);
      func_0x001f2cea(param_1[0x31],iVar4 + 1);
      func_0x001f306c(param_1[0x31],fVar12);
      lVar11 = (longdouble)func_0x0014a14e(param_1[0x26]);
      func_0x001f3094(param_1[0x31],(float)lVar11);
      piVar3 = (int *)param_1[0x31];
      goto LAB_00153b70;
    }
  }
  piVar3 = (int *)func_0x0014a18e(param_1[0x26]);
  param_1[0x2b] = (int)piVar3;
LAB_001534c1:
  if ((float)param_1[0x3a] != 0.0) {
    pfVar9 = *(float **)(param_3 + iVar8 * 4);
    pfVar5 = *(float **)(param_3 + 4 + iVar8 * 4);
    piVar3 = param_4;
    if (0 < (int)param_4) {
      iVar4 = 0;
      do {
        fVar12 = (float)param_1[0x39] + (float)param_1[0x3a];
        param_1[0x39] = (int)fVar12;
        if (((0.0 < (float)param_1[0x3a]) && ((float)param_1[0x38] <= fVar12)) ||
           (((float)param_1[0x3a] < 0.0 && (fVar12 <= (float)param_1[0x38])))) {
          param_1[0x39] = param_1[0x38];
          param_1[0x3a] = 0;
        }
        do {
          *pfVar9 = *pfVar9 * (float)param_1[0x39];
          pfVar9 = pfVar9 + 1;
          *pfVar5 = *pfVar5 * (float)param_1[0x39];
          pfVar5 = pfVar5 + 1;
          iVar4 = iVar4 + 1;
          piVar3 = param_1;
          if ((int)param_4 <= iVar4) goto LAB_001534f1;
        } while ((float)param_1[0x3a] == 0.0);
      } while( true );
    }
  }
LAB_001534f1:
  if ((float)param_1[0x3d] != 0.0) {
    pfVar9 = *(float **)(iVar8 * 4 + param_3);
    pfVar5 = *(float **)(param_3 + 4 + iVar8 * 4);
    piVar3 = param_4;
    if (0 < (int)param_4) {
      iVar4 = 0;
      do {
        fVar12 = (float)param_1[0x3c] + (float)param_1[0x3d];
        param_1[0x3c] = (int)fVar12;
        if (((0.0 < (float)param_1[0x3d]) && ((float)param_1[0x3b] <= fVar12)) ||
           (((float)param_1[0x3d] < 0.0 && (fVar12 <= (float)param_1[0x3b])))) {
          param_1[0x3c] = param_1[0x3b];
          param_1[0x3d] = 0;
        }
        do {
          *pfVar9 = *pfVar9 * (float)param_1[0x3c];
          pfVar9 = pfVar9 + 1;
          *pfVar5 = *pfVar5 * (float)param_1[0x3c];
          pfVar5 = pfVar5 + 1;
          iVar4 = iVar4 + 1;
          piVar3 = param_1;
          if ((int)param_4 <= iVar4) goto LAB_00153598;
        } while ((float)param_1[0x3d] == 0.0);
      } while( true );
    }
  }
LAB_00153598:
  if (((*(char *)((int)param_1 + 0x91) != '\0') && ((float)param_1[0x3d] == 0.0)) &&
     (!NAN((float)param_1[0x3d]))) {
    (**(code **)(*param_1 + 0x368))(param_1);
    uVar2 = func_0x0014a32c(param_1[0x26]);
    func_0x0001b35a(param_1[0x20],uVar2,0);
    piVar3 = (int *)FUN_0001b3bc(param_1[0x20]);
    if (((char)piVar3 == '\0') && (piVar3 = (int *)func_0x001563f4(param_1[0x20]), 0 < (int)piVar3))
    {
      piVar3 = (int *)param_1[0x20];
      piVar3[0x2c] = 0;
    }
  }
  return piVar3;
}


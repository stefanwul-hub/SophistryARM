
void FUN_00161700(int param_1,int param_2,undefined4 param_3,int param_4,uint param_5)

{
  uint uVar1;
  float *pfVar2;
  float *pfVar3;
  int iVar4;
  uint uVar5;
  
  uVar1 = param_5 & 0xff;
  if ((param_5 & 0x100) == 0) {
    uVar1 = param_5;
  }
  uVar5 = 0;
  if (uVar1 != 0) {
    do {
      pfVar3 = *(float **)(uVar5 * 4 + param_1);
      pfVar2 = *(float **)(uVar5 * 4 + param_2);
      if (param_4 != 0) {
        iVar4 = 0;
        do {
          *pfVar3 = *pfVar3 + *pfVar2;
          pfVar3 = pfVar3 + 1;
          pfVar2 = pfVar2 + 1;
          iVar4 = iVar4 + 1;
        } while (param_4 != iVar4);
      }
      uVar5 = uVar5 + 1;
    } while (uVar5 != uVar1);
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00162ba6(undefined4 *param_1)

{
  func_0x0002dc66(param_1);
  *param_1 = &UNK_0038c748;
  param_1[5] = 0;
  param_1[4] = 0;
  param_1[6] = 0;
  return;
}



undefined4 FUN_0001b3bc(int param_1)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = 0;
  while( true ) {
    iVar3 = FUN_00029ddc(*(undefined4 *)(param_1 + 0xac));
    if (iVar3 <= iVar4) {
      return 0;
    }
    piVar2 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0xac),iVar4);
    cVar1 = (**(code **)(*piVar2 + 0x36c))(piVar2);
    if (cVar1 != '\0') break;
    iVar4 = iVar4 + 1;
  }
  return 1;
}



int * FUN_001b5932(int *param_1,undefined4 param_2)

{
  undefined1 uVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int iVar5;
  
  uVar2 = __Znwm(0x20);
  FUN_0002765e(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  (**(code **)(*piVar3 + 0x1a4))(piVar3,0x20000);
  uVar2 = __Znwm(0x1c);
  FUN_00162ba6(uVar2);
  uVar2 = FUN_0002dfa6(uVar2);
  piVar4 = (int *)FUN_00162cd6(uVar2,piVar3);
  uVar1 = (**(code **)(*param_1 + 0x2ac))(param_1,param_2,piVar4);
  *(undefined1 *)(param_1 + 0xb) = uVar1;
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 0x44))(piVar4);
  }
  (**(code **)(*piVar3 + 0x48))(piVar3);
  iVar5 = (**(code **)(*param_1 + 0x2a4))(param_1);
  if (iVar5 != 0) {
    piVar4 = (int *)(**(code **)(*param_1 + 0x2a4))(param_1);
    piVar3 = (int *)(**(code **)(*piVar4 + 0x1a4))(piVar4,piVar3);
  }
  if ((char)param_1[0xb] == '\0') {
    piVar3 = (int *)0x0;
  }
  return piVar3;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001e8b3e(undefined4 *param_1)

{
  func_0x0002dc66(param_1);
  *param_1 = &UNK_0039a188;
  param_1[3] = 0;
  param_1[5] = 0;
  param_1[4] = 0;
  return;
}


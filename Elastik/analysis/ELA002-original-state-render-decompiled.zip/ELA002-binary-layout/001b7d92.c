
bool FUN_001b7d92(undefined4 param_1,int *param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  bool bVar3;
  undefined1 auStack_5c [84];
  
  piVar1 = (int *)(**(code **)(*param_2 + 0x248))(param_2);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x40))(piVar1);
    FUN_0000bea2(auStack_5c);
    iVar2 = _setjmp(auStack_5c);
    if (iVar2 == 0) {
      iVar2 = func_0x001b7b16(param_3,piVar1);
      FUN_0000bec0(auStack_5c);
      bVar3 = iVar2 != -1;
    }
    else {
      bVar3 = false;
    }
    (**(code **)(*piVar1 + 0x1a4))(piVar1);
    (**(code **)(*piVar1 + 0x44))(piVar1);
    return bVar3;
  }
  return false;
}


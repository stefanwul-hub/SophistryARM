
undefined4 FUN_001b9a32(undefined4 param_1,int param_2)

{
  char cVar1;
  int aiStack_10 [3];
  
  if (param_2 != 0) {
    cVar1 = func_0x00163006(param_2,aiStack_10);
    if ((cVar1 != '\0') && (aiStack_10[0] == 1)) {
      return 1;
    }
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001b71e2(int *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  
  if (param_1 == (int *)0x0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x1ea,uVar1,"this != 0");
  }
  if (param_1[10] == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x1ea,uVar1,"_stream");
  }
  if (param_1[7] == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x1ea,uVar1,"_classDescriptions");
  }
  func_0x0002ba66(param_1[7],1);
  func_0x001640f2(param_1[10],1);
  uVar1 = FUN_00029ddc(param_1[7]);
  func_0x001640f2(param_1[10],uVar1);
  for (iVar4 = 0; iVar3 = FUN_00029ddc(param_1[7]), iVar4 < iVar3; iVar4 = iVar4 + 1) {
    uVar1 = FUN_0002a364(param_1[7],iVar4);
    uVar2 = (**(code **)(*param_1 + 0x2c4))(param_1,uVar1);
    func_0x001640f2(param_1[10],uVar2);
    uVar2 = func_0x0001fa72(uVar1);
    func_0x001640f2(param_1[10],uVar2);
    uVar1 = func_0x0001f4dc(uVar1);
    func_0x00164748(param_1[10],uVar1);
  }
  return;
}


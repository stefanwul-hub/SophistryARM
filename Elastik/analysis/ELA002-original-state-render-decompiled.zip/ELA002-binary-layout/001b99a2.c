
int FUN_001b99a2(int *param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  
  if (param_2 != (int *)0x0) {
    iVar2 = (**(code **)(*param_2 + 0x248))(param_2);
    if (iVar2 != 0) {
      uVar3 = __Znwm(0x1c);
      FUN_00162ba6(uVar3);
      piVar4 = (int *)FUN_0002dfa6(uVar3);
      uVar3 = (**(code **)(*piVar4 + 0x48))(piVar4);
      func_0x00162f1a(uVar3,iVar2);
      cVar1 = (**(code **)(*param_1 + 0x2d0))(param_1,uVar3);
      return (int)cVar1;
    }
  }
  return 0;
}


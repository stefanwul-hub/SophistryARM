
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001b73d8(int *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  int iStack_20;
  
  if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x1fd,uVar2,"this != 0");
  }
  if (param_1[10] == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x1fd,uVar2,"_stream");
  }
  if (param_1[6] == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x1fd,uVar2,"_objects");
  }
  func_0x0002ba66(param_1[6],1);
  param_1[8] = 2;
  uVar2 = FUN_00029ddc(param_1[6]);
  func_0x001640f2(param_1[10],uVar2);
  iStack_20 = 0;
  while( true ) {
    iVar3 = FUN_00029ddc(param_1[6]);
    if (iVar3 <= iStack_20) break;
    pcVar1 = *(code **)(*param_1 + 0x2c4);
    piVar4 = (int *)FUN_0002a364(param_1[6],iStack_20);
    uVar2 = (**(code **)(*piVar4 + 0x74))(piVar4);
    uVar2 = (*pcVar1)(param_1,uVar2);
    func_0x001640f2(param_1[10],uVar2);
    iStack_20 = iStack_20 + 1;
  }
  iVar3 = 0;
  while( true ) {
    iVar5 = FUN_00029ddc(param_1[6]);
    if (iVar5 <= iVar3) break;
    piVar4 = (int *)FUN_0002a364(param_1[6],iVar3);
    (**(code **)(*piVar4 + 0x70))(piVar4,param_1);
    iVar3 = iVar3 + 1;
  }
  return;
}


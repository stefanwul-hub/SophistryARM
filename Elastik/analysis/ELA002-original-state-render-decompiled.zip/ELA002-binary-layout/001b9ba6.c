
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001b9ba6(int *param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  undefined1 auStack_6c [76];
  int *piStack_20;
  
  iVar3 = func_0x0002926c(param_3);
  if (iVar3 == 0) {
    return 0;
  }
  uVar4 = __Znwm(0x24);
  func_0x0017e50c(uVar4);
  piVar5 = (int *)FUN_0002dfa6(uVar4);
  func_0x0017f8a0(piVar5,iVar3);
  if (piVar5 != (int *)0x0) {
    FUN_0000bea2(auStack_6c);
    iVar3 = _setjmp(auStack_6c);
    if (iVar3 == 0) {
      iVar3 = func_0x001b7b16(param_2,piVar5);
      if (iVar3 == -1) {
        uVar4 = FUN_00033b90("GNArchiveTagNotFoundException");
        func_0x0000bf34(uVar4);
      }
      uVar4 = __Znwm(0x1c);
      FUN_00162ba6(uVar4);
      uVar4 = FUN_0002dfa6(uVar4);
      piVar6 = (int *)func_0x00162f1a(uVar4,piVar5);
      if (piVar6 == (int *)0x0) {
        uVar4 = FUN_00033b90("GNCodingException");
        FUN_0000bfd6(uVar4,"Cannot open stream");
      }
      uVar4 = (**(code **)(*param_1 + 0x2ac))(param_1,piVar6);
      FUN_0000bec0(auStack_6c);
      if (piVar6 != (int *)0x0) {
        (**(code **)(*piVar6 + 0x44))(piVar6);
      }
    }
    else {
      piVar6 = (int *)(**(code **)(*piStack_20 + 0x1ac))(piStack_20);
      pcVar1 = *(code **)(*piVar6 + 0x88);
      uVar4 = FUN_00033b90("GNArchiveTagNotFoundException");
      cVar2 = (*pcVar1)(piVar6,uVar4);
      if (cVar2 == '\0') {
        (**(code **)(*piVar5 + 0x1a4))(piVar5);
        (**(code **)(*piVar5 + 0x44))(piVar5);
        (**(code **)(*piStack_20 + 0x1a8))(piStack_20);
        return 0;
      }
      (**(code **)(*piStack_20 + 0x1b8))(piStack_20);
      uVar4 = 0;
    }
    (**(code **)(*piVar5 + 0x1a4))(piVar5);
    (**(code **)(*piVar5 + 0x44))(piVar5);
    return uVar4;
  }
  return 0;
}


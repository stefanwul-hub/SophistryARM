
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001b7f6c(undefined4 param_1,undefined4 param_2,int *param_3)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined1 auStack_60 [76];
  int *piStack_14;
  undefined4 uStack_10;
  
  uStack_10 = 0;
  piVar2 = (int *)(**(code **)(*param_3 + 0x248))(param_3);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x40))(piVar2);
    FUN_0000bea2(auStack_60);
    iVar3 = _setjmp(auStack_60);
    if (iVar3 == 0) {
      iVar3 = func_0x001b7b16(param_2,piVar2);
      if (iVar3 == -1) {
        uVar4 = FUN_00033b90("GNArchiveTagNotFoundException");
        func_0x0000bf34(uVar4);
      }
      cVar1 = func_0x0017fb68(piVar2,&uStack_10);
      if (cVar1 == '\0') {
        uVar4 = FUN_00033b90("GNCodingException");
        func_0x0000bf34(uVar4);
      }
      uVar4 = FUN_000858da(uStack_10);
      FUN_0000bec0(auStack_60);
    }
    else {
      (**(code **)(*piStack_14 + 0x1b8))(piStack_14);
      uVar4 = 0;
    }
    (**(code **)(*piVar2 + 0x1a4))(piVar2);
    (**(code **)(*piVar2 + 0x44))(piVar2);
    return uVar4;
  }
  return 0;
}


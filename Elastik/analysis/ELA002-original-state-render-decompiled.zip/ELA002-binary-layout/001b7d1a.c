
undefined4 FUN_001b7d1a(undefined4 param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  int aiStack_10 [2];
  
  piVar2 = (int *)(**(code **)(*param_2 + 0x248))(param_2);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x40))(piVar2);
    cVar1 = func_0x0017fb68(piVar2,aiStack_10);
    if ((cVar1 != '\0') && (aiStack_10[0] == 0x474e4f41)) {
      (**(code **)(*piVar2 + 0x1a4))(piVar2);
      (**(code **)(*piVar2 + 0x44))(piVar2);
      return 1;
    }
    (**(code **)(*piVar2 + 0x1a4))(piVar2);
    (**(code **)(*piVar2 + 0x44))(piVar2);
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_001b8078(undefined4 param_1,undefined4 param_2,int *param_3)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined1 auStack_5c [76];
  int *piStack_10;
  
  piVar1 = (int *)(**(code **)(*param_3 + 0x248))(param_3);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x40))(piVar1);
    FUN_0000bea2(auStack_5c);
    iVar2 = _setjmp(auStack_5c);
    if (iVar2 == 0) {
      iVar2 = func_0x001b7b16(param_2,piVar1);
      if (iVar2 == -1) {
        uVar3 = FUN_00033b90("GNArchiveTagNotFoundException");
        func_0x0000bf34(uVar3);
      }
      iVar2 = func_0x00180166(piVar1,iVar2);
      if (iVar2 == 0) {
        uVar3 = FUN_00033b90("GNCodingException");
        func_0x0000bf34(uVar3);
      }
      FUN_0000bec0(auStack_5c);
    }
    else {
      (**(code **)(*piStack_10 + 0x1b8))(piStack_10);
      iVar2 = 0;
    }
    (**(code **)(*piVar1 + 0x1a4))(piVar1);
    (**(code **)(*piVar1 + 0x44))(piVar1);
    return iVar2;
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001b7e2a(undefined4 param_1,undefined4 param_2,int *param_3)

{
  char cVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined1 auStack_70 [76];
  int *piStack_24;
  int aiStack_20 [4];
  
  piVar2 = (int *)(**(code **)(*param_3 + 0x248))(param_3);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x40))(piVar2);
    FUN_0000bea2(auStack_70);
    iVar3 = _setjmp(auStack_70);
    if (iVar3 == 0) {
      aiStack_20[0] = func_0x001b7b16(param_2,piVar2);
      if (aiStack_20[0] == -1) {
        uVar4 = FUN_00033b90("GNArchiveTagNotFoundException");
        func_0x0000bf34(uVar4);
      }
      iVar3 = FUN_0000aecc(aiStack_20[0] + -1);
      cVar1 = (**(code **)(*piVar2 + 0x1ac))(piVar2,iVar3,aiStack_20);
      if (cVar1 == '\0') {
        uVar4 = FUN_00033b90("GNCodingException");
        func_0x0000bf34(uVar4);
      }
      *(undefined1 *)(iVar3 + aiStack_20[0]) = 0;
      uVar4 = func_0x00039354(iVar3);
      func_0x0000b122(iVar3);
      FUN_0000bec0(auStack_70);
    }
    else {
      (**(code **)(*piStack_24 + 0x1b8))(piStack_24);
      uVar4 = 0;
    }
    (**(code **)(*piVar2 + 0x1a4))(piVar2);
    (**(code **)(*piVar2 + 0x44))(piVar2);
    return uVar4;
  }
  return 0;
}


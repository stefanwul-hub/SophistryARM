
void FUN_0001b52e(int *param_1,undefined4 param_2)

{
  undefined1 uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  uint uVar7;
  
  iVar2 = FUN_00060ab6(param_2);
  if (iVar2 == 0xb0) {
    iVar2 = FUN_00029ddc(param_1[0x53]);
    if (iVar2 != 0) {
      iVar2 = 0;
      while( true ) {
        iVar4 = FUN_00029ddc(param_1[0x53]);
        if (iVar4 <= iVar2) break;
        uVar3 = FUN_0002a364(param_1[0x53],iVar2);
        uVar1 = FUN_00060cfe(param_2);
        func_0x00156c38(uVar3,uVar1);
        iVar2 = iVar2 + 1;
      }
      return;
    }
    iVar2 = (**(code **)(*param_1 + 0x3b8))(param_1);
    if (iVar2 != 0) {
      uVar3 = (**(code **)(*param_1 + 0x3b8))(param_1);
      uVar3 = func_0x0015f7d6(uVar3);
      iVar2 = 0;
      while( true ) {
        iVar4 = FUN_00029ddc(uVar3);
        if (iVar4 <= iVar2) break;
        uVar5 = FUN_0002a364(uVar3,iVar2);
        uVar6 = func_0x00156c46(uVar5);
        uVar7 = FUN_00060cfe(param_2);
        if (uVar6 == (uVar7 & 0xff)) {
          uVar1 = FUN_00060d72(param_2);
          func_0x00157010(uVar5,uVar1);
        }
        iVar2 = iVar2 + 1;
      }
    }
  }
  return;
}


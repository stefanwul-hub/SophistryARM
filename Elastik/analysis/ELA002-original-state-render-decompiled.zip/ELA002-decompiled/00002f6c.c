
undefined4
FUN_00002f6c(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
            )

{
  undefined4 uVar1;
  
  func_0x000086a8(*(undefined4 *)(param_1 + 300),param_2,*(undefined8 *)(param_1 + 0x54));
  func_0x00009398(param_1 + 0x140,*(undefined4 *)(param_1 + 0x170));
  func_0x00009398(param_1 + 0x158,*(undefined4 *)(param_1 + 0x170));
  uVar1 = func_0x000085c0(*(undefined4 *)(param_1 + 300));
  func_0x0001ca16(*(undefined4 *)(param_1 + 0x13c),uVar1);
  uVar1 = func_0x000085cc(*(undefined4 *)(param_1 + 300));
  func_0x0001ca08(*(undefined4 *)(param_1 + 0x13c),uVar1);
  func_0x0001cac0(*(undefined4 *)(param_1 + 0x13c),*(undefined4 *)(param_1 + 0x170));
  (**(code **)(**(int **)(param_1 + 0x13c) + 0x354))(*(int **)(param_1 + 0x13c));
  (**(code **)(**(int **)(param_1 + 0x13c) + 0x27c))
            (*(int **)(param_1 + 0x13c),param_4,param_5,param_3);
  func_0x0002ad82(*(undefined4 *)(param_1 + 0x170));
  return 0;
}


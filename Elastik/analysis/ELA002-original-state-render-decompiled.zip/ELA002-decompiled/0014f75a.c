
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0014f75a(undefined4 *param_1)

{
  func_0x0001bfca(param_1);
  *param_1 = &UNK_0038ab68;
  param_1[0x21] = 0;
  param_1[0x26] = 0;
  param_1[0x2b] = 0;
  param_1[0x20] = 0;
  param_1[0x34] = 2;
  return;
}


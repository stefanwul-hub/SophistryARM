
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00066996(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piStack_20;
  
  puVar1 = (undefined4 *)__Znwm(0x18);
  func_0x0002dc66(puVar1);
  *puVar1 = &UNK_00371a88;
  puVar1[3] = 0;
  puVar1[4] = 0;
  puVar1[5] = 0;
  piVar2 = (int *)FUN_0002dfa6(puVar1);
  uVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
  piStack_20 = (int *)&stack0x00000008;
  if (param_1 != 0) {
    do {
      piVar2 = piStack_20 + 1;
      if (*piStack_20 == 0) {
        func_0x0000ab14(
                       "GNDictionary::createWithObjectsAndKeys(): Inconsistent number of objects and keys."
                       );
        return uVar3;
      }
      func_0x00066284(uVar3,param_1,*piStack_20);
      piStack_20 = piStack_20 + 2;
      param_1 = *piVar2;
    } while (param_1 != 0);
  }
  return uVar3;
}


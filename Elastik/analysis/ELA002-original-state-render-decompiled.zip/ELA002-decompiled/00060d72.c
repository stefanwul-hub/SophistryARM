
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined1 FUN_00060d72(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 != 0) {
    return *(undefined1 *)(param_1 + 0xe);
  }
  uVar1 = func_0x0000a930("/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNMidiEvent.cpp");
  uVar2 = FUN_00033b90("GNAssertionException");
  func_0x0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0xff,uVar1,"this != 0");
  return mach_header_00000000.filetype._2_1_;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0001b9ba(int param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  int *piVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  int iVar15;
  char *pcVar16;
  char *pcVar17;
  
  iVar2 = func_0x0001c8ba(param_1);
  if (iVar2 != 0x10) {
    uVar1 = *(uint *)(param_1 + 0x58);
    switch(uVar1) {
    case 0:
      iVar2 = 0;
      break;
    case 1:
      iVar2 = iRam003d3fb8;
      if (iRam003d3fb8 == 0) {
        uVar10 = __Znwm(0x20);
        FUN_00029d44(uVar10);
        iRam003d3fb8 = FUN_0002dfa6(uVar10);
        uVar10 = FUN_00033b90("channelFormat");
        uVar12 = FUN_000858da(1);
        uVar13 = FUN_00033b90("name");
        uVar14 = FUN_00033b90("Mono");
        uVar10 = FUN_00066996(uVar14,uVar13,uVar12,uVar10,0);
        func_0x0002bb40(iRam003d3fb8,uVar10);
        iVar2 = iRam003d3fb8;
      }
      break;
    case 2:
      iVar2 = iRam003d3fb4;
      if (iRam003d3fb4 == 0) {
        uVar10 = __Znwm(0x20);
        FUN_00029d44(uVar10);
        iRam003d3fb4 = FUN_0002dfa6(uVar10);
        uVar10 = FUN_00033b90("channelFormat");
        uVar12 = FUN_000858da(2);
        uVar13 = FUN_00033b90("name");
        uVar14 = FUN_00033b90("Stereo");
        uVar10 = FUN_00066996(uVar14,uVar13,uVar12,uVar10,0);
        func_0x0002bb40(iRam003d3fb4,uVar10);
        iVar2 = iRam003d3fb4;
      }
      break;
    default:
      uVar10 = __Znwm(0x20);
      FUN_00029d44(uVar10);
      piVar11 = (int *)FUN_0002dfa6(uVar10);
      iVar2 = (**(code **)(*piVar11 + 0x48))(piVar11);
      iVar15 = 0;
      if ((uVar1 & 0x100) == 0) {
        while (iVar15 < (int)uVar1) {
          uVar10 = FUN_00033b90("channelFormat");
          uVar12 = FUN_000858da(1);
          uVar13 = FUN_00033b90("name");
          iVar15 = iVar15 + 1;
          uVar14 = func_0x0003dd2a("Mono %d",iVar15);
          uVar10 = FUN_00066996(uVar14,uVar13,uVar12,uVar10,0);
          func_0x0002bb40(iVar2,uVar10);
        }
      }
      else {
        param_1._0_1_ = (char)uVar1;
        if ((char)param_1 != '\0') {
          do {
            uVar10 = FUN_00033b90("channelFormat");
            uVar12 = FUN_000858da(1);
            uVar13 = FUN_00033b90("name");
            iVar15 = iVar15 + 1;
            uVar14 = func_0x0003dd2a("Mono %d",iVar15);
            uVar10 = FUN_00066996(uVar14,uVar13,uVar12,uVar10,0);
            func_0x0002bb40(iVar2,uVar10);
          } while (iVar15 < (int)(uVar1 & 0xff));
        }
      }
      break;
    case 4:
      iVar2 = iRam003d3fb0;
      if (iRam003d3fb0 == 0) {
        uVar10 = __Znwm(0x20);
        FUN_00029d44(uVar10);
        iRam003d3fb0 = FUN_0002dfa6(uVar10);
        uVar10 = FUN_00033b90("channelFormat");
        uVar12 = FUN_000858da(2);
        uVar13 = FUN_00033b90("name");
        uVar14 = FUN_00033b90("Stereo Front");
        uVar10 = FUN_00066996(uVar14,uVar13,uVar12,uVar10,0);
        func_0x0002bb40(iRam003d3fb0,uVar10);
        uVar10 = FUN_00033b90("channelFormat");
        uVar12 = FUN_000858da(2);
        uVar13 = FUN_00033b90("name");
        uVar14 = FUN_00033b90("Stereo Rear");
        uVar10 = FUN_00066996(uVar14,uVar13,uVar12,uVar10,0);
        func_0x0002bb40(iRam003d3fb0,uVar10);
        iVar2 = iRam003d3fb0;
      }
      break;
    case 6:
      iVar2 = iRam003d3fac;
      if (iRam003d3fac == 0) {
        uVar10 = __Znwm(0x20);
        FUN_00029d44(uVar10);
        iRam003d3fac = FUN_0002dfa6(uVar10);
        uVar10 = FUN_00033b90("channelFormat");
        uVar12 = FUN_000858da(6);
        uVar13 = FUN_00033b90("name");
        uVar14 = FUN_00033b90("Dolby51");
        uVar10 = FUN_00066996(uVar14,uVar13,uVar12,uVar10,0);
        func_0x0002bb40(iRam003d3fac,uVar10);
        iVar2 = iRam003d3fac;
      }
    }
    return iVar2;
  }
  pcVar17 = "channelFormat";
  uVar10 = FUN_00033b90("channelFormat");
  uVar12 = FUN_000858da(2);
  pcVar16 = "name";
  uVar13 = FUN_00033b90("name");
  uVar14 = FUN_00033b90("Elastik 15-16");
  uVar10 = FUN_00066996(uVar14,uVar13,uVar12,uVar10,0);
  uVar12 = FUN_00033b90(pcVar17);
  uVar13 = FUN_000858da(2);
  uVar14 = FUN_00033b90(pcVar16);
  uVar3 = FUN_00033b90("Elastik 13-14");
  uVar12 = FUN_00066996(uVar3,uVar14,uVar13,uVar12,0);
  uVar13 = FUN_00033b90(pcVar17);
  uVar14 = FUN_000858da(2);
  uVar3 = FUN_00033b90(pcVar16);
  uVar4 = FUN_00033b90("Elastik 11-12");
  uVar13 = FUN_00066996(uVar4,uVar3,uVar14,uVar13,0);
  uVar14 = FUN_00033b90(pcVar17);
  uVar3 = FUN_000858da(2);
  uVar4 = FUN_00033b90(pcVar16);
  uVar5 = FUN_00033b90("Elastik 9-10");
  uVar14 = FUN_00066996(uVar5,uVar4,uVar3,uVar14,0);
  uVar3 = FUN_00033b90(pcVar17);
  uVar4 = FUN_000858da(2);
  uVar5 = FUN_00033b90(pcVar16);
  uVar6 = FUN_00033b90("Elastik 7-8");
  uVar3 = FUN_00066996(uVar6,uVar5,uVar4,uVar3,0);
  uVar4 = FUN_00033b90(pcVar17);
  uVar5 = FUN_000858da(2);
  uVar6 = FUN_00033b90(pcVar16);
  uVar7 = FUN_00033b90("Elastik 5-6");
  uVar4 = FUN_00066996(uVar7,uVar6,uVar5,uVar4,0);
  uVar5 = FUN_00033b90(pcVar17);
  uVar6 = FUN_000858da(2);
  uVar7 = FUN_00033b90(pcVar16);
  uVar8 = FUN_00033b90("Elastik 3-4");
  uVar5 = FUN_00066996(uVar8,uVar7,uVar6,uVar5,0);
  uVar6 = FUN_00033b90(pcVar17);
  uVar7 = FUN_000858da(2);
  uVar8 = FUN_00033b90(pcVar16);
  uVar9 = FUN_00033b90("Elastik 1-2");
  uVar6 = FUN_00066996(uVar9,uVar8,uVar7,uVar6,0);
  iVar2 = FUN_0002c670(uVar6,uVar5,uVar4,uVar3,uVar14,uVar13,uVar12,uVar10,0);
  return iVar2;
}


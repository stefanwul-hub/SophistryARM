
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

byte FUN_00060ab6(int param_1)

{
  byte bVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  byte bVar4;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930("/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNMidiEvent.cpp");
    uVar3 = FUN_00033b90("GNAssertionException");
    func_0x0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xba,uVar2,"this != 0");
  }
  bVar4 = *(byte *)(param_1 + 0xc) & 0xf0;
  bVar1 = *(byte *)(param_1 + 0xc);
  if (bVar4 != 0xf0) {
    bVar1 = bVar4;
  }
  return bVar1;
}


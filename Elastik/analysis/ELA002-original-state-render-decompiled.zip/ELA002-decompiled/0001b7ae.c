
void FUN_0001b7ae(int param_1)

{
  int *piVar1;
  
  FUN_00156368(param_1);
  piVar1 = *(int **)(param_1 + 0x158);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x240))(piVar1);
    piVar1 = *(int **)(param_1 + 0x158);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(undefined4 *)(param_1 + 0x158) = 0;
  }
  return;
}


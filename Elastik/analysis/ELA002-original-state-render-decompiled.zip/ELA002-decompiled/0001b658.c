
void FUN_0001b658(int *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  longdouble lVar5;
  undefined4 uStack_20;
  int iStack_10;
  
  uVar2 = (undefined4)*(undefined8 *)(param_1 + 0x58);
  uStack_20 = (undefined4)((ulonglong)*(undefined8 *)(param_1 + 0x58) >> 0x20);
  lVar5 = (longdouble)(**(code **)(*param_1 + 600))(param_1);
  if ((double)CONCAT44(uStack_20,uVar2) != (double)lVar5) {
    uVar2 = __Znwm(0xd4);
    FUN_0014f75a(uVar2);
    iVar3 = FUN_0002dfa6(uVar2);
    param_1[0x56] = iVar3;
    uVar2 = func_0x0001ce36(param_1);
    FUN_0001ce42(param_1[0x56],uVar2);
    pcVar1 = *(code **)(*(int *)param_1[0x56] + 0x254);
    lVar5 = (longdouble)(**(code **)(*param_1 + 600))(param_1);
    (*pcVar1)(param_1[0x56],(double)lVar5);
    pcVar1 = *(code **)(*(int *)param_1[0x56] + 0x25c);
    uVar2 = (**(code **)(*param_1 + 0x260))(param_1);
    (*pcVar1)(param_1[0x56],uVar2);
    FUN_0014f8c8(param_1[0x56],param_1);
    (**(code **)(*param_1 + 0x254))(param_1,*(undefined8 *)(param_1 + 0x58));
    (**(code **)(*(int *)param_1[0x56] + 0x23c))((int *)param_1[0x56]);
  }
  func_0x0001ddfc(param_1);
  for (iStack_10 = 0; iVar3 = FUN_00029ddc(param_1[0x2b]), iStack_10 < iVar3;
      iStack_10 = iStack_10 + 1) {
    piVar4 = (int *)FUN_0002a364(param_1[0x2b],iStack_10);
    pcVar1 = *(code **)(*piVar4 + 0x254);
    lVar5 = (longdouble)(**(code **)(*param_1 + 600))(param_1);
    (*pcVar1)(piVar4,(double)lVar5);
    pcVar1 = *(code **)(*piVar4 + 0x25c);
    uVar2 = (**(code **)(*param_1 + 0x260))(param_1);
    (*pcVar1)(piVar4,uVar2);
    uVar2 = func_0x0001ce36(param_1);
    FUN_0001ce42(piVar4,uVar2);
    uVar2 = func_0x0001cd2c(param_1);
    func_0x0001cd38(piVar4,uVar2);
    (**(code **)(*piVar4 + 0x23c))(piVar4);
  }
  return;
}


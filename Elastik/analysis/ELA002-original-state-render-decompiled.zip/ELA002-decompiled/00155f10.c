
int FUN_00155f10(int param_1,char param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_00029ddc(*(undefined4 *)(param_1 + 0xac));
  iVar1 = iVar1 + -1;
  if (-1 < iVar1) {
    do {
      iVar2 = FUN_0002a364(*(undefined4 *)(param_1 + 0xac),iVar1);
      if (*(char *)(iVar2 + 0x84) == param_2) {
        return iVar2;
      }
      iVar1 = iVar1 + -1;
    } while (iVar1 != -1);
  }
  return 0;
}



void FUN_001563c2(int *param_1)

{
  (**(code **)(*param_1 + 0x37c))(param_1,0,0);
  return;
}


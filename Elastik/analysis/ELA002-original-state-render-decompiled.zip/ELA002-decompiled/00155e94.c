
void FUN_00155e94(int *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_00029ddc(param_1[0x2b]);
  iVar2 = (**(code **)(*param_1 + 0x398))(param_1);
  if (iVar1 <= iVar2) {
    iVar2 = iVar1;
  }
  iVar2 = iVar2 + -1;
  if (-1 < iVar2) {
    do {
      iVar1 = FUN_0002a364(param_1[0x2b],iVar2);
      if ((*(char *)(iVar1 + 0x92) != '\0') && (*(char *)(iVar1 + 0x91) == '\0')) {
        return;
      }
      iVar2 = iVar2 + -1;
    } while (iVar2 != -1);
  }
  FUN_0002a364(param_1[0x2b],0);
  return;
}


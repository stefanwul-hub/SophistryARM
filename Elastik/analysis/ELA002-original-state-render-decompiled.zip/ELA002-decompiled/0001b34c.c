
undefined4 FUN_0001b34c(int param_1)

{
  return *(undefined4 *)(param_1 + 0xbc);
}



void FUN_00156368(int param_1)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  
  iVar6 = 0;
  while( true ) {
    iVar4 = FUN_00029ddc(*(undefined4 *)(param_1 + 0xac));
    if (iVar4 <= iVar6) break;
    piVar3 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0xac),iVar6);
    (**(code **)(*piVar3 + 0x240))(piVar3);
    iVar6 = iVar6 + 1;
  }
  *(undefined4 *)(param_1 + 0xb0) = 0;
  if (*(int *)(param_1 + 0x40) != 0) {
    iVar4 = 0;
    iVar6 = *(int *)(param_1 + 0x40);
    uVar5 = *(uint *)(param_1 + 0x54);
    uVar2 = uVar5 & 0xff;
    if ((uVar5 & 0x100) == 0) {
      uVar2 = uVar5;
    }
    if (0 < (int)uVar2) {
      do {
        iVar1 = *(int *)(iVar6 + iVar4 * 4);
        if (iVar1 != 0) {
          func_0x0000b122(iVar1);
          iVar6 = *(int *)(param_1 + 0x40);
          uVar5 = *(uint *)(param_1 + 0x54);
        }
        iVar4 = iVar4 + 1;
        uVar2 = uVar5 & 0xff;
        if ((uVar5 & 0x100) == 0) {
          uVar2 = uVar5;
        }
      } while (iVar4 < (int)uVar2);
    }
    func_0x0000b122(iVar6);
    *(undefined4 *)(param_1 + 0x40) = 0;
  }
  return;
}


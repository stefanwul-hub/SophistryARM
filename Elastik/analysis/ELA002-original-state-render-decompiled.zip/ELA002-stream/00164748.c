
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00164748(int param_1,int param_2)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0xca,uVar3,"this != 0");
  }
  if ((*(int *)(param_1 + 0x14) == 0) && (*(int *)(param_1 + 0x18) == 0)) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0xca,uVar3,"_data || _file");
  }
  if (param_2 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0xca,uVar3,"s != 0");
  }
  if (*(int *)(param_1 + 0x18) != 0) {
    cVar2 = FUN_00180772(*(int *)(param_1 + 0x18),0x2a);
    if (cVar2 != '\0') {
      uVar3 = FUN_000349f4(param_2);
      cVar2 = FUN_001640f2(param_1,uVar3);
      if (cVar2 != '\0') {
        pcVar1 = *(code **)(**(int **)(param_1 + 0x18) + 0x1b0);
        uVar3 = FUN_000349f4(param_2);
        uVar4 = FUN_00034962(param_2);
        cVar2 = (*pcVar1)(*(undefined4 *)(param_1 + 0x18),uVar4,uVar3);
        if (cVar2 != '\0') {
          return 1;
        }
      }
    }
    return 0;
  }
  iVar6 = *(int *)(param_1 + 0x10);
  iVar5 = FUN_000349f4(param_2);
  iVar6 = iVar6 + iVar5;
  iVar5 = *(int *)(param_1 + 0x14);
  if (iVar5 != 0) {
    iVar5 = FUN_000278d6(iVar5);
    if (iVar6 + 0x10 < iVar5) {
      iVar5 = *(int *)(param_1 + 0x14);
    }
    else {
      FUN_00027bec(*(undefined4 *)(param_1 + 0x14));
      (**(code **)(**(int **)(param_1 + 0x14) + 0x1a4))(*(int **)(param_1 + 0x14),iVar6 + 0x410);
      FUN_00027b4e(*(undefined4 *)(param_1 + 0x14));
      iVar5 = *(int *)(param_1 + 0x14);
    }
  }
  iVar6 = FUN_00027abc(iVar5);
  *(undefined1 *)(iVar6 + *(int *)(param_1 + 0x10)) = 0x2a;
  *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  uVar3 = FUN_000349f4(param_2);
  FUN_001640f2(param_1,uVar3);
  uVar3 = FUN_000349f4(param_2);
  uVar4 = FUN_00034962(param_2);
  _memcpy(iVar6 + *(int *)(param_1 + 0x10),uVar4,uVar3);
  iVar6 = *(int *)(param_1 + 0x10);
  iVar5 = FUN_000349f4(param_2);
  *(int *)(param_1 + 0x10) = iVar6 + iVar5;
  return 1;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00180772(int *param_1,undefined1 param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined1 auStack_20 [16];
  
  auStack_20[0] = param_2;
  if (param_1 != (int *)0x0) {
    cVar1 = (**(code **)(*param_1 + 0x1b0))(param_1,auStack_20,1);
    return (int)cVar1;
  }
  uVar2 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                         );
  uVar3 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x56d,uVar2,"this != 0");
  cVar1 = (**(code **)(mach_header_00000000.magic + 0x1b0))(0,auStack_20,1);
  return (int)cVar1;
}


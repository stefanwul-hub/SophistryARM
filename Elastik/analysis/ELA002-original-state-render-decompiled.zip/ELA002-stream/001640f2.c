
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001640f2(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined1 *puVar6;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x65,uVar2,"this != 0");
  }
  if (*(int *)(param_1 + 0x14) == 0) {
    iVar5 = *(int *)(param_1 + 0x18);
    if (iVar5 != 0) goto LAB_0016411d;
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x65,uVar2,"_data || _file");
  }
  iVar5 = *(int *)(param_1 + 0x18);
  if (iVar5 == 0) {
    iVar5 = *(int *)(param_1 + 0x10);
    iVar4 = *(int *)(param_1 + 0x14);
    if (iVar4 != 0) {
      iVar4 = FUN_000278d6(iVar4);
      if (iVar5 + 5 < iVar4) {
        iVar4 = *(int *)(param_1 + 0x14);
      }
      else {
        FUN_00027bec(*(undefined4 *)(param_1 + 0x14));
        (**(code **)(**(int **)(param_1 + 0x14) + 0x1a4))(*(int **)(param_1 + 0x14),iVar5 + 0x405);
        FUN_00027b4e(*(undefined4 *)(param_1 + 0x14));
        iVar4 = *(int *)(param_1 + 0x14);
      }
    }
    iVar5 = FUN_00027abc(iVar4);
    puVar6 = (undefined1 *)(iVar5 + *(int *)(param_1 + 0x10));
    *puVar6 = 0x69;
    *(undefined4 *)(puVar6 + 1) = param_2;
    func_0x0000a838(puVar6 + 1);
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 5;
    return 1;
  }
LAB_0016411d:
  cVar1 = FUN_00180772(iVar5,0x69);
  if ((cVar1 != '\0') &&
     (cVar1 = FUN_001805f2(*(undefined4 *)(param_1 + 0x18),param_2), cVar1 != '\0')) {
    return 1;
  }
  return 0;
}


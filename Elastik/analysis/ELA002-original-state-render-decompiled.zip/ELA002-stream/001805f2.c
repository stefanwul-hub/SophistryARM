
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_001805f2(int *param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 auStack_20 [4];
  
  auStack_20[0] = param_2;
  if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x55b,uVar2,"this != 0");
  }
  if (param_1[5] == 0) {
    cVar1 = (**(code **)(*param_1 + 0x1b0))(param_1,auStack_20,4);
    return (int)cVar1;
  }
  func_0x0000a838(auStack_20);
  cVar1 = (**(code **)(*param_1 + 0x1b0))(param_1,auStack_20,4);
  return (int)cVar1;
}


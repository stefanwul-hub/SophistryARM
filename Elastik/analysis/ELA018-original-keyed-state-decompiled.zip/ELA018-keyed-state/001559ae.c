
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001559ae(int param_1,int *param_2,int param_3)

{
  char cVar1;
  char *pcVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  int *piVar9;
  undefined4 uVar10;
  uint uVar11;
  char *pcVar12;
  int iStack_14;
  
  uVar8 = param_3;
  iVar4 = (int)param_2;
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNKeyValueArchiver.cpp"
                           );
    uVar10 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar10,"Assertion failed in line %d of %s: %s.",0x118,uVar3,"this != 0");
  }
  if (iVar4 == 0) {
    return;
  }
  cVar1 = FUN_0002ae60(*(undefined4 *)(param_1 + 0x18),iVar4);
  if (cVar1 == '\0') {
    FUN_0002bb40(*(undefined4 *)(param_1 + 0x18),iVar4);
  }
  iVar6 = FUN_00063cee(*(undefined4 *)(param_1 + 0x24),*(undefined4 *)(param_1 + 0x28));
  if (iVar6 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNKeyValueArchiver.cpp"
                           );
    uVar10 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar10,"Assertion failed in line %d of %s: %s.",0x120,uVar3,"d");
  }
  iVar7 = FUN_00154f96(param_1,uVar8);
  uVar8 = FUN_0002a8c2(*(undefined4 *)(param_1 + 0x18),iVar4);
  piVar9 = (int *)FUN_000858da(uVar8);
  param_2 = piVar9;
  param_3 = iVar7;
  if (iVar6 == 0) {
    uVar8 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xfe,uVar8,"this != 0");
  }
  if (*(int *)(iVar6 + 0xc) == 0) {
    uVar8 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xfe,uVar8,"_keys");
  }
  if (*(int *)(iVar6 + 0x10) == 0) {
    uVar8 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xfe,uVar8,"_objects");
  }
  if (iVar7 == 0) {
    func_0x0000acae("GNDictionary: key is 0");
  }
  if ((piVar9 == (int *)0x0) && (cVar1 = func_0x000639f0(iVar6), cVar1 == '\0')) {
    pcVar2 = "Attempt to insert 0 as an object into a dictionary";
    if (cRam003d3ef8 == '\0') {
      uVar11 = 0xffffffff;
      pcVar12 = pcVar2;
      do {
        if (uVar11 == 0) break;
        uVar11 = uVar11 - 1;
        cVar1 = *pcVar12;
        pcVar12 = pcVar12 + 1;
      } while (cVar1 != '\0');
      cVar1 = ~uVar11 - 1 < 0x2000;
      if ((bool)cVar1) {
        pcVar2 = (char *)FUN_0000aecc((~uVar11 - 1) * 3 + 0x400);
        _vsprintf(pcVar2,"Attempt to insert 0 as an object into a dictionary",&param_2);
      }
      if (piRam003d3f0c == (int *)0x0) {
        uVar8 = __Znwm(0x38);
        func_0x0006f04a(uVar8);
        piRam003d3f0c = (int *)FUN_0002dfa6(uVar8);
      }
      (**(code **)(*piRam003d3f0c + 0x1a4))(piRam003d3f0c);
      _puts(pcVar2);
      (**(code **)(*piRam003d3f0c + 0x1ac))(piRam003d3f0c);
      if (cVar1 != '\0') {
        if (pcVar2 != (char *)0x0) {
          if (cRam003d3f09 == '\0') {
            cRam003d3f09 = 1;
            if (iRam003d3ee8 != 0) {
              func_0x000424ac(iRam003d3ee8,pcVar2);
            }
            cRam003d3f09 = '\0';
          }
          _free(pcVar2);
          return;
        }
        FUN_0000ab14("GNFree(0)");
      }
    }
    return;
  }
  if (*(int *)(iVar6 + 0x14) == 0) {
    iVar4 = func_0x0002a9ba(*(undefined4 *)(iVar6 + 0xc),iVar7);
  }
  else {
    iVar4 = func_0x0006440e(iVar6,iVar7);
  }
  if (iVar4 != -1) {
    piVar5 = (int *)FUN_0002a364(*(undefined4 *)(iVar6 + 0x10),iVar4);
    if (piVar9 == piVar5) {
      return;
    }
    func_0x0002a62c(*(undefined4 *)(iVar6 + 0x10),iVar4);
    piVar5 = *(int **)(iVar6 + 0x10);
    param_2 = piVar9;
    param_3 = iVar4;
    if (piVar5 == (int *)0x0) {
      uVar8 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                             );
      uVar3 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x18c,uVar8,"this != 0");
    }
    if ((param_2 == (int *)0x0) && (*(char *)((int)piVar5 + 0x19) == '\0')) {
      uVar8 = (**(code **)(*piVar5 + 0xc))(piVar5);
      uVar8 = FUN_00034962(uVar8);
      func_0x0000acae("GNList::insertObjectAtIndex(): Cannot insert nil object into %s.",uVar8);
    }
    if ((piVar5[4] < param_3) || (param_3 < 0)) {
      uVar8 = (**(code **)(*piVar5 + 0xc))(piVar5);
      uVar8 = FUN_00034962(uVar8);
      func_0x0000acae("GNList::insertObjectAtIndex(): Index %i out of range of %s.",param_3,uVar8);
      iVar4 = piVar5[4] + 1;
      piVar5[4] = iVar4;
    }
    else {
      iVar4 = piVar5[4] + 1;
      piVar5[4] = iVar4;
    }
    iVar6 = iVar4 * 0x10 + 1;
    if (iVar6 < 0) {
      iVar6 = iVar4 * 0x10 + 0x10;
    }
    FUN_0002a14a(piVar5,iVar6 >> 4);
    iVar4 = piVar5[4] + -1;
    if (param_3 < iVar4) {
      iVar6 = iVar4 * 4;
      do {
        *(undefined4 *)(iVar6 + piVar5[3]) = ((undefined4 *)(iVar6 + piVar5[3]))[-1];
        iVar4 = iVar4 + -1;
        iVar6 = iVar6 + -4;
      } while (param_3 < iVar4);
    }
    *(int **)(piVar5[3] + param_3 * 4) = param_2;
    if (((char)piVar5[6] == '\0') && (param_2 != (int *)0x0)) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
    return;
  }
  FUN_0002bb40(*(undefined4 *)(iVar6 + 0xc),iVar7);
  FUN_0002bb40(*(undefined4 *)(iVar6 + 0x10),piVar9);
  iVar4 = FUN_00029ddc(*(undefined4 *)(iVar6 + 0xc));
  param_2 = (int *)(iVar4 + -1);
  if (*(int *)(iVar6 + 0x14) != 0) {
    piVar9 = (int *)func_0x000427b6(*(int *)(iVar6 + 0x14));
    iVar4 = func_0x00041be2(*(undefined4 *)(iVar6 + 0x14));
    piVar5 = (int *)FUN_0002a364(*(undefined4 *)(iVar6 + 0xc),param_2);
    iStack_14 = (**(code **)(*piVar5 + 0x90))(piVar5);
    if (iVar4 < 1) {
code_r0x00066056:
      func_0x00042ffe(*(undefined4 *)(iVar6 + 0x14),&iStack_14);
      return;
    }
    if (*piVar9 == iStack_14 || *piVar9 - iStack_14 < 0) {
      iVar7 = 0;
      do {
        piVar9 = piVar9 + 2;
        iVar7 = iVar7 + 1;
        if (iVar4 == iVar7) goto code_r0x00066056;
      } while (*piVar9 == iStack_14 || *piVar9 - iStack_14 < 0);
    }
    else {
      iVar7 = 0;
    }
    func_0x00042dcc(*(undefined4 *)(iVar6 + 0x14),&iStack_14,iVar7);
  }
  return;
}


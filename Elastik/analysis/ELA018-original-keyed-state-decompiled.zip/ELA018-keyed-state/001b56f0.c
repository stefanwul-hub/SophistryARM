
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001b56f0(undefined4 *param_1)

{
  func_0x001e8b3e(param_1);
  *param_1 = &UNK_003937c8;
  param_1[8] = 0;
  param_1[6] = 0;
  param_1[9] = 0;
  param_1[7] = 0;
  *(undefined1 *)((int)param_1 + 0x2d) = 0;
  param_1[0xc] = 0;
  return;
}



undefined4 FUN_000a0cc4(int param_1)

{
  return *(undefined4 *)(param_1 + 0xc);
}



int FUN_00022d78(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  if ((*(int *)(param_1 + 0x2c) != 0) &&
     (iVar1 = func_0x00041be2(*(int *)(param_1 + 0x2c)), iVar1 != 0)) {
    return 1;
  }
  iVar1 = FUN_00021738(param_1);
  if (iVar1 == 0) {
    return 0;
  }
  iVar1 = FUN_00021738(param_1);
  if ((*(int *)(iVar1 + 0x2c) == 0) || (iVar2 = func_0x00041be2(*(int *)(iVar1 + 0x2c)), iVar2 == 0)
     ) {
    iVar2 = FUN_00021738(iVar1);
    if (iVar2 != 0) {
      iVar1 = FUN_00021738(iVar1);
      if ((*(int *)(iVar1 + 0x2c) != 0) &&
         (iVar2 = func_0x00041be2(*(int *)(iVar1 + 0x2c)), iVar2 != 0)) goto LAB_00022ed0;
      iVar2 = FUN_00021738(iVar1);
      if (iVar2 != 0) {
        iVar1 = FUN_00021738(iVar1);
        if ((*(int *)(iVar1 + 0x2c) != 0) &&
           (iVar2 = func_0x00041be2(*(int *)(iVar1 + 0x2c)), iVar2 != 0)) goto LAB_00022ed0;
        iVar2 = FUN_00021738(iVar1);
        if (iVar2 != 0) {
          iVar1 = FUN_00021738(iVar1);
          if ((*(int *)(iVar1 + 0x2c) != 0) &&
             (iVar2 = func_0x00041be2(*(int *)(iVar1 + 0x2c)), iVar2 != 0)) goto LAB_00022ed0;
          iVar2 = FUN_00021738(iVar1);
          if (iVar2 != 0) {
            iVar1 = FUN_00021738(iVar1);
            if ((*(int *)(iVar1 + 0x2c) != 0) &&
               (iVar2 = func_0x00041be2(*(int *)(iVar1 + 0x2c)), iVar2 != 0)) goto LAB_00022ed0;
            iVar2 = FUN_00021738(iVar1);
            if (iVar2 != 0) {
              iVar1 = FUN_00021738(iVar1);
              if ((*(int *)(iVar1 + 0x2c) != 0) &&
                 (iVar2 = func_0x00041be2(*(int *)(iVar1 + 0x2c)), iVar2 != 0)) goto LAB_00022ed0;
              iVar2 = FUN_00021738(iVar1);
              if (iVar2 != 0) {
                uVar3 = FUN_00021738(iVar1);
                iVar2 = FUN_00022d78(uVar3);
              }
            }
          }
        }
      }
    }
    iVar1 = (int)(char)iVar2;
  }
  else {
LAB_00022ed0:
    iVar1 = 1;
  }
  return iVar1;
}


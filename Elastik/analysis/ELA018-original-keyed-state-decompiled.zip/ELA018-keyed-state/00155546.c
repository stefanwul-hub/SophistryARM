
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00155546(int *param_1,undefined4 param_2)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  
  FUN_0002ad82(param_1[7]);
  FUN_0002ad82(param_1[6]);
  FUN_0002ad82(param_1[8]);
  FUN_00065cea(param_1[9]);
  FUN_0002bb40(param_1[6],param_2);
  uVar3 = __Znwm(0x18);
  FUN_000630b6(uVar3);
  piVar4 = (int *)FUN_0002dfa6(uVar3);
  uVar3 = (**(code **)(*piVar4 + 0x48))(piVar4);
  FUN_00066072(param_1[9],uVar3,param_2);
  do {
    bVar1 = false;
    iVar8 = 0;
    iVar5 = FUN_00029ddc(param_1[6]);
    if (0 < iVar5) {
      do {
        uVar3 = FUN_0002a364(param_1[6],iVar8);
        cVar2 = FUN_0002ae60(param_1[8],uVar3);
        if ((cVar2 == '\0') && (cVar2 = FUN_00064044(param_1[9],uVar3), cVar2 != '\0')) {
          FUN_00155396(param_1,uVar3);
          FUN_0002bb40(param_1[8],uVar3);
          bVar1 = true;
        }
        iVar8 = iVar8 + 1;
        iVar5 = FUN_00029ddc(param_1[6]);
      } while (iVar8 < iVar5);
    }
  } while (bVar1);
  uVar3 = __Znwm(0x18);
  FUN_000630b6(uVar3);
  piVar4 = (int *)FUN_0002dfa6(uVar3);
  uVar3 = (**(code **)(*piVar4 + 0x48))(piVar4);
  uVar6 = FUN_00033b90("objects");
  uVar7 = FUN_00063ade(param_1[9]);
  FUN_00066284(uVar3,uVar7,uVar6);
  iVar5 = param_1[0xc];
  if (iVar5 == 2) {
    uVar6 = __Znwm(0x34);
    FUN_001b56f0(uVar6);
    piVar4 = (int *)FUN_0002dfa6(uVar6);
    piVar4 = (int *)(**(code **)(*piVar4 + 0x48))(piVar4);
    iVar5 = (**(code **)(*piVar4 + 0x298))(piVar4,uVar3);
  }
  else if (iVar5 == 1) {
    iVar5 = FUN_00065022(uVar3);
  }
  else {
    if (iVar5 != 0) {
      return 0;
    }
    iVar5 = FUN_000657ea(uVar3);
  }
  if ((iVar5 != 0) && (iVar8 = (**(code **)(*param_1 + 0x2a4))(param_1), iVar8 != 0)) {
    piVar4 = (int *)(**(code **)(*param_1 + 0x2a4))(param_1);
                    /* WARNING: Could not recover jumptable at 0x001556f6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    iVar5 = (**(code **)(*piVar4 + 0x1a4))();
    return iVar5;
  }
  return iVar5;
}


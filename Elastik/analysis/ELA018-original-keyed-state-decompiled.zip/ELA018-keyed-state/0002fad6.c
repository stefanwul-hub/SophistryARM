
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002fad6(int *param_1,int *param_2,char *param_3,char *param_4)

{
  char cVar1;
  undefined1 uVar2;
  char cVar3;
  int *piVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  char *pcVar9;
  int iVar10;
  char *pcVar11;
  undefined4 uVar12;
  int extraout_EDX;
  int extraout_EDX_00;
  int extraout_EDX_01;
  int extraout_EDX_02;
  int extraout_EDX_03;
  int extraout_EDX_04;
  int extraout_EDX_05;
  int extraout_EDX_06;
  code *UNRECOVERED_JUMPTABLE;
  float *pfVar13;
  double *pdVar14;
  undefined4 *puVar15;
  longdouble lVar16;
  undefined8 uVar17;
  int iStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 *puStack_20;
  
  iVar10 = (int)param_3;
  cVar3 = (char)param_4;
  if (iRam003d402c == 0) {
    iRam003d402c = FUN_00033b90("GNString");
  }
  if (iRam003d4028 == 0) {
    iRam003d4028 = FUN_00033b90("GNNumber");
  }
  if (iRam003d4024 == 0) {
    iRam003d4024 = FUN_00033b90("GNList");
  }
  if (iRam003d4020 == 0) {
    iRam003d4020 = FUN_00033b90("GNValue");
  }
  uVar5 = (**(code **)(*param_1 + 8))(param_1);
  piVar6 = (int *)FUN_00021922(uVar5,iVar10);
  iVar7 = FUN_00021c02(uVar5,iVar10);
  iVar8 = FUN_000219c4(uVar5,iVar10);
  cVar1 = (**(code **)(*param_1 + 0x158))(param_1,iVar10);
  if (cVar1 != '\0') {
    (**(code **)(*param_1 + 200))(param_1,param_2,iVar10);
  }
  if (iVar7 == 0) {
    if (iVar8 == 0) goto LAB_0002fbd7;
    func_0x000fc7a0(iVar8);
    if (extraout_EDX < 2) {
      func_0x000fc7a0(iVar8);
      if (extraout_EDX_02 != 1) goto LAB_0002fbd7;
      piVar6 = (int *)((int)param_1 + *piVar6);
      if (((cVar3 != '\0') && (*piVar6 != 0)) &&
         ((iVar10 = FUN_000fd052(iVar8), iVar10 != 0 && (iVar10 = FUN_000fcafe(iVar8), iVar10 != 0))
         )) {
        uVar5 = FUN_000fcafe(iVar8);
        func_0x000fc7a0(uVar5);
        if (extraout_EDX_03 < 2) {
          uVar5 = FUN_000fcafe(iVar8);
          func_0x000fc7a0(uVar5);
          if (extraout_EDX_06 == 1) {
            UNRECOVERED_JUMPTABLE = *(code **)(*(int *)*piVar6 + 0x168);
            uVar5 = FUN_000fd052(iVar8);
            (*UNRECOVERED_JUMPTABLE)(*piVar6,0,uVar5,0);
          }
        }
        else {
          UNRECOVERED_JUMPTABLE = *(code **)(*(int *)*piVar6 + 0x180);
          uVar5 = FUN_000fd052(iVar8);
          (*UNRECOVERED_JUMPTABLE)(*piVar6,param_1,uVar5,0);
        }
      }
      piVar4 = (int *)*piVar6;
      *piVar6 = (int)param_2;
      cVar1 = func_0x000fc858(iVar8);
      if (cVar1 != '\0') {
        piVar6 = (int *)*piVar6;
        if (piVar6 != (int *)0x0) {
          (**(code **)(*piVar6 + 0x40))(piVar6);
        }
        if (piVar4 != (int *)0x0) {
          (**(code **)(*piVar4 + 0x44))(piVar4);
        }
      }
      if (((cVar3 != '\0') && (param_2 != (int *)0x0)) &&
         ((iVar10 = FUN_000fd052(iVar8), iVar10 != 0 && (iVar10 = FUN_000fcafe(iVar8), iVar10 != 0))
         )) {
        uVar5 = FUN_000fcafe(iVar8);
        func_0x000fc7a0(uVar5);
        if (extraout_EDX_04 < 2) {
          uVar5 = FUN_000fcafe(iVar8);
          func_0x000fc7a0(uVar5);
          if (extraout_EDX_05 != 1) {
            return;
          }
          UNRECOVERED_JUMPTABLE = *(code **)(*param_2 + 0x168);
        }
        else {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_2 + 0x178);
        }
        param_3 = (char *)FUN_000fd052(iVar8);
        param_4 = (char *)0x0;
                    /* WARNING: Could not recover jumptable at 0x00030586. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (*UNRECOVERED_JUMPTABLE)();
        return;
      }
    }
    else {
      piVar4 = (int *)((int)param_1 + *piVar6);
      piVar6 = (int *)*piVar4;
      *piVar4 = (int)param_2;
      if (param_2 != (int *)0x0) {
        (**(code **)(*param_2 + 0x40))(param_2);
      }
      if (piVar6 != (int *)0x0) {
        (**(code **)(*piVar6 + 0x44))(piVar6);
      }
      if (((cVar3 != '\0') && (iVar10 = FUN_000fd052(iVar8), iVar10 != 0)) &&
         (iVar10 = FUN_000fcafe(iVar8), iVar10 != 0)) {
        for (iStack_40 = 0; iVar10 = FUN_00029ddc(*piVar4), iStack_40 < iVar10;
            iStack_40 = iStack_40 + 1) {
          piVar6 = (int *)FUN_0002a364(*piVar4,iStack_40);
          if (piVar6 != (int *)0x0) {
            uVar5 = FUN_000fcafe(iVar8);
            func_0x000fc7a0(uVar5);
            if (extraout_EDX_00 < 2) {
              uVar5 = FUN_000fcafe(iVar8);
              func_0x000fc7a0(uVar5);
              if (extraout_EDX_01 != 1) goto LAB_0002fe33;
              UNRECOVERED_JUMPTABLE = *(code **)(*piVar6 + 0x168);
            }
            else {
              UNRECOVERED_JUMPTABLE = *(code **)(*piVar6 + 0x178);
            }
            uVar5 = FUN_000fd052(iVar8);
            (*UNRECOVERED_JUMPTABLE)(piVar6,param_1,uVar5,0);
          }
LAB_0002fe33:
        }
      }
    }
  }
  else {
    iVar8 = func_0x000a993e(iVar7);
    if (iVar8 == 0) {
      uVar5 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNObject.cpp"
                             );
      uVar12 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar12,"Assertion failed in line %d of %s: %s.",0x52b,uVar5,
                   "attribute->getType()");
    }
    uVar5 = func_0x000a993e(iVar7);
    uVar5 = func_0x000fee6e(uVar5);
    uVar2 = FUN_00034a88(uVar5,0);
    switch(uVar2) {
    case 0x40:
      piVar6 = (int *)((int)param_1 + *piVar6);
      cVar1 = (**(code **)(*param_1 + 0x160))(param_1,iVar10);
      if (cVar1 != '\0') {
        (**(code **)(*param_1 + 0xc0))
                  (param_1,"_setValueForKeyDirectly","v@@b",*piVar6,iVar10,(int)cVar3);
      }
      piVar4 = (int *)*piVar6;
      *piVar6 = (int)param_2;
      if (param_2 != (int *)0x0) {
        (**(code **)(*param_2 + 0x40))(param_2);
      }
      if (piVar4 != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0002ff6b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*piVar4 + 0x44))();
        return;
      }
      break;
    default:
LAB_0002fbd7:
      if (iVar10 == 0) {
        pcVar9 = "";
      }
      else {
        pcVar9 = (char *)FUN_00034962(iVar10);
      }
      if (param_2 == (int *)0x0) {
        pcVar11 = "NULL";
      }
      else {
        iVar10 = (**(code **)(*param_2 + 0xc))(param_2);
        if (iVar10 == 0) {
          pcVar11 = "";
        }
        else {
          uVar5 = (**(code **)(*param_2 + 0xc))(param_2);
          pcVar11 = (char *)FUN_00034962(uVar5);
        }
      }
      uVar5 = FUN_00033b90("GNKeyValueCodingException");
      piStack_3c = (int *)0x20;
      param_3 = pcVar11;
      param_4 = pcVar9;
      piVar6 = (int *)__Znwm();
      piStack_3c = piVar6;
      FUN_000332e2();
      piStack_3c = piVar6;
      piStack_3c = (int *)FUN_0002dfa6();
      piVar6 = (int *)(**(code **)(*piStack_3c + 0x48))();
      piStack_3c = (int *)"Cannot set value %s for key %s directly.";
      puStack_20 = &param_3;
      uStack_38 = func_0x00039354();
      piStack_3c = piVar6;
      piStack_34 = (int *)&param_3;
      func_0x0003d480();
      piStack_3c = piVar6;
      FUN_00034b8e();
      piStack_3c = (int *)0x18;
      piVar4 = (int *)__Znwm();
      piStack_3c = piVar4;
      func_0x0002dc66();
      *piVar4 = (int)&UNK_0036ce88;
      piVar4[3] = 0;
      piVar4[4] = 0;
      piVar4[5] = 0;
      piStack_3c = piVar4;
      piStack_3c = (int *)FUN_0002dfa6();
      piVar4 = (int *)(**(code **)(*piStack_3c + 0x48))();
      uStack_30 = 0;
      piStack_3c = piVar4;
      uStack_38 = uVar5;
      piStack_34 = piVar6;
      (**(code **)(*piVar4 + 0x1a4))();
      piStack_3c = piVar4;
      (**(code **)(*piVar4 + 0x1a8))();
      return;
    case 0x43:
      iVar7 = *piVar6;
      if (param_2 == (int *)0x0) goto LAB_0002fbd7;
      cVar3 = FUN_0002e288(param_2,iRam003d402c);
      if (cVar3 == '\0') {
        cVar3 = FUN_0002e288(param_2,iRam003d4020);
        if (cVar3 == '\0') goto LAB_0002fbd7;
        uVar17 = func_0x0018297e(param_2);
        *(undefined8 *)((int)param_1 + iVar7) = uVar17;
      }
      else {
        uVar17 = func_0x00039cc2(param_2);
        *(undefined8 *)((int)param_1 + iVar7) = uVar17;
      }
      break;
    case 0x50:
      iVar7 = *piVar6;
      if (param_2 == (int *)0x0) goto LAB_0002fbd7;
      cVar3 = FUN_0002e288(param_2,iRam003d402c);
      if (cVar3 == '\0') {
        cVar3 = FUN_0002e288(param_2,iRam003d4020);
        if (cVar3 == '\0') goto LAB_0002fbd7;
        uVar17 = func_0x001825c6(param_2);
        *(undefined8 *)((int)param_1 + iVar7) = uVar17;
      }
      else {
        uVar17 = func_0x00039c16(param_2);
        *(undefined8 *)((int)param_1 + iVar7) = uVar17;
      }
      break;
    case 0x52:
      puVar15 = (undefined4 *)((int)param_1 + *piVar6);
      if (param_2 == (int *)0x0) goto LAB_0002fbd7;
      cVar3 = FUN_0002e288(param_2,iRam003d402c);
      if (cVar3 == '\0') {
        cVar3 = FUN_0002e288(param_2,iRam003d4020);
        if (cVar3 == '\0') goto LAB_0002fbd7;
        func_0x0018254e(&piStack_3c,param_2);
        *puVar15 = piStack_3c;
        puVar15[1] = uStack_38;
        puVar15[2] = piStack_34;
        puVar15[3] = uStack_30;
      }
      else {
        func_0x00039b2a(&uStack_2c,param_2);
        *puVar15 = uStack_2c;
        puVar15[1] = uStack_28;
        puVar15[2] = uStack_24;
        puVar15[3] = puStack_20;
      }
      break;
    case 0x53:
      iVar7 = *piVar6;
      if (param_2 == (int *)0x0) goto LAB_0002fbd7;
      cVar3 = FUN_0002e288(param_2,iRam003d402c);
      if (cVar3 == '\0') {
        cVar3 = FUN_0002e288(param_2,iRam003d4020);
        if (cVar3 == '\0') goto LAB_0002fbd7;
        uVar17 = func_0x0018261a(param_2);
        *(undefined8 *)((int)param_1 + iVar7) = uVar17;
      }
      else {
        uVar17 = func_0x00039b6a(param_2);
        *(undefined8 *)((int)param_1 + iVar7) = uVar17;
      }
      break;
    case 0x62:
      pcVar9 = (char *)((int)param_1 + *piVar6);
      if (param_2 == (int *)0x0) goto LAB_0002fbd7;
      cVar1 = FUN_0002e288(param_2,iRam003d4028);
      if (cVar1 == '\0') {
        cVar1 = FUN_0002e288(param_2,iRam003d402c);
        if (cVar1 == '\0') goto LAB_0002fbd7;
        cVar1 = (**(code **)(*param_1 + 0x160))(param_1,iVar10);
        if (cVar1 != '\0') {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xc0);
          uVar5 = func_0x00085800((int)*pcVar9);
          (*UNRECOVERED_JUMPTABLE)(param_1,"_setValueForKeyDirectly","v@@b",uVar5,iVar10,(int)cVar3)
          ;
        }
        UNRECOVERED_JUMPTABLE = *(code **)(*param_2 + 0x88);
        uVar5 = FUN_00033b90("YES");
        cVar3 = (*UNRECOVERED_JUMPTABLE)(param_2,uVar5);
        if (cVar3 == '\0') {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_2 + 0x88);
          uVar5 = FUN_00033b90("Yes");
          cVar3 = (*UNRECOVERED_JUMPTABLE)(param_2,uVar5);
          if (cVar3 == '\0') {
            UNRECOVERED_JUMPTABLE = *(code **)(*param_2 + 0x88);
            uVar5 = FUN_00033b90("yes");
            cVar3 = (*UNRECOVERED_JUMPTABLE)(param_2,uVar5);
            if (cVar3 == '\0') {
              UNRECOVERED_JUMPTABLE = *(code **)(*param_2 + 0x88);
              uVar5 = FUN_00033b90("true");
              cVar3 = (*UNRECOVERED_JUMPTABLE)(param_2,uVar5);
              if (cVar3 == '\0') {
                *pcVar9 = '\0';
                return;
              }
            }
          }
        }
        *pcVar9 = '\x01';
      }
      else {
        cVar1 = (**(code **)(*param_1 + 0x160))(param_1,iVar10);
        if (cVar1 != '\0') {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xc0);
          uVar5 = func_0x00085800((int)*pcVar9);
          (*UNRECOVERED_JUMPTABLE)(param_1,"_setValueForKeyDirectly","v@@b",uVar5,iVar10,(int)cVar3)
          ;
        }
        cVar3 = func_0x00086538(param_2);
        *pcVar9 = cVar3;
      }
      break;
    case 99:
      pcVar9 = (char *)((int)param_1 + *piVar6);
      if (param_2 == (int *)0x0) goto LAB_0002fbd7;
      cVar1 = FUN_0002e288(param_2,iRam003d4028);
      if (cVar1 == '\0') {
        cVar1 = FUN_0002e288(param_2,iRam003d402c);
        if (cVar1 == '\0') goto LAB_0002fbd7;
        cVar1 = (**(code **)(*param_1 + 0x160))(param_1,iVar10);
        if (cVar1 != '\0') {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xc0);
          uVar5 = FUN_000858da((int)*pcVar9);
          (*UNRECOVERED_JUMPTABLE)(param_1,"_setValueForKeyDirectly","v@@b",uVar5,iVar10,(int)cVar3)
          ;
        }
        cVar3 = FUN_00034584(param_2);
        *pcVar9 = cVar3;
      }
      else {
        cVar1 = (**(code **)(*param_1 + 0x160))(param_1,iVar10);
        if (cVar1 != '\0') {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xc0);
          uVar5 = FUN_000858da((int)*pcVar9);
          (*UNRECOVERED_JUMPTABLE)(param_1,"_setValueForKeyDirectly","v@@b",uVar5,iVar10,(int)cVar3)
          ;
        }
        cVar3 = func_0x00085f34(param_2);
        *pcVar9 = cVar3;
      }
      break;
    case 100:
      pdVar14 = (double *)((int)param_1 + *piVar6);
      if (param_2 == (int *)0x0) goto LAB_0002fbd7;
      cVar1 = FUN_0002e288(param_2,iRam003d4028);
      if (cVar1 == '\0') {
        cVar1 = FUN_0002e288(param_2,iRam003d402c);
        if (cVar1 == '\0') goto LAB_0002fbd7;
        cVar1 = (**(code **)(*param_1 + 0x160))(param_1,iVar10);
        if (cVar1 != '\0') {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xc0);
          uVar5 = func_0x00085b14(*pdVar14);
          (*UNRECOVERED_JUMPTABLE)(param_1,"_setValueForKeyDirectly","v@@b",uVar5,iVar10,(int)cVar3)
          ;
        }
        lVar16 = (longdouble)FUN_00034496(param_2);
        *pdVar14 = (double)(float)lVar16;
      }
      else {
        cVar1 = (**(code **)(*param_1 + 0x160))(param_1,iVar10);
        if (cVar1 != '\0') {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xc0);
          uVar5 = func_0x00085b14(*pdVar14);
          (*UNRECOVERED_JUMPTABLE)(param_1,"_setValueForKeyDirectly","v@@b",uVar5,iVar10,(int)cVar3)
          ;
        }
        lVar16 = (longdouble)func_0x00085302(param_2);
        *pdVar14 = (double)lVar16;
      }
      break;
    case 0x66:
      pfVar13 = (float *)((int)param_1 + *piVar6);
      if (param_2 == (int *)0x0) goto LAB_0002fbd7;
      cVar1 = FUN_0002e288(param_2,iRam003d4028);
      if (cVar1 == '\0') {
        cVar1 = FUN_0002e288(param_2,iRam003d402c);
        if (cVar1 == '\0') goto LAB_0002fbd7;
        cVar1 = (**(code **)(*param_1 + 0x160))(param_1,iVar10);
        if (cVar1 != '\0') {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xc0);
          uVar5 = func_0x00085a2c(*pfVar13);
          (*UNRECOVERED_JUMPTABLE)(param_1,"_setValueForKeyDirectly","v@@b",uVar5,iVar10,(int)cVar3)
          ;
        }
        lVar16 = (longdouble)FUN_00034496(param_2);
        *pfVar13 = (float)lVar16;
      }
      else {
        cVar1 = (**(code **)(*param_1 + 0x160))(param_1,iVar10);
        if (cVar1 != '\0') {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xc0);
          uVar5 = func_0x00085a2c(*pfVar13);
          (*UNRECOVERED_JUMPTABLE)(param_1,"_setValueForKeyDirectly","v@@b",uVar5,iVar10,(int)cVar3)
          ;
        }
        lVar16 = (longdouble)func_0x000853b8(param_2);
        *pfVar13 = (float)lVar16;
      }
      break;
    case 0x69:
      puVar15 = (undefined4 *)((int)param_1 + *piVar6);
      if (param_2 == (int *)0x0) goto LAB_0002fbd7;
      cVar1 = FUN_0002e288(param_2,iRam003d4028);
      if (cVar1 == '\0') {
        cVar1 = FUN_0002e288(param_2,iRam003d402c);
        if (cVar1 == '\0') goto LAB_0002fbd7;
        cVar1 = (**(code **)(*param_1 + 0x160))(param_1,iVar10);
        if (cVar1 != '\0') {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xc0);
          uVar5 = FUN_000858da(*puVar15);
          (*UNRECOVERED_JUMPTABLE)(param_1,"_setValueForKeyDirectly","v@@b",uVar5,iVar10,(int)cVar3)
          ;
        }
        uVar5 = FUN_00034584(param_2);
        *puVar15 = uVar5;
      }
      else {
        cVar1 = (**(code **)(*param_1 + 0x160))(param_1,iVar10);
        if (cVar1 != '\0') {
          UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0xc0);
          uVar5 = FUN_000858da(*puVar15);
          (*UNRECOVERED_JUMPTABLE)(param_1,"_setValueForKeyDirectly","v@@b",uVar5,iVar10,(int)cVar3)
          ;
        }
        uVar5 = func_0x00085f34(param_2);
        *puVar15 = uVar5;
      }
    }
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00063cee(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x1a3,uVar2,"this != 0");
  }
  if (*(int *)(param_1 + 0xc) == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x1a3,uVar2,"_keys");
  }
  if (*(int *)(param_1 + 0x10) == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x1a3,uVar2,"_objects");
  }
  if (param_2 == 0) {
    func_0x0000acae("GNDictionary: key is 0");
  }
  iVar4 = FUN_0002a8c2(*(undefined4 *)(param_1 + 0xc),param_2);
  if (iVar4 != -1) {
    piVar1 = *(int **)(param_1 + 0x10);
    if (piVar1 == (int *)0x0) {
      uVar2 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                             );
      uVar3 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x15b,uVar2,"this != 0");
    }
    if ((iVar4 < 0) || (piVar1[4] <= iVar4)) {
      uVar2 = (**(code **)(*piVar1 + 0xc))(piVar1);
      uVar2 = FUN_00034962(uVar2);
      func_0x0000acae("GNList::getObjectAtIndex(): Index %i out of range of %s.",iVar4,uVar2);
    }
    return *(undefined4 *)(piVar1[3] + iVar4 * 4);
  }
  return 0;
}


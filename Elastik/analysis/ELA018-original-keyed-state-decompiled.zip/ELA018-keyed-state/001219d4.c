
undefined4 FUN_001219d4(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char *pcVar4;
  int iVar5;
  int iVar6;
  
  uVar1 = FUN_00063426(*(undefined4 *)(param_1 + 0x28));
  uVar2 = FUN_00034962(param_2);
  iVar6 = 0;
  while( true ) {
    iVar5 = FUN_00029ddc(uVar1);
    if (iVar5 <= iVar6) {
      return 0;
    }
    uVar3 = FUN_0002a364(uVar1,iVar6);
    pcVar4 = (char *)FUN_00034962(uVar3);
    if (*pcVar4 == '@') {
      pcVar4 = pcVar4 + 1;
    }
    iVar5 = _strcmp(pcVar4,uVar2);
    if (iVar5 == 0) break;
    iVar6 = iVar6 + 1;
  }
  return 1;
}


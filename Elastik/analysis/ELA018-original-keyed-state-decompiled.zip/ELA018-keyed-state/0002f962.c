
int FUN_0002f962(int *param_1)

{
  char cVar1;
  undefined4 uVar2;
  
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_00022d78(uVar2);
  return (int)cVar1;
}


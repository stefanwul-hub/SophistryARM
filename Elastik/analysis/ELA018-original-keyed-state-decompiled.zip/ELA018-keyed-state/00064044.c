
int FUN_00064044(int param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = FUN_0002ae60(*(undefined4 *)(param_1 + 0xc),param_2);
  return (int)cVar1;
}


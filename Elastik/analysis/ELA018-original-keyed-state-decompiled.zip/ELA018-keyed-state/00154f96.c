
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00154f96(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (*(int *)(param_1 + 0x34) == 0) {
    uVar2 = __Znwm(0x18);
    FUN_000630b6(uVar2);
    uVar2 = FUN_0002dfa6(uVar2);
    *(undefined4 *)(param_1 + 0x34) = uVar2;
    iVar1 = FUN_00064626(*(undefined4 *)(param_1 + 0x34),param_2);
  }
  else {
    iVar1 = FUN_00064626(*(undefined4 *)(param_1 + 0x34),param_2);
  }
  if (iVar1 != 0) {
    return iVar1;
  }
  iVar1 = FUN_0003dd2a("@%@",param_2);
  FUN_00066284(*(undefined4 *)(param_1 + 0x34),iVar1,param_2);
  return iVar1;
}


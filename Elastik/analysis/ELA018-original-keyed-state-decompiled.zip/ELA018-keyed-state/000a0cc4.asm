000a0cc4  55  PUSH EBP
000a0cc5  89e5  MOV EBP,ESP
000a0cc7  8b4508  MOV EAX,dword ptr [EBP + 0x8]
000a0cca  8b400c  MOV EAX,dword ptr [EAX + 0xc]
000a0ccd  5d  POP EBP
000a0cce  c3  RET


int FUN_000219c4(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  
  if (*(int *)(param_1 + 0x44) == 0) {
    uVar4 = __Znwm(0x18);
    FUN_000630b6(uVar4);
    uVar4 = FUN_0002dfa6(uVar4);
    *(undefined4 *)(param_1 + 0x44) = uVar4;
    func_0x00065c4a(uVar4,1);
  }
  iVar2 = FUN_00064626(*(undefined4 *)(param_1 + 0x44),param_2);
  if (iVar2 != 0) {
    return iVar2;
  }
  iVar2 = *(int *)(param_1 + 0x24);
  if (iVar2 != 0) {
    iVar5 = 0;
    do {
      iVar2 = FUN_00029ddc(iVar2);
      if (iVar2 <= iVar5) break;
      iVar2 = FUN_0002a364(*(undefined4 *)(param_1 + 0x24),iVar5);
      piVar3 = (int *)FUN_000a0cc4(iVar2);
      cVar1 = (**(code **)(*piVar3 + 0x88))(piVar3,param_2);
      if (cVar1 != '\0') goto LAB_00021abd;
      iVar5 = iVar5 + 1;
      iVar2 = *(int *)(param_1 + 0x24);
    } while (iVar2 != 0);
  }
  iVar2 = FUN_00021738(param_1);
  if (iVar2 != 0) {
    uVar4 = FUN_00021738(param_1);
    iVar2 = FUN_000219c4(uVar4,param_2);
    if (iVar2 != 0) {
LAB_00021abd:
      FUN_00066284(*(undefined4 *)(param_1 + 0x44),iVar2,param_2);
      return iVar2;
    }
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

bool FUN_0002e288(int *param_1,int param_2)

{
  code *pcVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  if (param_1 == (int *)0x0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNObject.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x1e0,uVar4,"this != 0");
  }
  if (param_2 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNObject.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x1e0,uVar4,"classname");
  }
  piVar3 = (int *)(**(code **)(*param_1 + 8))(param_1);
  if (piVar3 != (int *)0x0) {
    pcVar1 = *(code **)(*piVar3 + 0x88);
    uVar4 = FUN_0001fcfc(param_2);
    cVar2 = (*pcVar1)(piVar3,uVar4);
    return cVar2 != '\0';
  }
  uVar4 = (**(code **)(*param_1 + 0xc))(param_1);
  FUN_0000ab14("GNObject::isMemberOfClassWithName(): %s is missing a class description.",uVar4);
  return false;
}


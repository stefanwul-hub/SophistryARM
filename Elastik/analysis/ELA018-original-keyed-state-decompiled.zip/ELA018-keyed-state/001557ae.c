
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001557ae(int param_1,int *param_2,int param_3)

{
  char cVar1;
  char *pcVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  int *piVar9;
  uint uVar10;
  char *pcVar11;
  int iStack_14;
  
  piVar9 = param_2;
  iVar8 = param_3;
  if (param_1 == 0) {
    uVar6 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNKeyValueArchiver.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xfa,uVar6,"this != 0");
  }
  if (piVar9 == (int *)0x0) {
    return;
  }
  iVar5 = FUN_00063cee(*(undefined4 *)(param_1 + 0x24),*(undefined4 *)(param_1 + 0x28));
  if (iVar5 == 0) {
    uVar6 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNKeyValueArchiver.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x100,uVar6,"d");
  }
  cVar1 = FUN_00154f1c(param_1,piVar9);
  if (cVar1 == '\0') {
    cVar1 = FUN_0002ae60(*(undefined4 *)(param_1 + 0x18),piVar9);
    if (cVar1 == '\0') {
      FUN_0002bb40(*(undefined4 *)(param_1 + 0x18),piVar9);
    }
    cVar1 = FUN_00064044(*(undefined4 *)(param_1 + 0x24),piVar9);
    if (cVar1 == '\0') {
      uVar6 = __Znwm(0x18);
      FUN_000630b6(uVar6);
      piVar7 = (int *)FUN_0002dfa6(uVar6);
      uVar6 = (**(code **)(*piVar7 + 0x48))(piVar7);
      FUN_00066072(*(undefined4 *)(param_1 + 0x24),uVar6,piVar9);
    }
    iVar8 = FUN_00154f96(param_1,iVar8);
    uVar6 = FUN_0002a8c2(*(undefined4 *)(param_1 + 0x18),piVar9);
    piVar9 = (int *)FUN_000858da(uVar6);
  }
  param_3 = iVar8;
  param_2 = piVar9;
  iVar8 = param_3;
  piVar9 = param_2;
  if (iVar5 == 0) {
    uVar6 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xfe,uVar6,"this != 0");
  }
  if (*(int *)(iVar5 + 0xc) == 0) {
    uVar6 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xfe,uVar6,"_keys");
  }
  if (*(int *)(iVar5 + 0x10) == 0) {
    uVar6 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xfe,uVar6,"_objects");
  }
  if (iVar8 == 0) {
    func_0x0000acae("GNDictionary: key is 0");
  }
  if ((piVar9 == (int *)0x0) && (cVar1 = func_0x000639f0(iVar5), cVar1 == '\0')) {
    pcVar2 = "Attempt to insert 0 as an object into a dictionary";
    if (cRam003d3ef8 == '\0') {
      uVar10 = 0xffffffff;
      pcVar11 = pcVar2;
      do {
        if (uVar10 == 0) break;
        uVar10 = uVar10 - 1;
        cVar1 = *pcVar11;
        pcVar11 = pcVar11 + 1;
      } while (cVar1 != '\0');
      cVar1 = ~uVar10 - 1 < 0x2000;
      if ((bool)cVar1) {
        pcVar2 = (char *)FUN_0000aecc((~uVar10 - 1) * 3 + 0x400);
        _vsprintf(pcVar2,"Attempt to insert 0 as an object into a dictionary",&param_2);
      }
      if (piRam003d3f0c == (int *)0x0) {
        uVar6 = __Znwm(0x38);
        func_0x0006f04a(uVar6);
        piRam003d3f0c = (int *)FUN_0002dfa6(uVar6);
      }
      (**(code **)(*piRam003d3f0c + 0x1a4))(piRam003d3f0c);
      _puts(pcVar2);
      (**(code **)(*piRam003d3f0c + 0x1ac))(piRam003d3f0c);
      if (cVar1 != '\0') {
        if (pcVar2 != (char *)0x0) {
          if (cRam003d3f09 == '\0') {
            cRam003d3f09 = 1;
            if (iRam003d3ee8 != 0) {
              func_0x000424ac(iRam003d3ee8,pcVar2);
            }
            cRam003d3f09 = '\0';
          }
          _free(pcVar2);
          return;
        }
        FUN_0000ab14("GNFree(0)");
      }
    }
    return;
  }
  if (*(int *)(iVar5 + 0x14) == 0) {
    iVar4 = func_0x0002a9ba(*(undefined4 *)(iVar5 + 0xc),iVar8);
  }
  else {
    iVar4 = func_0x0006440e(iVar5,iVar8);
  }
  if (iVar4 != -1) {
    piVar7 = (int *)FUN_0002a364(*(undefined4 *)(iVar5 + 0x10),iVar4);
    if (piVar9 == piVar7) {
      return;
    }
    func_0x0002a62c(*(undefined4 *)(iVar5 + 0x10),iVar4);
    piVar7 = *(int **)(iVar5 + 0x10);
    param_2 = piVar9;
    param_3 = iVar4;
    if (piVar7 == (int *)0x0) {
      uVar6 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                             );
      uVar3 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x18c,uVar6,"this != 0");
    }
    if ((param_2 == (int *)0x0) && (*(char *)((int)piVar7 + 0x19) == '\0')) {
      uVar6 = (**(code **)(*piVar7 + 0xc))(piVar7);
      uVar6 = FUN_00034962(uVar6);
      func_0x0000acae("GNList::insertObjectAtIndex(): Cannot insert nil object into %s.",uVar6);
    }
    if ((piVar7[4] < param_3) || (param_3 < 0)) {
      uVar6 = (**(code **)(*piVar7 + 0xc))(piVar7);
      uVar6 = FUN_00034962(uVar6);
      func_0x0000acae("GNList::insertObjectAtIndex(): Index %i out of range of %s.",param_3,uVar6);
      iVar8 = piVar7[4] + 1;
      piVar7[4] = iVar8;
    }
    else {
      iVar8 = piVar7[4] + 1;
      piVar7[4] = iVar8;
    }
    iVar5 = iVar8 * 0x10 + 1;
    if (iVar5 < 0) {
      iVar5 = iVar8 * 0x10 + 0x10;
    }
    FUN_0002a14a(piVar7,iVar5 >> 4);
    iVar8 = piVar7[4] + -1;
    if (param_3 < iVar8) {
      iVar5 = iVar8 * 4;
      do {
        *(undefined4 *)(iVar5 + piVar7[3]) = ((undefined4 *)(iVar5 + piVar7[3]))[-1];
        iVar8 = iVar8 + -1;
        iVar5 = iVar5 + -4;
      } while (param_3 < iVar8);
    }
    *(int **)(piVar7[3] + param_3 * 4) = param_2;
    if (((char)piVar7[6] == '\0') && (param_2 != (int *)0x0)) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
    return;
  }
  FUN_0002bb40(*(undefined4 *)(iVar5 + 0xc),iVar8);
  FUN_0002bb40(*(undefined4 *)(iVar5 + 0x10),piVar9);
  iVar8 = FUN_00029ddc(*(undefined4 *)(iVar5 + 0xc));
  param_2 = (int *)(iVar8 + -1);
  if (*(int *)(iVar5 + 0x14) != 0) {
    piVar9 = (int *)func_0x000427b6(*(int *)(iVar5 + 0x14));
    iVar8 = func_0x00041be2(*(undefined4 *)(iVar5 + 0x14));
    piVar7 = (int *)FUN_0002a364(*(undefined4 *)(iVar5 + 0xc),param_2);
    iStack_14 = (**(code **)(*piVar7 + 0x90))(piVar7);
    if (iVar8 < 1) {
code_r0x00066056:
      func_0x00042ffe(*(undefined4 *)(iVar5 + 0x14),&iStack_14);
      return;
    }
    if (*piVar9 == iStack_14 || *piVar9 - iStack_14 < 0) {
      iVar4 = 0;
      do {
        piVar9 = piVar9 + 2;
        iVar4 = iVar4 + 1;
        if (iVar8 == iVar4) goto code_r0x00066056;
      } while (*piVar9 == iStack_14 || *piVar9 - iStack_14 < 0);
    }
    else {
      iVar4 = 0;
    }
    func_0x00042dcc(*(undefined4 *)(iVar5 + 0x14),&iStack_14,iVar4);
  }
  return;
}


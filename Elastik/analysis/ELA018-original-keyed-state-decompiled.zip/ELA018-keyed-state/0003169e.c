
void FUN_0003169e(int *param_1,int *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  code *pcVar7;
  undefined4 uStack_10;
  
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  uVar3 = (**(code **)(*param_1 + 0x18c))(param_1,param_2);
  uStack_10 = 0;
  do {
    iVar5 = FUN_00029ddc(uVar3);
    if (iVar5 <= uStack_10) {
      return;
    }
    uVar6 = FUN_0002a364(uVar3,uStack_10);
    iVar5 = FUN_00021c02(uVar2,uVar6);
    if (iVar5 == 0) {
      iVar5 = FUN_000219c4(uVar2,uVar6);
      if (iVar5 != 0) {
        cVar1 = func_0x000fc83e(iVar5);
        if (cVar1 != '\0') goto LAB_000316da;
        pcVar7 = *(code **)(*param_2 + 0x238);
        goto LAB_000316e5;
      }
    }
    else {
LAB_000316da:
      pcVar7 = *(code **)(*param_2 + 0x234);
LAB_000316e5:
      uVar4 = (**(code **)(*param_1 + 0x16c))(param_1,uVar6);
      (*pcVar7)(param_2,uVar4,uVar6);
    }
    uStack_10 = uStack_10 + 1;
  } while( true );
}


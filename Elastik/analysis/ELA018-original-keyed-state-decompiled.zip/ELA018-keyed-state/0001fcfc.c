
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0001fcfc(int param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  char *pcVar4;
  int iVar5;
  
  if (iRam003d3fc4 == 0) {
    return 0;
  }
  iVar1 = FUN_00064626(iRam003d3fc4,param_1);
  if (iVar1 == 0) {
    for (iVar5 = 0; iVar3 = FUN_00029ddc(uRam003d3fc8), iVar5 < iVar3; iVar5 = iVar5 + 1) {
      piVar2 = (int *)FUN_0002a364(uRam003d3fc8,iVar5);
      iVar1 = (**(code **)(*piVar2 + 0x200))(piVar2,param_1);
      if (iVar1 != 0) {
        return iVar1;
      }
      iVar1 = 0;
    }
    if (param_1 == 0) {
      pcVar4 = "";
    }
    else {
      pcVar4 = (char *)FUN_00034962(param_1);
    }
    FUN_0000ab14("Class with name %s not registered.",pcVar4);
  }
  return iVar1;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0001fdb0(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char *pcVar3;
  int iVar4;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNClassDescription.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x14b,uVar1,"this != 0");
  }
  do {
    iVar4 = param_1;
    if (*(int *)(iVar4 + 0x14) != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001fe3f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar1 = (**(code **)(iVar4 + 0x14))();
      return uVar1;
    }
    param_1 = FUN_0001fcfc(*(undefined4 *)(iVar4 + 0xc));
  } while (param_1 != 0);
  if (*(code **)(iVar4 + 0x14) == (code *)0x0) {
    if (*(int *)(iVar4 + 0xc) == 0) {
      pcVar3 = "";
    }
    else {
      pcVar3 = (char *)FUN_00034962(*(int *)(iVar4 + 0xc));
    }
    func_0x0000acae("Cannot create new object of class %s. No function available.",pcVar3);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001fe33. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(iVar4 + 0x14))();
  return uVar1;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001218f2(int *param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char *pcVar4;
  int iVar5;
  int iVar6;
  
  uVar1 = FUN_00063426(*(undefined4 *)((int)param_1 + 0x28));
  uVar2 = FUN_00034962(param_2);
  param_2 = 0;
  while( true ) {
    iVar5 = FUN_00029ddc(uVar1);
    if (iVar5 <= param_2) {
      return 0;
    }
    uVar3 = FUN_0002a364(uVar1,param_2);
    pcVar4 = (char *)FUN_00034962(uVar3);
    iVar5 = _strcmp(pcVar4,uVar2);
    if (iVar5 == 0) {
      param_1 = (int *)FUN_00063ade(*(undefined4 *)((int)param_1 + 0x28));
      goto code_r0x0002a364;
    }
    if (*pcVar4 == '@') {
      pcVar4 = pcVar4 + 1;
    }
    iVar5 = _strcmp(pcVar4,uVar2);
    if (iVar5 == 0) break;
    param_2 = param_2 + 1;
  }
  uVar1 = FUN_00063ade(*(undefined4 *)((int)param_1 + 0x28));
  iVar6 = FUN_0002a364(uVar1,param_2);
  iVar5 = *(int *)((int)param_1 + 0x20);
  if (iVar5 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x16d,uVar1,"this != 0");
  }
  if (*(int *)(iVar5 + 0xc) == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x16d,uVar1,"_keys");
  }
  if (*(int *)(iVar5 + 0x10) == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x16d,uVar1,"_objects");
  }
  if (iVar6 == 0) {
    func_0x0000acae("GNDictionary: key is 0");
  }
  if (*(int *)(iVar5 + 0x14) != 0) {
    param_2 = func_0x0006440e(iVar5,iVar6);
    if (param_2 != -1) goto LAB_0006467d;
  }
  param_2 = func_0x0002a9ba(*(undefined4 *)(iVar5 + 0xc),iVar6);
  if (param_2 == -1) {
    return 0;
  }
LAB_0006467d:
  param_1 = *(int **)(iVar5 + 0x10);
code_r0x0002a364:
  if (param_1 == (int *)0x0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x15b,uVar1,"this != 0");
  }
  if ((param_2 < 0) || (param_1[4] <= param_2)) {
    uVar1 = (**(code **)(*param_1 + 0xc))(param_1);
    uVar1 = FUN_00034962(uVar1);
    func_0x0000acae("GNList::getObjectAtIndex(): Index %i out of range of %s.",param_2,uVar1);
  }
  return *(undefined4 *)(param_1[3] + param_2 * 4);
}


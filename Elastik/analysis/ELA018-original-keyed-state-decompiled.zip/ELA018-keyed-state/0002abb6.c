
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

bool FUN_0002abb6(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    iVar1 = func_0x0002a9ba(param_1,param_2);
    return iVar1 != -1;
  }
  uVar2 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                         );
  uVar3 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x2df,uVar2,"this != 0");
  iVar1 = func_0x0002a9ba(0,param_2);
  return iVar1 != -1;
}


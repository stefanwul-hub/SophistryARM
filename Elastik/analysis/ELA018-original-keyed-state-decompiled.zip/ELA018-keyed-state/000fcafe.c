
undefined4 FUN_000fcafe(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = func_0x000a0e70(param_1);
  if (iVar1 != 0) {
    uVar2 = FUN_000a0cc4(param_1);
    uVar2 = func_0x000226f0(iVar1,uVar2);
    return uVar2;
  }
  return 0;
}


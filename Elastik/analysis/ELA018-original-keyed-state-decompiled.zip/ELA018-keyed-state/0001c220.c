
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0001c220(int *param_1,int *param_2)

{
  code *pcVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  longdouble lVar7;
  int iStack_28;
  int iStack_20;
  
  pcVar1 = *(code **)(*param_2 + 0x270);
  uVar4 = FUN_00033b90("GNAudioProcessor");
  iVar5 = (*pcVar1)(param_2,uVar4);
  iStack_20 = iVar5;
  if (iVar5 == 0) {
    pcVar1 = *(code **)(*param_2 + 0x270);
    uVar4 = FUN_00033b90("GNAudioMixer");
    iVar6 = (*pcVar1)(param_2,uVar4);
    iStack_20 = 3;
    if (iVar6 != 3) {
      iStack_20 = iVar5;
    }
  }
  piVar2 = (int *)param_1[0xb];
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x44))(piVar2);
  }
  param_1[0xb] = 0;
  piVar2 = (int *)param_1[0xc];
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x44))(piVar2);
  }
  param_1[0xc] = 0;
  iVar5 = (**(code **)(*param_2 + 0x208))(param_2);
  param_1[0xb] = iVar5;
  iVar5 = (**(code **)(*param_2 + 0x208))(param_2);
  param_1[0xc] = iVar5;
  piVar2 = (int *)param_1[0xb];
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x40))(piVar2);
  }
  piVar2 = (int *)param_1[0xc];
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x40))(piVar2);
  }
  cVar3 = (**(code **)(*param_2 + 0x1e4))(param_2);
  if ((cVar3 != '\0') && (iVar5 = (**(code **)(*param_2 + 0x1ec))(param_2), 0 < iVar5)) {
    iStack_28 = 0;
    do {
      pcVar1 = *(code **)(*param_1 + 0x2a4);
      lVar7 = (longdouble)(**(code **)(*param_2 + 0x1f0))(param_2);
      (*pcVar1)(param_1,(float)lVar7,iStack_28);
      iStack_28 = iStack_28 + 1;
    } while (iVar5 != iStack_28);
  }
  if (2 < iStack_20) {
    iVar5 = (**(code **)(*param_2 + 0x208))(param_2);
    param_1[0xf] = iVar5;
  }
  return;
}


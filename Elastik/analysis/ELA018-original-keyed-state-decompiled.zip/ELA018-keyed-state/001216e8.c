
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_001216e8(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 *puVar2;
  int *piVar3;
  float *pfVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uVar7;
  longdouble lVar8;
  
  iVar6 = FUN_00064626(param_3,param_2);
  if (iVar6 == 0) {
    puVar2 = (undefined4 *)__Znwm(0x14);
    func_0x001821dc(puVar2);
    *puVar2 = &UNK_00374468;
    *(undefined1 *)(puVar2 + 4) = 0;
    puVar2[3] = 0;
    piVar3 = (int *)FUN_0002dfa6(puVar2);
    iVar6 = (**(code **)(*piVar3 + 0x48))(piVar3);
    if (iVar6 != 0) {
      *(undefined1 *)(iVar6 + 0x10) = 0x69;
      *(undefined4 *)(iVar6 + 0xc) = 0;
      return iVar6;
    }
    uVar7 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNNumber.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x9e,uVar7,"this != 0");
    mach_header_00000000.ncmds._0_1_ = 0x69;
    mach_header_00000000.filetype = 0;
    return 0;
  }
  uVar7 = FUN_00033b90("GNString");
  cVar1 = FUN_0002e288(iVar6,uVar7);
  if (cVar1 == '\0') {
    return iVar6;
  }
  lVar8 = (longdouble)FUN_00034496(iVar6);
  puVar2 = (undefined4 *)__Znwm(0x14);
  func_0x001821dc(puVar2);
  *puVar2 = &UNK_00374468;
  *(undefined1 *)(puVar2 + 4) = 0;
  puVar2[3] = 0;
  piVar3 = (int *)FUN_0002dfa6(puVar2);
  iVar6 = (**(code **)(*piVar3 + 0x48))(piVar3);
  if (iVar6 == 0) {
    uVar7 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNNumber.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xaf,uVar7,"this != 0");
  }
  *(undefined1 *)(iVar6 + 0x10) = 0x66;
  if (*(int *)(iVar6 + 0xc) != 0) {
    **(float **)(iVar6 + 0xc) = (float)lVar8;
    return iVar6;
  }
  pfVar4 = (float *)FUN_0000aecc(4);
  *(float **)(iVar6 + 0xc) = pfVar4;
  *pfVar4 = (float)lVar8;
  return iVar6;
}


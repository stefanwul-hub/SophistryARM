
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00155396(int param_1,int *param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  int *piVar9;
  undefined1 auStack_6c [76];
  int *piStack_20;
  
  uVar4 = (**(code **)(*param_2 + 8))(param_2);
  cVar3 = FUN_0002abb6(*(undefined4 *)(param_1 + 0x1c),uVar4);
  if (cVar3 == '\0') {
    FUN_0002bb40(*(undefined4 *)(param_1 + 0x1c),uVar4);
  }
  uVar5 = FUN_00063cee(*(undefined4 *)(param_1 + 0x24),param_2);
  uVar6 = FUN_00033b90("@id");
  uVar7 = FUN_0002a8c2(*(undefined4 *)(param_1 + 0x18),param_2);
  uVar7 = FUN_000858da(uVar7);
  FUN_00066284(uVar5,uVar7,uVar6);
  uVar6 = FUN_00033b90("@isa");
  uVar4 = func_0x0001f4dc(uVar4);
  FUN_00066284(uVar5,uVar4,uVar6);
  *(int **)(param_1 + 0x28) = param_2;
  FUN_0000bea2(auStack_6c);
  iVar8 = _setjmp(auStack_6c);
  if (iVar8 == 0) {
    cVar3 = (**(code **)(*param_2 + 0x164))(param_2);
    if (cVar3 == '\0') {
      (**(code **)(*param_2 + 0x70))(param_2,param_1);
    }
    else {
      (**(code **)(*param_2 + 0x188))(param_2,param_1);
    }
    FUN_0000bec0(auStack_6c);
  }
  else {
    piVar9 = (int *)(**(code **)(*piStack_20 + 0x1ac))(piStack_20);
    pcVar2 = *(code **)(*piVar9 + 0x88);
    uVar4 = FUN_00033b90("GNCodingDoneSignal");
    cVar3 = (*pcVar2)(piVar9,uVar4);
    if (cVar3 == '\0') {
      (**(code **)(*piStack_20 + 0x1a8))(piStack_20);
    }
  }
  puVar1 = *(undefined4 **)(param_1 + 0x2c);
  if (puVar1 != (undefined4 *)0x0) {
    (**(code **)*puVar1)(puVar1,param_1,param_2,uVar5);
  }
  return;
}


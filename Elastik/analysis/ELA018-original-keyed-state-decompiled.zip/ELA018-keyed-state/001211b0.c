
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_001211b0(int param_1,int *param_2)

{
  undefined4 *puVar1;
  code *pcVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  int *piVar10;
  int *piVar11;
  undefined4 uVar12;
  int iStack_7c;
  int iStack_70;
  undefined1 auStack_6c [76];
  int *piStack_20;
  
  if (param_2 != (int *)0x0) {
    uVar4 = FUN_00033b90("objects");
    uVar4 = FUN_00064626(param_2,uVar4);
    *(undefined4 *)(param_1 + 0x18) = uVar4;
    uVar4 = __Znwm(0x20);
    FUN_00029d44(uVar4);
    uVar4 = FUN_0002dfa6(uVar4);
    *(undefined4 *)(param_1 + 0x1c) = uVar4;
    uVar4 = __Znwm(0x18);
    FUN_000630b6(uVar4);
    uVar4 = FUN_0002dfa6(uVar4);
    *(undefined4 *)(param_1 + 0x20) = uVar4;
    for (iStack_7c = 0; iVar5 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x18)), iStack_7c < iVar5;
        iStack_7c = iStack_7c + 1) {
      uVar4 = FUN_0002a364(*(undefined4 *)(param_1 + 0x18),iStack_7c);
      uVar6 = FUN_00033b90("@id");
      iVar5 = FUN_00064626(uVar4,uVar6);
      if (iVar5 == 0) {
        uVar6 = func_0x0000a930(
                               "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNKeyValueUnarchiver.cpp"
                               );
        uVar12 = FUN_00033b90("GNAssertionException");
        FUN_0000bfd6(uVar12,"Assertion failed in line %d of %s: %s.",0xa8,uVar6,"objectId");
      }
      puVar1 = *(undefined4 **)(param_1 + 0x2c);
      if ((puVar1 == (undefined4 *)0x0) ||
         (piVar7 = (int *)(**(code **)*puVar1)(puVar1,param_1,uVar4), piVar7 == (int *)0x0)) {
        uVar6 = FUN_00033b90("@isa");
        iVar8 = FUN_00064626(uVar4,uVar6);
        if (iVar8 == 0) {
          uVar4 = func_0x0000a930(
                                 "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNKeyValueUnarchiver.cpp"
                                 );
          uVar6 = FUN_00033b90("GNAssertionException");
          FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0xb5,uVar4,
                       "classDescriptionName");
          iVar9 = FUN_0001fcfc(0);
          if (iVar9 == 0) goto LAB_001215fb;
LAB_00121325:
          piVar7 = (int *)FUN_0001fdb0(iVar9);
        }
        else {
          iVar9 = FUN_0001fcfc(iVar8);
          if (iVar9 != 0) goto LAB_00121325;
LAB_001215fb:
          uVar4 = FUN_00033b90("GNCodingException");
          FUN_0000bfd6(uVar4,"Class %@ not registered.",iVar8);
          piVar7 = (int *)FUN_0001fdb0(iVar9);
        }
        if (piVar7 == (int *)0x0) {
          uVar4 = func_0x0000a930(
                                 "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNKeyValueUnarchiver.cpp"
                                 );
          uVar6 = FUN_00033b90("GNAssertionException");
          FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0xba,uVar4,"object");
        }
        (**(code **)(*piVar7 + 0x54))(piVar7,param_1);
        FUN_0002bb40(*(undefined4 *)(param_1 + 0x1c),piVar7);
        (**(code **)(*piVar7 + 0x44))(piVar7);
      }
      else {
        FUN_0002bb40(*(undefined4 *)(param_1 + 0x1c),piVar7);
      }
      FUN_00066284(*(undefined4 *)(param_1 + 0x20),piVar7,iVar5);
    }
    for (iStack_70 = 0; iVar5 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x1c)), iStack_70 < iVar5;
        iStack_70 = iStack_70 + 1) {
      uVar4 = FUN_0002a364(*(undefined4 *)(param_1 + 0x1c),iStack_70);
      *(undefined4 *)(param_1 + 0x24) = uVar4;
      uVar4 = FUN_0002a364(*(undefined4 *)(param_1 + 0x18),iStack_70);
      *(undefined4 *)(param_1 + 0x28) = uVar4;
      uVar4 = __Znwm(0x14);
      FUN_0001e688(uVar4);
      piVar10 = (int *)FUN_0002dfa6(uVar4);
      piVar7 = *(int **)(param_1 + 0x2c);
      if (piVar7 != (int *)0x0) {
        (**(code **)(*piVar7 + 4))
                  (piVar7,param_1,*(undefined4 *)(param_1 + 0x24),*(undefined4 *)(param_1 + 0x28));
      }
      FUN_0000bea2(auStack_6c);
      iVar5 = _setjmp(auStack_6c);
      piVar7 = piStack_20;
      if (iVar5 == 0) {
        cVar3 = (**(code **)(**(int **)(param_1 + 0x24) + 0x164))(*(int **)(param_1 + 0x24));
        if (cVar3 == '\0') {
          (**(code **)(**(int **)(param_1 + 0x24) + 0x6c))(*(int **)(param_1 + 0x24),param_1);
        }
        else {
          (**(code **)(**(int **)(param_1 + 0x24) + 0x184))(*(int **)(param_1 + 0x24),param_1);
        }
        FUN_0000bec0(auStack_6c);
      }
      else {
        piVar11 = (int *)(**(code **)(*piStack_20 + 0x1ac))(piStack_20);
        pcVar2 = *(code **)(*piVar11 + 0x88);
        uVar4 = FUN_00033b90("GNCodingDoneSignal");
        cVar3 = (*pcVar2)(piVar11,uVar4);
        if (cVar3 == '\0') {
          (**(code **)(*piVar7 + 0x1a8))(piVar7);
        }
      }
      piVar7 = *(int **)(param_1 + 0x2c);
      if (piVar7 != (int *)0x0) {
        (**(code **)(*piVar7 + 8))
                  (piVar7,param_1,*(undefined4 *)(param_1 + 0x24),*(undefined4 *)(param_1 + 0x28));
      }
      FUN_0001ea42(piVar10);
      if (piVar10 != (int *)0x0) {
        (**(code **)(*piVar10 + 0x44))(piVar10);
      }
    }
    if (*(char *)(param_1 + 0x30) != '\0') {
      for (iVar5 = 0; iVar8 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x1c)), iVar5 < iVar8;
          iVar5 = iVar5 + 1) {
        piVar7 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0x1c),iVar5);
        *(int **)(param_1 + 0x24) = piVar7;
        (**(code **)(*piVar7 + 0x7c))(piVar7,param_1);
      }
    }
    iVar5 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x1c));
    if (iVar5 == 0) {
      FUN_0000ab14("GNKeyValueUnarchiver: Archive does not contain an object.");
    }
    param_2 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0x1c),0);
    if (param_2 != (int *)0x0) {
      (**(code **)(*param_2 + 0x40))(param_2);
      (**(code **)(*param_2 + 0x48))(param_2);
    }
  }
  return param_2;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_00021738(int param_1)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  
  if (*(int **)(param_1 + 0x40) != (int *)0x0) {
    return *(int **)(param_1 + 0x40);
  }
  iVar3 = *(int *)(param_1 + 0x10);
  if (iVar3 == 0) {
LAB_000217bb:
    piVar2 = (int *)0x0;
  }
  else {
    piVar2 = *(int **)(param_1 + 0x38);
    if (piVar2 == (int *)0x0) {
LAB_000217a0:
      piVar2 = (int *)(**(code **)(*piRam003d3fc0 + 0x200))(piRam003d3fc0,iVar3);
      if (piVar2 == (int *)0x0) goto LAB_000217bb;
    }
    else {
      piVar2 = (int *)(**(code **)(*piVar2 + 0x200))(piVar2,iVar3);
      if (piVar2 == (int *)0x0) {
        iVar3 = *(int *)(param_1 + 0x10);
        goto LAB_000217a0;
      }
    }
    piVar1 = *(int **)(param_1 + 0x40);
    if (piVar2 != piVar1) {
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x44))(piVar1);
      }
      *(int **)(param_1 + 0x40) = piVar2;
      (**(code **)(*piVar2 + 0x40))(piVar2);
    }
  }
  return piVar2;
}


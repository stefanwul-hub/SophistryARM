
undefined4 FUN_000fd052(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = func_0x000a0e70(param_1);
  if (iVar1 != 0) {
    uVar2 = FUN_000a0cc4(param_1);
    iVar1 = func_0x000226f0(iVar1,uVar2);
    if (iVar1 != 0) {
      return *(undefined4 *)(iVar1 + 0xc);
    }
  }
  return 0;
}


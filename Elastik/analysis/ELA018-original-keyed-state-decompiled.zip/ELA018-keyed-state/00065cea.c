
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00065cea(int param_1)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  
  if (param_1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x161,uVar4,"this != 0");
  }
  if (*(int *)(param_1 + 0xc) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x161,uVar4,"_keys");
  }
  if (*(int *)(param_1 + 0x10) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x161,uVar4,"_objects");
  }
  FUN_0002ad82(*(undefined4 *)(param_1 + 0xc));
  FUN_0002ad82(*(undefined4 *)(param_1 + 0x10));
  if (*(int *)(param_1 + 0x14) != 0) {
    func_0x0004258e(*(undefined4 *)(param_1 + 0x14));
    iVar1 = FUN_00029ddc(*(undefined4 *)(param_1 + 0xc));
    func_0x00041ab8(*(undefined4 *)(param_1 + 0x14),iVar1);
    func_0x00042828(*(undefined4 *)(param_1 + 0x14));
    puVar2 = (undefined4 *)func_0x000427b6(*(undefined4 *)(param_1 + 0x14));
    if (iVar1 < 1) {
      func_0x00042668(*(undefined4 *)(param_1 + 0x14),&UNK_000643fe,0);
      return;
    }
    iVar6 = 0;
    do {
      piVar3 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0xc),iVar6);
      uVar4 = (**(code **)(*piVar3 + 0x90))(piVar3);
      *puVar2 = uVar4;
      puVar2[1] = iVar6;
      puVar2 = puVar2 + 2;
      iVar6 = iVar6 + 1;
    } while (iVar1 != iVar6);
    func_0x00042668(*(undefined4 *)(param_1 + 0x14),&UNK_000643fe,0);
    return;
  }
  return;
}


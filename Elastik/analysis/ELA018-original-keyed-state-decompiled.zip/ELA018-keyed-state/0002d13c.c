
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002d13c(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x1cb,uVar2,"this != 0");
  }
  if ((param_2 != 0) && (iVar4 = *(int *)(param_2 + 0x10), iVar4 != 0)) {
    if (*(int *)(param_1 + 0x10) == 0) {
      FUN_0002a14a(param_1,iVar4);
      _memcpy(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_2 + 0xc),
              *(int *)(param_2 + 0x10) << 2);
      iVar4 = *(int *)(param_2 + 0x10);
      *(int *)(param_1 + 0x10) = iVar4;
      if ((*(char *)(param_1 + 0x18) == '\0') && (0 < iVar4)) {
        iVar4 = 0;
        do {
          piVar1 = *(int **)(*(int *)(param_1 + 0xc) + iVar4 * 4);
          if (piVar1 != (int *)0x0) {
            (**(code **)(*piVar1 + 0x40))(piVar1);
          }
          iVar4 = iVar4 + 1;
        } while (iVar4 < *(int *)(param_1 + 0x10));
      }
    }
    else if (0 < iVar4) {
      iVar4 = 0;
      do {
        uVar2 = FUN_0002a364(param_2,iVar4);
        FUN_0002bb40(param_1,uVar2);
        iVar4 = iVar4 + 1;
      } while (iVar4 < *(int *)(param_2 + 0x10));
      return;
    }
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0001ea42(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 *puVar5;
  int *piVar6;
  int iVar7;
  char *pcVar8;
  
  if ((*(int *)(param_1 + 0xc) != 0) &&
     ((cVar1 = func_0x0000a72a(), cVar1 != '\0' ||
      (iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0xc)), *(int *)(param_1 + 0x10) <= iVar2)))) {
    while (iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0xc)), *(int *)(param_1 + 0x10) <= iVar2)
    {
      while( true ) {
        piVar6 = *(int **)(param_1 + 0xc);
        func_0x0001e99c(param_1);
        iVar2 = FUN_00029ddc(piVar6);
        if (0 < iVar2) {
          iVar7 = 0;
          pcVar8 = "GNAutoreleasePool skips releasing the damaged object.";
          do {
            piVar4 = (int *)FUN_0002a364(piVar6,iVar7);
            cVar1 = func_0x0002e058(piVar4);
            if (cVar1 == '\0') {
              FUN_0000ab14(pcVar8);
            }
            else {
              (**(code **)(*piVar4 + 0x44))(piVar4);
            }
            iVar7 = iVar7 + 1;
          } while (iVar2 != iVar7);
        }
        if (piVar6 == (int *)0x0) break;
        (**(code **)(*piVar6 + 0x44))(piVar6);
        iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0xc));
        if (iVar2 < *(int *)(param_1 + 0x10)) goto LAB_0001eacb;
      }
    }
LAB_0001eacb:
    uVar3 = func_0x000410a8();
    cVar1 = func_0x00040c6a(uVar3);
    if (cVar1 != '\0') {
      if (iRam003d4818 != 0) {
code_r0x0016fe28:
        iVar2 = FUN_00029ddc(iRam003d4818);
        if (iVar2 != 0) {
          while( true ) {
            uRam003d4814 = func_0x0002a47c(iRam003d4818);
            iVar2 = func_0x0002e110(uRam003d4814);
            if (iVar2 < 2) break;
            func_0x0002a73a(iRam003d4818);
            puVar5 = (undefined4 *)__Znwm(0x10);
            func_0x0002dc66(puVar5);
            *puVar5 = &UNK_0038e888;
            puVar5[3] = 0;
            piVar6 = (int *)FUN_0002dfa6(puVar5);
            cVar1 = func_0x0016fd50(piVar6,uRam003d4814);
            if (cVar1 != '\0') {
              func_0x0016f7b8(piVar6,uRam003d4814);
            }
            if (piVar6 == (int *)0x0) goto code_r0x0016fe28;
            (**(code **)(*piVar6 + 0x44))(piVar6);
            iVar2 = FUN_00029ddc(iRam003d4818);
            if (iVar2 == 0) {
              return;
            }
          }
          func_0x0002a73a(iRam003d4818);
          goto code_r0x0016fe28;
        }
      }
      return;
    }
  }
  return;
}


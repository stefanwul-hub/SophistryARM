
int FUN_00021922(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  do {
    uVar1 = FUN_00034962(param_2);
    iVar2 = *(int *)(param_1 + 0x2c);
    if (iVar2 != 0) {
      iVar4 = 0;
      do {
        iVar2 = func_0x00041be2(iVar2);
        if (iVar2 <= iVar4) break;
        iVar2 = func_0x00041c54(*(undefined4 *)(param_1 + 0x2c),iVar4);
        iVar3 = FUN_00034962(*(undefined4 *)(iVar2 + 8));
        iVar3 = _strcmp(iVar3 + 1,uVar1);
        if (iVar3 == 0) {
          return iVar2;
        }
        iVar4 = iVar4 + 1;
        iVar2 = *(int *)(param_1 + 0x2c);
      } while (iVar2 != 0);
    }
    iVar2 = FUN_00021738(param_1);
    if (iVar2 == 0) {
      return 0;
    }
    param_1 = FUN_00021738(param_1);
  } while( true );
}


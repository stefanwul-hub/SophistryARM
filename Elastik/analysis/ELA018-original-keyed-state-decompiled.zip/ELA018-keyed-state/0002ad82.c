
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002ad82(int param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x2d2,uVar3,"this != 0");
  }
  iVar2 = *(int *)(param_1 + 0x10);
  iVar6 = iVar2 + -1;
  if (iVar6 < 0) {
    *(undefined4 *)(param_1 + 0x10) = 0;
    return;
  }
  iVar5 = iVar6 * 4;
  do {
    *(int *)(param_1 + 0x10) = iVar2 + -1;
    if (*(char *)(param_1 + 0x18) == '\0') {
      iVar2 = *(int *)(param_1 + 0xc);
      piVar1 = *(int **)(iVar2 + iVar5);
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x44))(piVar1);
        goto LAB_0002add5;
      }
    }
    else {
LAB_0002add5:
      iVar2 = *(int *)(param_1 + 0xc);
    }
    *(undefined4 *)(iVar2 + iVar5) = 0;
    iVar6 = iVar6 + -1;
    iVar5 = iVar5 + -4;
    if (iVar6 == -1) {
      *(undefined4 *)(param_1 + 0x10) = 0;
      return;
    }
    iVar2 = *(int *)(param_1 + 0x10);
  } while( true );
}


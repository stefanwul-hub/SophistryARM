
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_0003a042(int param_1,int param_2,int param_3)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  undefined4 *puVar5;
  char *pcVar6;
  undefined4 uVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar7 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar7,"Assertion failed in line %d of %s: %s.",0x935,uVar2,"this != 0");
  }
  if (param_2 < 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar7 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar7,"Assertion failed in line %d of %s: %s.",0x935,uVar2,"aRange.location >= 0");
  }
  iVar10 = param_3 + param_2;
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar7 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar7,"Assertion failed in line %d of %s: %s.",0x10f,uVar2,"this != 0");
  }
  iVar9 = *(int *)(param_1 + 0x14);
  if (iVar9 == -1) {
    if (*(char **)(param_1 + 0xc) == (char *)0x0) {
      iVar9 = 0;
    }
    else {
      uVar8 = 0xffffffff;
      pcVar6 = *(char **)(param_1 + 0xc);
      do {
        if (uVar8 == 0) break;
        uVar8 = uVar8 - 1;
        cVar1 = *pcVar6;
        pcVar6 = pcVar6 + 1;
      } while (cVar1 != '\0');
      iVar9 = ~uVar8 - 1;
    }
  }
  if (iVar9 < iVar10) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar7 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar7,"Assertion failed in line %d of %s: %s.",0x935,uVar2,
                 "aRange.location + aRange.length <= getLength()");
  }
  if (param_3 != 0) {
    puVar5 = (undefined4 *)__Znwm(0x20);
    func_0x0002dc66(puVar5);
    *puVar5 = &UNK_0036ec68;
    *(undefined1 *)(puVar5 + 6) = 1;
    puVar5[3] = 0;
    puVar5[4] = 0;
    puVar5[5] = 0xffffffff;
    puVar5[7] = 0xffffffff;
    piVar3 = (int *)FUN_0002dfa6(puVar5);
    if (*(int *)(param_1 + 0x14) == -1) {
      pcVar6 = *(char **)(param_1 + 0xc);
      if (pcVar6 == (char *)0x0) {
        pcVar6 = "";
      }
      FUN_0003948e(piVar3,pcVar6 + param_2,param_3);
    }
    else {
      iVar10 = FUN_00036896(param_1);
      FUN_00037fb4(piVar3,iVar10 + param_2 * 2,param_3);
    }
    if (piVar3 == (int *)0x0) {
      uVar2 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                             );
      uVar7 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar7,"Assertion failed in line %d of %s: %s.",0xd8,uVar2,"this != 0");
    }
    *(undefined1 *)(piVar3 + 6) = 0;
    (**(code **)(*piVar3 + 0x48))(piVar3);
    return piVar3;
  }
  if (piRam003d4050 == (int *)0x0) {
    uVar2 = __Znwm(0x38);
    func_0x0006f04a(uVar2);
    piRam003d4050 = (int *)FUN_0002dfa6(uVar2);
    (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
  }
  else {
    (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
  }
  if (iRam003d4054 == 0) {
    uVar2 = __Znwm(0x14);
    FUN_00084dba(uVar2);
    iRam003d4054 = FUN_0002dfa6(uVar2);
  }
  FUN_000854fe(iRam003d4054,"");
  if (iRam003d4058 == 0) {
    uVar2 = __Znwm(0x18);
    FUN_000630b6(uVar2);
    iRam003d4058 = FUN_0002dfa6(uVar2);
    func_0x00065c4a(iRam003d4058,1);
  }
  iVar10 = func_0x0006440e(iRam003d4058,iRam003d4054);
  if (iVar10 != -1) {
    uVar2 = FUN_00063ade(iRam003d4058);
    piVar3 = (int *)FUN_0002a364(uVar2,iVar10);
    (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
    return piVar3;
  }
  uVar2 = __Znwm(0x14);
  FUN_00084dba(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  FUN_000854fe(piVar3,"");
  piVar4 = (int *)func_0x00033aa6("");
  FUN_00066284(iRam003d4058,piVar4,piVar3);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x44))(piVar3);
  }
  (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
  return piVar4;
}


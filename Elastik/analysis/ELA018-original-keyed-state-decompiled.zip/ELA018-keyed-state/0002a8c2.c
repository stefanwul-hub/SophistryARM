
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0002a8c2(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int aiStack_24 [5];
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x26a,uVar3,"this != 0");
  }
  if (*(int *)(param_1 + 0x1c) == 0) {
    if (((param_2 != 0) || (*(char *)(param_1 + 0x19) != '\0')) && (0 < *(int *)(param_1 + 0x10))) {
      piVar1 = *(int **)(param_1 + 0xc);
      if (param_2 == *piVar1) {
        iVar2 = 0;
        piVar5 = piVar1;
      }
      else {
        iVar2 = 0;
        iVar6 = 4;
        do {
          iVar2 = iVar2 + 1;
          if (iVar2 == *(int *)(param_1 + 0x10)) {
            return -1;
          }
          piVar5 = (int *)((int)piVar1 + iVar6);
          iVar6 = iVar6 + 4;
        } while (param_2 != piVar1[iVar2]);
      }
      if (*piVar5 != 0) {
        return iVar2;
      }
    }
  }
  else {
    aiStack_24[0] = param_2;
    iVar2 = func_0x0018175c(*(undefined4 *)(param_1 + 0x1c),aiStack_24);
    if (iVar2 != 0) {
      return *(int *)(iVar2 + 4);
    }
  }
  return -1;
}



undefined4 FUN_00021c02(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  
  iVar2 = *(int *)(param_1 + 0x20);
  if (iVar2 == 0) goto LAB_00021c86;
  do {
    iVar5 = 0;
    do {
      iVar2 = FUN_00029ddc(iVar2);
      if (iVar2 <= iVar5) break;
      uVar3 = FUN_0002a364(*(undefined4 *)(param_1 + 0x20),iVar5);
      piVar4 = (int *)FUN_000a0cc4(uVar3);
      cVar1 = (**(code **)(*piVar4 + 0x88))(piVar4,param_2);
      if (cVar1 != '\0') {
        return uVar3;
      }
      iVar5 = iVar5 + 1;
      iVar2 = *(int *)(param_1 + 0x20);
    } while (iVar2 != 0);
    iVar2 = FUN_00021738(param_1);
    while( true ) {
      if (iVar2 == 0) {
        return 0;
      }
      param_1 = FUN_00021738(param_1);
      iVar2 = *(int *)(param_1 + 0x20);
      if (iVar2 != 0) break;
LAB_00021c86:
      iVar2 = FUN_00021738(param_1);
    }
  } while( true );
}


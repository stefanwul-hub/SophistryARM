
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Possible PIC construction at 0x00038017: Changing call to branch */

void FUN_00037fb4(int param_1,int param_2,int param_3)

{
  undefined1 *puVar1;
  code *pcVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined2 *puVar5;
  int iVar6;
  undefined4 unaff_EBX;
  undefined1 *puVar7;
  undefined1 *unaff_EBP;
  undefined4 unaff_ESI;
  undefined4 uStack_50;
  char *pcStack_4c;
  char *pcStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  char *pcStack_3c;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  undefined2 *puStack_24;
  int iStack_20;
  
  puVar7 = &stack0xfffffffc;
  uStack_50 = 0x37fc2;
  uVar4 = uStack_50;
  iStack_20 = param_2;
  puStack_24 = (undefined2 *)param_3;
  uVar3 = unaff_ESI;
  if (param_1 == 0) {
    pcStack_4c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
    uStack_50 = 0x38138;
    uVar3 = func_0x0000a930();
    pcStack_4c = "GNAssertionException";
    uStack_50 = 0x38148;
    pcStack_4c = (char *)FUN_00033b90();
    pcStack_3c = "this != 0";
    uStack_44 = 0x2d9;
    pcStack_48 = "Assertion failed in line %d of %s: %s.";
    uStack_50 = 0x38170;
    uStack_40 = uVar3;
    FUN_0000bfd6();
  }
  if (*(char *)(param_1 + 0x18) == '\0') {
    pcStack_4c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
    uStack_50 = 0x3807a;
    uVar3 = func_0x0000a930();
    pcStack_4c = "GNAssertionException";
    uStack_50 = 0x3808a;
    pcStack_4c = (char *)FUN_00033b90();
    pcStack_3c = "_isMutable";
    uStack_44 = 0x2d9;
    pcStack_48 = "Assertion failed in line %d of %s: %s.";
    uStack_50 = 0x380b2;
    uStack_40 = uVar3;
    FUN_0000bfd6();
  }
  if ((int)puStack_24 < 0) {
    pcStack_4c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
    uStack_50 = 0x380cb;
    uVar3 = func_0x0000a930();
    pcStack_4c = "GNAssertionException";
    uStack_50 = 0x380db;
    pcStack_4c = (char *)FUN_00033b90();
    pcStack_3c = "numChars >= 0";
    uStack_44 = 0x2d9;
    pcStack_48 = "Assertion failed in line %d of %s: %s.";
    uStack_50 = 0x38103;
    uStack_40 = uVar3;
    FUN_0000bfd6();
  }
  if (*(char *)(param_1 + 0x18) == '\0') {
    if ((*(int *)(param_1 + 0xc) == 0) && (*(int *)(param_1 + 0x14) != -1)) {
      pcStack_4c = (char *)param_1;
      uStack_50 = 0x38125;
      FUN_000340ba();
    }
    pcStack_48 = *(char **)(param_1 + 0xc);
    if (pcStack_48 == (char *)0x0) {
      pcStack_48 = "";
    }
    pcStack_4c = "Cannot modify an immutable string %s";
    register0x00000010 = (BADSPACEBASE *)&uStack_50;
    uStack_50 = 0x3801c;
    unaff_EBX = uVar4;
    unaff_EBP = puVar7;
    unaff_ESI = uVar3;
  }
  else {
    if (*(char **)(param_1 + 0xc) != (char *)0x0) {
      uStack_50 = 0x3802b;
      pcStack_4c = *(char **)(param_1 + 0xc);
      FUN_0000b122();
      *(undefined4 *)(param_1 + 0xc) = 0;
    }
    if (*(int *)(param_1 + 0x14) != -1) {
      pcStack_4c = *(char **)(param_1 + 0x10);
      uStack_50 = 0x38043;
      FUN_0000b122();
      *(undefined4 *)(param_1 + 0x10) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0xffffffff;
    }
    iStack_2c = iStack_20;
    iStack_30 = (int)puStack_24;
    if (param_1 == 0) {
      uVar3 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                             );
      uVar4 = FUN_00033b90("GNAssertionException");
      pcStack_4c = "this != 0";
      uStack_50 = uVar3;
      FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x95a);
    }
    if (*(char *)(param_1 + 0x18) != '\0') {
      if (iStack_30 != 0) {
        if (iStack_2c == 0) {
          uVar3 = func_0x0000a930(
                                 "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                                 );
          uVar4 = FUN_00033b90("GNAssertionException");
          pcStack_4c = "chars";
          uStack_50 = uVar3;
          FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x965);
        }
        if (*(int *)(param_1 + 0x14) == -1) {
          func_0x000358be(param_1);
        }
        if (*(int *)(param_1 + 0x10) == 0) {
          uVar3 = func_0x0000a930(
                                 "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                                 );
          uVar4 = FUN_00033b90("GNAssertionException");
          pcStack_4c = "_uniChars";
          uStack_50 = uVar3;
          FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x967);
        }
        iStack_20 = *(int *)(param_1 + 0x14);
        iStack_28 = iStack_30 + iStack_20;
        puStack_24 = (undefined2 *)FUN_0000aecc(iStack_28 * 2 + 2);
        if (puStack_24 == (undefined2 *)0x0) {
          uVar3 = func_0x0000a930(
                                 "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                                 );
          uVar4 = FUN_00033b90("GNAssertionException");
          pcStack_4c = "c";
          uStack_50 = uVar3;
          FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x96c);
        }
        iVar6 = iStack_20;
        puVar5 = puStack_24;
        if (iStack_20 != 0) {
          _memcpy(puStack_24,*(undefined4 *)(param_1 + 0x10),iStack_20 * 2);
          puStack_24[iVar6] = 0;
          puVar5 = puStack_24 + iVar6;
        }
        _memcpy(puVar5,iStack_2c,iStack_30 * 2);
        puStack_24[iStack_28] = 0;
        *(int *)(param_1 + 0x14) = iStack_28;
        FUN_0000b122(*(undefined4 *)(param_1 + 0x10));
        *(undefined2 **)(param_1 + 0x10) = puStack_24;
        if (*(int *)(param_1 + 0xc) != 0) {
          FUN_0000b122(*(int *)(param_1 + 0xc));
        }
        *(undefined4 *)(param_1 + 0xc) = 0;
      }
      return;
    }
    if ((*(int *)(param_1 + 0xc) == 0) && (*(int *)(param_1 + 0x14) != -1)) {
      FUN_000340ba(param_1);
    }
  }
  *(undefined1 **)((int)register0x00000010 + -4) = unaff_EBP;
  *(undefined4 *)((int)register0x00000010 + -8) = unaff_ESI;
  *(undefined4 *)((int)register0x00000010 + -0xc) = unaff_EBX;
  *(undefined **)((int)register0x00000010 + -0x430) = &UNK_0000acbe;
  iVar6 = *(int *)((int)register0x00000010 + -0x430);
  if (*(char *)(iVar6 + 0x3c9252) == '\0') {
    *(undefined1 *)(iVar6 + 0x3c9252) = 1;
    *(undefined1 **)((int)register0x00000010 + -0x10) = (undefined1 *)((int)register0x00000010 + 8);
    *(undefined1 **)((int)register0x00000010 + -0x424) = (undefined1 *)((int)register0x00000010 + 8)
    ;
    *(undefined4 *)((int)register0x00000010 + -0x428) = *(undefined4 *)((int)register0x00000010 + 4)
    ;
    puVar1 = (undefined1 *)((int)register0x00000010 + -0x410);
    *(undefined1 **)((int)register0x00000010 + -0x42c) = puVar1;
    *(undefined **)((int)register0x00000010 + -0x430) = &UNK_0000acf7;
    _vsprintf();
    *(undefined1 **)((int)register0x00000010 + -0x42c) = puVar1;
    *(undefined **)((int)register0x00000010 + -0x430) = &UNK_0000acff;
    FUN_0000ab14();
    pcVar2 = *(code **)(iVar6 + 0x3c9246);
    if (pcVar2 != (code *)0x0) {
      *(undefined1 **)((int)register0x00000010 + -0x42c) = puVar1;
      *(undefined **)((int)register0x00000010 + -0x430) = &UNK_0000ad0e;
      (*pcVar2)();
    }
    pcVar2 = *(code **)(iVar6 + 0x3c9242);
    if (pcVar2 != (code *)0x0) {
      *(undefined **)((int)register0x00000010 + -0x430) = &UNK_0000ad1a;
      (*pcVar2)();
    }
    if (*(char *)(iVar6 + 0x3c924a) == '\0') {
      *(undefined **)((int)register0x00000010 + -0x430) = &UNK_0000ad28;
      uVar3 = func_0x00084aa2();
      *(undefined4 *)((int)register0x00000010 + -0x42c) = uVar3;
      *(undefined **)((int)register0x00000010 + -0x430) = &UNK_0000ad30;
      func_0x00084bb6();
      return;
    }
  }
  return;
}


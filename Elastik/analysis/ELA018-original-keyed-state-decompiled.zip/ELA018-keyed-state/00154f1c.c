
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00154f1c(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_00033b90("GNString");
  cVar1 = FUN_0002e288(param_2,uVar2);
  if (cVar1 == '\0') {
    uVar2 = FUN_00033b90("GNNumber");
    cVar1 = FUN_0002e288(param_2,uVar2);
    if (cVar1 == '\0') {
      uVar2 = FUN_00033b90("GNData");
      cVar1 = FUN_0002e288(param_2,uVar2);
      if (cVar1 == '\0') {
        return 0;
      }
    }
  }
  return 1;
}


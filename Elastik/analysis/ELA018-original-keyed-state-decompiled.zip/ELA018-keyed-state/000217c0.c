
undefined4 FUN_000217c0(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  
  uVar1 = __Znwm(0x20);
  FUN_00029d44(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  uVar1 = (**(code **)(*piVar2 + 0x48))(piVar2);
  iVar3 = FUN_00021738(param_1);
  if (iVar3 != 0) {
    uVar4 = FUN_00021738(param_1);
    uVar4 = FUN_000217c0(uVar4);
    FUN_0002d13c(uVar1,uVar4);
  }
  if (*(int *)(param_1 + 0x20) != 0) {
    FUN_0002d13c(uVar1,*(int *)(param_1 + 0x20));
  }
  if (*(int *)(param_1 + 0x24) != 0) {
    FUN_0002d13c(uVar1,*(int *)(param_1 + 0x24));
  }
  return uVar1;
}


ELA011: 70 selected C/ASM exports across two root sets; 58 distinct functions, 38 new, 322 total.
Pinned i386 SHA: 5b313e738d92c438253927e8d57969ddfd99302b1d978372ac9e045490698920.
Ghidra 11.3.2 read-only, direct-call depth 1. Raw C/ASM unchanged; checkpoint/scope audit labels normalized.
Only eight named routines are translated into OriginalFileArchive.cpp; object/runtime/delegate dependencies remain explicit.
No installer, binary, original bank/audio, serial or private project is included.

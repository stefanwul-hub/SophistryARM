
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000e3ac8(int param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int *piStack_34;
  undefined4 uStack_30;
  undefined1 auStack_25 [21];
  
  if (*(char *)(*(int *)(param_1 + 0x10) + 0x2c) != '\0') {
    FUN_0000ab14("Archive is readonly");
    return 0;
  }
  piVar3 = *(int **)(*(int *)(param_1 + 0x10) + 0x20);
  (**(code **)(*piVar3 + 0x1a4))(piVar3);
  iVar7 = *(int *)(param_1 + 0x10);
  if (*(int *)(iVar7 + 0x24) != 0) {
    FUN_000df8d2(param_1);
    if (*(int *)(param_1 + 0x18) != 0) {
      iVar6 = 1;
      iVar7 = *(int *)(param_1 + 0x10);
      goto LAB_000e3b31;
    }
    iVar6 = *(int *)(param_1 + 0x14);
    iVar7 = *(int *)(param_1 + 0x10);
    if (iVar6 != 0) {
      iVar2 = iVar6 * 0x240 + *(int *)(iVar7 + 0x14);
      iVar4 = *(int *)(iVar2 + -0x234);
      if (-1 < iVar4) {
        if ((iVar4 < 1) && (*(int *)(iVar2 + -0x238) == 0)) {
          iVar6 = 0;
          goto LAB_000e3b31;
        }
        if (iVar6 == 0) {
          piStack_34 = (int *)FUN_00033b90("/");
        }
        else {
          iVar4 = *(int *)(iVar7 + 0x14);
          iVar6 = iVar6 * 0x240 + -0x240 + iVar4;
          uStack_30 = *(undefined4 *)(iVar6 + 0x23c);
          iVar6 = *(int *)(iVar6 + 0x20);
          if (iVar6 != 0) {
            while( true ) {
              iVar4 = iVar6 * 0x240 + -0x240 + iVar4;
              piVar3 = *(int **)(iVar4 + 0x23c);
              uStack_30 = (**(code **)(*piVar3 + 0x1a4))(piVar3,uStack_30);
              iVar6 = *(int *)(iVar4 + 0x20);
              if (iVar6 == 0) break;
              iVar4 = *(int *)(iVar7 + 0x14);
            }
          }
          piVar3 = (int *)FUN_00033b90("/");
          piStack_34 = (int *)(**(code **)(*piVar3 + 0x1a4))(piVar3,uStack_30);
        }
        iVar7 = *(int *)(param_1 + 0x10);
        if ((*(int *)(param_1 + 0x14) != 0) &&
           (iVar6 = *(int *)(param_1 + 0x14) * 0x240 + *(int *)(iVar7 + 0x14),
           *(int *)(iVar6 + -0x234) != 0 || *(int *)(iVar6 + -0x238) != 0)) {
          iVar4 = 8;
          do {
            (auStack_25 + 1)[iVar4 + -1] = 0;
            iVar4 = iVar4 + -1;
          } while (iVar4 != 0);
          (**(code **)(**(int **)(iVar7 + 0x24) + 0x1c0))
                    (*(int **)(iVar7 + 0x24),*(int *)(iVar6 + -0x14) + 8);
          cVar1 = (**(code **)(**(int **)(iVar7 + 0x24) + 0x1b0))
                            (*(int **)(iVar7 + 0x24),auStack_25 + 1,8);
          if (cVar1 != '\0') {
            *(undefined4 *)(iVar6 + -0x238) = 0;
            *(undefined4 *)(iVar6 + -0x234) = 0;
            *(undefined4 *)(param_1 + 0x14) = 0;
            uVar5 = (**(code **)(*piStack_34 + 0x40))(piStack_34);
            *(undefined4 *)(param_1 + 0x18) = uVar5;
            iVar6 = (int)cVar1;
            iVar7 = *(int *)(param_1 + 0x10);
            goto LAB_000e3b31;
          }
          iVar7 = *(int *)(param_1 + 0x10);
        }
      }
    }
  }
  iVar6 = 0;
LAB_000e3b31:
  (**(code **)(**(int **)(iVar7 + 0x20) + 0x1ac))(*(int **)(iVar7 + 0x20));
  return iVar6;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000715c6(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  
  if ((iRam003d4338 != 0) && (iVar3 = func_0x000714bc(iRam003d4338,param_1,param_2), iVar3 != 0)) {
    return iVar3;
  }
  if (piRam003d4050 == (int *)0x0) {
    uVar1 = __Znwm(0x38);
    FUN_0006f04a(uVar1);
    piRam003d4050 = (int *)FUN_0002dfa6(uVar1);
    (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
  }
  else {
    (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
  }
  if (iRam003d4054 == 0) {
    uVar1 = __Znwm(0x14);
    func_0x00084dba(uVar1);
    iRam003d4054 = FUN_0002dfa6(uVar1);
  }
  func_0x000854fe(iRam003d4054,param_1);
  if (iRam003d4058 == 0) {
    uVar1 = __Znwm(0x18);
    FUN_000630b6(uVar1);
    iRam003d4058 = FUN_0002dfa6(uVar1);
    func_0x00065c4a(iRam003d4058,1);
  }
  iVar3 = func_0x0006440e(iRam003d4058,iRam003d4054);
  if (iVar3 != -1) {
    uVar1 = FUN_00063ade(iRam003d4058);
    iVar3 = FUN_0002a364(uVar1,iVar3);
    (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
    return iVar3;
  }
  uVar1 = __Znwm(0x14);
  func_0x00084dba(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  func_0x000854fe(piVar2,param_1);
  iVar3 = func_0x00033aa6(param_1);
  FUN_00066284(iRam003d4058,iVar3,piVar2);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x44))(piVar2);
  }
  (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
  return iVar3;
}



undefined4 FUN_000e09c0(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  
  piVar1 = *(int **)(*(int *)(param_1 + 0x10) + 0x20);
  (**(code **)(*piVar1 + 0x1a4))(piVar1);
  iVar4 = *(int *)(param_1 + 0x10);
  if (*(int *)(iVar4 + 0x24) != 0) {
    FUN_000df8d2(param_1);
    if (*(int *)(param_1 + 0x18) == 0) {
      iVar4 = *(int *)(param_1 + 0x10);
      if ((*(int *)(param_1 + 0x14) != 0) &&
         (iVar3 = *(int *)(param_1 + 0x14) * 0x240 + *(int *)(iVar4 + 0x14),
         uVar2 = *(undefined4 *)(iVar3 + -0x238), -1 < *(int *)(iVar3 + -0x234))) {
        (**(code **)(**(int **)(iVar4 + 0x20) + 0x1ac))(*(int **)(iVar4 + 0x20));
        return uVar2;
      }
    }
    else {
      iVar4 = *(int *)(param_1 + 0x10);
    }
  }
  (**(code **)(**(int **)(iVar4 + 0x20) + 0x1ac))(*(int **)(iVar4 + 0x20));
  return 0;
}


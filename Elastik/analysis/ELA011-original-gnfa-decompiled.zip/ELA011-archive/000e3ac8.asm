000e3ac8  55  PUSH EBP
000e3ac9  89e5  MOV EBP,ESP
000e3acb  57  PUSH EDI
000e3acc  56  PUSH ESI
000e3acd  53  PUSH EBX
000e3ace  83ec3c  SUB ESP,0x3c
000e3ad1  e846152000  CALL 0x002e501c
000e3ad6  8b5508  MOV EDX,dword ptr [EBP + 0x8]
000e3ad9  8b4210  MOV EAX,dword ptr [EDX + 0x10]
000e3adc  80782c00  CMP byte ptr [EAX + 0x2c],0x0
000e3ae0  741a  JZ 0x000e3afc
000e3ae2  8d8312b31e00  LEA EAX,[EBX + 0x1eb312]
000e3ae8  890424  MOV dword ptr [ESP],EAX
000e3aeb  e82470f2ff  CALL 0x0000ab14
000e3af0  31f6  XOR ESI,ESI
000e3af2  89f0  MOV EAX,ESI
000e3af4  83c43c  ADD ESP,0x3c
000e3af7  5b  POP EBX
000e3af8  5e  POP ESI
000e3af9  5f  POP EDI
000e3afa  5d  POP EBP
000e3afb  c3  RET
000e3afc  8b4020  MOV EAX,dword ptr [EAX + 0x20]
000e3aff  8b10  MOV EDX,dword ptr [EAX]
000e3b01  890424  MOV dword ptr [ESP],EAX
000e3b04  ff92a4010000  CALL dword ptr [EDX + 0x1a4]
000e3b0a  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
000e3b0d  8b7910  MOV EDI,dword ptr [ECX + 0x10]
000e3b10  8b4724  MOV EAX,dword ptr [EDI + 0x24]
000e3b13  85c0  TEST EAX,EAX
000e3b15  7438  JZ 0x000e3b4f
000e3b17  890c24  MOV dword ptr [ESP],ECX
000e3b1a  e8b3bdffff  CALL 0x000df8d2
000e3b1f  8b4508  MOV EAX,dword ptr [EBP + 0x8]
000e3b22  8b7818  MOV EDI,dword ptr [EAX + 0x18]
000e3b25  85ff  TEST EDI,EDI
000e3b27  742a  JZ 0x000e3b53
000e3b29  be01000000  MOV ESI,0x1
000e3b2e  8b7810  MOV EDI,dword ptr [EAX + 0x10]
000e3b31  8b4720  MOV EAX,dword ptr [EDI + 0x20]
000e3b34  8b10  MOV EDX,dword ptr [EAX]
000e3b36  890424  MOV dword ptr [ESP],EAX
000e3b39  ff92ac010000  CALL dword ptr [EDX + 0x1ac]
000e3b3f  89f0  MOV EAX,ESI
000e3b41  83c43c  ADD ESP,0x3c
000e3b44  5b  POP EBX
000e3b45  5e  POP ESI
000e3b46  5f  POP EDI
000e3b47  5d  POP EBP
000e3b48  c3  RET
000e3b49  8b5508  MOV EDX,dword ptr [EBP + 0x8]
000e3b4c  8b7a10  MOV EDI,dword ptr [EDX + 0x10]
000e3b4f  31f6  XOR ESI,ESI
000e3b51  ebde  JMP 0x000e3b31
000e3b53  8b5014  MOV EDX,dword ptr [EAX + 0x14]
000e3b56  8b7810  MOV EDI,dword ptr [EAX + 0x10]
000e3b59  85d2  TEST EDX,EDX
000e3b5b  74f2  JZ 0x000e3b4f
000e3b5d  8d04d2  LEA EAX,[EDX + EDX*0x8]
000e3b60  c1e006  SHL EAX,0x6
000e3b63  034714  ADD EAX,dword ptr [EDI + 0x14]
000e3b66  2d40020000  SUB EAX,0x240
000e3b6b  83780c00  CMP dword ptr [EAX + 0xc],0x0
000e3b6f  7cde  JL 0x000e3b4f
000e3b71  0f8e5c010000  JLE 0x000e3cd3
000e3b77  85d2  TEST EDX,EDX
000e3b79  0f843e010000  JZ 0x000e3cbd
000e3b7f  8d04d2  LEA EAX,[EDX + EDX*0x8]
000e3b82  c1e006  SHL EAX,0x6
000e3b85  8b5714  MOV EDX,dword ptr [EDI + 0x14]
000e3b88  8d8410c0fdffff  LEA EAX,[EAX + EDX*0x1 + 0xfffffdc0]
000e3b8f  8b883c020000  MOV ECX,dword ptr [EAX + 0x23c]
000e3b95  894dd4  MOV dword ptr [EBP + -0x2c],ECX
000e3b98  8b4020  MOV EAX,dword ptr [EAX + 0x20]
000e3b9b  85c0  TEST EAX,EAX
000e3b9d  0f85e6000000  JNZ 0x000e3c89
000e3ba3  8d831e161e00  LEA EAX,[EBX + 0x1e161e]
000e3ba9  890424  MOV dword ptr [ESP],EAX
000e3bac  e8dffff4ff  CALL 0x00033b90
000e3bb1  8b10  MOV EDX,dword ptr [EAX]
000e3bb3  8b4dd4  MOV ECX,dword ptr [EBP + -0x2c]
000e3bb6  894c2404  MOV dword ptr [ESP + 0x4],ECX
000e3bba  890424  MOV dword ptr [ESP],EAX
000e3bbd  ff92a4010000  CALL dword ptr [EDX + 0x1a4]
000e3bc3  8945d0  MOV dword ptr [EBP + -0x30],EAX
000e3bc6  8b5508  MOV EDX,dword ptr [EBP + 0x8]
000e3bc9  8b4214  MOV EAX,dword ptr [EDX + 0x14]
000e3bcc  8b7a10  MOV EDI,dword ptr [EDX + 0x10]
000e3bcf  85c0  TEST EAX,EAX
000e3bd1  0f8478ffffff  JZ 0x000e3b4f
000e3bd7  8d04c0  LEA EAX,[EAX + EAX*0x8]
000e3bda  c1e006  SHL EAX,0x6
000e3bdd  034714  ADD EAX,dword ptr [EDI + 0x14]
000e3be0  8db0c0fdffff  LEA ESI,[EAX + 0xfffffdc0]
000e3be6  8b460c  MOV EAX,dword ptr [ESI + 0xc]
000e3be9  0b4608  OR EAX,dword ptr [ESI + 0x8]
000e3bec  0f845dffffff  JZ 0x000e3b4f
000e3bf2  b808000000  MOV EAX,0x8
000e3bf7  8d4de0  LEA ECX,[EBP + -0x20]
000e3bfa  894dcc  MOV dword ptr [EBP + -0x34],ECX
000e3bfd  89ca  MOV EDX,ECX
000e3bff  eb03  JMP 0x000e3c04
000e3c01  8b55cc  MOV EDX,dword ptr [EBP + -0x34]
000e3c04  c64410ff00  MOV byte ptr [EAX + EDX*0x1 + -0x1],0x0
000e3c09  83e801  SUB EAX,0x1
000e3c0c  75f3  JNZ 0x000e3c01
000e3c0e  8b5724  MOV EDX,dword ptr [EDI + 0x24]
000e3c11  8b0a  MOV ECX,dword ptr [EDX]
000e3c13  8b862c020000  MOV EAX,dword ptr [ESI + 0x22c]
000e3c19  83c008  ADD EAX,0x8
000e3c1c  89442404  MOV dword ptr [ESP + 0x4],EAX
000e3c20  891424  MOV dword ptr [ESP],EDX
000e3c23  ff91c0010000  CALL dword ptr [ECX + 0x1c0]
000e3c29  8b4724  MOV EAX,dword ptr [EDI + 0x24]
000e3c2c  8b10  MOV EDX,dword ptr [EAX]
000e3c2e  c744240808000000  MOV dword ptr [ESP + 0x8],0x8
000e3c36  8b4dcc  MOV ECX,dword ptr [EBP + -0x34]
000e3c39  894c2404  MOV dword ptr [ESP + 0x4],ECX
000e3c3d  890424  MOV dword ptr [ESP],EAX
000e3c40  ff92b0010000  CALL dword ptr [EDX + 0x1b0]
000e3c46  89c7  MOV EDI,EAX
000e3c48  84c0  TEST AL,AL
000e3c4a  0f84f9feffff  JZ 0x000e3b49
000e3c50  c7460800000000  MOV dword ptr [ESI + 0x8],0x0
000e3c57  c7460c00000000  MOV dword ptr [ESI + 0xc],0x0
000e3c5e  8b4508  MOV EAX,dword ptr [EBP + 0x8]
000e3c61  c7401400000000  MOV dword ptr [EAX + 0x14],0x0
000e3c68  8b55d0  MOV EDX,dword ptr [EBP + -0x30]
000e3c6b  8b02  MOV EAX,dword ptr [EDX]
000e3c6d  891424  MOV dword ptr [ESP],EDX
000e3c70  ff5040  CALL dword ptr [EAX + 0x40]
000e3c73  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
000e3c76  894118  MOV dword ptr [ECX + 0x18],EAX
000e3c79  89f8  MOV EAX,EDI
000e3c7b  0fbef0  MOVSX ESI,AL
000e3c7e  8b7910  MOV EDI,dword ptr [ECX + 0x10]
000e3c81  e9abfeffff  JMP 0x000e3b31
000e3c86  8b5714  MOV EDX,dword ptr [EDI + 0x14]
000e3c89  8d34c0  LEA ESI,[EAX + EAX*0x8]
000e3c8c  c1e606  SHL ESI,0x6
000e3c8f  8db416c0fdffff  LEA ESI,[ESI + EDX*0x1 + 0xfffffdc0]
000e3c96  8b863c020000  MOV EAX,dword ptr [ESI + 0x23c]
000e3c9c  8b10  MOV EDX,dword ptr [EAX]
000e3c9e  8b4dd4  MOV ECX,dword ptr [EBP + -0x2c]
000e3ca1  894c2404  MOV dword ptr [ESP + 0x4],ECX
000e3ca5  890424  MOV dword ptr [ESP],EAX
000e3ca8  ff92a4010000  CALL dword ptr [EDX + 0x1a4]
000e3cae  8945d4  MOV dword ptr [EBP + -0x2c],EAX
000e3cb1  8b4620  MOV EAX,dword ptr [ESI + 0x20]
000e3cb4  85c0  TEST EAX,EAX
000e3cb6  75ce  JNZ 0x000e3c86
000e3cb8  e9e6feffff  JMP 0x000e3ba3
000e3cbd  8d831e161e00  LEA EAX,[EBX + 0x1e161e]
000e3cc3  890424  MOV dword ptr [ESP],EAX
000e3cc6  e8c5fef4ff  CALL 0x00033b90
000e3ccb  8945d0  MOV dword ptr [EBP + -0x30],EAX
000e3cce  e9f3feffff  JMP 0x000e3bc6
000e3cd3  83780800  CMP dword ptr [EAX + 0x8],0x0
000e3cd7  0f879afeffff  JA 0x000e3b77
000e3cdd  31f6  XOR ESI,ESI
000e3cdf  e94dfeffff  JMP 0x000e3b31

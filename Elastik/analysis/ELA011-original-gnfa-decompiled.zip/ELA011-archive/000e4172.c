
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000e4172(int param_1,undefined4 param_2,uint *param_3)

{
  uint *puVar1;
  uint uVar2;
  uint uVar3;
  int *piVar4;
  char cVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  int iStack_24;
  
  if (*(int *)(param_1 + 0x2c) == 0) {
    cVar5 = FUN_0017f918(param_1,param_2,param_3);
    return (int)cVar5;
  }
  if (*(int *)(*(int *)(*(int *)(param_1 + 0x28) + 0x10) + 0x24) == 0) {
    iStack_24 = 0;
  }
  else {
    FUN_000df8d2(*(int *)(param_1 + 0x28));
    iVar8 = *(int *)(param_1 + 0x28);
    if (*(int *)(iVar8 + 0x18) != 0) {
      uVar6 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                             );
      uVar7 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar7,"Assertion failed in line %d of %s: %s.",0x630,uVar6,
                   "_fileArchiveFilePath->_posixPath == 0");
      iVar8 = *(int *)(param_1 + 0x28);
    }
    iStack_24 = *(int *)(iVar8 + 0x14) * 0x240 + *(int *)(*(int *)(iVar8 + 0x10) + 0x14) + -0x240;
  }
  uVar2 = *param_3;
  uVar9 = uVar2;
  if (iStack_24 == 0) {
    uVar6 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                           );
    uVar7 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar7,"Assertion failed in line %d of %s: %s.",0x581,uVar6,"desc != 0");
    uVar9 = *param_3;
  }
  uVar3 = *(uint *)(param_1 + 0x30);
  uVar10 = ((int)uVar9 >> 0x1f) + *(int *)(param_1 + 0x34) + (uint)CARRY4(uVar9,uVar3);
  if ((uVar10 < *(uint *)(iStack_24 + 0xc)) ||
     ((uVar10 <= *(uint *)(iStack_24 + 0xc) && (uVar9 + uVar3 <= *(uint *)(iStack_24 + 8))))) {
    cVar5 = *(char *)(param_1 + 0x38);
  }
  else {
    *param_3 = *(uint *)(iStack_24 + 8) - uVar3;
    cVar5 = *(char *)(param_1 + 0x38);
  }
  if (cVar5 == '\0') {
    cVar5 = (**(code **)(**(int **)(param_1 + 0x2c) + 0x1ac))
                      (*(int **)(param_1 + 0x2c),param_2,param_3);
    uVar3 = *param_3;
    puVar1 = (uint *)(param_1 + 0x30);
    uVar9 = *puVar1;
    *puVar1 = *puVar1 + uVar3;
    *(int *)(param_1 + 0x34) =
         *(int *)(param_1 + 0x34) + ((int)uVar3 >> 0x1f) + (uint)CARRY4(uVar9,uVar3);
    uVar9 = *param_3;
  }
  else {
    piVar4 = *(int **)(*(int *)(*(int *)(param_1 + 0x28) + 0x10) + 0x20);
    (**(code **)(*piVar4 + 0x1a4))(piVar4);
    uVar6 = (**(code **)(**(int **)(param_1 + 0x2c) + 0x1b8))(*(int **)(param_1 + 0x2c));
    (**(code **)(**(int **)(param_1 + 0x2c) + 0x1c0))
              (*(int **)(param_1 + 0x2c),*(int *)(iStack_24 + 0x234) + *(int *)(param_1 + 0x30));
    cVar5 = (**(code **)(**(int **)(param_1 + 0x2c) + 0x1ac))
                      (*(int **)(param_1 + 0x2c),param_2,param_3);
    (**(code **)(**(int **)(param_1 + 0x2c) + 0x1c0))(*(int **)(param_1 + 0x2c),uVar6);
    piVar4 = *(int **)(*(int *)(*(int *)(param_1 + 0x28) + 0x10) + 0x20);
    (**(code **)(*piVar4 + 0x1ac))(piVar4);
    uVar3 = *param_3;
    puVar1 = (uint *)(param_1 + 0x30);
    uVar9 = *puVar1;
    *puVar1 = *puVar1 + uVar3;
    *(int *)(param_1 + 0x34) =
         *(int *)(param_1 + 0x34) + ((int)uVar3 >> 0x1f) + (uint)CARRY4(uVar9,uVar3);
    uVar9 = *param_3;
  }
  if ((int)uVar9 < 1) {
    if ((int)uVar9 < 0) {
      *param_3 = 0;
      return 0;
    }
  }
  else if (uVar2 == uVar9) {
    return (int)cVar5;
  }
  return 0;
}


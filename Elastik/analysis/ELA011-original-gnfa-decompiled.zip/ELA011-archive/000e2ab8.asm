000e2ab8  55  PUSH EBP
000e2ab9  89e5  MOV EBP,ESP
000e2abb  57  PUSH EDI
000e2abc  56  PUSH ESI
000e2abd  53  PUSH EBX
000e2abe  83ec2c  SUB ESP,0x2c
000e2ac1  e856252000  CALL 0x002e501c
000e2ac6  8b7d08  MOV EDI,dword ptr [EBP + 0x8]
000e2ac9  8b4710  MOV EAX,dword ptr [EDI + 0x10]
000e2acc  8b4020  MOV EAX,dword ptr [EAX + 0x20]
000e2acf  8b10  MOV EDX,dword ptr [EAX]
000e2ad1  890424  MOV dword ptr [ESP],EAX
000e2ad4  ff92a4010000  CALL dword ptr [EDX + 0x1a4]
000e2ada  8b5710  MOV EDX,dword ptr [EDI + 0x10]
000e2add  8b4224  MOV EAX,dword ptr [EDX + 0x24]
000e2ae0  85c0  TEST EAX,EAX
000e2ae2  0f84ed000000  JZ 0x000e2bd5
000e2ae8  893c24  MOV dword ptr [ESP],EDI
000e2aeb  e8e2cdffff  CALL 0x000df8d2
000e2af0  8b4714  MOV EAX,dword ptr [EDI + 0x14]
000e2af3  85c0  TEST EAX,EAX
000e2af5  7428  JZ 0x000e2b1f
000e2af7  8b5710  MOV EDX,dword ptr [EDI + 0x10]
000e2afa  8d04c0  LEA EAX,[EAX + EAX*0x8]
000e2afd  c1e006  SHL EAX,0x6
000e2b00  034214  ADD EAX,dword ptr [EDX + 0x14]
000e2b03  2d40020000  SUB EAX,0x240
000e2b08  b901000000  MOV ECX,0x1
000e2b0d  83780c00  CMP dword ptr [EAX + 0xc],0x0
000e2b11  0f8ed8000000  JLE 0x000e2bef
000e2b17  85c9  TEST ECX,ECX
000e2b19  0f84b6000000  JZ 0x000e2bd5
000e2b1f  c7042420000000  MOV dword ptr [ESP],0x20
000e2b26  e87a752f00  CALL 0x003da0a5
000e2b2b  89c6  MOV ESI,EAX
000e2b2d  890424  MOV dword ptr [ESP],EAX
000e2b30  e8294bf4ff  CALL 0x0002765e
000e2b35  893424  MOV dword ptr [ESP],ESI
000e2b38  e869b4f4ff  CALL 0x0002dfa6
000e2b3d  8b10  MOV EDX,dword ptr [EAX]
000e2b3f  890424  MOV dword ptr [ESP],EAX
000e2b42  ff5248  CALL dword ptr [EDX + 0x48]
000e2b45  8945e4  MOV dword ptr [EBP + -0x1c],EAX
000e2b48  c704243c000000  MOV dword ptr [ESP],0x3c
000e2b4f  e851752f00  CALL 0x003da0a5
000e2b54  89c6  MOV ESI,EAX
000e2b56  890424  MOV dword ptr [ESP],EAX
000e2b59  e89cba0900  CALL 0x0017e5fa
000e2b5e  8d83c2892900  LEA EAX,[EBX + 0x2989c2]
000e2b64  8906  MOV dword ptr [ESI],EAX
000e2b66  c7463000000000  MOV dword ptr [ESI + 0x30],0x0
000e2b6d  c7463400000000  MOV dword ptr [ESI + 0x34],0x0
000e2b74  c7462c00000000  MOV dword ptr [ESI + 0x2c],0x0
000e2b7b  c7462800000000  MOV dword ptr [ESI + 0x28],0x0
000e2b82  c6462400  MOV byte ptr [ESI + 0x24],0x0
000e2b86  c6463800  MOV byte ptr [ESI + 0x38],0x0
000e2b8a  893424  MOV dword ptr [ESP],ESI
000e2b8d  e814b4f4ff  CALL 0x0002dfa6
000e2b92  8b10  MOV EDX,dword ptr [EAX]
000e2b94  890424  MOV dword ptr [ESP],EAX
000e2b97  ff5248  CALL dword ptr [EDX + 0x48]
000e2b9a  89c6  MOV ESI,EAX
000e2b9c  8b07  MOV EAX,dword ptr [EDI]
000e2b9e  893c24  MOV dword ptr [ESP],EDI
000e2ba1  ff5040  CALL dword ptr [EAX + 0x40]
000e2ba4  894628  MOV dword ptr [ESI + 0x28],EAX
000e2ba7  c6462401  MOV byte ptr [ESI + 0x24],0x1
000e2bab  8b45e4  MOV EAX,dword ptr [EBP + -0x1c]
000e2bae  89442404  MOV dword ptr [ESP + 0x4],EAX
000e2bb2  893424  MOV dword ptr [ESP],ESI
000e2bb5  e894cc0900  CALL 0x0017f84e
000e2bba  8b5710  MOV EDX,dword ptr [EDI + 0x10]
000e2bbd  8b4220  MOV EAX,dword ptr [EDX + 0x20]
000e2bc0  8b10  MOV EDX,dword ptr [EAX]
000e2bc2  890424  MOV dword ptr [ESP],EAX
000e2bc5  ff92ac010000  CALL dword ptr [EDX + 0x1ac]
000e2bcb  89f0  MOV EAX,ESI
000e2bcd  83c42c  ADD ESP,0x2c
000e2bd0  5b  POP EBX
000e2bd1  5e  POP ESI
000e2bd2  5f  POP EDI
000e2bd3  5d  POP EBP
000e2bd4  c3  RET
000e2bd5  31f6  XOR ESI,ESI
000e2bd7  8b4220  MOV EAX,dword ptr [EDX + 0x20]
000e2bda  8b10  MOV EDX,dword ptr [EAX]
000e2bdc  890424  MOV dword ptr [ESP],EAX
000e2bdf  ff92ac010000  CALL dword ptr [EDX + 0x1ac]
000e2be5  89f0  MOV EAX,ESI
000e2be7  83c42c  ADD ESP,0x2c
000e2bea  5b  POP EBX
000e2beb  5e  POP ESI
000e2bec  5f  POP EDI
000e2bed  5d  POP EBP
000e2bee  c3  RET
000e2bef  7c0a  JL 0x000e2bfb
000e2bf1  83780800  CMP dword ptr [EAX + 0x8],0x0
000e2bf5  0f871cffffff  JA 0x000e2b17
000e2bfb  31c9  XOR ECX,ECX
000e2bfd  e915ffffff  JMP 0x000e2b17

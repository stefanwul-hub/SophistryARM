
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

uint __regparm3 FUN_000e0202(int param_1,undefined4 param_2)

{
  uint *puVar1;
  int *piVar2;
  char cVar3;
  undefined4 uVar4;
  uint uVar5;
  int *piVar6;
  char *pcVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 *puVar10;
  uint uVar11;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  undefined1 auStack_21 [17];
  
  uVar4 = FUN_00033b90("/");
  uVar4 = func_0x00039a08(param_2,uVar4);
  uVar5 = FUN_00029ddc(uVar4);
  if (uVar5 == 0) {
    return 0;
  }
  uStack_34 = 0;
  uStack_3c = 0;
  do {
    piVar6 = (int *)FUN_0002a364(uVar4,uStack_3c);
    uVar11 = 0;
    if (*(int *)(param_1 + 0x10) != 0) {
      do {
        iVar9 = uVar11 * 0x240 + *(int *)(param_1 + 0x14);
        if ((((*(int *)(iVar9 + 0xc) != 0 || *(int *)(iVar9 + 8) != 0) &&
             (uStack_34 == *(uint *)(iVar9 + 0x20))) &&
            (cVar3 = (**(code **)(**(int **)(iVar9 + 0x23c) + 0x88))
                               (*(int **)(iVar9 + 0x23c),piVar6), cVar3 != '\0')) &&
           (uStack_38 = uVar11 + 1, uStack_38 != 0)) {
          if (-1 < *(int *)(iVar9 + 0xc)) {
            if (piVar6 == (int *)0x0) {
              pcVar7 = "";
            }
            else {
              pcVar7 = (char *)FUN_00034962(piVar6);
            }
            FUN_0000ab14("createDirectory failed, subpath \'%s\' already exits as file",pcVar7);
            return 0;
          }
          goto LAB_000e0528;
        }
        uVar11 = uVar11 + 1;
      } while (uVar11 < *(uint *)(param_1 + 0x10));
    }
    uStack_38 = 0;
    while (uVar11 = *(uint *)(param_1 + 0x10), uStack_38 < uVar11) {
      while ((puVar10 = (undefined4 *)(uStack_38 * 0x240 + *(int *)(param_1 + 0x14)),
             puVar10[3] != 0 || puVar10[2] != 0 || (puVar10[5] != 0 || puVar10[4] != 0))) {
        uStack_38 = uStack_38 + 1;
        uVar11 = *(uint *)(param_1 + 0x10);
        if (uVar11 <= uStack_38) goto LAB_000e02e6;
      }
      uStack_38 = uStack_38 + 1;
      _memset(puVar10 + 9,0,0x200);
      piVar2 = (int *)puVar10[0x8f];
      if (piVar2 != (int *)0x0) {
        (**(code **)(*piVar2 + 0x44))(piVar2);
      }
      puVar10[0x8f] = 0;
      if (uStack_38 != 0) goto LAB_000e0493;
    }
LAB_000e02e6:
    iVar9 = FUN_0000aecc(uVar11 * 0x240 + 0x240);
    if (*(int *)(param_1 + 0x10) != 0) {
      _memcpy(iVar9,*(undefined4 *)(param_1 + 0x14),uVar11 * 0x240);
    }
    if (*(int *)(param_1 + 0x14) != 0) {
      FUN_0000b122(*(int *)(param_1 + 0x14));
    }
    *(int *)(param_1 + 0x14) = iVar9;
    puVar10 = (undefined4 *)(iVar9 + *(int *)(param_1 + 0x10) * 0x240);
    _memset(puVar10,0,0x240);
    uStack_38 = *(int *)(param_1 + 0x10) + 1;
    *(uint *)(param_1 + 0x10) = uStack_38;
    uVar8 = *(undefined4 *)(param_1 + 0x1c);
    puVar10[0x8b] = *(undefined4 *)(param_1 + 0x18);
    puVar10[0x8c] = uVar8;
    uVar11 = *(uint *)(param_1 + 0x10);
    iVar9 = 4;
    do {
      (auStack_21 + 1)[iVar9 + -1] = (char)uVar11;
      uVar11 = uVar11 >> 8;
      iVar9 = iVar9 + -1;
    } while (iVar9 != 0);
    (**(code **)(**(int **)(param_1 + 0x24) + 0x1c0))(*(int **)(param_1 + 0x24),0x10);
    cVar3 = (**(code **)(**(int **)(param_1 + 0x24) + 0x1b0))
                      (*(int **)(param_1 + 0x24),auStack_21 + 1,4);
    if (cVar3 == '\0') {
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + -1;
      return 0;
    }
    puVar1 = (uint *)(param_1 + 0x18);
    uVar11 = *puVar1;
    *puVar1 = *puVar1 + 0x22c;
    *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + (uint)(0xfffffdd3 < uVar11);
LAB_000e0493:
    iVar9 = FUN_000349f4(piVar6);
    uVar8 = FUN_00036896(piVar6);
    _memcpy(puVar10 + 9,uVar8,iVar9 * 2);
    *puVar10 = 0x22c;
    puVar10[8] = uStack_34;
    puVar10[2] = 0;
    puVar10[3] = 0x80000000;
    puVar10[4] = 0;
    puVar10[5] = 0;
    puVar10[7] = 0;
    puVar10[6] = 0;
    puVar10[1] = 0;
    uVar8 = (**(code **)(*piVar6 + 0x40))(piVar6);
    puVar10[0x8f] = uVar8;
    cVar3 = FUN_000dfe52();
    if (cVar3 == '\0') {
      FUN_0000ab14("createDirectory failed in writing data, archive is damaged now");
      return 0;
    }
    if (uStack_38 == 0) {
      return 0;
    }
LAB_000e0528:
    uStack_3c = uStack_3c + 1;
    uStack_34 = uStack_38;
    if (uVar5 <= uStack_3c) {
      return uStack_38;
    }
  } while( true );
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001aaed6(int param_1)

{
  char cVar1;
  int iVar2;
  longdouble lVar3;
  
  iVar2 = FUN_001aa9c6(param_1);
  if (iVar2 != 0) {
    if ((*(int *)(param_1 + 0x14) == 0) ||
       (iVar2 = FUN_000349f4(*(int *)(param_1 + 0x14)), iVar2 == 0)) {
      FUN_000715c6("free","Elastik");
    }
    else {
      cVar1 = FUN_001aa276(param_1);
      if (cVar1 == '\0') {
        lVar3 = (longdouble)FUN_001aa1d2(param_1);
        if ((double)lVar3 == DOUBLE_00364718) {
          FUN_000715c6("not licensed","Elastik");
        }
        else {
          FUN_000715c6("grace periode","Elastik");
        }
      }
      else {
        FUN_000715c6("licensed","Elastik");
      }
    }
    return;
  }
  FUN_000715c6("undefined","Elastik");
  return;
}


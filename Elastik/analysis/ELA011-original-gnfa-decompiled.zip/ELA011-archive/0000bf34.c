
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0000bf34(undefined4 param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  
  puVar1 = (undefined4 *)__Znwm(0x18);
  func_0x0002dc66(puVar1);
  *puVar1 = &UNK_0036ce88;
  puVar1[3] = 0;
  puVar1[4] = 0;
  puVar1[5] = 0;
  piVar2 = (int *)FUN_0002dfa6(puVar1);
  piVar2 = (int *)(**(code **)(*piVar2 + 0x48))(piVar2);
  (**(code **)(*piVar2 + 0x1a4))(piVar2,param_1,0,0);
                    /* WARNING: Could not recover jumptable at 0x0000bfc1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*piVar2 + 0x1a8))();
  return;
}


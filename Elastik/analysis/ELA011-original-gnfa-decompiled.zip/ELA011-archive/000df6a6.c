
void FUN_000df6a6(int param_1)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0x14);
  piVar1 = *(int **)(iVar2 + 0x20);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x44))(piVar1);
    iVar2 = *(int *)(param_1 + 0x14);
  }
  *(undefined4 *)(iVar2 + 0x20) = 0;
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x1a4))(piVar1);
    piVar1 = *(int **)(param_1 + 0xc);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  return;
}



undefined1 FUN_000e05a2(int param_1)

{
  int *piVar1;
  undefined1 uVar2;
  int iVar3;
  int iVar4;
  
  piVar1 = *(int **)(*(int *)(param_1 + 0x10) + 0x20);
  (**(code **)(*piVar1 + 0x1a4))(piVar1);
  iVar4 = *(int *)(param_1 + 0x10);
  if (*(int *)(iVar4 + 0x24) == 0) {
LAB_000e05d9:
    (**(code **)(**(int **)(iVar4 + 0x20) + 0x1ac))(*(int **)(iVar4 + 0x20));
    return 0;
  }
  FUN_000df8d2(param_1);
  if (*(int *)(param_1 + 0x18) != 0) {
    iVar4 = *(int *)(param_1 + 0x10);
    goto LAB_000e05d9;
  }
  if (*(int *)(param_1 + 0x14) != 0) {
    iVar3 = *(int *)(param_1 + 0x14) * 0x240 + *(int *)(*(int *)(param_1 + 0x10) + 0x14);
    iVar4 = *(int *)(iVar3 + -0x234);
    if ((-1 < iVar4) && ((0 < iVar4 || (*(int *)(iVar3 + -0x238) != 0)))) {
      uVar2 = 1;
      goto LAB_000e0619;
    }
  }
  uVar2 = 0;
LAB_000e0619:
  piVar1 = *(int **)(*(int *)(param_1 + 0x10) + 0x20);
  (**(code **)(*piVar1 + 0x1ac))(piVar1);
  return uVar2;
}


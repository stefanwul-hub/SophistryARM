
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001aa276(int param_1)

{
  int iVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  undefined1 *puStack_48;
  int iStack_44;
  int *piStack_40;
  undefined1 auStack_37 [5];
  undefined1 auStack_32 [6];
  int aiStack_2c [7];
  
  if ((*(int *)(param_1 + 0x18) != 0) &&
     (iVar4 = FUN_000349f4(*(int *)(param_1 + 0x18)), iVar4 == 0xe)) {
    uVar5 = FUN_00034962(*(undefined4 *)(param_1 + 0x18));
    _strcpy(auStack_37,uVar5);
    puStack_48 = auStack_32;
    iVar4 = 0;
    iStack_44 = 1;
    piStack_40 = (int *)&UNK_0036567c;
    do {
      iVar1 = (char)puStack_48[-4] * 100 + (char)puStack_48[-5] * 1000 + (char)puStack_48[-3] * 10 +
              -0xd050 + (int)(char)puStack_48[-2];
      if (iVar1 < 0x2707) {
        iVar4 = (iVar1 * iVar1) % 0x2707;
        if (*piStack_40 != 2) {
          iVar7 = 0;
          do {
            iVar4 = (iVar1 * iVar4) % 0x2707;
            iVar7 = iVar7 + 1;
          } while (*piStack_40 + -2 != iVar7);
        }
      }
      aiStack_2c[iStack_44] = iVar4;
      puStack_48 = puStack_48 + 5;
      iStack_44 = iStack_44 + 1;
      piStack_40 = piStack_40 + 1;
    } while (iStack_44 != 4);
    piVar6 = (int *)FUN_0003dd2a("%04i-%04i-%04i",aiStack_2c[1],aiStack_2c[2],aiStack_2c[3]);
    pcVar2 = *(code **)(*piVar6 + 0x88);
    uVar5 = func_0x001a9e08(param_1);
    cVar3 = (*pcVar2)(piVar6,uVar5);
    if (cVar3 != '\0') {
      return 1;
    }
  }
  return 0;
}


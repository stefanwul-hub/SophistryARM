
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000e2ab8(int *param_1)

{
  int iVar1;
  bool bVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  
  (**(code **)(**(int **)(param_1[4] + 0x20) + 0x1a4))(*(int **)(param_1[4] + 0x20));
  iVar7 = param_1[4];
  if (*(int *)(iVar7 + 0x24) != 0) {
    FUN_000df8d2(param_1);
    if (param_1[5] != 0) {
      iVar7 = param_1[4];
      iVar3 = param_1[5] * 0x240 + *(int *)(iVar7 + 0x14);
      bVar2 = true;
      iVar1 = *(int *)(iVar3 + -0x234);
      if ((iVar1 < 1) && ((iVar1 < 0 || (*(int *)(iVar3 + -0x238) == 0)))) {
        bVar2 = false;
      }
      if (!bVar2) goto LAB_000e2bd5;
    }
    uVar4 = __Znwm(0x20);
    FUN_0002765e(uVar4);
    piVar5 = (int *)FUN_0002dfa6(uVar4);
    uVar4 = (**(code **)(*piVar5 + 0x48))(piVar5);
    puVar6 = (undefined4 *)__Znwm(0x3c);
    FUN_0017e5fa(puVar6);
    *puVar6 = &UNK_0037b488;
    puVar6[0xc] = 0;
    puVar6[0xd] = 0;
    puVar6[0xb] = 0;
    puVar6[10] = 0;
    *(undefined1 *)(puVar6 + 9) = 0;
    *(undefined1 *)(puVar6 + 0xe) = 0;
    piVar5 = (int *)FUN_0002dfa6(puVar6);
    iVar7 = (**(code **)(*piVar5 + 0x48))(piVar5);
    uVar8 = (**(code **)(*param_1 + 0x40))(param_1);
    *(undefined4 *)(iVar7 + 0x28) = uVar8;
    *(undefined1 *)(iVar7 + 0x24) = 1;
    FUN_0017f84e(iVar7,uVar4);
    (**(code **)(**(int **)(param_1[4] + 0x20) + 0x1ac))(*(int **)(param_1[4] + 0x20));
    return iVar7;
  }
LAB_000e2bd5:
  (**(code **)(**(int **)(iVar7 + 0x20) + 0x1ac))(*(int **)(iVar7 + 0x20));
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0017f64a(int param_1)

{
  int *piVar1;
  short sVar2;
  int iVar3;
  undefined4 uVar4;
  char *pcVar5;
  undefined4 uVar6;
  
  if (param_1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x309,uVar4,"this != 0");
  }
  if (*(int *)(param_1 + 0xc) == 0) {
    if (*(short *)(param_1 + 0x10) != 0) {
      sVar2 = _FSCloseFork((int)*(short *)(param_1 + 0x10));
      if (sVar2 != 0) {
        piVar1 = *(int **)(param_1 + 0x18);
        if (piVar1 == (int *)0x0) {
          pcVar5 = "NA";
        }
        else {
          iVar3 = (**(code **)(*piVar1 + 0x1bc))(piVar1);
          if (iVar3 == 0) {
            pcVar5 = "";
          }
          else {
            uVar4 = (**(code **)(**(int **)(param_1 + 0x18) + 0x1bc))(*(int **)(param_1 + 0x18));
            pcVar5 = (char *)FUN_00034962(uVar4);
          }
        }
        FUN_0000ab14("HFS: Cannot close file %s (%i)",pcVar5,(int)sVar2);
      }
      *(undefined2 *)(param_1 + 0x10) = 0;
      return;
    }
  }
  else {
    FUN_00027bec(*(int *)(param_1 + 0xc));
    (**(code **)(**(int **)(param_1 + 0xc) + 0x1a4))
              (*(int **)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x20));
  }
  return;
}


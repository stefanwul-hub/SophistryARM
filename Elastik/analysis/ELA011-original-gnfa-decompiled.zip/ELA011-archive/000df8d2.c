
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000df8d2(int param_1)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  int iStack_24;
  uint uStack_20;
  
  if (*(int *)(param_1 + 0x18) != 0) {
    iVar3 = FUN_000349f4(*(int *)(param_1 + 0x18));
    if (iVar3 < 2) {
      *(undefined4 *)(param_1 + 0x14) = 0;
      piVar1 = *(int **)(param_1 + 0x18);
    }
    else {
      uVar4 = FUN_00033b90("/");
      uVar4 = func_0x00039a08(*(undefined4 *)(param_1 + 0x18),uVar4);
      iStack_24 = 0;
      iVar3 = 1;
      uStack_20 = 0;
      iVar5 = FUN_00029ddc(uVar4);
      if (iVar5 != 0) {
        do {
          uVar6 = FUN_0002a364(uVar4,uStack_20);
          uVar7 = 0;
          iVar3 = *(int *)(param_1 + 0x10);
          if (*(int *)(iVar3 + 0x10) == 0) {
            return;
          }
          while ((((iVar3 = uVar7 * 0x240 + *(int *)(iVar3 + 0x14),
                   *(int *)(iVar3 + 0x20) != iStack_24 ||
                   (*(int *)(iVar3 + 0xc) == 0 && *(int *)(iVar3 + 8) == 0)) ||
                  (cVar2 = (**(code **)(**(int **)(iVar3 + 0x23c) + 0x88))
                                     (*(int **)(iVar3 + 0x23c),uVar6), cVar2 == '\0')) ||
                 (iVar3 = uVar7 + 1, iVar3 == 0))) {
            uVar7 = uVar7 + 1;
            iVar3 = *(int *)(param_1 + 0x10);
            if (*(uint *)(iVar3 + 0x10) <= uVar7) {
              return;
            }
          }
          uStack_20 = uStack_20 + 1;
          if (iVar3 == 0) {
            return;
          }
          uVar7 = FUN_00029ddc(uVar4);
          iStack_24 = iVar3;
        } while (uStack_20 < uVar7);
      }
      if (iVar3 == 0) {
        return;
      }
      *(int *)(param_1 + 0x14) = iVar3;
      piVar1 = *(int **)(param_1 + 0x18);
    }
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
      *(undefined4 *)(param_1 + 0x18) = 0;
      return;
    }
  }
  return;
}


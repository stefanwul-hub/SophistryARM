
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000e2d84(int param_1)

{
  undefined4 *puVar1;
  code *pcVar2;
  int *piVar3;
  char cVar4;
  int iVar5;
  int *piVar6;
  int iVar7;
  char *pcVar8;
  uint uVar9;
  undefined4 uVar10;
  uint uVar11;
  undefined4 uVar12;
  uint uVar13;
  uint uVar14;
  int iVar15;
  uint uVar16;
  uint uVar17;
  uint *puVar18;
  undefined1 *puStack_290;
  undefined4 uStack_28c;
  int iStack_284;
  undefined4 uStack_27c;
  uint *puStack_278;
  uint uStack_26c;
  int iStack_260;
  undefined1 auStack_251 [557];
  uint uStack_24;
  uint auStack_20 [4];
  
  piVar6 = *(int **)(param_1 + 0x2c);
  if (piVar6 != (int *)0x0) {
    if (*(char *)(param_1 + 0x38) != '\0') {
      return;
    }
    (**(code **)(*piVar6 + 0x1a4))(piVar6);
    return;
  }
  if (*(char *)(param_1 + 0x24) == '\0') {
    FUN_0017f64a(param_1);
    return;
  }
  FUN_0017f64a(param_1);
  piVar6 = *(int **)(*(int *)(*(int *)(param_1 + 0x28) + 0x10) + 0x20);
  (**(code **)(*piVar6 + 0x1a4))(piVar6);
  iVar15 = *(int *)(*(int *)(param_1 + 0x28) + 0x10);
  if (*(int *)(iVar15 + 0x24) == 0) goto LAB_000e2eb6;
  FUN_000df8d2(*(int *)(param_1 + 0x28));
  iVar15 = *(int *)(param_1 + 0x28);
  iVar7 = *(int *)(iVar15 + 0x18);
  if (iVar7 == 0) {
    uStack_27c = *(undefined4 *)(param_1 + 0xc);
    uVar9 = *(uint *)(iVar15 + 0x14);
    iVar15 = *(int *)(iVar15 + 0x10);
    piVar6 = *(int **)(iVar15 + 0x24);
    if ((uVar9 == 0) || (*(uint *)(iVar15 + 0x10) < uVar9)) {
      uVar10 = func_0x0000a930(
                              "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                              );
      uVar12 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar12,"Assertion failed in line %d of %s: %s.",0x2f8,uVar10,
                   "fileNumber > 0 && fileNumber <= fileArchive->_header._countOfEntries");
    }
    uStack_24 = 0;
    auStack_20[0] = 0;
    iVar7 = uVar9 * 0x240 + *(int *)(iVar15 + 0x14);
    puStack_278 = (uint *)(iVar7 + -0x240);
    puVar1 = *(undefined4 **)(*(int *)(iVar15 + 0x28) + 0x10);
    if (puVar1 != (undefined4 *)0x0) {
      uStack_27c = (**(code **)*puVar1)
                             (puVar1,uStack_27c,*(undefined4 *)(iVar7 + -4),&uStack_24,auStack_20);
    }
    uVar9 = *(uint *)(iVar7 + -0x220);
    uVar11 = *(uint *)(iVar7 + -0x230);
    iVar5 = *(int *)(iVar7 + -0x22c);
    if (iVar5 != 0 || uVar11 != 0) {
      uVar14 = *(uint *)(iVar7 + -0x240);
      uVar16 = uVar14 + uVar11;
      uVar13 = FUN_000278d6(uStack_27c);
      if ((iVar5 + (uint)CARRY4(uVar14,uVar11) + -1 + (uint)(0x22b < uVar16) == 0) &&
         (uVar16 - 0x22c < uVar13)) {
        *(undefined4 *)(iVar7 + -0x238) = 0;
        *(undefined4 *)(iVar7 + -0x234) = 0;
        piVar3 = *(int **)(iVar7 + -4);
        iVar5 = 8;
        do {
          (auStack_251 + 1)[iVar5 + -1] = 0;
          iVar5 = iVar5 + -1;
        } while (iVar5 != 0);
        (**(code **)(*piVar6 + 0x1c0))(piVar6,*(int *)(iVar7 + -0x14) + 8);
        cVar4 = (**(code **)(*piVar6 + 0x1b0))(piVar6,auStack_251 + 1,8);
        if (cVar4 == '\0') {
          (**(code **)(**(int **)(iVar15 + 0x20) + 0x1ac))(*(int **)(iVar15 + 0x20));
          uVar10 = FUN_00033b90("GNFileArchiveCannotWriteArchiveException");
          FUN_0000bf34(uVar10);
        }
        uStack_26c = 0;
        iStack_260 = 0;
        do {
          if (*(uint *)(iVar15 + 0x10) <= uStack_26c) {
            iVar5 = *(uint *)(iVar15 + 0x10) * 0x240;
            iVar7 = FUN_0000aecc(iVar5 + 0x240);
            if (*(int *)(iVar15 + 0x10) != 0) {
              _memcpy(iVar7,*(undefined4 *)(iVar15 + 0x14),iVar5);
            }
            if (*(int *)(iVar15 + 0x14) != 0) {
              FUN_0000b122(*(int *)(iVar15 + 0x14));
            }
            *(int *)(iVar15 + 0x14) = iVar7;
            puStack_278 = (uint *)(iVar7 + *(int *)(iVar15 + 0x10) * 0x240);
            _memset(puStack_278,0,0x240);
            *(int *)(iVar15 + 0x10) = *(int *)(iVar15 + 0x10) + 1;
            uVar11 = FUN_000278d6(uStack_27c);
            puStack_278[4] = uVar11;
            puStack_278[5] = (int)uVar11 >> 0x1f;
            uVar11 = *(uint *)(iVar15 + 0x1c);
            puStack_278[0x8b] = *(uint *)(iVar15 + 0x18);
            puStack_278[0x8c] = uVar11;
            uVar11 = *(uint *)(iVar15 + 0x18);
            iVar7 = *(int *)(iVar15 + 0x1c);
            iVar5 = FUN_000278d6(uStack_27c);
            *(uint *)(iVar15 + 0x18) = uVar11 + iVar5 + 0x22cU;
            *(uint *)(iVar15 + 0x1c) = iVar7 + (uint)CARRY4(uVar11,iVar5 + 0x22cU);
            puVar18 = puStack_278 + 9;
            goto LAB_000e369c;
          }
          puStack_278 = (uint *)(iStack_260 + *(int *)(iVar15 + 0x14));
          if (puStack_278[3] == 0 && puStack_278[2] == 0) {
            uVar11 = puStack_278[4];
            uVar14 = puStack_278[5];
            if (uVar14 == 0 && uVar11 == 0) goto LAB_000e3512;
            uVar13 = *puStack_278;
            uVar17 = uVar13 + uVar11;
            uVar16 = FUN_000278d6(uStack_27c);
            if ((uVar14 + CARRY4(uVar13,uVar11) + -1 + (uint)(0x22b < uVar17) == 0) &&
               (uVar17 - 0x22c < uVar16)) goto LAB_000e3512;
          }
          else {
LAB_000e3512:
            puStack_278 = (uint *)0x0;
          }
          uStack_26c = uStack_26c + 1;
          iStack_260 = iStack_260 + 0x240;
        } while (puStack_278 == (uint *)0x0);
        uVar11 = puStack_278[4];
        uVar14 = *puStack_278 + puStack_278[4];
        puStack_278[4] = uVar14 - 0x22c;
        puStack_278[5] =
             puStack_278[5] + (uint)CARRY4(*puStack_278,uVar11) + -1 + (uint)(0x22b < uVar14);
        puVar18 = puStack_278 + 9;
        _memset(puVar18,0,0x200);
LAB_000e369c:
        uVar11 = (**(code **)(*piVar3 + 0x40))(piVar3);
        puStack_278[0x8f] = uVar11;
        iVar7 = FUN_000349f4(uVar11);
        uVar10 = FUN_00036896(puStack_278[0x8f]);
        _memcpy(puVar18,uVar10,iVar7 * 2);
      }
    }
    puStack_290 = auStack_251 + 1;
    puStack_278[8] = uVar9;
    *puStack_278 = 0x22c;
    uVar9 = FUN_000278d6(uStack_27c);
    puStack_278[2] = uVar9;
    puStack_278[3] = (int)uVar9 >> 0x1f;
    puStack_278[7] = uStack_24;
    puStack_278[6] = auStack_20[0];
    puStack_278[1] = 0;
    cVar4 = FUN_000dfe52();
    if (cVar4 == '\0') {
      uVar10 = FUN_00033b90("GNFileArchiveCannotWriteArchiveException");
      FUN_0000bf34(uVar10);
    }
    FUN_00027b4e(uStack_27c);
    pcVar2 = *(code **)(*piVar6 + 0x1b0);
    uVar10 = FUN_000278d6(uStack_27c);
    uVar12 = FUN_00027abc(uStack_27c);
    cVar4 = (*pcVar2)(piVar6,uVar12,uVar10);
    if (cVar4 == '\0') {
      FUN_00027bec(uStack_27c);
      uVar10 = FUN_00033b90("GNFileArchiveCannotWriteArchiveException");
      FUN_0000bf34(uVar10);
    }
    FUN_00027bec(uStack_27c);
    (**(code **)(*piVar6 + 0x1c0))(piVar6,0x10);
    uVar9 = *(uint *)(iVar15 + 0x10);
    iVar15 = 4;
    do {
      puStack_290[iVar15 + -1] = (char)uVar9;
      uVar9 = uVar9 >> 8;
      iVar15 = iVar15 + -1;
    } while (iVar15 != 0);
    cVar4 = (**(code **)(*piVar6 + 0x1b0))(piVar6,puStack_290,4);
    if (cVar4 == '\0') {
      uVar10 = FUN_00033b90("GNFileArchiveCannotWriteArchiveException");
      FUN_0000bf34(uVar10);
      iVar15 = *(int *)(*(int *)(param_1 + 0x28) + 0x10);
    }
    else {
      iVar15 = *(int *)(*(int *)(param_1 + 0x28) + 0x10);
    }
    goto LAB_000e2eb6;
  }
  uStack_28c = *(undefined4 *)(param_1 + 0xc);
  iVar15 = *(int *)(iVar15 + 0x10);
  auStack_20[0] = 0;
  uStack_24 = 0;
  iVar5 = FUN_0003a64e(iVar7);
  piVar6 = (int *)FUN_0003a99a(iVar7);
  iVar7 = FUN_000349f4(iVar5);
  if (iVar7 < 2) {
    iStack_284 = 0;
LAB_000e3120:
    puVar1 = *(undefined4 **)(*(int *)(iVar15 + 0x28) + 0x10);
    if (puVar1 != (undefined4 *)0x0) {
      uStack_28c = (**(code **)*puVar1)(puVar1,uStack_28c,piVar6,&uStack_24,auStack_20);
    }
    iVar5 = *(int *)(iVar15 + 0x10) * 0x240;
    iVar7 = FUN_0000aecc(iVar5 + 0x240);
    if (*(int *)(iVar15 + 0x10) != 0) {
      _memcpy(iVar7,*(undefined4 *)(iVar15 + 0x14),iVar5);
    }
    if (*(int *)(iVar15 + 0x14) != 0) {
      FUN_0000b122(*(int *)(iVar15 + 0x14));
    }
    *(int *)(iVar15 + 0x14) = iVar7;
    puVar1 = (undefined4 *)(iVar7 + *(int *)(iVar15 + 0x10) * 0x240);
    _memset(puVar1,0,0x240);
    *(int *)(iVar15 + 0x10) = *(int *)(iVar15 + 0x10) + 1;
    iVar7 = FUN_000349f4(piVar6);
    uVar10 = FUN_00036896(piVar6);
    _memcpy(puVar1 + 9,uVar10,iVar7 * 2);
    uVar10 = (**(code **)(*piVar6 + 0x40))(piVar6);
    puVar1[0x8f] = uVar10;
    puVar1[8] = iStack_284;
    *puVar1 = 0x22c;
    iVar7 = FUN_000278d6(uStack_28c);
    puVar1[2] = iVar7;
    puVar1[3] = iVar7 >> 0x1f;
    iVar7 = FUN_000278d6(uStack_28c);
    puVar1[4] = iVar7;
    puVar1[5] = iVar7 >> 0x1f;
    puVar1[7] = uStack_24;
    puVar1[6] = auStack_20[0];
    puVar1[1] = 0;
    uVar10 = *(undefined4 *)(iVar15 + 0x1c);
    puVar1[0x8b] = *(undefined4 *)(iVar15 + 0x18);
    puVar1[0x8c] = uVar10;
    (**(code **)(**(int **)(iVar15 + 0x24) + 0x1c0))(*(int **)(iVar15 + 0x24),0x10);
    auStack_251[4] = (undefined1)*(uint *)(iVar15 + 0x10);
    iVar7 = 3;
    uVar9 = *(uint *)(iVar15 + 0x10);
    do {
      (auStack_251 + 1)[iVar7 + -1] = (char)(uVar9 >> 8);
      iVar7 = iVar7 + -1;
      uVar9 = uVar9 >> 8;
    } while (iVar7 != 0);
    cVar4 = (**(code **)(**(int **)(iVar15 + 0x24) + 0x1b0))
                      (*(int **)(iVar15 + 0x24),auStack_251 + 1,4);
    if (cVar4 == '\0') {
      *(int *)(iVar15 + 0x10) = *(int *)(iVar15 + 0x10) + -1;
    }
    else {
      puVar18 = (uint *)(iVar15 + 0x18);
      uVar9 = *puVar18;
      *puVar18 = *puVar18 + 0x22c;
      *(int *)(iVar15 + 0x1c) = *(int *)(iVar15 + 0x1c) + (uint)(0xfffffdd3 < uVar9);
      (**(code **)(**(int **)(iVar15 + 0x24) + 0x1c0))(*(int **)(iVar15 + 0x24),puVar1[0x8b]);
      cVar4 = FUN_000dfe52();
      if (cVar4 == '\0') {
        uVar10 = FUN_00033b90("GNFileArchiveCannotWriteArchiveException");
        FUN_0000bf34(uVar10);
      }
      uVar9 = *(uint *)(iVar15 + 0x18);
      iVar7 = *(int *)(iVar15 + 0x1c);
      uVar11 = FUN_000278d6(uStack_28c);
      *(uint *)(iVar15 + 0x18) = uVar9 + uVar11;
      *(uint *)(iVar15 + 0x1c) = iVar7 + ((int)uVar11 >> 0x1f) + (uint)CARRY4(uVar9,uVar11);
      FUN_00027b4e(uStack_28c);
      pcVar2 = *(code **)(**(int **)(iVar15 + 0x24) + 0x1b0);
      uVar10 = FUN_000278d6(uStack_28c);
      uVar12 = FUN_00027abc(uStack_28c);
      cVar4 = (*pcVar2)(*(undefined4 *)(iVar15 + 0x24),uVar12,uVar10);
      if (cVar4 == '\0') {
        FUN_00027bec(uStack_28c);
        uVar10 = FUN_00033b90("GNFileArchiveCannotWriteArchiveException");
        FUN_0000bf34(uVar10);
      }
      FUN_00027bec(uStack_28c);
    }
  }
  else {
    iStack_284 = FUN_000e0202();
    if (iStack_284 != 0) goto LAB_000e3120;
    if (iVar5 == 0) {
      pcVar8 = "";
    }
    else {
      pcVar8 = (char *)FUN_00034962(iVar5);
    }
    FUN_0000ab14("createFileData failed, can\'t create directory \'%s\'",pcVar8);
  }
  FUN_000df8d2(*(undefined4 *)(param_1 + 0x28));
  iVar15 = *(int *)(*(int *)(param_1 + 0x28) + 0x10);
LAB_000e2eb6:
  (**(code **)(**(int **)(iVar15 + 0x20) + 0x1ac))(*(int **)(iVar15 + 0x20));
  return;
}



void FUN_000df5a4(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  FUN_0002defe(param_1);
  iVar1 = *(int *)(param_1 + 0x14);
  uVar2 = __Znwm(0x38);
  FUN_0006f04a(uVar2);
  uVar2 = FUN_0002dfa6(uVar2);
  *(undefined4 *)(iVar1 + 0x20) = uVar2;
  return;
}


000df6a6  55  PUSH EBP
000df6a7  89e5  MOV EBP,ESP
000df6a9  56  PUSH ESI
000df6aa  83ec14  SUB ESP,0x14
000df6ad  8b7508  MOV ESI,dword ptr [EBP + 0x8]
000df6b0  8b4614  MOV EAX,dword ptr [ESI + 0x14]
000df6b3  8b5020  MOV EDX,dword ptr [EAX + 0x20]
000df6b6  85d2  TEST EDX,EDX
000df6b8  740b  JZ 0x000df6c5
000df6ba  8b02  MOV EAX,dword ptr [EDX]
000df6bc  891424  MOV dword ptr [ESP],EDX
000df6bf  ff5044  CALL dword ptr [EAX + 0x44]
000df6c2  8b4614  MOV EAX,dword ptr [ESI + 0x14]
000df6c5  c7402000000000  MOV dword ptr [EAX + 0x20],0x0
000df6cc  8b560c  MOV EDX,dword ptr [ESI + 0xc]
000df6cf  85d2  TEST EDX,EDX
000df6d1  7421  JZ 0x000df6f4
000df6d3  8b02  MOV EAX,dword ptr [EDX]
000df6d5  891424  MOV dword ptr [ESP],EDX
000df6d8  ff90a4010000  CALL dword ptr [EAX + 0x1a4]
000df6de  8b560c  MOV EDX,dword ptr [ESI + 0xc]
000df6e1  85d2  TEST EDX,EDX
000df6e3  7408  JZ 0x000df6ed
000df6e5  8b02  MOV EAX,dword ptr [EDX]
000df6e7  891424  MOV dword ptr [ESP],EDX
000df6ea  ff5044  CALL dword ptr [EAX + 0x44]
000df6ed  c7460c00000000  MOV dword ptr [ESI + 0xc],0x0
000df6f4  897508  MOV dword ptr [EBP + 0x8],ESI
000df6f7  83c414  ADD ESP,0x14
000df6fa  5e  POP ESI
000df6fb  5d  POP EBP
000df6fc  e975e8f4ff  JMP 0x0002df76

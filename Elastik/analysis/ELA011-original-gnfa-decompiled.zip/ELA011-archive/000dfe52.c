
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int __regparm3 FUN_000dfe52(int param_1,uint *param_2)

{
  undefined1 *puVar1;
  ulonglong uVar2;
  longlong lVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  int *piVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined1 *puVar10;
  int iVar11;
  uint uVar12;
  uint *puVar13;
  longdouble lVar14;
  undefined4 uStack_25c;
  int iStack_258;
  undefined1 auStack_249 [33];
  undefined1 auStack_228 [4];
  undefined1 auStack_224 [511];
  undefined1 auStack_25 [21];
  
  iVar5 = func_0x001a7df0(0x7b2,1,1,0,0,0);
  uVar6 = __Znwm(0x14);
  func_0x001a7cfa(uVar6);
  piVar7 = (int *)FUN_0002dfa6(uVar6);
  if ((iVar5 == 0) || (piVar7 == (int *)0x0)) {
    uVar6 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                           );
    uVar9 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar9,"Assertion failed in line %d of %s: %s.",0x20d,uVar6,
                 "reference != 0 && currentDate != 0");
  }
  (**(code **)(**(int **)(param_1 + 0x24) + 0x1c0))(*(int **)(param_1 + 0x24),param_2[0x8b]);
  puVar1 = auStack_249 + 1;
  auStack_249[4] = (undefined1)*param_2;
  iVar11 = 3;
  uVar8 = *param_2;
  do {
    puVar1[iVar11 + -1] = (char)(uVar8 >> 8);
    iVar11 = iVar11 + -1;
    uVar8 = uVar8 >> 8;
  } while (iVar11 != 0);
  uVar8 = param_2[1];
  iVar11 = 4;
  do {
    auStack_249[iVar11 + 4] = (char)uVar8;
    uVar8 = uVar8 >> 8;
    iVar11 = iVar11 + -1;
  } while (iVar11 != 0);
  uVar8 = param_2[2];
  uVar12 = param_2[3];
  iVar11 = 8;
  do {
    auStack_249[iVar11 + 8] = (char)uVar8;
    uVar8 = uVar8 >> 8 | uVar12 << 0x18;
    uVar12 = uVar12 >> 8;
    iVar11 = iVar11 + -1;
  } while (iVar11 != 0);
  uVar8 = param_2[4];
  uVar12 = param_2[5];
  iVar11 = 8;
  do {
    auStack_249[iVar11 + 0x10] = (char)uVar8;
    uVar8 = uVar8 >> 8 | uVar12 << 0x18;
    uVar12 = uVar12 >> 8;
    iVar11 = iVar11 + -1;
  } while (iVar11 != 0);
  uVar8 = param_2[6];
  iVar11 = 4;
  do {
    auStack_249[iVar11 + 0x18] = (char)uVar8;
    uVar8 = uVar8 >> 8;
    iVar11 = iVar11 + -1;
  } while (iVar11 != 0);
  uVar8 = param_2[7];
  iVar11 = 4;
  do {
    auStack_249[iVar11 + 0x1c] = (char)uVar8;
    uVar8 = uVar8 >> 8;
    iVar11 = iVar11 + -1;
  } while (iVar11 != 0);
  uVar8 = param_2[8];
  iVar11 = 3;
  do {
    auStack_228[iVar11] = (char)uVar8;
    uVar8 = uVar8 >> 8;
    iVar11 = iVar11 + -1;
  } while (iVar11 != -1);
  iVar11 = 0;
  puVar10 = puVar1;
  puVar13 = param_2;
  do {
    uVar8 = puVar13[9];
    puVar10[0x24] = (char)((ushort)(short)uVar8 >> 8);
    puVar10[0x25] = (char)(short)uVar8;
    iVar11 = iVar11 + 1;
    puVar10 = puVar10 + 2;
    puVar13 = (uint *)((int)puVar13 + 2);
  } while (iVar11 != 0x100);
  lVar14 = (longdouble)func_0x001a6528(piVar7,iVar5);
  if (DOUBLE_003647e8 <= (double)lVar14) {
    lVar3 = (longlong)ROUND((double)lVar14 - DOUBLE_003647e8);
    uStack_25c = (undefined4)lVar3;
    iStack_258 = (int)((ulonglong)lVar3 >> 0x20);
    uVar2 = CONCAT44(iStack_258 + -0x80000000,uStack_25c);
  }
  else {
    uVar2 = (ulonglong)ROUND(lVar14);
  }
  *(ulonglong *)(param_2 + 0x89) = uVar2;
  iVar5 = 8;
  do {
    auStack_25[iVar5] = (char)uVar2;
    uVar2 = uVar2 >> 8;
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  if (piVar7 != (int *)0x0) {
    (**(code **)(*piVar7 + 0x44))(piVar7);
  }
  param_2[0x8d] = param_2[0x8b] + 0x22c;
  param_2[0x8e] = param_2[0x8c] + (uint)(0xfffffdd3 < param_2[0x8b]);
  cVar4 = (**(code **)(**(int **)(param_1 + 0x24) + 0x1b0))(*(int **)(param_1 + 0x24),puVar1,0x22c);
  return (int)cVar4;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000e440a(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x2c) == 0) {
    if (param_1 == 0) {
      uVar1 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                             );
      uVar2 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x67a,uVar1,"this != 0");
    }
    if (param_2 < 0) {
      uVar1 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                             );
      uVar2 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x67a,uVar1,"offset >= 0");
    }
    if (*(int *)(param_1 + 0xc) == 0) {
      if (*(short *)(param_1 + 0x10) == 0) {
        uVar1 = func_0x0000a930(
                               "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                               );
        uVar2 = FUN_00033b90("GNAssertionException");
        FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x689,uVar1,"_private");
      }
      _FSSetForkPosition((int)*(short *)(param_1 + 0x10),1,param_2,param_2 >> 0x1f);
      return;
    }
    *(int *)(param_1 + 0x1c) = param_2;
    return;
  }
  if (*(int *)(*(int *)(*(int *)(param_1 + 0x28) + 0x10) + 0x24) != 0) {
    FUN_000df8d2(*(int *)(param_1 + 0x28));
    iVar3 = *(int *)(param_1 + 0x28);
    if (*(int *)(iVar3 + 0x18) != 0) {
      uVar1 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                             );
      uVar2 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x630,uVar1,
                   "_fileArchiveFilePath->_posixPath == 0");
      iVar3 = *(int *)(param_1 + 0x28);
    }
    if (*(int *)(iVar3 + 0x14) * 0x240 + *(int *)(*(int *)(iVar3 + 0x10) + 0x14) != 0x240)
    goto LAB_000e44b7;
  }
  uVar1 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                         );
  uVar2 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x5e1,uVar1,"desc != 0");
LAB_000e44b7:
  *(int *)(param_1 + 0x30) = param_2;
  *(int *)(param_1 + 0x34) = param_2 >> 0x1f;
  if (*(char *)(param_1 + 0x38) == '\0') {
                    /* WARNING: Could not recover jumptable at 0x000e44f4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(param_1 + 0x2c) + 0x1c0))();
    return;
  }
  return;
}


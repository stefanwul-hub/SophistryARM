
void FUN_0017f84e(int param_1,int *param_2)

{
  int *piVar1;
  
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != param_2) {
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(int **)(param_1 + 0xc) = param_2;
    piVar1 = param_2;
    if (param_2 != (int *)0x0) {
      (**(code **)(*param_2 + 0x40))(param_2);
      piVar1 = *(int **)(param_1 + 0xc);
    }
  }
  FUN_00027b4e(piVar1);
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x20) = 0;
  return;
}


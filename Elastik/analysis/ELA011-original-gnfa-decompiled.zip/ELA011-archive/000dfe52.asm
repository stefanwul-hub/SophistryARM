000dfe52  55  PUSH EBP
000dfe53  89e5  MOV EBP,ESP
000dfe55  57  PUSH EDI
000dfe56  56  PUSH ESI
000dfe57  53  PUSH EBX
000dfe58  81ec8c020000  SUB ESP,0x28c
000dfe5e  e8b9512000  CALL 0x002e501c
000dfe63  898594fdffff  MOV dword ptr [EBP + 0xfffffd94],EAX
000dfe69  899590fdffff  MOV dword ptr [EBP + 0xfffffd90],EDX
000dfe6f  c744241400000000  MOV dword ptr [ESP + 0x14],0x0
000dfe77  c744241000000000  MOV dword ptr [ESP + 0x10],0x0
000dfe7f  c744240c00000000  MOV dword ptr [ESP + 0xc],0x0
000dfe87  c744240801000000  MOV dword ptr [ESP + 0x8],0x1
000dfe8f  c744240401000000  MOV dword ptr [ESP + 0x4],0x1
000dfe97  c70424b2070000  MOV dword ptr [ESP],0x7b2
000dfe9e  e84d7f0c00  CALL 0x001a7df0
000dfea3  8985a0fdffff  MOV dword ptr [EBP + 0xfffffda0],EAX
000dfea9  c7042414000000  MOV dword ptr [ESP],0x14
000dfeb0  e8f0a12f00  CALL 0x003da0a5
000dfeb5  89c7  MOV EDI,EAX
000dfeb7  890424  MOV dword ptr [ESP],EAX
000dfeba  e83b7e0c00  CALL 0x001a7cfa
000dfebf  893c24  MOV dword ptr [ESP],EDI
000dfec2  e8dfe0f4ff  CALL 0x0002dfa6
000dfec7  8985a4fdffff  MOV dword ptr [EBP + 0xfffffda4],EAX
000dfecd  8b85a0fdffff  MOV EAX,dword ptr [EBP + 0xfffffda0]
000dfed3  85c0  TEST EAX,EAX
000dfed5  0f84ca020000  JZ 0x000e01a5
000dfedb  8b85a4fdffff  MOV EAX,dword ptr [EBP + 0xfffffda4]
000dfee1  85c0  TEST EAX,EAX
000dfee3  0f84bc020000  JZ 0x000e01a5
000dfee9  8b9594fdffff  MOV EDX,dword ptr [EBP + 0xfffffd94]
000dfeef  8b4224  MOV EAX,dword ptr [EDX + 0x24]
000dfef2  8b08  MOV ECX,dword ptr [EAX]
000dfef4  8bb590fdffff  MOV ESI,dword ptr [EBP + 0xfffffd90]
000dfefa  8b962c020000  MOV EDX,dword ptr [ESI + 0x22c]
000dff00  89542404  MOV dword ptr [ESP + 0x4],EDX
000dff04  890424  MOV dword ptr [ESP],EAX
000dff07  ff91c0010000  CALL dword ptr [ECX + 0x1c0]
000dff0d  8b06  MOV EAX,dword ptr [ESI]
000dff0f  ba04000000  MOV EDX,0x4
000dff14  8d8dbcfdffff  LEA ECX,[EBP + 0xfffffdbc]
000dff1a  898d8cfdffff  MOV dword ptr [EBP + 0xfffffd8c],ECX
000dff20  89ce  MOV ESI,ECX
000dff22  884432ff  MOV byte ptr [EDX + ESI*0x1 + -0x1],AL
000dff26  c1e808  SHR EAX,0x8
000dff29  83ea01  SUB EDX,0x1
000dff2c  7412  JZ 0x000dff40
000dff2e  8bb58cfdffff  MOV ESI,dword ptr [EBP + 0xfffffd8c]
000dff34  884432ff  MOV byte ptr [EDX + ESI*0x1 + -0x1],AL
000dff38  c1e808  SHR EAX,0x8
000dff3b  83ea01  SUB EDX,0x1
000dff3e  75ee  JNZ 0x000dff2e
000dff40  8b9590fdffff  MOV EDX,dword ptr [EBP + 0xfffffd90]
000dff46  8b4204  MOV EAX,dword ptr [EDX + 0x4]
000dff49  ba04000000  MOV EDX,0x4
000dff4e  8b8d8cfdffff  MOV ECX,dword ptr [EBP + 0xfffffd8c]
000dff54  88441103  MOV byte ptr [ECX + EDX*0x1 + 0x3],AL
000dff58  c1e808  SHR EAX,0x8
000dff5b  83ea01  SUB EDX,0x1
000dff5e  75ee  JNZ 0x000dff4e
000dff60  8bb590fdffff  MOV ESI,dword ptr [EBP + 0xfffffd90]
000dff66  8b4608  MOV EAX,dword ptr [ESI + 0x8]
000dff69  8b560c  MOV EDX,dword ptr [ESI + 0xc]
000dff6c  b908000000  MOV ECX,0x8
000dff71  8bb58cfdffff  MOV ESI,dword ptr [EBP + 0xfffffd8c]
000dff77  88440e07  MOV byte ptr [ESI + ECX*0x1 + 0x7],AL
000dff7b  0facd008  SHRD EAX,EDX,0x8
000dff7f  c1ea08  SHR EDX,0x8
000dff82  83e901  SUB ECX,0x1
000dff85  75ea  JNZ 0x000dff71
000dff87  8b8d90fdffff  MOV ECX,dword ptr [EBP + 0xfffffd90]
000dff8d  8b4110  MOV EAX,dword ptr [ECX + 0x10]
000dff90  8b5114  MOV EDX,dword ptr [ECX + 0x14]
000dff93  b908000000  MOV ECX,0x8
000dff98  8bb58cfdffff  MOV ESI,dword ptr [EBP + 0xfffffd8c]
000dff9e  88440e0f  MOV byte ptr [ESI + ECX*0x1 + 0xf],AL
000dffa2  0facd008  SHRD EAX,EDX,0x8
000dffa6  c1ea08  SHR EDX,0x8
000dffa9  83e901  SUB ECX,0x1
000dffac  75ea  JNZ 0x000dff98
000dffae  8b9590fdffff  MOV EDX,dword ptr [EBP + 0xfffffd90]
000dffb4  8b4218  MOV EAX,dword ptr [EDX + 0x18]
000dffb7  ba04000000  MOV EDX,0x4
000dffbc  8b8d8cfdffff  MOV ECX,dword ptr [EBP + 0xfffffd8c]
000dffc2  88441117  MOV byte ptr [ECX + EDX*0x1 + 0x17],AL
000dffc6  c1e808  SHR EAX,0x8
000dffc9  83ea01  SUB EDX,0x1
000dffcc  75ee  JNZ 0x000dffbc
000dffce  8bb590fdffff  MOV ESI,dword ptr [EBP + 0xfffffd90]
000dffd4  8b461c  MOV EAX,dword ptr [ESI + 0x1c]
000dffd7  ba04000000  MOV EDX,0x4
000dffdc  8b8d8cfdffff  MOV ECX,dword ptr [EBP + 0xfffffd8c]
000dffe2  8844111b  MOV byte ptr [ECX + EDX*0x1 + 0x1b],AL
000dffe6  c1e808  SHR EAX,0x8
000dffe9  83ea01  SUB EDX,0x1
000dffec  75ee  JNZ 0x000dffdc
000dffee  8bb590fdffff  MOV ESI,dword ptr [EBP + 0xfffffd90]
000dfff4  8b4620  MOV EAX,dword ptr [ESI + 0x20]
000dfff7  ba03000000  MOV EDX,0x3
000dfffc  8b8d8cfdffff  MOV ECX,dword ptr [EBP + 0xfffffd8c]
000e0002  88441120  MOV byte ptr [ECX + EDX*0x1 + 0x20],AL
000e0006  c1e808  SHR EAX,0x8
000e0009  83ea01  SUB EDX,0x1
000e000c  83faff  CMP EDX,-0x1
000e000f  75eb  JNZ 0x000dfffc
000e0011  8bb590fdffff  MOV ESI,dword ptr [EBP + 0xfffffd90]
000e0017  31ff  XOR EDI,EDI
000e0019  8b8d8cfdffff  MOV ECX,dword ptr [EBP + 0xfffffd8c]
000e001f  0fb75624  MOVZX EDX,word ptr [ESI + 0x24]
000e0023  89d0  MOV EAX,EDX
000e0025  66c1e808  SHR AX,0x8
000e0029  884124  MOV byte ptr [ECX + 0x24],AL
000e002c  885125  MOV byte ptr [ECX + 0x25],DL
000e002f  83c701  ADD EDI,0x1
000e0032  83c102  ADD ECX,0x2
000e0035  83c602  ADD ESI,0x2
000e0038  81ff00010000  CMP EDI,0x100
000e003e  75df  JNZ 0x000e001f
000e0040  8bb5a0fdffff  MOV ESI,dword ptr [EBP + 0xfffffda0]
000e0046  89742404  MOV dword ptr [ESP + 0x4],ESI
000e004a  8b85a4fdffff  MOV EAX,dword ptr [EBP + 0xfffffda4]
000e0050  890424  MOV dword ptr [ESP],EAX
000e0053  e8d0640c00  CALL 0x001a6528
000e0058  dd9598fdffff  FST qword ptr [EBP + 0xfffffd98]
000e005e  f20f108385492800  MOVSD XMM0,qword ptr [EBX + 0x284985]
000e0066  f20f108d98fdffff  MOVSD XMM1,qword ptr [EBP + 0xfffffd98]
000e006e  660f2ec8  UCOMISD XMM1,XMM0
000e0072  0f83d8000000  JNC 0x000e0150
000e0078  d9bdb6fdffff  FNSTCW word ptr [EBP + 0xfffffdb6]
000e007e  0fb785b6fdffff  MOVZX EAX,word ptr [EBP + 0xfffffdb6]
000e0085  b40c  MOV AH,0xc
000e0087  668985b4fdffff  MOV word ptr [EBP + 0xfffffdb4],AX
000e008e  d9adb4fdffff  FLDCW word ptr [EBP + 0xfffffdb4]
000e0094  dfbda8fdffff  FISTP qword ptr [EBP + 0xfffffda8]
000e009a  d9adb6fdffff  FLDCW word ptr [EBP + 0xfffffdb6]
000e00a0  8bb5a8fdffff  MOV ESI,dword ptr [EBP + 0xfffffda8]
000e00a6  8bbdacfdffff  MOV EDI,dword ptr [EBP + 0xfffffdac]
000e00ac  8b8590fdffff  MOV EAX,dword ptr [EBP + 0xfffffd90]
000e00b2  89b024020000  MOV dword ptr [EAX + 0x224],ESI
000e00b8  89b828020000  MOV dword ptr [EAX + 0x228],EDI
000e00be  b808000000  MOV EAX,0x8
000e00c3  89f2  MOV EDX,ESI
000e00c5  8b8d8cfdffff  MOV ECX,dword ptr [EBP + 0xfffffd8c]
000e00cb  88940123020000  MOV byte ptr [ECX + EAX*0x1 + 0x223],DL
000e00d2  0facfe08  SHRD ESI,EDI,0x8
000e00d6  c1ef08  SHR EDI,0x8
000e00d9  83e801  SUB EAX,0x1
000e00dc  75e5  JNZ 0x000e00c3
000e00de  8b85a4fdffff  MOV EAX,dword ptr [EBP + 0xfffffda4]
000e00e4  85c0  TEST EAX,EAX
000e00e6  740e  JZ 0x000e00f6
000e00e8  8bb5a4fdffff  MOV ESI,dword ptr [EBP + 0xfffffda4]
000e00ee  8b06  MOV EAX,dword ptr [ESI]
000e00f0  893424  MOV dword ptr [ESP],ESI
000e00f3  ff5044  CALL dword ptr [EAX + 0x44]
000e00f6  8b8d90fdffff  MOV ECX,dword ptr [EBP + 0xfffffd90]
000e00fc  8b812c020000  MOV EAX,dword ptr [ECX + 0x22c]
000e0102  8b9130020000  MOV EDX,dword ptr [ECX + 0x230]
000e0108  052c020000  ADD EAX,0x22c
000e010d  83d200  ADC EDX,0x0
000e0110  898134020000  MOV dword ptr [ECX + 0x234],EAX
000e0116  899138020000  MOV dword ptr [ECX + 0x238],EDX
000e011c  8bb594fdffff  MOV ESI,dword ptr [EBP + 0xfffffd94]
000e0122  8b4624  MOV EAX,dword ptr [ESI + 0x24]
000e0125  8b10  MOV EDX,dword ptr [EAX]
000e0127  c74424082c020000  MOV dword ptr [ESP + 0x8],0x22c
000e012f  8b8d8cfdffff  MOV ECX,dword ptr [EBP + 0xfffffd8c]
000e0135  894c2404  MOV dword ptr [ESP + 0x4],ECX
000e0139  890424  MOV dword ptr [ESP],EAX
000e013c  ff92b0010000  CALL dword ptr [EDX + 0x1b0]
000e0142  0fbec0  MOVSX EAX,AL
000e0145  81c48c020000  ADD ESP,0x28c
000e014b  5b  POP EBX
000e014c  5e  POP ESI
000e014d  5f  POP EDI
000e014e  5d  POP EBP
000e014f  c3  RET
000e0150  ddd8  FSTP ST0
000e0152  f20f5cc8  SUBSD XMM1,XMM0
000e0156  f20f118d98fdffff  MOVSD qword ptr [EBP + 0xfffffd98],XMM1
000e015e  d9bdb6fdffff  FNSTCW word ptr [EBP + 0xfffffdb6]
000e0164  0fb785b6fdffff  MOVZX EAX,word ptr [EBP + 0xfffffdb6]
000e016b  b40c  MOV AH,0xc
000e016d  668985b4fdffff  MOV word ptr [EBP + 0xfffffdb4],AX
000e0174  dd8598fdffff  FLD qword ptr [EBP + 0xfffffd98]
000e017a  d9adb4fdffff  FLDCW word ptr [EBP + 0xfffffdb4]
000e0180  dfbda8fdffff  FISTP qword ptr [EBP + 0xfffffda8]
000e0186  d9adb6fdffff  FLDCW word ptr [EBP + 0xfffffdb6]
000e018c  8bb5a8fdffff  MOV ESI,dword ptr [EBP + 0xfffffda8]
000e0192  8bbdacfdffff  MOV EDI,dword ptr [EBP + 0xfffffdac]
000e0198  8d9700000080  LEA EDX,[EDI + 0x80000000]
000e019e  89d7  MOV EDI,EDX
000e01a0  e907ffffff  JMP 0x000e00ac
000e01a5  8d8391ed1e00  LEA EAX,[EBX + 0x1eed91]
000e01ab  890424  MOV dword ptr [ESP],EAX
000e01ae  e87da7f2ff  CALL 0x0000a930
000e01b3  89c6  MOV ESI,EAX
000e01b5  8d83cd3b1e00  LEA EAX,[EBX + 0x1e3bcd]
000e01bb  890424  MOV dword ptr [ESP],EAX
000e01be  e8cd39f5ff  CALL 0x00033b90
000e01c3  8d9349ee1e00  LEA EDX,[EBX + 0x1eee49]
000e01c9  89542410  MOV dword ptr [ESP + 0x10],EDX
000e01cd  8974240c  MOV dword ptr [ESP + 0xc],ESI
000e01d1  c74424080d020000  MOV dword ptr [ESP + 0x8],0x20d
000e01d9  8d93013c1e00  LEA EDX,[EBX + 0x1e3c01]
000e01df  89542404  MOV dword ptr [ESP + 0x4],EDX
000e01e3  890424  MOV dword ptr [ESP],EAX
000e01e6  e8ebbdf2ff  CALL 0x0000bfd6
000e01eb  e9f9fcffff  JMP 0x000dfee9

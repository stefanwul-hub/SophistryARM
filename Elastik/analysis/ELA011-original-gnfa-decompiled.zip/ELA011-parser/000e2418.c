
undefined4 __regparm3 FUN_000e2418(int param_1,int *param_2,int param_3,undefined4 param_4)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  bool bVar7;
  uint uStack_2c;
  int iStack_28;
  uint uStack_10;
  
  iVar5 = *(int *)(param_3 + 0x14);
  if (iVar5 != 0) {
    iVar4 = *(int *)(param_1 + 0x14);
    iVar2 = iVar5 * 0x240;
    if (-1 < *(int *)(iVar2 + -0x234 + iVar4)) {
      bVar7 = false;
      uStack_2c = *(uint *)(iVar2 + -0x238 + iVar4);
      iStack_28 = *(int *)(iVar2 + -0x234 + iVar4);
      if (iStack_28 < 0) {
        uStack_2c = 0;
        iStack_28 = 0;
      }
      iVar2 = 0;
      goto LAB_000e2475;
    }
  }
  bVar7 = true;
  iVar2 = FUN_000e1b04(0);
  uStack_2c = 0;
  iStack_28 = 0;
  iVar5 = *(int *)(param_3 + 0x14);
  iVar4 = *(int *)(param_1 + 0x14);
LAB_000e2475:
  if (bVar7) {
    if (iVar2 != 0) {
      for (uVar6 = 0; uVar3 = FUN_00029ddc(iVar2), uVar6 < uVar3; uVar6 = uVar6 + 1) {
        FUN_0002a364(iVar2,uVar6);
        cVar1 = FUN_000e2418(param_4);
        if (cVar1 == '\0') {
          return 0;
        }
      }
    }
  }
  else {
    (**(code **)(**(int **)(param_1 + 0x24) + 0x1c0))
              (*(int **)(param_1 + 0x24),*(undefined4 *)(iVar5 * 0x240 + iVar4 + -0xc));
    if ((iStack_28 != 0) || (0x400 < uStack_2c)) {
      do {
        uStack_10 = 0x400;
        cVar1 = (**(code **)(**(int **)(param_1 + 0x24) + 0x1ac))
                          (*(int **)(param_1 + 0x24),param_4,&uStack_10);
        if (cVar1 == '\0') {
          return 0;
        }
        if (uStack_10 != 0x400) {
          return 0;
        }
        cVar1 = (**(code **)(*param_2 + 0x1b0))(param_2,param_4,0x400);
        if (cVar1 == '\0') {
          return 0;
        }
        bVar7 = 0x3ff < uStack_2c;
        uStack_2c = uStack_2c - 0x400;
        iStack_28 = iStack_28 + -1 + (uint)bVar7;
      } while ((iStack_28 != 0) || (0x400 < uStack_2c));
    }
    uStack_10 = uStack_2c;
    cVar1 = (**(code **)(**(int **)(param_1 + 0x24) + 0x1ac))
                      (*(int **)(param_1 + 0x24),param_4,&uStack_10);
    if ((cVar1 == '\0') ||
       ((uStack_2c != uStack_10 ||
        (cVar1 = (**(code **)(*param_2 + 0x1b0))(param_2,param_4,uStack_2c), cVar1 == '\0')))) {
      return 0;
    }
  }
  return 1;
}


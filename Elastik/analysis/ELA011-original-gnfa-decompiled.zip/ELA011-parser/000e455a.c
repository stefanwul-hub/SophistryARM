
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000e455a(int param_1)

{
  char cVar1;
  int iVar2;
  short sVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iStack_24;
  int iStack_20;
  
  iStack_24 = param_1;
  if (*(int *)(param_1 + 0x2c) == 0) {
    if (param_1 == 0) {
      uVar4 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                             );
      uVar5 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x609,uVar4,"this != 0");
    }
    if (*(int *)(param_1 + 0xc) == 0) {
      if (*(short *)(param_1 + 0x10) == 0) {
        uVar4 = func_0x0000a930(
                               "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                               );
        uVar5 = FUN_00033b90("GNAssertionException");
        FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x61b,uVar4,"_private");
      }
      sVar3 = _FSSetForkPosition((int)*(short *)(param_1 + 0x10),2,0,0);
      if ((sVar3 != 0) ||
         (sVar3 = _FSGetForkPosition((int)*(short *)(param_1 + 0x10),&iStack_24), sVar3 != 0)) {
        return 0;
      }
    }
    else {
      iStack_24 = *(int *)(param_1 + 0x20);
      *(int *)(param_1 + 0x1c) = iStack_24;
    }
    return iStack_24;
  }
  if (*(int *)(*(int *)(*(int *)(param_1 + 0x28) + 0x10) + 0x24) == 0) {
    iStack_20 = 0;
  }
  else {
    FUN_000df8d2(*(int *)(param_1 + 0x28));
    iVar6 = *(int *)(iStack_24 + 0x28);
    if (*(int *)(iVar6 + 0x18) != 0) {
      uVar4 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                             );
      uVar5 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x630,uVar4,
                   "_fileArchiveFilePath->_posixPath == 0");
      iVar6 = *(int *)(iStack_24 + 0x28);
    }
    iVar6 = *(int *)(iVar6 + 0x14) * 0x240 + *(int *)(*(int *)(iVar6 + 0x10) + 0x14);
    iStack_20 = iVar6 + -0x240;
    if (iStack_20 != 0) {
      iVar2 = *(int *)(iVar6 + -0x238);
      uVar4 = *(undefined4 *)(iVar6 + -0x234);
      *(int *)(iStack_24 + 0x30) = iVar2;
      *(undefined4 *)(iStack_24 + 0x34) = uVar4;
      cVar1 = *(char *)(iStack_24 + 0x38);
      goto joined_r0x000e468a;
    }
  }
  uVar4 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                         );
  uVar5 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x5fd,uVar4,"desc != 0");
  iVar2 = *(int *)(iStack_20 + 8);
  uVar4 = *(undefined4 *)(iStack_20 + 0xc);
  *(int *)(iStack_24 + 0x30) = iVar2;
  *(undefined4 *)(iStack_24 + 0x34) = uVar4;
  cVar1 = *(char *)(iStack_24 + 0x38);
joined_r0x000e468a:
  if (cVar1 == '\0') {
    (**(code **)(**(int **)(iStack_24 + 0x2c) + 0x1c0))
              (*(int **)(iStack_24 + 0x2c),iVar2 + *(int *)(iStack_20 + 0x234));
    return *(int *)(iStack_24 + 0x30);
  }
  return *(int *)(iStack_24 + 0x30);
}


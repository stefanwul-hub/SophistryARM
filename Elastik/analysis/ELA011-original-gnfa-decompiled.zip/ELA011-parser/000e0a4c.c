
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void __regparm3 FUN_000e0a4c(int param_1)

{
  short *psVar1;
  byte *pbVar2;
  int *piVar3;
  char cVar4;
  undefined4 uVar5;
  uint uVar6;
  uint *puVar7;
  int iVar8;
  uint uVar9;
  uint *puVar10;
  byte *pbVar11;
  byte *pbVar12;
  byte *pbVar13;
  byte *pbVar14;
  undefined1 uVar15;
  uint uStack_28c;
  uint uStack_288;
  uint uStack_280;
  int iStack_270;
  byte abStack_265 [5];
  byte abStack_260 [4];
  byte abStack_25c [4];
  byte abStack_258 [4];
  byte abStack_254 [8];
  byte abStack_24c [4];
  byte abStack_248 [4];
  byte abStack_244 [4];
  byte abStack_240 [512];
  byte abStack_40 [28];
  int iStack_24;
  int aiStack_20 [4];
  
  piVar3 = *(int **)(param_1 + 0x24);
  aiStack_20[0] = 0x14;
  (**(code **)(*piVar3 + 0x1c0))(piVar3,0);
  pbVar2 = abStack_265 + 1;
  cVar4 = (**(code **)(*piVar3 + 0x1ac))(piVar3,pbVar2,aiStack_20);
  uVar15 = cVar4 == '\0';
  if (((bool)uVar15) || (uVar15 = aiStack_20[0] == 0x14, !(bool)uVar15)) {
    uVar5 = FUN_00033b90("GNFileArchiveFormatNotSupportedException");
    FUN_0000bf34(uVar5);
  }
  iVar8 = 4;
  pbVar11 = (byte *)"GNFA";
  pbVar13 = pbVar2;
  do {
    pbVar12 = pbVar11;
    pbVar14 = pbVar13;
    if (iVar8 == 0) break;
    iVar8 = iVar8 + -1;
    pbVar14 = pbVar13 + 1;
    pbVar12 = pbVar11 + 1;
    uVar15 = *pbVar11 == *pbVar13;
    pbVar11 = pbVar12;
    pbVar13 = pbVar14;
  } while ((bool)uVar15);
  iVar8 = 0;
  if (!(bool)uVar15) {
    iVar8 = (uint)pbVar12[-1] - (uint)pbVar14[-1];
  }
  if (iVar8 != 0) {
    uVar5 = FUN_00033b90("GNFileArchiveFormatNotSupportedException");
    FUN_0000bf34(uVar5);
  }
  *(undefined4 *)(param_1 + 4) = 0;
  iVar8 = 0;
  uVar6 = 0;
  do {
    uVar6 = uVar6 << 8 | (uint)abStack_260[iVar8];
    iVar8 = iVar8 + 1;
  } while (iVar8 != 4);
  *(uint *)(param_1 + 4) = uVar6;
  *(undefined4 *)(param_1 + 8) = 0;
  iVar8 = 0;
  uVar6 = 0;
  do {
    uVar6 = uVar6 << 8 | (uint)abStack_25c[iVar8];
    iVar8 = iVar8 + 1;
  } while (iVar8 != 4);
  *(uint *)(param_1 + 8) = uVar6;
  if (*(uint *)(param_1 + 4) < 0x14) {
    uVar5 = FUN_00033b90("GNFileArchiveFormatNotSupportedException");
    FUN_0000bf34(uVar5);
  }
  *(undefined4 *)(param_1 + 0xc) = 0;
  iVar8 = 0;
  uVar6 = 0;
  do {
    uVar6 = uVar6 << 8 | (uint)abStack_258[iVar8];
    iVar8 = iVar8 + 1;
  } while (iVar8 != 4);
  *(uint *)(param_1 + 0xc) = uVar6;
  *(undefined4 *)(param_1 + 0x10) = 0;
  iVar8 = 0;
  uVar6 = 0;
  do {
    uVar6 = uVar6 << 8 | (uint)abStack_254[iVar8];
    iVar8 = iVar8 + 1;
  } while (iVar8 != 4);
  *(uint *)(param_1 + 0x10) = uVar6;
  uStack_28c = *(uint *)(param_1 + 4);
  uStack_288 = 0;
  if (*(int *)(param_1 + 0x10) != 0) {
    aiStack_20[0] = *(int *)(param_1 + 0x10) * 0x240;
    uVar5 = FUN_0000aecc(aiStack_20[0]);
    *(undefined4 *)(param_1 + 0x14) = uVar5;
    _memset(uVar5,0,aiStack_20[0]);
  }
  if (*(int *)(param_1 + 0xc) != 0) {
    *(undefined1 *)(param_1 + 0x2c) = 1;
  }
  if (*(int *)(param_1 + 0x10) != 0) {
    uStack_280 = 0;
    iStack_270 = 0;
    do {
      (**(code **)(*piVar3 + 0x1c0))(piVar3,uStack_28c);
      puVar7 = (uint *)(iStack_270 + *(int *)(param_1 + 0x14));
      if ((*(uint *)(param_1 + 0x1c) <= uStack_288) &&
         ((*(uint *)(param_1 + 0x1c) < uStack_288 || (*(uint *)(param_1 + 0x18) < uStack_28c)))) {
        uVar5 = FUN_00033b90("GNFileArchiveFormatNotSupportedException");
        FUN_0000bf34(uVar5);
      }
      iStack_24 = 0x22c;
      cVar4 = (**(code **)(*piVar3 + 0x1ac))(piVar3,pbVar2,&iStack_24);
      if ((cVar4 == '\0') || (iStack_24 != 0x22c)) {
        uVar5 = FUN_00033b90("GNFileArchiveIsCorruptedException");
        FUN_0000bf34(uVar5);
      }
      puVar7[0x8b] = uStack_28c;
      puVar7[0x8c] = uStack_288;
      *puVar7 = 0;
      iVar8 = 1;
      do {
        *puVar7 = *puVar7 << 8 | (uint)pbVar2[iVar8 + -1];
        iVar8 = iVar8 + 1;
      } while (iVar8 != 5);
      puVar7[1] = 0;
      iVar8 = 0;
      uVar6 = 0;
      do {
        uVar6 = (uint)abStack_260[iVar8] | uVar6 << 8;
        puVar7[1] = uVar6;
        iVar8 = iVar8 + 1;
      } while (iVar8 != 4);
      puVar7[2] = 0;
      puVar7[3] = 0;
      iVar8 = 0;
      uVar6 = 0;
      uVar9 = 0;
      do {
        uVar9 = uVar9 << 8 | uVar6 >> 0x18;
        uVar6 = uVar6 << 8 | (uint)abStack_25c[iVar8];
        puVar7[2] = uVar6;
        puVar7[3] = uVar9;
        iVar8 = iVar8 + 1;
      } while (iVar8 != 8);
      puVar7[4] = 0;
      puVar7[5] = 0;
      iVar8 = 0;
      uVar6 = 0;
      uVar9 = 0;
      do {
        uVar9 = uVar9 << 8 | uVar6 >> 0x18;
        uVar6 = uVar6 << 8 | (uint)abStack_254[iVar8];
        puVar7[4] = uVar6;
        puVar7[5] = uVar9;
        iVar8 = iVar8 + 1;
      } while (iVar8 != 8);
      puVar7[6] = 0;
      iVar8 = 0;
      uVar6 = 0;
      do {
        uVar6 = (uint)abStack_24c[iVar8] | uVar6 << 8;
        puVar7[6] = uVar6;
        iVar8 = iVar8 + 1;
      } while (iVar8 != 4);
      puVar7[7] = 0;
      iVar8 = 0;
      uVar6 = 0;
      do {
        uVar6 = (uint)abStack_248[iVar8] | uVar6 << 8;
        puVar7[7] = uVar6;
        iVar8 = iVar8 + 1;
      } while (iVar8 != 4);
      puVar7[8] = 0;
      iVar8 = 0;
      uVar6 = 0;
      do {
        uVar6 = (uint)abStack_244[iVar8] | uVar6 << 8;
        puVar7[8] = uVar6;
        iVar8 = iVar8 + 1;
      } while (iVar8 != 4);
      iVar8 = 0;
      do {
        *(ushort *)(iVar8 + (int)(puVar7 + 9)) = CONCAT11(pbVar2[iVar8 + 0x24],pbVar2[iVar8 + 0x25])
        ;
        iVar8 = iVar8 + 2;
      } while (iVar8 != 0x200);
      iStack_24 = 0;
      if ((short)puVar7[9] != 0) {
        iStack_24 = 0;
        puVar10 = puVar7;
        do {
          iStack_24 = iStack_24 + 1;
          psVar1 = (short *)((int)puVar10 + 0x26);
          puVar10 = (uint *)((int)puVar10 + 2);
        } while (*psVar1 != 0);
        if (0 < iStack_24) {
          uVar5 = __Znwm(0x20);
          func_0x000332e2(uVar5);
          uVar6 = FUN_0002dfa6(uVar5);
          puVar7[0x8f] = uVar6;
          func_0x0003788a(uVar6,puVar7 + 9,iStack_24);
        }
      }
      puVar7[0x89] = 0;
      puVar7[0x8a] = 0;
      iVar8 = 0;
      uVar6 = 0;
      uVar9 = 0;
      do {
        uVar9 = uVar9 << 8 | uVar6 >> 0x18;
        uVar6 = uVar6 << 8 | (uint)abStack_40[iVar8];
        puVar7[0x89] = uVar6;
        puVar7[0x8a] = uVar9;
        iVar8 = iVar8 + 1;
      } while (iVar8 != 8);
      if (*(int *)(param_1 + 0xc) == 0) {
        uVar9 = *puVar7;
        puVar7[0x8d] = uStack_28c + uVar9;
        puVar7[0x8e] = uStack_288 + CARRY4(uStack_28c,uVar9);
        uVar6 = uVar9 + puVar7[4];
        uStack_288 = uStack_288 + puVar7[5] + (uint)CARRY4(uVar9,puVar7[4]) +
                     (uint)CARRY4(uStack_28c,uVar6);
      }
      else {
        puVar7[0x8d] = puVar7[4];
        puVar7[0x8e] = puVar7[5];
        uVar6 = *puVar7;
        uStack_288 = uStack_288 + CARRY4(uStack_28c,uVar6);
      }
      uStack_28c = uStack_28c + uVar6;
      uStack_280 = uStack_280 + 1;
      iStack_270 = iStack_270 + 0x240;
    } while (uStack_280 < *(uint *)(param_1 + 0x10));
  }
  return;
}


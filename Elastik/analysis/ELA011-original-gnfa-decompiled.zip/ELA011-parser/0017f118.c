
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0017f118(int param_1,int *param_2)

{
  int *piVar1;
  short sVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined2 uStack_21c;
  undefined1 auStack_21a [522];
  
  if (param_1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x229,uVar4,"this != 0");
  }
  if (param_2 == (int *)0x0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x229,uVar4,"filePath != 0");
  }
  iVar3 = func_0x00069274(param_2);
  if (iVar3 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x244,uVar4,
                 "hfsFilepath->getFSRefPtr()");
  }
  sVar2 = _FSGetDataForkName(&uStack_21c);
  if (sVar2 == 0) {
    uVar4 = func_0x00069274(param_2);
    sVar2 = _FSOpenFork(uVar4,uStack_21c,auStack_21a,3,param_1 + 0x10);
    if (sVar2 == 0) goto LAB_0017f1a2;
  }
  uVar4 = (**(code **)(*param_2 + 0x1c8))(param_2);
  uVar5 = FUN_00033b90("GNFileException");
  FUN_0000bfd6(uVar5,"Cannot open %@.",uVar4);
LAB_0017f1a2:
  _FSSetForkPosition((int)*(short *)(param_1 + 0x10),2,0,0);
  piVar1 = *(int **)(param_1 + 0x18);
  if (param_2 != piVar1) {
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(int **)(param_1 + 0x18) = param_2;
    if (param_2 != (int *)0x0) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
  }
  return;
}


000e0a4c  55  PUSH EBP
000e0a4d  89e5  MOV EBP,ESP
000e0a4f  57  PUSH EDI
000e0a50  56  PUSH ESI
000e0a51  53  PUSH EBX
000e0a52  81ecec020000  SUB ESP,0x2ec
000e0a58  e8bf452000  CALL 0x002e501c
000e0a5d  898570fdffff  MOV dword ptr [EBP + 0xfffffd70],EAX
000e0a63  8b4024  MOV EAX,dword ptr [EAX + 0x24]
000e0a66  898580fdffff  MOV dword ptr [EBP + 0xfffffd80],EAX
000e0a6c  c745e414000000  MOV dword ptr [EBP + -0x1c],0x14
000e0a73  89c2  MOV EDX,EAX
000e0a75  8b00  MOV EAX,dword ptr [EAX]
000e0a77  c744240400000000  MOV dword ptr [ESP + 0x4],0x0
000e0a7f  891424  MOV dword ptr [ESP],EDX
000e0a82  ff90c0010000  CALL dword ptr [EAX + 0x1c0]
000e0a88  8b8d80fdffff  MOV ECX,dword ptr [EBP + 0xfffffd80]
000e0a8e  8b11  MOV EDX,dword ptr [ECX]
000e0a90  8d45e4  LEA EAX,[EBP + -0x1c]
000e0a93  89442408  MOV dword ptr [ESP + 0x8],EAX
000e0a97  8db5a0fdffff  LEA ESI,[EBP + 0xfffffda0]
000e0a9d  89b550fdffff  MOV dword ptr [EBP + 0xfffffd50],ESI
000e0aa3  89742404  MOV dword ptr [ESP + 0x4],ESI
000e0aa7  890c24  MOV dword ptr [ESP],ECX
000e0aaa  ff92ac010000  CALL dword ptr [EDX + 0x1ac]
000e0ab0  84c0  TEST AL,AL
000e0ab2  7406  JZ 0x000e0aba
000e0ab4  837de414  CMP dword ptr [EBP + -0x1c],0x14
000e0ab8  7416  JZ 0x000e0ad0
000e0aba  8d839fe31e00  LEA EAX,[EBX + 0x1ee39f]
000e0ac0  890424  MOV dword ptr [ESP],EAX
000e0ac3  e8c830f5ff  CALL 0x00033b90
000e0ac8  890424  MOV dword ptr [ESP],EAX
000e0acb  e864b4f2ff  CALL 0x0000bf34
000e0ad0  b904000000  MOV ECX,0x4
000e0ad5  fc  CLD
000e0ad6  8dbbcbe31e00  LEA EDI,[EBX + 0x1ee3cb]
000e0adc  89fe  MOV ESI,EDI
000e0ade  8bbd50fdffff  MOV EDI,dword ptr [EBP + 0xfffffd50]
000e0ae4  f3a6  CMPSB.REPE ES:EDI,ESI
000e0ae6  b800000000  MOV EAX,0x0
000e0aeb  740a  JZ 0x000e0af7
000e0aed  0fb646ff  MOVZX EAX,byte ptr [ESI + -0x1]
000e0af1  0fb64fff  MOVZX ECX,byte ptr [EDI + -0x1]
000e0af5  29c8  SUB EAX,ECX
000e0af7  85c0  TEST EAX,EAX
000e0af9  7416  JZ 0x000e0b11
000e0afb  8d839fe31e00  LEA EAX,[EBX + 0x1ee39f]
000e0b01  890424  MOV dword ptr [ESP],EAX
000e0b04  e88730f5ff  CALL 0x00033b90
000e0b09  890424  MOV dword ptr [ESP],EAX
000e0b0c  e823b4f2ff  CALL 0x0000bf34
000e0b11  8bb570fdffff  MOV ESI,dword ptr [EBP + 0xfffffd70]
000e0b17  83c604  ADD ESI,0x4
000e0b1a  8b8d70fdffff  MOV ECX,dword ptr [EBP + 0xfffffd70]
000e0b20  c7410400000000  MOV dword ptr [ECX + 0x4],0x0
000e0b27  31c9  XOR ECX,ECX
000e0b29  31c0  XOR EAX,EAX
000e0b2b  8bbd50fdffff  MOV EDI,dword ptr [EBP + 0xfffffd50]
000e0b31  89c2  MOV EDX,EAX
000e0b33  c1e208  SHL EDX,0x8
000e0b36  0fb6440f04  MOVZX EAX,byte ptr [EDI + ECX*0x1 + 0x4]
000e0b3b  09c2  OR EDX,EAX
000e0b3d  89d0  MOV EAX,EDX
000e0b3f  83c101  ADD ECX,0x1
000e0b42  83f904  CMP ECX,0x4
000e0b45  75ea  JNZ 0x000e0b31
000e0b47  8916  MOV dword ptr [ESI],EDX
000e0b49  8bb570fdffff  MOV ESI,dword ptr [EBP + 0xfffffd70]
000e0b4f  83c608  ADD ESI,0x8
000e0b52  8b8570fdffff  MOV EAX,dword ptr [EBP + 0xfffffd70]
000e0b58  c7400800000000  MOV dword ptr [EAX + 0x8],0x0
000e0b5f  81e100ffffff  AND ECX,0xffffff00
000e0b65  31c0  XOR EAX,EAX
000e0b67  8bbd50fdffff  MOV EDI,dword ptr [EBP + 0xfffffd50]
000e0b6d  89c2  MOV EDX,EAX
000e0b6f  c1e208  SHL EDX,0x8
000e0b72  0fb6440f08  MOVZX EAX,byte ptr [EDI + ECX*0x1 + 0x8]
000e0b77  09c2  OR EDX,EAX
000e0b79  89d0  MOV EAX,EDX
000e0b7b  83c101  ADD ECX,0x1
000e0b7e  83f904  CMP ECX,0x4
000e0b81  75ea  JNZ 0x000e0b6d
000e0b83  8916  MOV dword ptr [ESI],EDX
000e0b85  8b8570fdffff  MOV EAX,dword ptr [EBP + 0xfffffd70]
000e0b8b  83780413  CMP dword ptr [EAX + 0x4],0x13
000e0b8f  7716  JA 0x000e0ba7
000e0b91  8d839fe31e00  LEA EAX,[EBX + 0x1ee39f]
000e0b97  890424  MOV dword ptr [ESP],EAX
000e0b9a  e8f12ff5ff  CALL 0x00033b90
000e0b9f  890424  MOV dword ptr [ESP],EAX
000e0ba2  e88db3f2ff  CALL 0x0000bf34
000e0ba7  8bb570fdffff  MOV ESI,dword ptr [EBP + 0xfffffd70]
000e0bad  83c60c  ADD ESI,0xc
000e0bb0  8b9570fdffff  MOV EDX,dword ptr [EBP + 0xfffffd70]
000e0bb6  c7420c00000000  MOV dword ptr [EDX + 0xc],0x0
000e0bbd  31c9  XOR ECX,ECX
000e0bbf  31c0  XOR EAX,EAX
000e0bc1  8bbd50fdffff  MOV EDI,dword ptr [EBP + 0xfffffd50]
000e0bc7  89c2  MOV EDX,EAX
000e0bc9  c1e208  SHL EDX,0x8
000e0bcc  0fb6440f0c  MOVZX EAX,byte ptr [EDI + ECX*0x1 + 0xc]
000e0bd1  09c2  OR EDX,EAX
000e0bd3  89d0  MOV EAX,EDX
000e0bd5  83c101  ADD ECX,0x1
000e0bd8  83f904  CMP ECX,0x4
000e0bdb  75ea  JNZ 0x000e0bc7
000e0bdd  8916  MOV dword ptr [ESI],EDX
000e0bdf  8bb570fdffff  MOV ESI,dword ptr [EBP + 0xfffffd70]
000e0be5  83c610  ADD ESI,0x10
000e0be8  8b8570fdffff  MOV EAX,dword ptr [EBP + 0xfffffd70]
000e0bee  c7401000000000  MOV dword ptr [EAX + 0x10],0x0
000e0bf5  81e100ffffff  AND ECX,0xffffff00
000e0bfb  31c0  XOR EAX,EAX
000e0bfd  8bbd50fdffff  MOV EDI,dword ptr [EBP + 0xfffffd50]
000e0c03  89c2  MOV EDX,EAX
000e0c05  c1e208  SHL EDX,0x8
000e0c08  0fb6440f10  MOVZX EAX,byte ptr [EDI + ECX*0x1 + 0x10]
000e0c0d  09c2  OR EDX,EAX
000e0c0f  89d0  MOV EAX,EDX
000e0c11  83c101  ADD ECX,0x1
000e0c14  83f904  CMP ECX,0x4
000e0c17  75ea  JNZ 0x000e0c03
000e0c19  8916  MOV dword ptr [ESI],EDX
000e0c1b  8b9570fdffff  MOV EDX,dword ptr [EBP + 0xfffffd70]
000e0c21  8b4204  MOV EAX,dword ptr [EDX + 0x4]
000e0c24  31d2  XOR EDX,EDX
000e0c26  898578fdffff  MOV dword ptr [EBP + 0xfffffd78],EAX
000e0c2c  89957cfdffff  MOV dword ptr [EBP + 0xfffffd7c],EDX
000e0c32  8b8d70fdffff  MOV ECX,dword ptr [EBP + 0xfffffd70]
000e0c38  8b4110  MOV EAX,dword ptr [ECX + 0x10]
000e0c3b  85c0  TEST EAX,EAX
000e0c3d  7431  JZ 0x000e0c70
000e0c3f  8d04c0  LEA EAX,[EAX + EAX*0x8]
000e0c42  c1e006  SHL EAX,0x6
000e0c45  8945e4  MOV dword ptr [EBP + -0x1c],EAX
000e0c48  890424  MOV dword ptr [ESP],EAX
000e0c4b  e87ca2f2ff  CALL 0x0000aecc
000e0c50  8bb570fdffff  MOV ESI,dword ptr [EBP + 0xfffffd70]
000e0c56  894614  MOV dword ptr [ESI + 0x14],EAX
000e0c59  8b55e4  MOV EDX,dword ptr [EBP + -0x1c]
000e0c5c  89542408  MOV dword ptr [ESP + 0x8],EDX
000e0c60  c744240400000000  MOV dword ptr [ESP + 0x4],0x0
000e0c68  890424  MOV dword ptr [ESP],EAX
000e0c6b  e812942f00  CALL 0x003da082
000e0c70  8bbd70fdffff  MOV EDI,dword ptr [EBP + 0xfffffd70]
000e0c76  8b470c  MOV EAX,dword ptr [EDI + 0xc]
000e0c79  85c0  TEST EAX,EAX
000e0c7b  7404  JZ 0x000e0c81
000e0c7d  c6472c01  MOV byte ptr [EDI + 0x2c],0x1
000e0c81  8b8570fdffff  MOV EAX,dword ptr [EBP + 0xfffffd70]
000e0c87  8b7810  MOV EDI,dword ptr [EAX + 0x10]
000e0c8a  85ff  TEST EDI,EDI
000e0c8c  750b  JNZ 0x000e0c99
000e0c8e  81c4ec020000  ADD ESP,0x2ec
000e0c94  5b  POP EBX
000e0c95  5e  POP ESI
000e0c96  5f  POP EDI
000e0c97  5d  POP EBP
000e0c98  c3  RET
000e0c99  c78584fdffff00000000  MOV dword ptr [EBP + 0xfffffd84],0x0
000e0ca3  c78594fdffff00000000  MOV dword ptr [EBP + 0xfffffd94],0x0
000e0cad  8d55e0  LEA EDX,[EBP + -0x20]
000e0cb0  899554fdffff  MOV dword ptr [EBP + 0xfffffd54],EDX
000e0cb6  8b8d80fdffff  MOV ECX,dword ptr [EBP + 0xfffffd80]
000e0cbc  8b01  MOV EAX,dword ptr [ECX]
000e0cbe  8bb578fdffff  MOV ESI,dword ptr [EBP + 0xfffffd78]
000e0cc4  89742404  MOV dword ptr [ESP + 0x4],ESI
000e0cc8  890c24  MOV dword ptr [ESP],ECX
000e0ccb  ff90c0010000  CALL dword ptr [EAX + 0x1c0]
000e0cd1  8b8594fdffff  MOV EAX,dword ptr [EBP + 0xfffffd94]
000e0cd7  8bbd70fdffff  MOV EDI,dword ptr [EBP + 0xfffffd70]
000e0cdd  034714  ADD EAX,dword ptr [EDI + 0x14]
000e0ce0  898574fdffff  MOV dword ptr [EBP + 0xfffffd74],EAX
000e0ce6  8b957cfdffff  MOV EDX,dword ptr [EBP + 0xfffffd7c]
000e0cec  3b571c  CMP EDX,dword ptr [EDI + 0x1c]
000e0cef  7223  JC 0x000e0d14
000e0cf1  770b  JA 0x000e0cfe
000e0cf3  8b8d78fdffff  MOV ECX,dword ptr [EBP + 0xfffffd78]
000e0cf9  3b4f18  CMP ECX,dword ptr [EDI + 0x18]
000e0cfc  7616  JBE 0x000e0d14
000e0cfe  8d839fe31e00  LEA EAX,[EBX + 0x1ee39f]
000e0d04  890424  MOV dword ptr [ESP],EAX
000e0d07  e8842ef5ff  CALL 0x00033b90
000e0d0c  890424  MOV dword ptr [ESP],EAX
000e0d0f  e820b2f2ff  CALL 0x0000bf34
000e0d14  c745e02c020000  MOV dword ptr [EBP + -0x20],0x22c
000e0d1b  8bb580fdffff  MOV ESI,dword ptr [EBP + 0xfffffd80]
000e0d21  8b06  MOV EAX,dword ptr [ESI]
000e0d23  8bbd54fdffff  MOV EDI,dword ptr [EBP + 0xfffffd54]
000e0d29  897c2408  MOV dword ptr [ESP + 0x8],EDI
000e0d2d  8b9550fdffff  MOV EDX,dword ptr [EBP + 0xfffffd50]
000e0d33  89542404  MOV dword ptr [ESP + 0x4],EDX
000e0d37  893424  MOV dword ptr [ESP],ESI
000e0d3a  ff90ac010000  CALL dword ptr [EAX + 0x1ac]
000e0d40  84c0  TEST AL,AL
000e0d42  7409  JZ 0x000e0d4d
000e0d44  817de02c020000  CMP dword ptr [EBP + -0x20],0x22c
000e0d4b  7416  JZ 0x000e0d63
000e0d4d  8d83d3e31e00  LEA EAX,[EBX + 0x1ee3d3]
000e0d53  890424  MOV dword ptr [ESP],EAX
000e0d56  e8352ef5ff  CALL 0x00033b90
000e0d5b  890424  MOV dword ptr [ESP],EAX
000e0d5e  e8d1b1f2ff  CALL 0x0000bf34
000e0d63  8bb578fdffff  MOV ESI,dword ptr [EBP + 0xfffffd78]
000e0d69  8bbd7cfdffff  MOV EDI,dword ptr [EBP + 0xfffffd7c]
000e0d6f  8b8574fdffff  MOV EAX,dword ptr [EBP + 0xfffffd74]
000e0d75  89b02c020000  MOV dword ptr [EAX + 0x22c],ESI
000e0d7b  89b830020000  MOV dword ptr [EAX + 0x230],EDI
000e0d81  c70000000000  MOV dword ptr [EAX],0x0
000e0d87  b901000000  MOV ECX,0x1
000e0d8c  8b9574fdffff  MOV EDX,dword ptr [EBP + 0xfffffd74]
000e0d92  8b02  MOV EAX,dword ptr [EDX]
000e0d94  c1e008  SHL EAX,0x8
000e0d97  8bb550fdffff  MOV ESI,dword ptr [EBP + 0xfffffd50]
000e0d9d  0fb65431ff  MOVZX EDX,byte ptr [ECX + ESI*0x1 + -0x1]
000e0da2  09d0  OR EAX,EDX
000e0da4  8bbd74fdffff  MOV EDI,dword ptr [EBP + 0xfffffd74]
000e0daa  8907  MOV dword ptr [EDI],EAX
000e0dac  83c101  ADD ECX,0x1
000e0daf  83f905  CMP ECX,0x5
000e0db2  75d8  JNZ 0x000e0d8c
000e0db4  89fe  MOV ESI,EDI
000e0db6  83c604  ADD ESI,0x4
000e0db9  c7470400000000  MOV dword ptr [EDI + 0x4],0x0
000e0dc0  81e100ffffff  AND ECX,0xffffff00
000e0dc6  31d2  XOR EDX,EDX
000e0dc8  c1e208  SHL EDX,0x8
000e0dcb  8bbd50fdffff  MOV EDI,dword ptr [EBP + 0xfffffd50]
000e0dd1  0fb6440f04  MOVZX EAX,byte ptr [EDI + ECX*0x1 + 0x4]
000e0dd6  09d0  OR EAX,EDX
000e0dd8  89c2  MOV EDX,EAX
000e0dda  8906  MOV dword ptr [ESI],EAX
000e0ddc  83c101  ADD ECX,0x1
000e0ddf  83f904  CMP ECX,0x4
000e0de2  75e4  JNZ 0x000e0dc8
000e0de4  8b8574fdffff  MOV EAX,dword ptr [EBP + 0xfffffd74]
000e0dea  83c008  ADD EAX,0x8
000e0ded  898588fdffff  MOV dword ptr [EBP + 0xfffffd88],EAX
000e0df3  8b9574fdffff  MOV EDX,dword ptr [EBP + 0xfffffd74]
000e0df9  c7420800000000  MOV dword ptr [EDX + 0x8],0x0
000e0e00  c7420c00000000  MOV dword ptr [EDX + 0xc],0x0
000e0e07  81e100ffffff  AND ECX,0xffffff00
000e0e0d  31c0  XOR EAX,EAX
000e0e0f  31d2  XOR EDX,EDX
000e0e11  0fa4c208  SHLD EDX,EAX,0x8
000e0e15  c1e008  SHL EAX,0x8
000e0e18  898568fdffff  MOV dword ptr [EBP + 0xfffffd68],EAX
000e0e1e  89956cfdffff  MOV dword ptr [EBP + 0xfffffd6c],EDX
000e0e24  8b8550fdffff  MOV EAX,dword ptr [EBP + 0xfffffd50]
000e0e2a  0fb6740808  MOVZX ESI,byte ptr [EAX + ECX*0x1 + 0x8]
000e0e2f  31ff  XOR EDI,EDI
000e0e31  8b8568fdffff  MOV EAX,dword ptr [EBP + 0xfffffd68]
000e0e37  09f0  OR EAX,ESI
000e0e39  8b956cfdffff  MOV EDX,dword ptr [EBP + 0xfffffd6c]
000e0e3f  09fa  OR EDX,EDI
000e0e41  8bb588fdffff  MOV ESI,dword ptr [EBP + 0xfffffd88]
000e0e47  8906  MOV dword ptr [ESI],EAX
000e0e49  895604  MOV dword ptr [ESI + 0x4],EDX
000e0e4c  83c101  ADD ECX,0x1
000e0e4f  83f908  CMP ECX,0x8
000e0e52  75bd  JNZ 0x000e0e11
000e0e54  8bbd74fdffff  MOV EDI,dword ptr [EBP + 0xfffffd74]
000e0e5a  83c710  ADD EDI,0x10
000e0e5d  89bd8cfdffff  MOV dword ptr [EBP + 0xfffffd8c],EDI
000e0e63  8b8574fdffff  MOV EAX,dword ptr [EBP + 0xfffffd74]
000e0e69  c7401000000000  MOV dword ptr [EAX + 0x10],0x0
000e0e70  c7401400000000  MOV dword ptr [EAX + 0x14],0x0
000e0e77  81e100ffffff  AND ECX,0xffffff00
000e0e7d  31c0  XOR EAX,EAX
000e0e7f  31d2  XOR EDX,EDX
000e0e81  0fa4c208  SHLD EDX,EAX,0x8
000e0e85  c1e008  SHL EAX,0x8
000e0e88  898560fdffff  MOV dword ptr [EBP + 0xfffffd60],EAX
000e0e8e  899564fdffff  MOV dword ptr [EBP + 0xfffffd64],EDX
000e0e94  8b9550fdffff  MOV EDX,dword ptr [EBP + 0xfffffd50]
000e0e9a  0fb6740a10  MOVZX ESI,byte ptr [EDX + ECX*0x1 + 0x10]
000e0e9f  31ff  XOR EDI,EDI
000e0ea1  8b8560fdffff  MOV EAX,dword ptr [EBP + 0xfffffd60]
000e0ea7  09f0  OR EAX,ESI
000e0ea9  8b9564fdffff  MOV EDX,dword ptr [EBP + 0xfffffd64]
000e0eaf  09fa  OR EDX,EDI
000e0eb1  8bb58cfdffff  MOV ESI,dword ptr [EBP + 0xfffffd8c]
000e0eb7  8906  MOV dword ptr [ESI],EAX
000e0eb9  895604  MOV dword ptr [ESI + 0x4],EDX
000e0ebc  83c101  ADD ECX,0x1
000e0ebf  83f908  CMP ECX,0x8
000e0ec2  75bd  JNZ 0x000e0e81
000e0ec4  8bb574fdffff  MOV ESI,dword ptr [EBP + 0xfffffd74]
000e0eca  83c618  ADD ESI,0x18
000e0ecd  8bbd74fdffff  MOV EDI,dword ptr [EBP + 0xfffffd74]
000e0ed3  c7471800000000  MOV dword ptr [EDI + 0x18],0x0
000e0eda  81e100ffffff  AND ECX,0xffffff00
000e0ee0  31d2  XOR EDX,EDX
000e0ee2  c1e208  SHL EDX,0x8
000e0ee5  8bbd50fdffff  MOV EDI,dword ptr [EBP + 0xfffffd50]
000e0eeb  0fb6440f18  MOVZX EAX,byte ptr [EDI + ECX*0x1 + 0x18]
000e0ef0  09d0  OR EAX,EDX
000e0ef2  89c2  MOV EDX,EAX
000e0ef4  8906  MOV dword ptr [ESI],EAX
000e0ef6  83c101  ADD ECX,0x1
000e0ef9  83f904  CMP ECX,0x4
000e0efc  75e4  JNZ 0x000e0ee2
000e0efe  8bb574fdffff  MOV ESI,dword ptr [EBP + 0xfffffd74]
000e0f04  83c61c  ADD ESI,0x1c
000e0f07  8b8574fdffff  MOV EAX,dword ptr [EBP + 0xfffffd74]
000e0f0d  c7401c00000000  MOV dword ptr [EAX + 0x1c],0x0
000e0f14  81e100ffffff  AND ECX,0xffffff00
000e0f1a  31d2  XOR EDX,EDX
000e0f1c  c1e208  SHL EDX,0x8
000e0f1f  8bbd50fdffff  MOV EDI,dword ptr [EBP + 0xfffffd50]
000e0f25  0fb6440f1c  MOVZX EAX,byte ptr [EDI + ECX*0x1 + 0x1c]
000e0f2a  09d0  OR EAX,EDX
000e0f2c  89c2  MOV EDX,EAX
000e0f2e  8906  MOV dword ptr [ESI],EAX
000e0f30  83c101  ADD ECX,0x1
000e0f33  83f904  CMP ECX,0x4
000e0f36  75e4  JNZ 0x000e0f1c
000e0f38  8bb574fdffff  MOV ESI,dword ptr [EBP + 0xfffffd74]
000e0f3e  83c620  ADD ESI,0x20
000e0f41  8b8574fdffff  MOV EAX,dword ptr [EBP + 0xfffffd74]
000e0f47  c7402000000000  MOV dword ptr [EAX + 0x20],0x0
000e0f4e  81e100ffffff  AND ECX,0xffffff00
000e0f54  31d2  XOR EDX,EDX
000e0f56  c1e208  SHL EDX,0x8
000e0f59  8bbd50fdffff  MOV EDI,dword ptr [EBP + 0xfffffd50]
000e0f5f  0fb6440f20  MOVZX EAX,byte ptr [EDI + ECX*0x1 + 0x20]
000e0f64  09d0  OR EAX,EDX
000e0f66  89c2  MOV EDX,EAX
000e0f68  8906  MOV dword ptr [ESI],EAX
000e0f6a  83c101  ADD ECX,0x1
000e0f6d  83f904  CMP ECX,0x4
000e0f70  75e4  JNZ 0x000e0f56
000e0f72  81e100ffffff  AND ECX,0xffffff00
000e0f78  8b8574fdffff  MOV EAX,dword ptr [EBP + 0xfffffd74]
000e0f7e  8d7024  LEA ESI,[EAX + 0x24]
000e0f81  8bbd50fdffff  MOV EDI,dword ptr [EBP + 0xfffffd50]
000e0f87  0fb6543924  MOVZX EDX,byte ptr [ECX + EDI*0x1 + 0x24]
000e0f8c  c1e208  SHL EDX,0x8
000e0f8f  0fb6443925  MOVZX EAX,byte ptr [ECX + EDI*0x1 + 0x25]
000e0f94  09d0  OR EAX,EDX
000e0f96  66890431  MOV word ptr [ECX + ESI*0x1],AX
000e0f9a  83c102  ADD ECX,0x2
000e0f9d  81f900020000  CMP ECX,0x200
000e0fa3  75dc  JNZ 0x000e0f81
000e0fa5  c745e000000000  MOV dword ptr [EBP + -0x20],0x0
000e0fac  8b8574fdffff  MOV EAX,dword ptr [EBP + 0xfffffd74]
000e0fb2  6683782400  CMP word ptr [EAX + 0x24],0x0
000e0fb7  0f8434010000  JZ 0x000e10f1
000e0fbd  89c2  MOV EDX,EAX
000e0fbf  6631c9  XOR CX,CX
000e0fc2  83c101  ADD ECX,0x1
000e0fc5  894de0  MOV dword ptr [EBP + -0x20],ECX
000e0fc8  0fb74226  MOVZX EAX,word ptr [EDX + 0x26]
000e0fcc  83c202  ADD EDX,0x2
000e0fcf  6685c0  TEST AX,AX
000e0fd2  75ee  JNZ 0x000e0fc2
000e0fd4  85c9  TEST ECX,ECX
000e0fd6  0f8e64010000  JLE 0x000e1140
000e0fdc  c7042420000000  MOV dword ptr [ESP],0x20
000e0fe3  e8bd902f00  CALL 0x003da0a5
000e0fe8  89c7  MOV EDI,EAX
000e0fea  890424  MOV dword ptr [ESP],EAX
000e0fed  e8f022f5ff  CALL 0x000332e2
000e0ff2  893c24  MOV dword ptr [ESP],EDI
000e0ff5  e8accff4ff  CALL 0x0002dfa6
000e0ffa  8b9574fdffff  MOV EDX,dword ptr [EBP + 0xfffffd74]
000e1000  89823c020000  MOV dword ptr [EDX + 0x23c],EAX
000e1006  8b55e0  MOV EDX,dword ptr [EBP + -0x20]
000e1009  89542408  MOV dword ptr [ESP + 0x8],EDX
000e100d  89742404  MOV dword ptr [ESP + 0x4],ESI
000e1011  890424  MOV dword ptr [ESP],EAX
000e1014  e87168f5ff  CALL 0x0003788a
000e1019  8b8d74fdffff  MOV ECX,dword ptr [EBP + 0xfffffd74]
000e101f  8bb574fdffff  MOV ESI,dword ptr [EBP + 0xfffffd74]
000e1025  81c124020000  ADD ECX,0x224
000e102b  898d90fdffff  MOV dword ptr [EBP + 0xfffffd90],ECX
000e1031  c7862402000000000000  MOV dword ptr [ESI + 0x224],0x0
000e103b  c7862802000000000000  MOV dword ptr [ESI + 0x228],0x0
000e1045  31c9  XOR ECX,ECX
000e1047  31c0  XOR EAX,EAX
000e1049  31d2  XOR EDX,EDX
000e104b  0fa4c208  SHLD EDX,EAX,0x8
000e104f  c1e008  SHL EAX,0x8
000e1052  898558fdffff  MOV dword ptr [EBP + 0xfffffd58],EAX
000e1058  89955cfdffff  MOV dword ptr [EBP + 0xfffffd5c],EDX
000e105e  8b8550fdffff  MOV EAX,dword ptr [EBP + 0xfffffd50]
000e1064  0fb6b40824020000  MOVZX ESI,byte ptr [EAX + ECX*0x1 + 0x224]
000e106c  31ff  XOR EDI,EDI
000e106e  8b8558fdffff  MOV EAX,dword ptr [EBP + 0xfffffd58]
000e1074  09f0  OR EAX,ESI
000e1076  8b955cfdffff  MOV EDX,dword ptr [EBP + 0xfffffd5c]
000e107c  09fa  OR EDX,EDI
000e107e  8bb590fdffff  MOV ESI,dword ptr [EBP + 0xfffffd90]
000e1084  8906  MOV dword ptr [ESI],EAX
000e1086  895604  MOV dword ptr [ESI + 0x4],EDX
000e1089  83c101  ADD ECX,0x1
000e108c  83f908  CMP ECX,0x8
000e108f  75ba  JNZ 0x000e104b
000e1091  8bbd70fdffff  MOV EDI,dword ptr [EBP + 0xfffffd70]
000e1097  8b470c  MOV EAX,dword ptr [EDI + 0xc]
000e109a  85c0  TEST EAX,EAX
000e109c  745c  JZ 0x000e10fa
000e109e  8b8d74fdffff  MOV ECX,dword ptr [EBP + 0xfffffd74]
000e10a4  8b4110  MOV EAX,dword ptr [ECX + 0x10]
000e10a7  8b5114  MOV EDX,dword ptr [ECX + 0x14]
000e10aa  898134020000  MOV dword ptr [ECX + 0x234],EAX
000e10b0  899138020000  MOV dword ptr [ECX + 0x238],EDX
000e10b6  8b01  MOV EAX,dword ptr [ECX]
000e10b8  31d2  XOR EDX,EDX
000e10ba  018578fdffff  ADD dword ptr [EBP + 0xfffffd78],EAX
000e10c0  11957cfdffff  ADC dword ptr [EBP + 0xfffffd7c],EDX
000e10c6  838584fdffff01  ADD dword ptr [EBP + 0xfffffd84],0x1
000e10cd  818594fdffff40020000  ADD dword ptr [EBP + 0xfffffd94],0x240
000e10d7  8b8584fdffff  MOV EAX,dword ptr [EBP + 0xfffffd84]
000e10dd  8bbd70fdffff  MOV EDI,dword ptr [EBP + 0xfffffd70]
000e10e3  3b4710  CMP EAX,dword ptr [EDI + 0x10]
000e10e6  0f82cafbffff  JC 0x000e0cb6
000e10ec  e99dfbffff  JMP 0x000e0c8e
000e10f1  89c1  MOV ECX,EAX
000e10f3  89c6  MOV ESI,EAX
000e10f5  e92bffffff  JMP 0x000e1025
000e10fa  8bb574fdffff  MOV ESI,dword ptr [EBP + 0xfffffd74]
000e1100  8b06  MOV EAX,dword ptr [ESI]
000e1102  31d2  XOR EDX,EDX
000e1104  8bb578fdffff  MOV ESI,dword ptr [EBP + 0xfffffd78]
000e110a  8bbd7cfdffff  MOV EDI,dword ptr [EBP + 0xfffffd7c]
000e1110  01c6  ADD ESI,EAX
000e1112  11d7  ADC EDI,EDX
000e1114  8b8d74fdffff  MOV ECX,dword ptr [EBP + 0xfffffd74]
000e111a  89b134020000  MOV dword ptr [ECX + 0x234],ESI
000e1120  89b938020000  MOV dword ptr [ECX + 0x238],EDI
000e1126  8bb574fdffff  MOV ESI,dword ptr [EBP + 0xfffffd74]
000e112c  034610  ADD EAX,dword ptr [ESI + 0x10]
000e112f  135614  ADC EDX,dword ptr [ESI + 0x14]
000e1132  018578fdffff  ADD dword ptr [EBP + 0xfffffd78],EAX
000e1138  11957cfdffff  ADC dword ptr [EBP + 0xfffffd7c],EDX
000e113e  eb86  JMP 0x000e10c6
000e1140  8b8d74fdffff  MOV ECX,dword ptr [EBP + 0xfffffd74]
000e1146  8bb574fdffff  MOV ESI,dword ptr [EBP + 0xfffffd74]
000e114c  e9d4feffff  JMP 0x000e1025

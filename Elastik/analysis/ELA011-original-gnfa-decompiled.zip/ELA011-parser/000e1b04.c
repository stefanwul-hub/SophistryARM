
undefined4 __regparm3 FUN_000e1b04(int param_1,int param_2,code *param_3,undefined4 param_4)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  
  uVar2 = __Znwm(0x20);
  FUN_00029d44(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  uVar2 = (**(code **)(*piVar3 + 0x48))(piVar3);
  if (*(int *)(param_1 + 0x10) != 0) {
    uVar6 = 0;
    iVar7 = 0;
    do {
      iVar5 = iVar7 + *(int *)(param_1 + 0x14);
      if (((*(int *)(iVar5 + 0xc) != 0 || *(int *)(iVar5 + 8) != 0) &&
          (*(int *)(iVar5 + 0x20) == param_2)) &&
         ((param_3 == (code *)0x0 || (cVar1 = (*param_3)(iVar5,param_4), cVar1 != '\0')))) {
        uVar4 = func_0x000e1a7a(param_1,uVar6 + 1);
        FUN_0002bb40(uVar2,uVar4);
      }
      iVar7 = iVar7 + 0x240;
      uVar6 = uVar6 + 1;
    } while (uVar6 < *(uint *)(param_1 + 0x10));
  }
  return uVar2;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0017e9be(int param_1,int *param_2)

{
  char cVar1;
  short sVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int *piVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  char *pcVar11;
  char *pcVar12;
  undefined2 uStack_21c;
  undefined1 auStack_21a [522];
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x121,uVar3,"this != 0");
  }
  if (param_2 == (int *)0x0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x121,uVar3,"filePath != 0");
  }
  uVar3 = func_0x0006a14a(param_2);
  uVar4 = func_0x0006a17a(param_2);
  iVar5 = func_0x00069274(param_2);
  if ((iVar5 != 0) && (cVar1 = (**(code **)(*param_2 + 0x21c))(param_2), cVar1 == '\0')) {
    iVar5 = (**(code **)(*param_2 + 0x1bc))(param_2);
    if (iVar5 == 0) {
      pcVar11 = "";
    }
    else {
      uVar3 = (**(code **)(*param_2 + 0x1bc))(param_2);
      pcVar11 = (char *)FUN_00034962(uVar3);
    }
    pcVar12 = "HFS: Cannot delete file %s";
    goto LAB_0017ed90;
  }
  iVar5 = (**(code **)(*param_2 + 0x204))(param_2);
  if ((iVar5 == 0) || (iVar6 = (**(code **)(*param_2 + 0x1bc))(param_2), iVar6 == 0)) {
    uVar7 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar9 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar9,"Assertion failed in line %d of %s: %s.",0x14f,uVar7,
                 "hfsParent && hfsFilepath->getPosixPath()");
  }
  uVar7 = __Znwm(0x20);
  func_0x000332e2(uVar7);
  piVar8 = (int *)FUN_0002dfa6(uVar7);
  uVar7 = (**(code **)(*param_2 + 0x1bc))(param_2);
  uVar7 = func_0x0003a99a(uVar7);
  func_0x0003c4d8(piVar8,uVar7);
  func_0x00035256(piVar8,0x3a,0x2f);
  if (piVar8 == (int *)0x0) {
    uVar7 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar9 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar9,"Assertion failed in line %d of %s: %s.",0x156,uVar7,"name");
  }
  iVar6 = FUN_000349f4(piVar8);
  if (iVar6 < 1) {
    uVar7 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar9 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar9,"Assertion failed in line %d of %s: %s.",0x157,uVar7,"name->getLength() > 0")
    ;
  }
  iVar6 = func_0x00036896(piVar8);
  if (iVar6 == 0) {
    uVar7 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar9 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar9,"Assertion failed in line %d of %s: %s.",0x158,uVar7,
                 "name->getCharactersPtr()");
  }
  uVar7 = func_0x00036896(piVar8);
  uVar9 = FUN_000349f4(piVar8);
  uVar10 = func_0x00069274(iVar5);
  sVar2 = _FSCreateFileUnicode(uVar10,uVar9,uVar7,0,0,0,0);
  if (piVar8 != (int *)0x0) {
    (**(code **)(*piVar8 + 0x44))(piVar8);
  }
  if (sVar2 != 0) {
    iVar5 = (**(code **)(*param_2 + 0x1bc))(param_2);
    if (iVar5 == 0) {
      pcVar11 = "";
    }
    else {
      uVar7 = (**(code **)(*param_2 + 0x1bc))(param_2);
      pcVar11 = (char *)FUN_00034962(uVar7);
    }
    FUN_0000ab14("HFS: Cannot create spec %s (%i)",pcVar11,(int)sVar2);
    uVar7 = (**(code **)(*param_2 + 0x1c8))(param_2);
    uVar9 = FUN_00033b90("GNFileException");
    FUN_0000bfd6(uVar9,"Cannot open %@.",uVar7);
  }
  iVar5 = func_0x00069274(param_2);
  if (iVar5 == 0) {
    uVar7 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar9 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar9,"Assertion failed in line %d of %s: %s.",0x1ac,uVar7,
                 "hfsFilepath->getFSRefPtr()");
  }
  uVar7 = func_0x00069274(param_2);
  sVar2 = func_0x001b3120(uVar7,uVar3,uVar4);
  if ((sVar2 == 0) && (sVar2 = _FSGetDataForkName(&uStack_21c), sVar2 == 0)) {
    uVar3 = func_0x00069274(param_2);
    sVar2 = _FSOpenFork(uVar3,uStack_21c,auStack_21a,3,param_1 + 0x10);
    if (sVar2 != 0) goto LAB_0017ebc6;
  }
  else {
LAB_0017ebc6:
    iVar5 = (**(code **)(*param_2 + 0x1bc))(param_2);
    if (iVar5 == 0) {
      pcVar11 = "";
    }
    else {
      uVar3 = (**(code **)(*param_2 + 0x1bc))(param_2);
      pcVar11 = (char *)FUN_00034962(uVar3);
    }
    FUN_0000ab14("HFS: Cannot open data fork %s (%i)",pcVar11,(int)sVar2);
    uVar3 = (**(code **)(*param_2 + 0x1c8))(param_2);
    uVar4 = FUN_00033b90("GNFileException");
    FUN_0000bfd6(uVar4,"Cannot open %@.",uVar3);
  }
  sVar2 = _FSSetForkSize((int)*(short *)(param_1 + 0x10),1,0,0);
  if (sVar2 == 0) {
    piVar8 = *(int **)(param_1 + 0x18);
    if (param_2 != piVar8) {
      if (piVar8 != (int *)0x0) {
        (**(code **)(*piVar8 + 0x44))(piVar8);
      }
      *(int **)(param_1 + 0x18) = param_2;
      (**(code **)(*param_2 + 0x40))(param_2);
    }
    return;
  }
  iVar5 = (**(code **)(*param_2 + 0x1bc))(param_2);
  if (iVar5 == 0) {
    pcVar11 = "";
  }
  else {
    uVar3 = (**(code **)(*param_2 + 0x1bc))(param_2);
    pcVar11 = (char *)FUN_00034962(uVar3);
  }
  pcVar12 = "HFS: Cannot open set EOF %s (%i)";
LAB_0017ed90:
  FUN_0000ab14(pcVar12,pcVar11);
  uVar3 = (**(code **)(*param_2 + 0x1c8))(param_2);
  uVar4 = FUN_00033b90("GNFileException");
  FUN_0000bfd6(uVar4,"Cannot open %@.",uVar3);
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_00028308(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  
  if (param_1 < 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNData.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x30,uVar3,"byteSize >= 0");
  }
  puVar1 = (undefined4 *)__Znwm(0x20);
  func_0x0002dc66(puVar1);
  *puVar1 = &UNK_0036e728;
  puVar1[3] = 0;
  puVar1[4] = 0;
  *(undefined1 *)(puVar1 + 5) = 0;
  *(undefined1 *)((int)puVar1 + 0x15) = 0;
  *(undefined1 *)((int)puVar1 + 0x16) = 1;
  puVar1[7] = 0;
  puVar1[6] = 0;
  piVar2 = (int *)FUN_0002dfa6(puVar1);
  piVar2 = (int *)(**(code **)(*piVar2 + 0x48))(piVar2);
  (**(code **)(*piVar2 + 0x1a4))(piVar2,param_1);
  FUN_00027b4e(piVar2);
  iVar5 = piVar2[6];
  if (iVar5 == 0) {
    if (piVar2[3] == 0) {
      FUN_0000ab14("GNData::bytes(). Data object doesn\'t have alloced memory yet.");
      iVar5 = 0;
    }
    else {
      iVar5 = **(int **)(piVar2[3] + 0xc);
    }
  }
  _memset(iVar5,0,param_1);
  if ((piVar2[6] == 0) && (piVar2[3] != 0)) {
    func_0x0000ad7c(piVar2[3]);
    return piVar2;
  }
  return piVar2;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 __regparm3 FUN_000e063c(int param_1,uint param_2)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int aiStack_20 [4];
  
  piVar5 = *(int **)(param_1 + 0x24);
  if ((param_2 == 0) || (*(uint *)(param_1 + 0x10) < param_2)) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x377,uVar3,
                 "fileNumber > 0 && fileNumber <= fileArchive->_header._countOfEntries");
    if (param_2 != 0) goto LAB_000e082b;
  }
  else {
LAB_000e082b:
    param_2 = param_2 * 0x240;
    iVar6 = *(int *)(*(int *)(param_1 + 0x14) + -0x234 + param_2);
    if ((-1 < iVar6) &&
       ((0 < iVar6 || (*(int *)(*(int *)(param_1 + 0x14) + -0x238 + param_2) != 0))))
    goto LAB_000e06f9;
  }
  uVar3 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                         );
  uVar4 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x379,uVar3,
               "::isFile(fileArchive, fileNumber) == YES");
LAB_000e06f9:
  iVar6 = param_2 + *(int *)(param_1 + 0x14);
  if (*(int *)(iVar6 + -0x234) == 0 && *(int *)(iVar6 + -0x238) == 0) {
    uVar3 = __Znwm(0x20);
    FUN_0002765e(uVar3);
    piVar5 = (int *)FUN_0002dfa6(uVar3);
    uVar3 = (**(code **)(*piVar5 + 0x48))(piVar5);
    return uVar3;
  }
  uVar3 = FUN_00028308(*(int *)(iVar6 + -0x238));
  (**(code **)(*piVar5 + 0x1c0))(piVar5,*(undefined4 *)(iVar6 + -0xc));
  aiStack_20[0] = *(int *)(iVar6 + -0x238);
  FUN_00027b4e(uVar3);
  pcVar1 = *(code **)(*piVar5 + 0x1ac);
  uVar4 = FUN_00027abc(uVar3);
  cVar2 = (*pcVar1)(piVar5,uVar4,aiStack_20);
  if ((cVar2 == '\0') ||
     (*(int *)(iVar6 + -0x234) != aiStack_20[0] >> 0x1f || aiStack_20[0] != *(int *)(iVar6 + -0x238)
     )) {
    uVar4 = FUN_00033b90("GNFileArchiveCannotReadArchiveException");
    FUN_0000bf34(uVar4);
    FUN_00027bec(uVar3);
  }
  FUN_00027bec(uVar3);
  piVar5 = *(int **)(*(int *)(param_1 + 0x28) + 0x10);
  if (piVar5 == (int *)0x0) {
    return uVar3;
  }
  uVar3 = (**(code **)(*piVar5 + 4))
                    (piVar5,uVar3,*(undefined4 *)(iVar6 + -4),*(undefined4 *)(iVar6 + -0x224),
                     *(undefined4 *)(iVar6 + -0x228));
  return uVar3;
}


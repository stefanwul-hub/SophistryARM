
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000e1164(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  undefined4 uStack_30;
  undefined1 auStack_2c [28];
  
  if (*(int *)(param_1 + 0xc) != 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x509,uVar3,"_file == 0");
  }
  iVar5 = (**(code **)(*param_2 + 0x1d8))(param_2);
  *(undefined1 *)(*(int *)(param_1 + 0x14) + 0x2c) = 0;
  if (iVar5 < 1) {
    iVar5 = *(int *)(param_1 + 0x14);
    *(undefined4 *)(iVar5 + 0x18) = 0;
    *(undefined4 *)(iVar5 + 0x1c) = 0;
  }
  else {
    iVar7 = *(int *)(param_1 + 0x14);
    *(int *)(iVar7 + 0x18) = iVar5;
    *(int *)(iVar7 + 0x1c) = iVar5 >> 0x1f;
  }
  uVar3 = __Znwm(0x24);
  FUN_0017e50c(uVar3);
  uVar3 = FUN_0002dfa6(uVar3);
  *(undefined4 *)(param_1 + 0xc) = uVar3;
  cVar2 = (**(code **)(*param_2 + 0x1d4))(param_2);
  if (cVar2 != '\0') {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x515,uVar3,
                 "filePath->isDirectory() == NO");
  }
  cVar2 = (**(code **)(*param_2 + 0x1d0))(param_2);
  if (cVar2 == '\0') {
    FUN_0017e9be(*(undefined4 *)(param_1 + 0xc),param_2);
  }
  else {
    FUN_0017f118(*(undefined4 *)(param_1 + 0xc),param_2);
  }
  (**(code **)(**(int **)(param_1 + 0xc) + 0x1c0))(*(int **)(param_1 + 0xc),0);
  *(undefined4 *)(*(int *)(param_1 + 0x14) + 0x24) = *(undefined4 *)(param_1 + 0xc);
  iVar5 = *(int *)(param_1 + 0x14);
  if (*(int *)(iVar5 + 0x1c) != 0 || *(int *)(iVar5 + 0x18) != 0) {
    FUN_000e0a4c();
    return;
  }
  *(undefined4 *)(iVar5 + 0x18) = 0x14;
  *(undefined4 *)(iVar5 + 0x1c) = 0;
  *(undefined4 *)(*(int *)(param_1 + 0x14) + 4) = 0x14;
  *(undefined4 *)(*(int *)(param_1 + 0x14) + 0x10) = 0;
  *(undefined4 *)(*(int *)(param_1 + 0x14) + 8) = 0;
  iVar5 = *(int *)(param_1 + 0x14);
  piVar1 = *(int **)(iVar5 + 0x24);
  uStack_30 = 0x41464e47;
  (**(code **)(*piVar1 + 0x1c0))(piVar1,0);
  uVar6 = *(uint *)(iVar5 + 4);
  iVar7 = 4;
  do {
    auStack_2c[iVar7 + -1] = (char)uVar6;
    uVar6 = uVar6 >> 8;
    iVar7 = iVar7 + -1;
  } while (iVar7 != 0);
  uVar6 = *(uint *)(iVar5 + 8);
  iVar7 = 4;
  do {
    auStack_2c[iVar7 + 3] = (char)uVar6;
    uVar6 = uVar6 >> 8;
    iVar7 = iVar7 + -1;
  } while (iVar7 != 0);
  iVar7 = 4;
  do {
    auStack_2c[iVar7 + 7] = 0;
    iVar7 = iVar7 + -1;
  } while (iVar7 != 0);
  uVar6 = *(uint *)(iVar5 + 0x10);
  iVar5 = 4;
  do {
    auStack_2c[iVar5 + 0xb] = (char)uVar6;
    uVar6 = uVar6 >> 8;
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  (**(code **)(*piVar1 + 0x1b0))(piVar1,&uStack_30,0x14);
  return;
}



undefined4 __regparm3
FUN_000e2102(int param_1,int *param_2,int param_3,int *param_4,uint param_5,uint *param_6,
            int param_7)

{
  undefined2 uVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uStack_1c;
  uint uStack_18;
  int iStack_14;
  
  iVar5 = *(int *)(param_3 + 0x14);
  if (iVar5 == 0) {
    iStack_14 = FUN_000e1b04(0);
  }
  else {
    iVar6 = *(int *)(param_1 + 0x14);
    iVar4 = iVar5 * 0x240;
    if (-1 < *(int *)(iVar4 + -0x234 + iVar6)) {
      bVar2 = false;
      uStack_1c = *(uint *)(iVar4 + -0x238 + iVar6);
      uStack_18 = *(uint *)(iVar4 + -0x234 + iVar6);
      if ((int)uStack_18 < 0) {
        uStack_1c = 0;
        uStack_18 = 0;
      }
      iStack_14 = 0;
      goto LAB_000e2189;
    }
    iStack_14 = FUN_000e1b04(0);
  }
  if (iStack_14 == 0) {
    bVar2 = true;
    uStack_1c = 0;
    uStack_18 = 0x80000000;
    iVar5 = *(int *)(param_3 + 0x14);
    iVar6 = *(int *)(param_1 + 0x14);
  }
  else {
    bVar2 = true;
    uStack_1c = FUN_00029ddc(iStack_14);
    uStack_18 = (int)uStack_1c >> 0x1f | 0x80000000;
    iVar5 = *(int *)(param_3 + 0x14);
    iVar6 = *(int *)(param_1 + 0x14);
  }
LAB_000e2189:
  iVar6 = iVar5 * 0x240 + -0x240 + iVar6;
  uVar7 = 0x22c;
  iVar5 = 4;
  do {
    *(char *)(param_7 + -1 + iVar5) = (char)uVar7;
    uVar7 = uVar7 >> 8;
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  iVar5 = 4;
  do {
    *(undefined1 *)(param_7 + 3 + iVar5) = 0;
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  iVar5 = 8;
  uVar7 = uStack_1c;
  uVar8 = uStack_18;
  do {
    *(char *)(param_7 + 7 + iVar5) = (char)uVar7;
    uVar7 = uVar7 >> 8 | uVar8 << 0x18;
    uVar8 = uVar8 >> 8;
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  if (bVar2) {
    iVar5 = 8;
    do {
      *(undefined1 *)(param_7 + 0xf + iVar5) = 0;
      iVar5 = iVar5 + -1;
    } while (iVar5 != 0);
  }
  else {
    uVar7 = *param_6;
    uVar8 = param_6[1];
    iVar5 = 8;
    do {
      *(char *)(param_7 + 0xf + iVar5) = (char)uVar7;
      uVar7 = uVar7 >> 8 | uVar8 << 0x18;
      uVar8 = uVar8 >> 8;
      iVar5 = iVar5 + -1;
    } while (iVar5 != 0);
  }
  uVar7 = *(uint *)(iVar6 + 0x18);
  iVar5 = 4;
  do {
    *(char *)(param_7 + 0x17 + iVar5) = (char)uVar7;
    uVar7 = uVar7 >> 8;
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  uVar7 = *(uint *)(iVar6 + 0x1c);
  iVar5 = 4;
  do {
    *(char *)(param_7 + 0x1b + iVar5) = (char)uVar7;
    uVar7 = uVar7 >> 8;
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  iVar5 = 4;
  do {
    *(char *)(param_7 + 0x1f + iVar5) = (char)param_5;
    param_5 = param_5 >> 8;
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  iVar9 = 0;
  iVar5 = param_7;
  iVar4 = iVar6;
  do {
    uVar1 = *(undefined2 *)(iVar4 + 0x24);
    *(char *)(iVar5 + 0x24) = (char)((ushort)uVar1 >> 8);
    *(char *)(iVar5 + 0x25) = (char)uVar1;
    iVar9 = iVar9 + 1;
    iVar5 = iVar5 + 2;
    iVar4 = iVar4 + 2;
  } while (iVar9 != 0x100);
  uVar7 = *(uint *)(iVar6 + 0x224);
  uVar8 = *(uint *)(iVar6 + 0x228);
  iVar5 = 8;
  do {
    *(char *)(param_7 + 0x223 + iVar5) = (char)uVar7;
    uVar7 = uVar7 >> 8 | uVar8 << 0x18;
    uVar8 = uVar8 >> 8;
    iVar5 = iVar5 + -1;
  } while (iVar5 != 0);
  cVar3 = (**(code **)(*param_2 + 0x1b0))(param_2,param_7,0x22c);
  if (cVar3 == '\0') {
    return 0;
  }
  iVar5 = *param_4;
  *param_4 = iVar5 + 1;
  if (!bVar2) {
    uVar7 = *param_6;
    *param_6 = *param_6 + uStack_1c;
    param_6[1] = param_6[1] + uStack_18 + (uint)CARRY4(uVar7,uStack_1c);
    return 1;
  }
  if (iStack_14 != 0) {
    for (uVar7 = 0; uVar8 = FUN_00029ddc(iStack_14), uVar7 < uVar8; uVar7 = uVar7 + 1) {
      FUN_0002a364(iStack_14,uVar7);
      cVar3 = FUN_000e2102(param_4,iVar5 + 1,param_6,param_7);
      if (cVar3 == '\0') {
        return 0;
      }
    }
  }
  return 1;
}



int * FUN_000e2606(int param_1,int *param_2)

{
  int *piVar1;
  bool bVar2;
  char cVar3;
  int *piVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  undefined1 uVar9;
  int iVar10;
  uint uStack_428;
  uint uStack_424;
  uint uStack_420;
  undefined4 uStack_41c;
  undefined1 auStack_418 [4];
  undefined1 auStack_414 [1016];
  int aiStack_1c [3];
  undefined4 uStack_10;
  
  piVar4 = (int *)(**(code **)(*param_2 + 0x24c))(param_2);
  if (piVar4 != (int *)0x0) {
    piVar1 = *(int **)(*(int *)(param_1 + 0x14) + 0x20);
    (**(code **)(*piVar1 + 0x1a4))(piVar1);
    uVar6 = *(uint *)(*(int *)(param_1 + 0x14) + 0x10);
    if (uVar6 != 0) {
      iVar5 = *(int *)(*(int *)(param_1 + 0x14) + 0x14);
      uVar8 = 1;
      uStack_424 = 0;
      iVar10 = 0x240;
      do {
        iVar7 = iVar10;
        bVar2 = true;
        if ((*(int *)(iVar7 + -0x234 + iVar5) < 1) &&
           ((*(int *)(iVar7 + -0x234 + iVar5) < 0 || (*(int *)(iVar7 + -0x238 + iVar5) == 0)))) {
          bVar2 = false;
        }
        iVar10 = iVar7;
        if (bVar2) goto LAB_000e28d2;
        do {
          if ((uVar8 == 0) || (*(int *)(iVar7 + -0x234 + iVar5) < 0)) {
LAB_000e28d2:
            uStack_424 = uStack_424 + 1;
          }
          uVar8 = uVar8 + 1;
          iVar10 = iVar10 + 0x240;
          if (uVar6 < uVar8) goto LAB_000e2662;
          iVar7 = iVar7 + 0x240;
        } while (uVar8 == 0);
      } while( true );
    }
    uStack_424 = 0;
LAB_000e2662:
    uStack_41c = 0x41464e47;
    uVar9 = 0x14;
    iVar5 = 3;
    do {
      auStack_418[iVar5] = uVar9;
      uVar9 = 0;
      iVar5 = iVar5 + -1;
    } while (iVar5 != -1);
    iVar5 = 3;
    do {
      auStack_414[iVar5] = 0;
      iVar5 = iVar5 + -1;
    } while (iVar5 != -1);
    uVar9 = 1;
    iVar5 = 4;
    do {
      auStack_414[iVar5 + 3] = uVar9;
      uVar9 = 0;
      iVar5 = iVar5 + -1;
    } while (iVar5 != 0);
    iVar5 = 4;
    uVar6 = uStack_424;
    do {
      auStack_414[iVar5 + 7] = (char)uVar6;
      uVar6 = uVar6 >> 8;
      iVar5 = iVar5 + -1;
    } while (iVar5 != 0);
    cVar3 = (**(code **)(*piVar4 + 0x1b0))(piVar4,&uStack_41c,0x14);
    iVar5 = FUN_000e1b04(0);
    if ((cVar3 != '\0') && (uStack_424 != 0)) {
      aiStack_1c[0] = uStack_424 * 0x22c + 0x14;
      aiStack_1c[1] = 0;
      uStack_10 = 0;
      if (cVar3 == '\x01') {
        if (iVar5 == 0) {
LAB_000e2837:
          cVar3 = '\x01';
        }
        else {
          uStack_428 = 0;
          do {
            uVar6 = FUN_00029ddc(iVar5);
            if (uVar6 <= uStack_428) goto LAB_000e27da;
            FUN_0002a364(iVar5,uStack_428);
            cVar3 = FUN_000e2102(&uStack_10,0,aiStack_1c,&uStack_41c);
            uStack_428 = uStack_428 + 1;
          } while (cVar3 == '\x01');
          if ((cVar3 != '\0') && (cVar3 == '\x01')) {
LAB_000e27da:
            uStack_420 = 0;
            do {
              uVar6 = FUN_00029ddc(iVar5);
              if (uVar6 <= uStack_420) goto LAB_000e2837;
              FUN_0002a364(iVar5,uStack_420);
              cVar3 = FUN_000e2418(&uStack_41c);
              uStack_420 = uStack_420 + 1;
            } while (cVar3 == '\x01');
          }
        }
      }
    }
    piVar1 = *(int **)(*(int *)(param_1 + 0x14) + 0x20);
    (**(code **)(*piVar1 + 0x1ac))(piVar1);
    (**(code **)(*piVar4 + 0x1a4))(piVar4);
    piVar4 = (int *)(int)cVar3;
  }
  return piVar4;
}



int * FUN_0002dfa6(int *param_1)

{
  (**(code **)(*param_1 + 0x38))(param_1);
  return param_1;
}


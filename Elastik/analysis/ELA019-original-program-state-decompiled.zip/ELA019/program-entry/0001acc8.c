
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0001acc8(void)

{
  undefined4 uVar1;
  
  if (iRam003d3f98 != 0) {
    return iRam003d3f98;
  }
  uVar1 = FUN_00033b90("ETInstrument");
  iRam003d3f98 = FUN_0001ffde(uVar1,&UNK_0001ae20);
  return iRam003d3f98;
}


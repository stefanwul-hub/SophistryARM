
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0001ffde(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNClassDescription.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x18b,uVar1,"classname");
  }
  if (param_2 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNClassDescription.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x18b,uVar1,"newObjectFunction");
  }
  if (iRam003d3fc4 == 0) {
    func_0x0001fbc2();
  }
  uVar1 = __Znwm(0x78);
  func_0x0001ed00(uVar1);
  uVar1 = FUN_0002dfa6(uVar1);
  func_0x0001f518(uVar1,param_1);
  func_0x0001fae4(uVar1,param_2);
  FUN_00066284(iRam003d3fc4,uVar1,param_1);
  (**(code **)(*piRam003d3fc0 + 0x1bc))(piRam003d3fc0,uVar1);
  return uVar1;
}


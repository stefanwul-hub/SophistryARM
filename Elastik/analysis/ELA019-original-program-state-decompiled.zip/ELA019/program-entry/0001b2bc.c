
void FUN_0001b2bc(int param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  longdouble lVar6;
  
  piVar4 = *(int **)(param_1 + 0xbc);
  if (piVar4 != (int *)0x0) {
    func_0x0015f752(piVar4,0);
    piVar4 = *(int **)(param_1 + 0xbc);
  }
  if (piVar4 != param_2) {
    if (piVar4 != (int *)0x0) {
      (**(code **)(*piVar4 + 0x44))(piVar4);
    }
    *(int **)(param_1 + 0xbc) = param_2;
    if (param_2 == (int *)0x0) {
      return;
    }
    (**(code **)(*param_2 + 0x40))(param_2);
    piVar4 = *(int **)(param_1 + 0xbc);
  }
  if (piVar4 == (int *)0x0) {
    return;
  }
  func_0x0015f752(piVar4,param_1);
  lVar6 = (longdouble)func_0x0015f258(param_2);
  *(double *)(param_1 + 0x144) = (double)lVar6;
  iVar5 = 0;
  iVar2 = func_0x00029ddc(param_2[7]);
  if (0 < iVar2) {
    do {
      uVar3 = func_0x0002a364(param_2[7],iVar5);
      cVar1 = func_0x0014a6c0(uVar3);
      if (cVar1 == '\0') {
        func_0x0014bcd4(uVar3);
      }
      iVar5 = iVar5 + 1;
      iVar2 = func_0x00029ddc(param_2[7]);
    } while (iVar5 < iVar2);
  }
  return;
}


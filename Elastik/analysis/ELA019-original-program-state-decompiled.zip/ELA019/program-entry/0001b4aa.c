
void FUN_0001b4aa(int *param_1,int param_2)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  
  uVar1 = __Znwm(0x34);
  FUN_00120f0e(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  piVar2 = (int *)(**(code **)(*piVar2 + 0x48))(piVar2);
  if (param_2 != 0) {
    iVar3 = (**(code **)(*piVar2 + 0x29c))(piVar2,param_2);
    if (iVar3 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001b513. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*param_1 + 0x3b4))();
      return;
    }
  }
  return;
}


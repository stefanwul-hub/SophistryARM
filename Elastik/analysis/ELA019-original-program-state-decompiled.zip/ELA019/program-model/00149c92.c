
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00149c92(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  FUN_0002defe(param_1);
  *(undefined4 *)(param_1 + 0x2c) = 0x3f333333;
  *(undefined4 *)(param_1 + 100) = 0x3f000000;
  *(undefined4 *)(param_1 + 0x84) = 4;
  uVar1 = __Znwm(0x20);
  FUN_00029d44(uVar1);
  uVar1 = FUN_0002dfa6(uVar1);
  *(undefined4 *)(param_1 + 0x80) = uVar1;
  uVar1 = FUN_00033b90("volume");
  uVar2 = FUN_00033b90("Volume");
  FUN_00149bea(param_1,uVar2,uVar1);
  uVar1 = FUN_00033b90("formattedPanorama");
  uVar2 = FUN_00033b90("Panorama");
  FUN_00149bea(param_1,uVar2,uVar1);
  uVar1 = FUN_00033b90("filterCutOff");
  uVar2 = FUN_00033b90("Cut Off");
  FUN_00149bea(param_1,uVar2,uVar1);
  uVar1 = FUN_00033b90("filterResonance");
  uVar2 = FUN_00033b90("Resonance");
  FUN_00149bea(param_1,uVar2,uVar1);
  uVar1 = FUN_00033b90("envelopeAttack");
  uVar2 = FUN_00033b90("Attack");
  FUN_00149bea(param_1,uVar2,uVar1);
  uVar1 = FUN_00033b90("envelopeRelease");
  uVar2 = FUN_00033b90("Release");
  FUN_00149bea(param_1,uVar2,uVar1);
  uVar1 = FUN_00033b90("position");
  uVar2 = FUN_00033b90("Position");
  FUN_00149bea(param_1,uVar2,uVar1);
  uVar1 = FUN_00033b90("direction");
  uVar2 = FUN_00033b90("Direction");
  FUN_00149bea(param_1,uVar2,uVar1);
  return;
}


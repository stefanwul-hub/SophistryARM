
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002defe(int *param_1)

{
  int iVar1;
  
  if ((cRam003d4018 != '\0') && (cRam003d401a == '\0')) {
    iVar1 = (**(code **)(*param_1 + 8))(param_1);
    if (iVar1 != 0) {
      *(int *)(iVar1 + 0x58) = *(int *)(iVar1 + 0x58) + 1;
      (**(code **)(**(int **)(iVar1 + 0x60) + 0x1a4))(*(int **)(iVar1 + 0x60));
      FUN_0002bb40(*(undefined4 *)(iVar1 + 100),param_1);
      (**(code **)(**(int **)(iVar1 + 0x60) + 0x1ac))(*(int **)(iVar1 + 0x60));
      param_1[2] = -0xff;
      return;
    }
  }
  return;
}


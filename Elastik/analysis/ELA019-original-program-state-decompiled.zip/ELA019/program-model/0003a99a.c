
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0003a99a(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  char *pcVar7;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x2f7,uVar2,"this != 0");
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x10f,uVar2,"this != 0");
  }
  if (*(int *)(param_1 + 0x14) == -1) {
    if (*(char **)(param_1 + 0xc) == (char *)0x0) {
      return param_1;
    }
    uVar4 = 0xffffffff;
    pcVar7 = *(char **)(param_1 + 0xc);
    do {
      if (uVar4 == 0) break;
      uVar4 = uVar4 - 1;
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    iVar6 = ~uVar4 - 2;
  }
  else {
    iVar6 = *(int *)(param_1 + 0x14) + -1;
  }
  if (-1 < iVar6) {
    do {
      cVar1 = FUN_00034a88(param_1,iVar6);
      if (cVar1 == '/') {
        iVar5 = *(int *)(param_1 + 0x14);
        if (iVar5 != -1) goto LAB_0003aa23;
        if (*(char **)(param_1 + 0xc) != (char *)0x0) {
          uVar4 = 0xffffffff;
          pcVar7 = *(char **)(param_1 + 0xc);
          goto code_r0x0003aaec;
        }
        iVar5 = 0;
        goto LAB_0003aa23;
      }
      iVar6 = iVar6 + -1;
    } while (iVar6 != -1);
  }
  return param_1;
  while( true ) {
    uVar4 = uVar4 - 1;
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
    if (cVar1 == '\0') break;
code_r0x0003aaec:
    if (uVar4 == 0) break;
  }
  iVar5 = ~uVar4 - 1;
LAB_0003aa23:
  iVar6 = func_0x0003a042(param_1,iVar6 + 1,(iVar5 - iVar6) + -1);
  return iVar6;
}


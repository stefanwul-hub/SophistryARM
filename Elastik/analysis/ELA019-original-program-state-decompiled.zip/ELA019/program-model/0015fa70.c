
void FUN_0015fa70(int param_1)

{
  double dVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  longdouble lVar6;
  
  iVar5 = 0;
  iVar3 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x1c));
  if (0 < iVar3) {
    do {
      uVar4 = FUN_0002a364(*(undefined4 *)(param_1 + 0x1c),iVar5);
      func_0x0014a310(uVar4,param_1);
      cVar2 = FUN_0014a6c0(uVar4);
      if (cVar2 == '\0') {
        dVar1 = *(double *)(param_1 + 0x10);
        lVar6 = (longdouble)func_0x00149f88(uVar4);
        FUN_0014c234(uVar4,(float)((double)(float)lVar6 * dVar1));
      }
      iVar5 = iVar5 + 1;
      iVar3 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x1c));
    } while (iVar5 < iVar3);
  }
  return;
}


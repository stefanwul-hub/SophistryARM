
longdouble FUN_001aa1d2(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  longdouble lVar3;
  double dVar4;
  
  uVar1 = __Znwm(0x14);
  func_0x001a7cfa(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  lVar3 = (longdouble)func_0x001a6284(piVar2);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x44))(piVar2);
  }
  dVar4 = *(double *)(param_1 + 0x2c);
  if ((dVar4 != 0.0) && (dVar4 <= (double)lVar3)) {
    dVar4 = (double)lVar3 - dVar4;
    if (dVar4 < *(double *)(param_1 + 0x34)) {
      return (longdouble)(*(double *)(param_1 + 0x34) - dVar4);
    }
  }
  return (longdouble)0.0;
}


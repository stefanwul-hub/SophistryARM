
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0014a6fa(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  if (*(int *)(param_1 + 0x24) == 0) {
    return 0;
  }
  uVar2 = FUN_0003a99a(*(int *)(param_1 + 0x24));
  uVar2 = func_0x0003a512(uVar2);
  uVar3 = FUN_00033b90("+");
  cVar1 = func_0x0003ac96(uVar2,uVar3);
  if (cVar1 == '\0') {
    uVar3 = FUN_00033b90("-");
    cVar1 = func_0x0003ac96(uVar2,uVar3);
    if (cVar1 == '\0') {
      return uVar2;
    }
  }
  iVar4 = FUN_000349f4(uVar2);
  uVar2 = func_0x0003a32e(uVar2,iVar4 + -1);
  return uVar2;
}


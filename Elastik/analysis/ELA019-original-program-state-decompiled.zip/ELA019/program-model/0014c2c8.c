
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0014c2c8(int *param_1,char *param_2)

{
  code *pcVar1;
  float *pfVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  char *pcVar9;
  bool bVar10;
  
  bVar10 = (dword *)&stack0x00000000 == &section_00000054.offset;
  iVar5 = 0x11;
  pcVar6 = param_2;
  pcVar8 = "setOutputChannel";
  do {
    pcVar7 = pcVar6;
    pcVar9 = pcVar8;
    if (iVar5 == 0) break;
    iVar5 = iVar5 + -1;
    pcVar9 = pcVar8 + 1;
    pcVar7 = pcVar6 + 1;
    bVar10 = *pcVar6 == *pcVar8;
    pcVar6 = pcVar7;
    pcVar8 = pcVar9;
  } while (bVar10);
  iVar5 = 0;
  if (!bVar10) {
    iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
  }
  bVar10 = iVar5 == 0;
  if (bVar10) {
    piVar4 = (int *)FUN_00031a5c();
    param_1[0x13] = *piVar4 * 2;
    return 0;
  }
  iVar5 = 0x11;
  pcVar6 = param_2;
  pcVar8 = "getOutputChannel";
  do {
    pcVar7 = pcVar6;
    pcVar9 = pcVar8;
    if (iVar5 == 0) break;
    iVar5 = iVar5 + -1;
    pcVar9 = pcVar8 + 1;
    pcVar7 = pcVar6 + 1;
    bVar10 = *pcVar6 == *pcVar8;
    pcVar6 = pcVar7;
    pcVar8 = pcVar9;
  } while (bVar10);
  iVar5 = 0;
  if (!bVar10) {
    iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
  }
  bVar10 = iVar5 == 0;
  if (!bVar10) {
    iVar5 = 0x17;
    pcVar6 = param_2;
    pcVar8 = "setPitchShiftSemitones";
    do {
      pcVar7 = pcVar6;
      pcVar9 = pcVar8;
      if (iVar5 == 0) break;
      iVar5 = iVar5 + -1;
      pcVar9 = pcVar8 + 1;
      pcVar7 = pcVar6 + 1;
      bVar10 = *pcVar6 == *pcVar8;
      pcVar6 = pcVar7;
      pcVar8 = pcVar9;
    } while (bVar10);
    iVar5 = 0;
    if (!bVar10) {
      iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
    }
    bVar10 = iVar5 == 0;
    if (bVar10) {
      piVar4 = (int *)FUN_00031a5c();
      param_1[0x14] = *piVar4;
      FUN_0014bcd4();
      return 0;
    }
    iVar5 = 0x12;
    pcVar6 = param_2;
    pcVar8 = "setPitchShiftCent";
    do {
      pcVar7 = pcVar6;
      pcVar9 = pcVar8;
      if (iVar5 == 0) break;
      iVar5 = iVar5 + -1;
      pcVar9 = pcVar8 + 1;
      pcVar7 = pcVar6 + 1;
      bVar10 = *pcVar6 == *pcVar8;
      pcVar6 = pcVar7;
      pcVar8 = pcVar9;
    } while (bVar10);
    iVar5 = 0;
    if (!bVar10) {
      iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
    }
    bVar10 = iVar5 == 0;
    if (bVar10) {
      piVar4 = (int *)FUN_00031a5c();
      param_1[0x15] = *piVar4;
      FUN_0014bcd4();
      return 0;
    }
    iVar5 = 0xb;
    pcVar6 = param_2;
    pcVar8 = "setFilterQ";
    do {
      pcVar7 = pcVar6;
      pcVar9 = pcVar8;
      if (iVar5 == 0) break;
      iVar5 = iVar5 + -1;
      pcVar9 = pcVar8 + 1;
      pcVar7 = pcVar6 + 1;
      bVar10 = *pcVar6 == *pcVar8;
      pcVar6 = pcVar7;
      pcVar8 = pcVar9;
    } while (bVar10);
    iVar5 = 0;
    if (!bVar10) {
      iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
    }
    bVar10 = iVar5 == 0;
    if (bVar10) {
      piVar4 = (int *)FUN_00031a5c();
      param_1[0x10] = *piVar4;
      return 0;
    }
    iVar5 = 0xb;
    pcVar6 = param_2;
    pcVar8 = "getFilterQ";
    do {
      pcVar7 = pcVar6;
      pcVar9 = pcVar8;
      if (iVar5 == 0) break;
      iVar5 = iVar5 + -1;
      pcVar9 = pcVar8 + 1;
      pcVar7 = pcVar6 + 1;
      bVar10 = *pcVar6 == *pcVar8;
      pcVar6 = pcVar7;
      pcVar8 = pcVar9;
    } while (bVar10);
    iVar5 = 0;
    if (!bVar10) {
      iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
    }
    bVar10 = iVar5 == 0;
    if (!bVar10) {
      iVar5 = 0xe;
      pcVar6 = param_2;
      pcVar8 = "getPresetName";
      do {
        pcVar7 = pcVar6;
        pcVar9 = pcVar8;
        if (iVar5 == 0) break;
        iVar5 = iVar5 + -1;
        pcVar9 = pcVar8 + 1;
        pcVar7 = pcVar6 + 1;
        bVar10 = *pcVar6 == *pcVar8;
        pcVar6 = pcVar7;
        pcVar8 = pcVar9;
      } while (bVar10);
      iVar5 = 0;
      if (!bVar10) {
        iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
      }
      bVar10 = iVar5 == 0;
      if (bVar10) {
        if (param_1[9] != 0) {
          FUN_0003a64e();
          FUN_0003a99a();
        }
      }
      else {
        iVar5 = 0xc;
        pcVar6 = param_2;
        pcVar8 = "getLoopName";
        do {
          pcVar7 = pcVar6;
          pcVar9 = pcVar8;
          if (iVar5 == 0) break;
          iVar5 = iVar5 + -1;
          pcVar9 = pcVar8 + 1;
          pcVar7 = pcVar6 + 1;
          bVar10 = *pcVar6 == *pcVar8;
          pcVar6 = pcVar7;
          pcVar8 = pcVar9;
        } while (bVar10);
        iVar5 = 0;
        if (!bVar10) {
          iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
        }
        bVar10 = iVar5 == 0;
        if (bVar10) {
          FUN_0014a6fa();
        }
        else {
          iVar5 = 0xc;
          pcVar6 = param_2;
          pcVar8 = "setPosition";
          do {
            pcVar7 = pcVar6;
            pcVar9 = pcVar8;
            if (iVar5 == 0) break;
            iVar5 = iVar5 + -1;
            pcVar9 = pcVar8 + 1;
            pcVar7 = pcVar6 + 1;
            bVar10 = *pcVar6 == *pcVar8;
            pcVar6 = pcVar7;
            pcVar8 = pcVar9;
          } while (bVar10);
          iVar5 = 0;
          if (!bVar10) {
            iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
          }
          bVar10 = iVar5 == 0;
          if (bVar10) {
            FUN_00031a5c();
            FUN_0014b090();
            return 0;
          }
          iVar5 = 0xc;
          pcVar6 = param_2;
          pcVar8 = "getPosition";
          do {
            pcVar7 = pcVar6;
            pcVar9 = pcVar8;
            if (iVar5 == 0) break;
            iVar5 = iVar5 + -1;
            pcVar9 = pcVar8 + 1;
            pcVar7 = pcVar6 + 1;
            bVar10 = *pcVar6 == *pcVar8;
            pcVar6 = pcVar7;
            pcVar8 = pcVar9;
          } while (bVar10);
          iVar5 = 0;
          if (!bVar10) {
            iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
          }
          bVar10 = iVar5 == 0;
          if (bVar10) {
            func_0x0014a796();
          }
          else {
            iVar5 = 0x14;
            pcVar6 = param_2;
            pcVar8 = "setPitchShifterMode";
            do {
              pcVar7 = pcVar6;
              pcVar9 = pcVar8;
              if (iVar5 == 0) break;
              iVar5 = iVar5 + -1;
              pcVar9 = pcVar8 + 1;
              pcVar7 = pcVar6 + 1;
              bVar10 = *pcVar6 == *pcVar8;
              pcVar6 = pcVar7;
              pcVar8 = pcVar9;
            } while (bVar10);
            iVar5 = 0;
            if (!bVar10) {
              iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
            }
            bVar10 = iVar5 == 0;
            if (bVar10) {
              piVar4 = (int *)FUN_00031a5c();
              iVar5 = param_1[0x21];
              if (*piVar4 == iVar5) {
                return 0;
              }
              param_1[0x21] = *piVar4;
              if (iVar5 != 4) {
                FUN_0014bcd4();
                return 0;
              }
              return 0;
            }
            iVar5 = 0x14;
            pcVar6 = param_2;
            pcVar8 = "getPitchShifterMode";
            do {
              pcVar7 = pcVar6;
              pcVar9 = pcVar8;
              if (iVar5 == 0) break;
              iVar5 = iVar5 + -1;
              pcVar9 = pcVar8 + 1;
              pcVar7 = pcVar6 + 1;
              bVar10 = *pcVar6 == *pcVar8;
              pcVar6 = pcVar7;
              pcVar8 = pcVar9;
            } while (bVar10);
            iVar5 = 0;
            if (!bVar10) {
              iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
            }
            bVar10 = iVar5 == 0;
            if (!bVar10) {
              iVar5 = 0xd;
              pcVar6 = param_2;
              pcVar8 = "setDirection";
              do {
                pcVar7 = pcVar6;
                pcVar9 = pcVar8;
                if (iVar5 == 0) break;
                iVar5 = iVar5 + -1;
                pcVar9 = pcVar8 + 1;
                pcVar7 = pcVar6 + 1;
                bVar10 = *pcVar6 == *pcVar8;
                pcVar6 = pcVar7;
                pcVar8 = pcVar9;
              } while (bVar10);
              iVar5 = 0;
              if (!bVar10) {
                iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
              }
              bVar10 = iVar5 == 0;
              if (bVar10) {
                piVar4 = (int *)FUN_00031a5c();
                param_1[0x17] = *piVar4;
                if (param_1[0x1e] == 0) {
                  return 0;
                }
                func_0x0015f7f4();
                return 0;
              }
              iVar5 = 0xd;
              pcVar6 = param_2;
              pcVar8 = "getDirection";
              do {
                pcVar7 = pcVar6;
                pcVar9 = pcVar8;
                if (iVar5 == 0) break;
                iVar5 = iVar5 + -1;
                pcVar9 = pcVar8 + 1;
                pcVar7 = pcVar6 + 1;
                bVar10 = *pcVar6 == *pcVar8;
                pcVar6 = pcVar7;
                pcVar8 = pcVar9;
              } while (bVar10);
              iVar5 = 0;
              if (!bVar10) {
                iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
              }
              bVar10 = iVar5 == 0;
              if (!bVar10) {
                iVar5 = 0xd;
                pcVar6 = param_2;
                pcVar8 = "setUserTempo";
                do {
                  pcVar7 = pcVar6;
                  pcVar9 = pcVar8;
                  if (iVar5 == 0) break;
                  iVar5 = iVar5 + -1;
                  pcVar9 = pcVar8 + 1;
                  pcVar7 = pcVar6 + 1;
                  bVar10 = *pcVar6 == *pcVar8;
                  pcVar6 = pcVar7;
                  pcVar8 = pcVar9;
                } while (bVar10);
                iVar5 = 0;
                if (!bVar10) {
                  iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                }
                bVar10 = iVar5 == 0;
                if (bVar10) {
                  FUN_00031a5c();
                  FUN_0014c234();
                  return 0;
                }
                iVar5 = 0xd;
                pcVar6 = param_2;
                pcVar8 = "getUserTempo";
                do {
                  pcVar7 = pcVar6;
                  pcVar9 = pcVar8;
                  if (iVar5 == 0) break;
                  iVar5 = iVar5 + -1;
                  pcVar9 = pcVar8 + 1;
                  pcVar7 = pcVar6 + 1;
                  bVar10 = *pcVar6 == *pcVar8;
                  pcVar6 = pcVar7;
                  pcVar8 = pcVar9;
                } while (bVar10);
                iVar5 = 0;
                if (!bVar10) {
                  iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                }
                bVar10 = iVar5 == 0;
                if (bVar10) {
                  if (param_1[0x1e] != 0) {
                    func_0x0015f258();
                  }
                  FUN_00031dac();
                  iVar5 = FUN_00041c54();
                  return **(undefined4 **)(iVar5 + 8);
                }
                iVar5 = 0x15;
                pcVar6 = param_2;
                pcVar8 = "setFormattedPanorama";
                do {
                  pcVar7 = pcVar6;
                  pcVar9 = pcVar8;
                  if (iVar5 == 0) break;
                  iVar5 = iVar5 + -1;
                  pcVar9 = pcVar8 + 1;
                  pcVar7 = pcVar6 + 1;
                  bVar10 = *pcVar6 == *pcVar8;
                  pcVar6 = pcVar7;
                  pcVar8 = pcVar9;
                } while (bVar10);
                iVar5 = 0;
                if (!bVar10) {
                  iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                }
                bVar10 = iVar5 == 0;
                if (bVar10) {
                  pfVar2 = (float *)FUN_00031a5c();
                  param_1[0x19] = (int)(*pfVar2 / FLOAT_00365d1c + FLOAT_00365cd0);
                  if (param_1[0x1e] != 0) {
                    func_0x0015f7f4();
                    return 0;
                  }
                  return 0;
                }
                iVar5 = 0x15;
                pcVar6 = param_2;
                pcVar8 = "getFormattedPanorama";
                do {
                  pcVar7 = pcVar6;
                  pcVar9 = pcVar8;
                  if (iVar5 == 0) break;
                  iVar5 = iVar5 + -1;
                  pcVar9 = pcVar8 + 1;
                  pcVar7 = pcVar6 + 1;
                  bVar10 = *pcVar6 == *pcVar8;
                  pcVar6 = pcVar7;
                  pcVar8 = pcVar9;
                } while (bVar10);
                iVar5 = 0;
                if (!bVar10) {
                  iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                }
                bVar10 = iVar5 == 0;
                if (!bVar10) {
                  iVar5 = 10;
                  pcVar6 = param_2;
                  pcVar8 = "setVolume";
                  do {
                    pcVar7 = pcVar6;
                    pcVar9 = pcVar8;
                    if (iVar5 == 0) break;
                    iVar5 = iVar5 + -1;
                    pcVar9 = pcVar8 + 1;
                    pcVar7 = pcVar6 + 1;
                    bVar10 = *pcVar6 == *pcVar8;
                    pcVar6 = pcVar7;
                    pcVar8 = pcVar9;
                  } while (bVar10);
                  iVar5 = 0;
                  if (!bVar10) {
                    iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                  }
                  bVar10 = iVar5 == 0;
                  if (bVar10) {
                    piVar4 = (int *)FUN_00031a5c();
                    iVar5 = *piVar4;
                    pcVar1 = *(code **)(*param_1 + 200);
                    FUN_00033b90();
                    FUN_00085a2c();
                    (*pcVar1)();
                    param_1[0xb] = iVar5;
                    if (param_1[0x1e] != 0) {
                      func_0x0015f7f4();
                      return 0;
                    }
                    return 0;
                  }
                  iVar5 = 10;
                  pcVar6 = param_2;
                  pcVar8 = "getVolume";
                  do {
                    pcVar7 = pcVar6;
                    pcVar9 = pcVar8;
                    if (iVar5 == 0) break;
                    iVar5 = iVar5 + -1;
                    pcVar9 = pcVar8 + 1;
                    pcVar7 = pcVar6 + 1;
                    bVar10 = *pcVar6 == *pcVar8;
                    pcVar6 = pcVar7;
                    pcVar8 = pcVar9;
                  } while (bVar10);
                  iVar5 = 0;
                  if (!bVar10) {
                    iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                  }
                  bVar10 = iVar5 == 0;
                  if (!bVar10) {
                    iVar5 = 0x10;
                    pcVar6 = param_2;
                    pcVar8 = "setFilterCutOff";
                    do {
                      pcVar7 = pcVar6;
                      pcVar9 = pcVar8;
                      if (iVar5 == 0) break;
                      iVar5 = iVar5 + -1;
                      pcVar9 = pcVar8 + 1;
                      pcVar7 = pcVar6 + 1;
                      bVar10 = *pcVar6 == *pcVar8;
                      pcVar6 = pcVar7;
                      pcVar8 = pcVar9;
                    } while (bVar10);
                    iVar5 = 0;
                    if (!bVar10) {
                      iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                    }
                    bVar10 = iVar5 == 0;
                    if (bVar10) {
                      piVar4 = (int *)FUN_00031a5c();
                      param_1[0xf] = *piVar4;
                      if (param_1[0x1e] != 0) {
                        func_0x0015f7f4();
                        return 0;
                      }
                      return 0;
                    }
                    iVar5 = 0x10;
                    pcVar6 = param_2;
                    pcVar8 = "getFilterCutOff";
                    do {
                      pcVar7 = pcVar6;
                      pcVar9 = pcVar8;
                      if (iVar5 == 0) break;
                      iVar5 = iVar5 + -1;
                      pcVar9 = pcVar8 + 1;
                      pcVar7 = pcVar6 + 1;
                      bVar10 = *pcVar6 == *pcVar8;
                      pcVar6 = pcVar7;
                      pcVar8 = pcVar9;
                    } while (bVar10);
                    iVar5 = 0;
                    if (!bVar10) {
                      iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                    }
                    bVar10 = iVar5 == 0;
                    if (!bVar10) {
                      iVar5 = 0x13;
                      pcVar6 = param_2;
                      pcVar8 = "setFilterResonance";
                      do {
                        pcVar7 = pcVar6;
                        pcVar9 = pcVar8;
                        if (iVar5 == 0) break;
                        iVar5 = iVar5 + -1;
                        pcVar9 = pcVar8 + 1;
                        pcVar7 = pcVar6 + 1;
                        bVar10 = *pcVar6 == *pcVar8;
                        pcVar6 = pcVar7;
                        pcVar8 = pcVar9;
                      } while (bVar10);
                      iVar5 = 0;
                      if (!bVar10) {
                        iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                      }
                      bVar10 = iVar5 == 0;
                      if (bVar10) {
                        piVar4 = (int *)FUN_00031a5c();
                        param_1[0xe] = *piVar4;
                        if (param_1[0x1e] != 0) {
                          func_0x0015f7f4();
                          return 0;
                        }
                        return 0;
                      }
                      iVar5 = 0x13;
                      pcVar6 = param_2;
                      pcVar8 = "getFilterResonance";
                      do {
                        pcVar7 = pcVar6;
                        pcVar9 = pcVar8;
                        if (iVar5 == 0) break;
                        iVar5 = iVar5 + -1;
                        pcVar9 = pcVar8 + 1;
                        pcVar7 = pcVar6 + 1;
                        bVar10 = *pcVar6 == *pcVar8;
                        pcVar6 = pcVar7;
                        pcVar8 = pcVar9;
                      } while (bVar10);
                      iVar5 = 0;
                      if (!bVar10) {
                        iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                      }
                      bVar10 = iVar5 == 0;
                      if (!bVar10) {
                        iVar5 = 0x12;
                        pcVar6 = param_2;
                        pcVar8 = "setEnvelopeAttack";
                        do {
                          pcVar7 = pcVar6;
                          pcVar9 = pcVar8;
                          if (iVar5 == 0) break;
                          iVar5 = iVar5 + -1;
                          pcVar9 = pcVar8 + 1;
                          pcVar7 = pcVar6 + 1;
                          bVar10 = *pcVar6 == *pcVar8;
                          pcVar6 = pcVar7;
                          pcVar8 = pcVar9;
                        } while (bVar10);
                        iVar5 = 0;
                        if (!bVar10) {
                          iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                        }
                        bVar10 = iVar5 == 0;
                        if (bVar10) {
                          piVar4 = (int *)FUN_00031a5c();
                          param_1[0xd] = *piVar4;
                          if (param_1[0x1e] != 0) {
                            func_0x0015f7f4();
                            return 0;
                          }
                          return 0;
                        }
                        iVar5 = 0x12;
                        pcVar6 = param_2;
                        pcVar8 = "getEnvelopeAttack";
                        do {
                          pcVar7 = pcVar6;
                          pcVar9 = pcVar8;
                          if (iVar5 == 0) break;
                          iVar5 = iVar5 + -1;
                          pcVar9 = pcVar8 + 1;
                          pcVar7 = pcVar6 + 1;
                          bVar10 = *pcVar6 == *pcVar8;
                          pcVar6 = pcVar7;
                          pcVar8 = pcVar9;
                        } while (bVar10);
                        iVar5 = 0;
                        if (!bVar10) {
                          iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                        }
                        bVar10 = iVar5 == 0;
                        if (!bVar10) {
                          iVar5 = 0x13;
                          pcVar6 = param_2;
                          pcVar8 = "setEnvelopeRelease";
                          do {
                            pcVar7 = pcVar6;
                            pcVar9 = pcVar8;
                            if (iVar5 == 0) break;
                            iVar5 = iVar5 + -1;
                            pcVar9 = pcVar8 + 1;
                            pcVar7 = pcVar6 + 1;
                            bVar10 = *pcVar6 == *pcVar8;
                            pcVar6 = pcVar7;
                            pcVar8 = pcVar9;
                          } while (bVar10);
                          iVar5 = 0;
                          if (!bVar10) {
                            iVar5 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar9[-1];
                          }
                          bVar10 = iVar5 == 0;
                          if (bVar10) {
                            piVar4 = (int *)FUN_00031a5c();
                            param_1[0xc] = *piVar4;
                            if (param_1[0x1e] != 0) {
                              func_0x0015f7f4();
                              return 0;
                            }
                            return 0;
                          }
                          iVar5 = 0x13;
                          pcVar6 = "getEnvelopeRelease";
                          do {
                            pcVar8 = param_2;
                            pcVar7 = pcVar6;
                            if (iVar5 == 0) break;
                            iVar5 = iVar5 + -1;
                            pcVar7 = pcVar6 + 1;
                            pcVar8 = param_2 + 1;
                            bVar10 = *param_2 == *pcVar6;
                            param_2 = pcVar8;
                            pcVar6 = pcVar7;
                          } while (bVar10);
                          iVar5 = 0;
                          if (!bVar10) {
                            iVar5 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar7[-1];
                          }
                          if (iVar5 != 0) {
                            uVar3 = FUN_000320ba();
                            return uVar3;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  FUN_00031dac();
  iVar5 = FUN_00041c54();
  return **(undefined4 **)(iVar5 + 8);
}



void FUN_0006d8fe(void)

{
  undefined4 uVar1;
  
  uVar1 = func_0x000410a8();
  func_0x00040bfe(uVar1);
  return;
}


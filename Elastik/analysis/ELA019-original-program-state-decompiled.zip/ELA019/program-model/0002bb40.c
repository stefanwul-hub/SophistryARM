
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002bb40(int *param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x174,uVar2,"this != 0");
  }
  if ((param_2 == (int *)0x0) && (*(char *)((int)param_1 + 0x19) == '\0')) {
    uVar2 = (**(code **)(*param_1 + 0xc))(param_1);
    uVar2 = func_0x00034962(uVar2);
    func_0x0000acae("GNList::addObject(): Cannot add nil object to %s.",uVar2);
  }
  iVar1 = (param_1[4] + 1) * 0x10;
  iVar4 = iVar1 + 1;
  if (iVar4 < 0) {
    iVar4 = iVar1 + 0x10;
  }
  func_0x0002a14a(param_1,iVar4 >> 4);
  *(int **)(param_1[3] + param_1[4] * 4) = param_2;
  param_1[4] = param_1[4] + 1;
  if (((char)param_1[6] == '\0') && (param_2 != (int *)0x0)) {
    (**(code **)(*param_2 + 0x40))(param_2);
  }
  return;
}


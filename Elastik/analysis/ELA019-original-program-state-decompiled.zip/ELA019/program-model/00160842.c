
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00160842(int param_1,char *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined1 *puVar3;
  int iVar4;
  char *pcVar5;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  bool bVar9;
  
  bVar9 = (dword *)&stack0x00000000 == &section_00000054.offset;
  iVar4 = 0xe;
  pcVar5 = param_2;
  pcVar7 = "setAutoselect";
  do {
    pcVar6 = pcVar5;
    pcVar8 = pcVar7;
    if (iVar4 == 0) break;
    iVar4 = iVar4 + -1;
    pcVar8 = pcVar7 + 1;
    pcVar6 = pcVar5 + 1;
    bVar9 = *pcVar5 == *pcVar7;
    pcVar5 = pcVar6;
    pcVar7 = pcVar8;
  } while (bVar9);
  iVar4 = 0;
  if (!bVar9) {
    iVar4 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
  }
  bVar9 = iVar4 == 0;
  if (bVar9) {
    puVar3 = (undefined1 *)FUN_00031a5c();
    *(undefined1 *)(param_1 + 0xc) = *puVar3;
    return 0;
  }
  iVar4 = 9;
  pcVar5 = param_2;
  pcVar7 = "setTempo";
  do {
    pcVar6 = pcVar5;
    pcVar8 = pcVar7;
    if (iVar4 == 0) break;
    iVar4 = iVar4 + -1;
    pcVar8 = pcVar7 + 1;
    pcVar6 = pcVar5 + 1;
    bVar9 = *pcVar5 == *pcVar7;
    pcVar5 = pcVar6;
    pcVar7 = pcVar8;
  } while (bVar9);
  iVar4 = 0;
  if (!bVar9) {
    iVar4 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
  }
  bVar9 = iVar4 == 0;
  if (bVar9) {
    FUN_00031a5c();
    FUN_0016072e();
    return 0;
  }
  iVar4 = 9;
  pcVar5 = param_2;
  pcVar7 = "getTempo";
  do {
    pcVar6 = pcVar5;
    pcVar8 = pcVar7;
    if (iVar4 == 0) break;
    iVar4 = iVar4 + -1;
    pcVar8 = pcVar7 + 1;
    pcVar6 = pcVar5 + 1;
    bVar9 = *pcVar5 == *pcVar7;
    pcVar5 = pcVar6;
    pcVar7 = pcVar8;
  } while (bVar9);
  iVar4 = 0;
  if (!bVar9) {
    iVar4 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
  }
  bVar9 = iVar4 == 0;
  if (!bVar9) {
    iVar4 = 0xd;
    pcVar5 = param_2;
    pcVar7 = "setAlgorithm";
    do {
      pcVar6 = pcVar5;
      pcVar8 = pcVar7;
      if (iVar4 == 0) break;
      iVar4 = iVar4 + -1;
      pcVar8 = pcVar7 + 1;
      pcVar6 = pcVar5 + 1;
      bVar9 = *pcVar5 == *pcVar7;
      pcVar5 = pcVar6;
      pcVar7 = pcVar8;
    } while (bVar9);
    iVar4 = 0;
    if (!bVar9) {
      iVar4 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
    }
    bVar9 = iVar4 == 0;
    if (bVar9) {
      piVar1 = (int *)FUN_00031a5c();
      if (*piVar1 == *(int *)(param_1 + 0x30)) {
        return 0;
      }
      *(int *)(param_1 + 0x30) = *piVar1;
      FUN_0015fa70();
      return 0;
    }
    iVar4 = 0xd;
    pcVar5 = param_2;
    pcVar7 = "getAlgorithm";
    do {
      pcVar6 = pcVar5;
      pcVar8 = pcVar7;
      if (iVar4 == 0) break;
      iVar4 = iVar4 + -1;
      pcVar8 = pcVar7 + 1;
      pcVar6 = pcVar5 + 1;
      bVar9 = *pcVar5 == *pcVar7;
      pcVar5 = pcVar6;
      pcVar7 = pcVar8;
    } while (bVar9);
    iVar4 = 0;
    if (!bVar9) {
      iVar4 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
    }
    bVar9 = iVar4 == 0;
    if (!bVar9) {
      iVar4 = 0x1c;
      pcVar5 = param_2;
      pcVar7 = "setSyncUserTempoToFileTempo";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar4 == 0) break;
        iVar4 = iVar4 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar4 = 0;
      if (!bVar9) {
        iVar4 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar4 == 0;
      if (bVar9) {
        puVar3 = (undefined1 *)FUN_00031a5c();
        *(undefined1 *)(param_1 + 0x38) = *puVar3;
        return 0;
      }
      iVar4 = 0x1c;
      pcVar5 = param_2;
      pcVar7 = "getSyncUserTempoToFileTempo";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar4 == 0) break;
        iVar4 = iVar4 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar4 = 0;
      if (!bVar9) {
        iVar4 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar4 == 0;
      if (!bVar9) {
        iVar4 = 0x16;
        pcVar5 = param_2;
        pcVar7 = "isTempoInSyncWithHost";
        do {
          pcVar6 = pcVar5;
          pcVar8 = pcVar7;
          if (iVar4 == 0) break;
          iVar4 = iVar4 + -1;
          pcVar8 = pcVar7 + 1;
          pcVar6 = pcVar5 + 1;
          bVar9 = *pcVar5 == *pcVar7;
          pcVar5 = pcVar6;
          pcVar7 = pcVar8;
        } while (bVar9);
        iVar4 = 0;
        if (!bVar9) {
          iVar4 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
        }
        bVar9 = iVar4 == 0;
        if (bVar9) {
          (**(code **)(**(int **)(param_1 + 0x28) + 0x3bc))();
        }
        else {
          iVar4 = 0xe;
          pcVar5 = "isTempoInSync";
          do {
            pcVar7 = param_2;
            pcVar6 = pcVar5;
            if (iVar4 == 0) break;
            iVar4 = iVar4 + -1;
            pcVar6 = pcVar5 + 1;
            pcVar7 = param_2 + 1;
            bVar9 = *param_2 == *pcVar5;
            param_2 = pcVar7;
            pcVar5 = pcVar6;
          } while (bVar9);
          iVar4 = 0;
          if (!bVar9) {
            iVar4 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar6[-1];
          }
          if (iVar4 != 0) {
            uVar2 = FUN_000320ba();
            return uVar2;
          }
          FUN_00160112();
        }
      }
    }
  }
  FUN_00031dac();
  iVar4 = FUN_00041c54();
  return **(undefined4 **)(iVar4 + 8);
}


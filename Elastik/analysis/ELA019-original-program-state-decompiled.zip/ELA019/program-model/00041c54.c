
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00041c54(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0xb7,uVar1,"this != 0");
  }
  if (param_2 < 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0xb7,uVar1,"index >= 0");
  }
  if (*(int *)(param_1 + 0x10) <= param_2) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0xb7,uVar1,"index < _numElements");
    if (*(int *)(param_1 + 0x10) <= param_2) {
      return 0;
    }
  }
  if (*(char *)(param_1 + 0x1c) == '\0') {
    return *(int *)(param_1 + 0xc) + param_2 * *(int *)(param_1 + 0x18);
  }
  return *(int *)(*(int *)(param_1 + 0xc) + param_2 * 4);
}


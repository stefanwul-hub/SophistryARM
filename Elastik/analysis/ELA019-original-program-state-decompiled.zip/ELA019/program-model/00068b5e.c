
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00068b5e(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  longdouble lVar3;
  
  iVar2 = func_0x00068ad2(param_1,param_2);
  if (iVar2 == 0) {
    return 0;
  }
  cVar1 = func_0x001a9f5e(iVar2);
  if ((cVar1 != '\0') && (cVar1 = FUN_001aa276(iVar2), cVar1 == '\0')) {
    lVar3 = (longdouble)FUN_001aa1d2(iVar2);
    if (((double)lVar3 == DOUBLE_00364718) && (!NAN((double)lVar3) && !NAN(DOUBLE_00364718))) {
      return 0;
    }
  }
  return iVar2;
}


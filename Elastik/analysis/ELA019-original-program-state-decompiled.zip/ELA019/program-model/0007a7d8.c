
int FUN_0007a7d8(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = func_0x0007a4e0(param_1,param_2);
  if (iVar1 == 0) {
    uVar2 = func_0x00079cf2(param_1,param_2);
    func_0x0007a71a(param_1,param_3,uVar2);
  }
  return iVar1;
}


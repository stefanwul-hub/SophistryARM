
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000320ba(int *param_1,char *param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  char *pcVar6;
  int iVar7;
  char *pcVar8;
  code *pcVar9;
  char *pcVar10;
  char *pcVar11;
  undefined1 uVar12;
  bool bVar13;
  undefined4 auStack_20 [4];
  
  if (param_1 == (int *)0x0) {
    uVar5 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNObject.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x331,uVar5,"this != 0");
  }
  if (param_2 == (char *)0x0) {
    uVar5 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNObject.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x331,uVar5,"selector");
  }
  uVar12 = param_3 == 0;
  if ((bool)uVar12) {
    uVar5 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNObject.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x331,uVar5,"arguments");
  }
  iVar7 = 0x18;
  pcVar6 = param_2;
  pcVar10 = "isMemberOfClassWithName";
  do {
    pcVar8 = pcVar6;
    pcVar11 = pcVar10;
    if (iVar7 == 0) break;
    iVar7 = iVar7 + -1;
    pcVar11 = pcVar10 + 1;
    pcVar8 = pcVar6 + 1;
    uVar12 = *pcVar6 == *pcVar10;
    pcVar6 = pcVar8;
    pcVar10 = pcVar11;
  } while ((bool)uVar12);
  iVar7 = 0;
  if (!(bool)uVar12) {
    iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
  }
  bVar13 = iVar7 == 0;
  if (bVar13) {
    iVar7 = FUN_00041c54(param_3,1);
    cVar1 = func_0x0002e288(param_1,**(undefined4 **)(iVar7 + 8));
    iVar7 = FUN_00041c54(param_3,0);
    if (*(int *)(iVar7 + 8) != 0) {
      iVar7 = FUN_00041c54(param_3,0);
      **(char **)(iVar7 + 8) = cVar1;
    }
    return (int)cVar1;
  }
  iVar7 = 0x15;
  pcVar6 = param_2;
  pcVar10 = "getObjectDescription";
  do {
    pcVar8 = pcVar6;
    pcVar11 = pcVar10;
    if (iVar7 == 0) break;
    iVar7 = iVar7 + -1;
    pcVar11 = pcVar10 + 1;
    pcVar8 = pcVar6 + 1;
    bVar13 = *pcVar6 == *pcVar10;
    pcVar6 = pcVar8;
    pcVar10 = pcVar11;
  } while (bVar13);
  iVar7 = 0;
  if (!bVar13) {
    iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
  }
  bVar13 = iVar7 == 0;
  if (bVar13) {
    auStack_20[0] = (**(code **)(*param_1 + 0xc))(param_1);
    pcVar6 = "GNString *";
LAB_000323c3:
    FUN_00031dac(pcVar6,0,param_3,auStack_20);
    iVar7 = FUN_00041c54(param_3,0);
    return **(int **)(iVar7 + 8);
  }
  iVar7 = 0xb;
  pcVar6 = param_2;
  pcVar10 = "initObject";
  do {
    pcVar8 = pcVar6;
    pcVar11 = pcVar10;
    if (iVar7 == 0) break;
    iVar7 = iVar7 + -1;
    pcVar11 = pcVar10 + 1;
    pcVar8 = pcVar6 + 1;
    bVar13 = *pcVar6 == *pcVar10;
    pcVar6 = pcVar8;
    pcVar10 = pcVar11;
  } while (bVar13);
  iVar7 = 0;
  if (!bVar13) {
    iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
  }
  bVar13 = iVar7 == 0;
  if (bVar13) {
    (**(code **)(*param_1 + 0x34))(param_1);
    return 0;
  }
  iVar7 = 0xf;
  pcVar6 = param_2;
  pcVar10 = "setValueForKey";
  do {
    pcVar8 = pcVar6;
    pcVar11 = pcVar10;
    if (iVar7 == 0) break;
    iVar7 = iVar7 + -1;
    pcVar11 = pcVar10 + 1;
    pcVar8 = pcVar6 + 1;
    bVar13 = *pcVar6 == *pcVar10;
    pcVar6 = pcVar8;
    pcVar10 = pcVar11;
  } while (bVar13);
  iVar7 = 0;
  if (!bVar13) {
    iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
  }
  bVar13 = iVar7 == 0;
  if (bVar13) {
    pcVar9 = *(code **)(*param_1 + 0xec);
  }
  else {
    iVar7 = 0x1f;
    pcVar6 = param_2;
    pcVar10 = "addObjectToRelationshipWithKey";
    do {
      pcVar8 = pcVar6;
      pcVar11 = pcVar10;
      if (iVar7 == 0) break;
      iVar7 = iVar7 + -1;
      pcVar11 = pcVar10 + 1;
      pcVar8 = pcVar6 + 1;
      bVar13 = *pcVar6 == *pcVar10;
      pcVar6 = pcVar8;
      pcVar10 = pcVar11;
    } while (bVar13);
    iVar7 = 0;
    if (!bVar13) {
      iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
    }
    bVar13 = iVar7 == 0;
    if (bVar13) {
      pcVar9 = *(code **)(*param_1 + 0x100);
    }
    else {
      iVar7 = 0x24;
      pcVar6 = param_2;
      pcVar10 = "removeObjectFromRelationshipWithKey";
      do {
        pcVar8 = pcVar6;
        pcVar11 = pcVar10;
        if (iVar7 == 0) break;
        iVar7 = iVar7 + -1;
        pcVar11 = pcVar10 + 1;
        pcVar8 = pcVar6 + 1;
        bVar13 = *pcVar6 == *pcVar10;
        pcVar6 = pcVar8;
        pcVar10 = pcVar11;
      } while (bVar13);
      iVar7 = 0;
      if (!bVar13) {
        iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
      }
      bVar13 = iVar7 == 0;
      if (bVar13) {
        pcVar9 = *(code **)(*param_1 + 0x108);
      }
      else {
        iVar7 = 0x18;
        pcVar6 = param_2;
        pcVar10 = "_setValueForKeyDirectly";
        do {
          pcVar8 = pcVar6;
          pcVar11 = pcVar10;
          if (iVar7 == 0) break;
          iVar7 = iVar7 + -1;
          pcVar11 = pcVar10 + 1;
          pcVar8 = pcVar6 + 1;
          bVar13 = *pcVar6 == *pcVar10;
          pcVar6 = pcVar8;
          pcVar10 = pcVar11;
        } while (bVar13);
        iVar7 = 0;
        if (!bVar13) {
          iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
        }
        bVar13 = iVar7 == 0;
        if (bVar13) {
          pcVar9 = *(code **)(*param_1 + 0x168);
          iVar7 = FUN_00041c54(param_3,3);
          cVar1 = **(char **)(iVar7 + 8);
          iVar7 = FUN_00041c54(param_3,2);
          uVar5 = **(undefined4 **)(iVar7 + 8);
          iVar7 = FUN_00041c54(param_3,1);
          (*pcVar9)(param_1,**(undefined4 **)(iVar7 + 8),uVar5,(int)cVar1);
          return 0;
        }
        iVar7 = 0x13;
        pcVar6 = param_2;
        pcVar10 = "setValueForKeyPath";
        do {
          pcVar8 = pcVar6;
          pcVar11 = pcVar10;
          if (iVar7 == 0) break;
          iVar7 = iVar7 + -1;
          pcVar11 = pcVar10 + 1;
          pcVar8 = pcVar6 + 1;
          bVar13 = *pcVar6 == *pcVar10;
          pcVar6 = pcVar8;
          pcVar10 = pcVar11;
        } while (bVar13);
        iVar7 = 0;
        if (!bVar13) {
          iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
        }
        bVar13 = iVar7 == 0;
        if (!bVar13) {
          iVar7 = 0x28;
          pcVar6 = param_2;
          pcVar10 = "_addObjectToRelationshipWithKeyDirectly";
          do {
            pcVar8 = pcVar6;
            pcVar11 = pcVar10;
            if (iVar7 == 0) break;
            iVar7 = iVar7 + -1;
            pcVar11 = pcVar10 + 1;
            pcVar8 = pcVar6 + 1;
            bVar13 = *pcVar6 == *pcVar10;
            pcVar6 = pcVar8;
            pcVar10 = pcVar11;
          } while (bVar13);
          iVar7 = 0;
          if (!bVar13) {
            iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
          }
          bVar13 = iVar7 == 0;
          if (bVar13) {
            pcVar9 = *(code **)(*param_1 + 0x178);
            iVar7 = FUN_00041c54(param_3,3);
            cVar1 = **(char **)(iVar7 + 8);
            iVar7 = FUN_00041c54(param_3,2);
            uVar5 = **(undefined4 **)(iVar7 + 8);
            iVar7 = FUN_00041c54(param_3,1);
            (*pcVar9)(param_1,**(undefined4 **)(iVar7 + 8),uVar5,(int)cVar1);
            return 0;
          }
          iVar7 = 0x2d;
          pcVar6 = param_2;
          pcVar10 = "_removeObjectFromRelationshipWithKeyDirectly";
          do {
            pcVar8 = pcVar6;
            pcVar11 = pcVar10;
            if (iVar7 == 0) break;
            iVar7 = iVar7 + -1;
            pcVar11 = pcVar10 + 1;
            pcVar8 = pcVar6 + 1;
            bVar13 = *pcVar6 == *pcVar10;
            pcVar6 = pcVar8;
            pcVar10 = pcVar11;
          } while (bVar13);
          iVar7 = 0;
          if (!bVar13) {
            iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
          }
          bVar13 = iVar7 == 0;
          if (bVar13) {
            pcVar9 = *(code **)(*param_1 + 0x180);
            iVar7 = FUN_00041c54(param_3,3);
            cVar1 = **(char **)(iVar7 + 8);
            iVar7 = FUN_00041c54(param_3,2);
            uVar5 = **(undefined4 **)(iVar7 + 8);
            iVar7 = FUN_00041c54(param_3,1);
            (*pcVar9)(param_1,**(undefined4 **)(iVar7 + 8),uVar5,(int)cVar1);
            return 0;
          }
          iVar7 = 0xf;
          pcVar6 = param_2;
          pcVar10 = "getValueForKey";
          do {
            pcVar8 = pcVar6;
            pcVar11 = pcVar10;
            if (iVar7 == 0) break;
            iVar7 = iVar7 + -1;
            pcVar11 = pcVar10 + 1;
            pcVar8 = pcVar6 + 1;
            bVar13 = *pcVar6 == *pcVar10;
            pcVar6 = pcVar8;
            pcVar10 = pcVar11;
          } while (bVar13);
          iVar7 = 0;
          if (!bVar13) {
            iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
          }
          bVar13 = iVar7 == 0;
          if (bVar13) {
            pcVar9 = *(code **)(*param_1 + 0xf0);
          }
          else {
            iVar7 = 0x13;
            pcVar6 = param_2;
            pcVar10 = "getValueForKeyPath";
            do {
              pcVar8 = pcVar6;
              pcVar11 = pcVar10;
              if (iVar7 == 0) break;
              iVar7 = iVar7 + -1;
              pcVar11 = pcVar10 + 1;
              pcVar8 = pcVar6 + 1;
              bVar13 = *pcVar6 == *pcVar10;
              pcVar6 = pcVar8;
              pcVar10 = pcVar11;
            } while (bVar13);
            iVar7 = 0;
            if (!bVar13) {
              iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
            }
            bVar13 = iVar7 == 0;
            if (bVar13) {
              pcVar9 = *(code **)(*param_1 + 0xf8);
            }
            else {
              iVar7 = 0x18;
              pcVar6 = param_2;
              pcVar10 = "_getValueForKeyDirectly";
              do {
                pcVar8 = pcVar6;
                pcVar11 = pcVar10;
                if (iVar7 == 0) break;
                iVar7 = iVar7 + -1;
                pcVar11 = pcVar10 + 1;
                pcVar8 = pcVar6 + 1;
                bVar13 = *pcVar6 == *pcVar10;
                pcVar6 = pcVar8;
                pcVar10 = pcVar11;
              } while (bVar13);
              iVar7 = 0;
              if (!bVar13) {
                iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
              }
              bVar13 = iVar7 == 0;
              if (!bVar13) {
                iVar7 = 0x18;
                pcVar6 = param_2;
                pcVar10 = "getDirectlyOwnedObjects";
                do {
                  pcVar8 = pcVar6;
                  pcVar11 = pcVar10;
                  if (iVar7 == 0) break;
                  iVar7 = iVar7 + -1;
                  pcVar11 = pcVar10 + 1;
                  pcVar8 = pcVar6 + 1;
                  bVar13 = *pcVar6 == *pcVar10;
                  pcVar6 = pcVar8;
                  pcVar10 = pcVar11;
                } while (bVar13);
                iVar7 = 0;
                if (!bVar13) {
                  iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
                }
                bVar13 = iVar7 == 0;
                if (bVar13) {
                  auStack_20[0] = (**(code **)(*param_1 + 0x20))(param_1);
                }
                else {
                  iVar7 = 0x10;
                  pcVar6 = param_2;
                  pcVar10 = "getOwnedObjects";
                  do {
                    pcVar8 = pcVar6;
                    pcVar11 = pcVar10;
                    if (iVar7 == 0) break;
                    iVar7 = iVar7 + -1;
                    pcVar11 = pcVar10 + 1;
                    pcVar8 = pcVar6 + 1;
                    bVar13 = *pcVar6 == *pcVar10;
                    pcVar6 = pcVar8;
                    pcVar10 = pcVar11;
                  } while (bVar13);
                  iVar7 = 0;
                  if (!bVar13) {
                    iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
                  }
                  bVar13 = iVar7 == 0;
                  if (!bVar13) {
                    iVar7 = 0x1a;
                    pcVar6 = param_2;
                    pcVar10 = "addToDirectlyOwnedObjects";
                    do {
                      pcVar8 = pcVar6;
                      pcVar11 = pcVar10;
                      if (iVar7 == 0) break;
                      iVar7 = iVar7 + -1;
                      pcVar11 = pcVar10 + 1;
                      pcVar8 = pcVar6 + 1;
                      bVar13 = *pcVar6 == *pcVar10;
                      pcVar6 = pcVar8;
                      pcVar10 = pcVar11;
                    } while (bVar13);
                    iVar7 = 0;
                    if (!bVar13) {
                      iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
                    }
                    bVar13 = iVar7 == 0;
                    if (bVar13) {
                      pcVar9 = *(code **)(*param_1 + 0x28);
                    }
                    else {
                      iVar7 = 0x1f;
                      pcVar6 = param_2;
                      pcVar10 = "removeFromDirectlyOwnedObjects";
                      do {
                        pcVar8 = pcVar6;
                        pcVar11 = pcVar10;
                        if (iVar7 == 0) break;
                        iVar7 = iVar7 + -1;
                        pcVar11 = pcVar10 + 1;
                        pcVar8 = pcVar6 + 1;
                        bVar13 = *pcVar6 == *pcVar10;
                        pcVar6 = pcVar8;
                        pcVar10 = pcVar11;
                      } while (bVar13);
                      iVar7 = 0;
                      if (!bVar13) {
                        iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
                      }
                      bVar13 = iVar7 == 0;
                      if (!bVar13) {
                        iVar7 = 0x14;
                        pcVar6 = param_2;
                        pcVar10 = "getClassDescription";
                        do {
                          pcVar8 = pcVar6;
                          pcVar11 = pcVar10;
                          if (iVar7 == 0) break;
                          iVar7 = iVar7 + -1;
                          pcVar11 = pcVar10 + 1;
                          pcVar8 = pcVar6 + 1;
                          bVar13 = *pcVar6 == *pcVar10;
                          pcVar6 = pcVar8;
                          pcVar10 = pcVar11;
                        } while (bVar13);
                        iVar7 = 0;
                        if (!bVar13) {
                          iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
                        }
                        bVar13 = iVar7 == 0;
                        if (bVar13) {
                          auStack_20[0] = (**(code **)(*param_1 + 8))(param_1);
                          pcVar6 = "GNClassDescription *";
                        }
                        else {
                          iVar7 = 0xc;
                          pcVar6 = param_2;
                          pcVar10 = "getGlobalID";
                          do {
                            pcVar8 = pcVar6;
                            pcVar11 = pcVar10;
                            if (iVar7 == 0) break;
                            iVar7 = iVar7 + -1;
                            pcVar11 = pcVar10 + 1;
                            pcVar8 = pcVar6 + 1;
                            bVar13 = *pcVar6 == *pcVar10;
                            pcVar6 = pcVar8;
                            pcVar10 = pcVar11;
                          } while (bVar13);
                          iVar7 = 0;
                          if (!bVar13) {
                            iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
                          }
                          if (iVar7 != 0) {
                            uVar5 = (**(code **)(*param_1 + 8))(param_1);
                            iVar7 = func_0x0001f4dc(uVar5);
                            if (iVar7 == 0) {
                              pcVar6 = "";
                            }
                            else {
                              uVar5 = (**(code **)(*param_1 + 8))(param_1);
                              uVar5 = func_0x0001f4dc(uVar5);
                              pcVar6 = (char *)func_0x00034962(uVar5);
                            }
                            uVar5 = FUN_00033b90("GNKeyValueCodingException");
                            FUN_0000bfd6(uVar5,"%s does not respond to selector %s",pcVar6,param_2);
                            return 0;
                          }
                          auStack_20[0] = (**(code **)(*param_1 + 0xbc))(param_1);
                          pcVar6 = "GNGlobalID *";
                        }
                        goto LAB_000323c3;
                      }
                      pcVar9 = *(code **)(*param_1 + 0x2c);
                    }
                    puVar4 = (undefined4 *)FUN_00031a5c("GNObject *",1,param_3);
                    (*pcVar9)(param_1,*puVar4);
                    return 0;
                  }
                  auStack_20[0] = (**(code **)(*param_1 + 0x1c))(param_1);
                }
                pcVar6 = "GNList *";
                goto LAB_000323c3;
              }
              pcVar9 = *(code **)(*param_1 + 0x16c);
            }
          }
          iVar7 = FUN_00041c54(param_3,1);
          iVar7 = (*pcVar9)(param_1,**(undefined4 **)(iVar7 + 8));
          iVar2 = FUN_00041c54(param_3,0);
          if (*(int *)(iVar2 + 8) == 0) {
            return iVar7;
          }
          iVar2 = FUN_00041c54(param_3,0);
          **(int **)(iVar2 + 8) = iVar7;
          return iVar7;
        }
        pcVar9 = *(code **)(*param_1 + 0xf4);
      }
    }
  }
  iVar7 = FUN_00041c54(param_3,2);
  uVar5 = **(undefined4 **)(iVar7 + 8);
  iVar7 = FUN_00041c54(param_3,1);
  (*pcVar9)(param_1,**(undefined4 **)(iVar7 + 8),uVar5);
  return 0;
}


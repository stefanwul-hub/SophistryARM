
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0014c234(int *param_1,float param_2)

{
  code *pcVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longdouble lVar6;
  double dVar7;
  
  lVar6 = (longdouble)func_0x0015f258(param_1[0x1e]);
  pcVar1 = *(code **)(*param_1 + 200);
  uVar4 = FUN_00033b90("userTempoFactor");
  uVar5 = FUN_00085a2c(param_2 / (float)lVar6);
  (*pcVar1)(param_1,uVar5,uVar4);
  param_1[0x22] = (int)(param_2 / (float)lVar6);
  if (param_1[0x1e] == 0) {
    dVar7 = 0.0;
  }
  else {
    lVar6 = (longdouble)func_0x0015f258(param_1[0x1e]);
    dVar7 = (double)((float)param_1[0x22] * (float)lVar6);
  }
  lVar6 = (longdouble)FUN_0014a5d8(param_1);
  if (((((float)(dVar7 / (double)lVar6) != FLOAT_00365ce8) ||
       (NAN((float)(dVar7 / (double)lVar6)) || NAN(FLOAT_00365ce8))) || (param_1[0x14] != 0)) ||
     (param_1[0x15] != 0)) {
    piVar3 = (int *)param_1[0x27];
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x44))(piVar3);
      param_1[0x27] = 0;
    }
    iVar2 = FUN_0014b680(param_1);
    if (iVar2 != 0) {
      uVar4 = func_0x00079a9c();
      iVar2 = FUN_0007a7d8(uVar4,iVar2,param_1);
      if (iVar2 == 0) {
        FUN_0014b252(param_1,0);
        return;
      }
      uVar4 = func_0x00079a9c();
      FUN_0007a5f0(uVar4,param_1);
      if ((char)param_1[0x28] != '\0') {
        FUN_0014bb38(param_1,0);
      }
      goto LAB_0014bdd9;
    }
    uVar4 = func_0x00079a9c();
    FUN_0007a5f0(uVar4,param_1);
    if ((char)param_1[0x28] != '\0') {
      FUN_0014bb38(param_1,0);
    }
  }
  else {
    uVar4 = func_0x00079a9c();
    FUN_0007a5f0(uVar4,param_1);
    if ((char)param_1[0x28] != '\0') {
      FUN_0014bb38(param_1,0);
    }
  }
  if (((param_1[0x1e] == 0) || (param_1[10] == 0)) || (param_1[9] == 0)) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_0015f48c(param_1[0x1e],param_1[10],param_1[9]);
  }
LAB_0014bdd9:
  FUN_0014b252(param_1,iVar2);
  piVar3 = (int *)FUN_0006d8fe();
  pcVar1 = *(code **)(*piVar3 + 0x1a4);
  uVar4 = FUN_00033b90("KeyMappingHasUpdatedSoundFile");
  (*pcVar1)(piVar3,uVar4,param_1);
  return;
}


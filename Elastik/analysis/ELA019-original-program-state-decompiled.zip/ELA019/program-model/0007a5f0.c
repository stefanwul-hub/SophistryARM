
void FUN_0007a5f0(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  
  (**(code **)(**(int **)(param_1 + 0x48) + 0x1a4))(*(int **)(param_1 + 0x48));
  uVar1 = func_0x00063ade(*(undefined4 *)(param_1 + 0x44));
  uVar1 = func_0x0007a544(param_2,uVar1);
  iVar2 = FUN_00029ddc(uVar1);
  if (0 < iVar2) {
    iVar6 = 0;
    do {
      piVar3 = (int *)FUN_0002a364(uVar1,iVar6);
      (**(code **)(*piVar3 + 0x1f0))(piVar3,param_2);
      iVar6 = iVar6 + 1;
    } while (iVar2 != iVar6);
  }
  uVar1 = func_0x00063ade(*(undefined4 *)(param_1 + 0x40));
  uVar1 = func_0x0007a544(param_2,uVar1);
  iVar2 = FUN_00029ddc(uVar1);
  if (0 < iVar2) {
    iVar6 = 0;
    do {
      piVar3 = (int *)FUN_0002a364(uVar1,iVar6);
      (**(code **)(*piVar3 + 0x1f0))(piVar3,param_2);
      uVar4 = (**(code **)(*piVar3 + 0x1e8))(piVar3);
      iVar5 = FUN_00029ddc(uVar4);
      if (iVar5 == 0) {
        uVar4 = (**(code **)(*piVar3 + 0x1d0))(piVar3);
        func_0x00066606(*(undefined4 *)(param_1 + 0x40),uVar4);
      }
      iVar6 = iVar6 + 1;
    } while (iVar2 != iVar6);
  }
                    /* WARNING: Could not recover jumptable at 0x0007a686. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x48) + 0x1ac))();
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00160112(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  longdouble lVar5;
  
  lVar5 = (longdouble)(**(code **)(**(int **)(param_1 + 0x28) + 0x3bc))(*(int **)(param_1 + 0x28));
  if ((double)lVar5 != *(double *)(param_1 + 0x10)) {
    return 0;
  }
  iVar4 = 0;
  iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x1c));
  if (0 < iVar2) {
    do {
      uVar3 = FUN_0002a364(*(undefined4 *)(param_1 + 0x1c),iVar4);
      cVar1 = FUN_0014a6c0(uVar3);
      if (cVar1 == '\0') {
        lVar5 = (longdouble)func_0x0014ab7e(uVar3);
        if (((float)lVar5 == FLOAT_00365ce8) && (!NAN((float)lVar5) && !NAN(FLOAT_00365ce8))) {
          lVar5 = (longdouble)FUN_0014a5d8(uVar3);
          if ((double)lVar5 != *(double *)(param_1 + 0x10)) {
            return 0;
          }
          if (NAN((double)lVar5) || NAN(*(double *)(param_1 + 0x10))) {
            return 0;
          }
        }
      }
      iVar4 = iVar4 + 1;
      iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x1c));
    } while (iVar4 < iVar2);
  }
  return 1;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0001e688(undefined4 *param_1)

{
  func_0x0002dc66(param_1);
  *param_1 = &UNK_0036dda8;
  param_1[4] = 1;
  param_1[3] = 0;
  return;
}


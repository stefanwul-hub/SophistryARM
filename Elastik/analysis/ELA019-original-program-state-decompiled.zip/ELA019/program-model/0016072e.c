
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0016072e(int param_1,double param_2)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  
  if (piRam003d47e0 == (int *)0x0) {
    uVar3 = __Znwm(0x30);
    func_0x0011025c(uVar3);
    piRam003d47e0 = (int *)FUN_0002dfa6(uVar3);
    func_0x0011079e(piRam003d47e0,2);
    (**(code **)(*piRam003d47e0 + 0x1dc))(piRam003d47e0,0x447a0000);
    (**(code **)(*piRam003d47e0 + 0x1d4))(piRam003d47e0,0);
  }
  *(double *)(param_1 + 0x10) = param_2;
  piVar2 = (int *)(**(code **)(*piRam003d47e0 + 0x1ac))(piRam003d47e0,(float)param_2);
  piVar1 = *(int **)(param_1 + 0x34);
  if (piVar2 != piVar1) {
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(int **)(param_1 + 0x34) = piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0x40))(piVar2);
    }
  }
                    /* WARNING: Could not recover jumptable at 0x001607b6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x28) + 0x3c0))();
  return;
}


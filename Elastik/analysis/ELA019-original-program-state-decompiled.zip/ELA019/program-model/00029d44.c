
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00029d44(undefined4 *param_1)

{
  func_0x0002dc66(param_1);
  *param_1 = &UNK_0036e8e8;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  *(undefined1 *)(param_1 + 6) = 0;
  *(undefined1 *)((int)param_1 + 0x19) = 0;
  param_1[7] = 0;
  return;
}


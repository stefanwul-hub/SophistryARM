
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 * FUN_0014b522(void)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)__Znwm(0xb0);
  func_0x0002dc66(puVar1);
  *puVar1 = &UNK_0038a768;
  puVar1[9] = 0;
  puVar1[10] = 0;
  puVar1[0xb] = 0;
  puVar1[0xc] = 0;
  puVar1[0xd] = 0;
  puVar1[0xe] = 0;
  puVar1[0xf] = 0;
  puVar1[0x10] = 0;
  puVar1[0x11] = 0;
  *(undefined1 *)(puVar1 + 0x12) = 0;
  puVar1[0x13] = 0;
  puVar1[0x14] = 0;
  puVar1[0x15] = 0;
  puVar1[0x16] = 1;
  puVar1[0x17] = 0;
  puVar1[0x18] = 5;
  puVar1[0x19] = 0;
  *(undefined1 *)(puVar1 + 0x1a) = 0;
  puVar1[0x1b] = 0;
  puVar1[0x1c] = 0;
  puVar1[0x1e] = 0;
  puVar1[0x1f] = 0;
  puVar1[0x23] = 0;
  puVar1[0x24] = 0;
  *(undefined1 *)(puVar1 + 0x1d) = 0;
  puVar1[0x25] = 0xffffffff;
  puVar1[0x26] = 0xffffffff;
  puVar1[0x27] = 0;
  *(undefined1 *)(puVar1 + 0x28) = 0;
  puVar1[0x29] = 0;
  puVar1[0x20] = 0;
  puVar1[6] = 0;
  puVar1[7] = 0;
  puVar1[8] = 0;
  puVar1[0x21] = 4;
  *(undefined1 *)(puVar1 + 0x2a) = 0;
  puVar1[0x22] = 0x3f800000;
  puVar1[3] = 0x3d4ccccd;
  puVar1[4] = 0x3dcccccd;
  puVar1[5] = 0x3f000000;
  puVar1[0x2b] = 0xbf800000;
  return puVar1;
}



void FUN_00160ba8(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  longdouble lVar6;
  undefined4 uStack_10;
  
  func_0x0002e1fc(param_1,param_2);
  uStack_10 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x20));
  if (uStack_10 < 8) {
    do {
      uVar3 = __Znwm(0x18);
      FUN_00156ad8(uVar3);
      piVar4 = (int *)FUN_0002dfa6(uVar3);
      uVar3 = (**(code **)(*piVar4 + 0x48))(piVar4);
      uStack_10 = uStack_10 + 1;
      FUN_00156ca8(uVar3,uStack_10);
      FUN_0002bb40(*(undefined4 *)(param_1 + 0x20),uVar3);
    } while (uStack_10 != 8);
  }
  if (*(int *)(param_1 + 0x34) != 0) {
    lVar6 = (longdouble)FUN_00034496(*(int *)(param_1 + 0x34));
    *(double *)(param_1 + 0x10) = (double)(float)lVar6;
  }
  iVar5 = 0;
  iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x1c));
  if (0 < iVar2) {
    do {
      uVar3 = FUN_0002a364(*(undefined4 *)(param_1 + 0x1c),iVar5);
      cVar1 = FUN_0014a83e(uVar3);
      if (cVar1 == '\0') {
        FUN_0014b946(uVar3);
      }
      iVar5 = iVar5 + 1;
      iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x1c));
    } while (iVar5 < iVar2);
  }
  return;
}



void FUN_00149bea(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int *piVar2;
  
  uVar1 = __Znwm(0x1c);
  func_0x001f1054(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  (**(code **)(*piVar2 + 0x1a4))(piVar2,param_2);
  (**(code **)(*piVar2 + 0x1ac))(piVar2,param_3);
  (**(code **)(*piVar2 + 0x1bc))(piVar2,param_1);
  FUN_0002bb40(*(undefined4 *)(param_1 + 0x80),piVar2);
                    /* WARNING: Could not recover jumptable at 0x00149c7d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*piVar2 + 0x44))();
  return;
}


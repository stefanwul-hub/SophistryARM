
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00160584(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  
  FUN_0002defe(param_1);
  *(undefined1 *)(param_1 + 0xc) = 1;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0x405e0000;
  piVar1 = (int *)FUN_00033b90("120.00");
  piVar3 = *(int **)(param_1 + 0x34);
  if (piVar1 != piVar3) {
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x44))(piVar3);
    }
    *(int **)(param_1 + 0x34) = piVar1;
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x40))(piVar1);
    }
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  uVar2 = __Znwm(0x20);
  FUN_00029d44(uVar2);
  uVar2 = FUN_0002dfa6(uVar2);
  *(undefined4 *)(param_1 + 0x1c) = uVar2;
  iVar4 = 0x24;
  do {
    uVar2 = __Znwm(0xb0);
    FUN_00149908(uVar2);
    piVar3 = (int *)FUN_0002dfa6(uVar2);
    FUN_0002bb40(*(undefined4 *)(param_1 + 0x1c),piVar3);
    if (0x47 < iVar4) {
      func_0x0014a256(piVar3,1);
    }
    func_0x0014a31e(piVar3,iVar4);
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x44))(piVar3);
    }
    iVar4 = iVar4 + 1;
  } while (iVar4 != 0x68);
  uVar2 = __Znwm(0x20);
  FUN_00029d44(uVar2);
  uVar2 = FUN_0002dfa6(uVar2);
  *(undefined4 *)(param_1 + 0x20) = uVar2;
  iVar4 = 0;
  do {
    uVar2 = __Znwm(0x18);
    FUN_00156ad8(uVar2);
    piVar3 = (int *)FUN_0002dfa6(uVar2);
    uVar2 = (**(code **)(*piVar3 + 0x48))(piVar3);
    iVar4 = iVar4 + 1;
    FUN_00156ca8(uVar2,iVar4);
    FUN_0002bb40(*(undefined4 *)(param_1 + 0x20),uVar2);
  } while (iVar4 != 8);
  return;
}


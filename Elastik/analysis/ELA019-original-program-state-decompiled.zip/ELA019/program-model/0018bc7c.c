
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_0018bc7c(undefined4 param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int *piVar3;
  
  puVar1 = (undefined4 *)__Znwm(0x18);
  func_0x0002dc66(puVar1);
  *puVar1 = &UNK_00390d88;
  puVar1[3] = 0;
  puVar1[5] = 0;
  uVar2 = func_0x0003401a();
  puVar1[4] = uVar2;
  piVar3 = (int *)FUN_0002dfa6(puVar1);
  piVar3 = (int *)(**(code **)(*piVar3 + 0x48))(piVar3);
  (**(code **)(*piVar3 + 0x1a4))(piVar3,param_1);
  return piVar3;
}


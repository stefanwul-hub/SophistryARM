
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000340ba(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x7cd,uVar1,"this != 0");
  }
  if (*(int *)(param_1 + 0x14) == -1) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x7cd,uVar1,"_uniCharLength != -1");
  }
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_0000b122(*(int *)(param_1 + 0xc));
  }
  uVar1 = FUN_0000aecc(*(int *)(param_1 + 0x14) + 1);
  *(undefined4 *)(param_1 + 0xc) = uVar1;
  func_0x00189b58(*(undefined4 *)(param_1 + 0x10),uVar1,0,*(undefined4 *)(param_1 + 0x14));
  *(undefined1 *)(*(int *)(param_1 + 0xc) + *(int *)(param_1 + 0x14)) = 0;
  return;
}


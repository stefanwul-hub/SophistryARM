
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0014a83e(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longdouble lVar4;
  
  if ((*(int *)(param_1 + 0x78) != 0) && (iVar3 = *(int *)(param_1 + 0x28), iVar3 != 0)) {
    uVar2 = func_0x0000cfca();
    iVar3 = FUN_00068b5e(uVar2,iVar3);
    if (iVar3 != 0) {
      cVar1 = func_0x001a9f5e(iVar3);
      if (((cVar1 != '\0') && (cVar1 = FUN_001aa276(iVar3), cVar1 == '\0')) &&
         (lVar4 = (longdouble)FUN_001aa1d2(iVar3), (double)lVar4 <= DOUBLE_00364718)) {
        return 0;
      }
      return 1;
    }
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0014bcd4(int param_1)

{
  code *pcVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  longdouble lVar5;
  double dVar6;
  
  if (*(int *)(param_1 + 0x78) == 0) {
    dVar6 = 0.0;
  }
  else {
    lVar5 = (longdouble)func_0x0015f258(*(int *)(param_1 + 0x78));
    dVar6 = (double)(*(float *)(param_1 + 0x88) * (float)lVar5);
  }
  lVar5 = (longdouble)FUN_0014a5d8(param_1);
  if (((((float)(dVar6 / (double)lVar5) != FLOAT_00365ce8) ||
       (NAN((float)(dVar6 / (double)lVar5)) || NAN(FLOAT_00365ce8))) ||
      (*(int *)(param_1 + 0x50) != 0)) || (*(int *)(param_1 + 0x54) != 0)) {
    piVar4 = *(int **)(param_1 + 0x9c);
    if (piVar4 != (int *)0x0) {
      (**(code **)(*piVar4 + 0x44))(piVar4);
      *(undefined4 *)(param_1 + 0x9c) = 0;
    }
    iVar2 = FUN_0014b680(param_1);
    if (iVar2 != 0) {
      uVar3 = func_0x00079a9c();
      iVar2 = FUN_0007a7d8(uVar3,iVar2,param_1);
      if (iVar2 == 0) {
        FUN_0014b252(param_1,0);
        return;
      }
      uVar3 = func_0x00079a9c();
      FUN_0007a5f0(uVar3,param_1);
      if (*(char *)(param_1 + 0xa0) != '\0') {
        FUN_0014bb38(param_1,0);
      }
      goto LAB_0014bdd9;
    }
    uVar3 = func_0x00079a9c();
    FUN_0007a5f0(uVar3,param_1);
    if (*(char *)(param_1 + 0xa0) != '\0') {
      FUN_0014bb38(param_1,0);
    }
  }
  else {
    uVar3 = func_0x00079a9c();
    FUN_0007a5f0(uVar3,param_1);
    if (*(char *)(param_1 + 0xa0) != '\0') {
      FUN_0014bb38(param_1,0);
    }
  }
  if (((*(int *)(param_1 + 0x78) == 0) || (*(int *)(param_1 + 0x28) == 0)) ||
     (*(int *)(param_1 + 0x24) == 0)) {
    iVar2 = 0;
  }
  else {
    iVar2 = FUN_0015f48c(*(int *)(param_1 + 0x78),*(int *)(param_1 + 0x28),*(int *)(param_1 + 0x24))
    ;
  }
LAB_0014bdd9:
  FUN_0014b252(param_1,iVar2);
  piVar4 = (int *)FUN_0006d8fe();
  pcVar1 = *(code **)(*piVar4 + 0x1a4);
  uVar3 = FUN_00033b90("KeyMappingHasUpdatedSoundFile");
  (*pcVar1)(piVar4,uVar3,param_1);
  return;
}


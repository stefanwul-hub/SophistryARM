
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0014bb38(int param_1,char param_2)

{
  code *pcVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  
  if (*(char *)(param_1 + 0xa0) == param_2) {
    return;
  }
  *(char *)(param_1 + 0xa0) = param_2;
  if (param_2 == '\0') {
    piVar3 = (int *)FUN_0006d8fe();
    pcVar1 = *(code **)(*piVar3 + 0x1b8);
    uVar4 = FUN_00033b90("renderingReady");
    (*pcVar1)(piVar3,param_1,uVar4,param_1);
    piVar5 = (int *)FUN_0014b680(param_1);
    piVar3 = *(int **)(param_1 + 0xa4);
    if (piVar5 == piVar3) goto LAB_0014baa2;
  }
  else {
    piVar3 = (int *)FUN_0006d8fe();
    pcVar1 = *(code **)(*piVar3 + 0x1b4);
    uVar4 = FUN_00033b90("renderingReady");
    (*pcVar1)(piVar3,param_1,uVar4,param_1);
    piVar5 = (int *)FUN_0014b680(param_1);
    piVar3 = *(int **)(param_1 + 0xa4);
    if (piVar5 == piVar3) goto LAB_0014baa2;
  }
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x44))(piVar3);
  }
  *(int **)(param_1 + 0xa4) = piVar5;
  if (piVar5 != (int *)0x0) {
    (**(code **)(*piVar5 + 0x40))(piVar5);
  }
LAB_0014baa2:
  iVar2 = *(int *)(param_1 + 0xa4);
  if (iVar2 != 0) {
    uVar4 = func_0x00079a9c();
    iVar2 = func_0x0007a4e0(uVar4,iVar2);
    if (iVar2 != 0) {
      FUN_0014b252(param_1,iVar2);
      piVar3 = (int *)FUN_0006d8fe();
      pcVar1 = *(code **)(*piVar3 + 0x1a4);
      uVar4 = FUN_00033b90("KeyMappingHasUpdatedSoundFile");
      (*pcVar1)(piVar3,uVar4,param_1);
    }
    piVar3 = *(int **)(param_1 + 0xa4);
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x44))(piVar3);
      *(undefined4 *)(param_1 + 0xa4) = 0;
    }
  }
  return;
}


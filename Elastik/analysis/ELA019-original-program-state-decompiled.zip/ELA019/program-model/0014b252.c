
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0014b252(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  int *piVar5;
  double dVar6;
  int iStack_20;
  
  if (((*(int *)(param_1 + 0x8c) != 0) &&
      (piVar3 = (int *)func_0x001f0b58(*(int *)(param_1 + 0x8c)), piVar3 != (int *)0x0)) &&
     (iVar4 = func_0x00079a9c(), iVar4 != 0)) {
    (**(code **)(*piVar3 + 0x40))(piVar3);
    cVar1 = func_0x00079e7e(iVar4,piVar3);
    if (cVar1 != '\0') {
      func_0x00079faa(iVar4,piVar3);
    }
    if (*(int *)(param_1 + 0x8c) != 0) {
      func_0x001ae634(piVar3,*(int *)(param_1 + 0x8c));
      piVar5 = *(int **)(param_1 + 0x8c);
      if (piVar5 != (int *)0x0) {
        (**(code **)(*piVar5 + 0x44))(piVar5);
      }
      *(undefined4 *)(param_1 + 0x8c) = 0;
    }
    if (*(int *)(param_1 + 0x90) != 0) {
      func_0x001ae634(piVar3,*(int *)(param_1 + 0x90));
      piVar5 = *(int **)(param_1 + 0x90);
      if (piVar5 != (int *)0x0) {
        (**(code **)(*piVar5 + 0x44))(piVar5);
      }
      *(undefined4 *)(param_1 + 0x90) = 0;
    }
    cVar1 = func_0x00079e7e(iVar4,piVar3);
    if (cVar1 != '\0') {
      func_0x001ac7dc(piVar3);
    }
    (**(code **)(*piVar3 + 0x44))(piVar3);
  }
  if (param_2 == 0) {
    piVar3 = *(int **)(param_1 + 0x8c);
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x44))(piVar3);
    }
    *(undefined4 *)(param_1 + 0x8c) = 0;
    piVar3 = *(int **)(param_1 + 0x90);
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x44))(piVar3);
    }
    *(undefined4 *)(param_1 + 0x90) = 0;
  }
  else {
    iVar4 = func_0x00079a9c();
    if ((iVar4 != 0) && (cVar1 = func_0x00079e7e(iVar4,param_2), cVar1 != '\0')) {
      func_0x00079ec4(iVar4,param_2);
    }
    piVar5 = (int *)func_0x001aca46(param_2);
    piVar3 = *(int **)(param_1 + 0x8c);
    if (piVar5 != piVar3) {
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 0x44))(piVar3);
      }
      *(int **)(param_1 + 0x8c) = piVar5;
      if (piVar5 != (int *)0x0) {
        (**(code **)(*piVar5 + 0x40))(piVar5);
      }
    }
    piVar5 = (int *)func_0x001aca46(param_2);
    piVar3 = *(int **)(param_1 + 0x90);
    if (piVar5 != piVar3) {
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 0x44))(piVar3);
      }
      *(int **)(param_1 + 0x90) = piVar5;
      if (piVar5 != (int *)0x0) {
        (**(code **)(*piVar5 + 0x40))(piVar5);
      }
    }
  }
  if (*(int *)(param_1 + 0x8c) == 0) {
    return;
  }
  iVar4 = func_0x001f0b58(*(int *)(param_1 + 0x8c));
  if (iVar4 == 0) {
    return;
  }
  dVar6 = (double)*(float *)(param_1 + 0x6c);
  if (dVar6 == 0.0) {
code_r0x0014af79:
    iStack_20 = 0;
  }
  else {
    if ((dVar6 == DOUBLE_00364840) && (!NAN(dVar6) && !NAN(DOUBLE_00364840))) goto code_r0x0014af79;
    iVar2 = func_0x001ab7c0(iVar4);
    iStack_20 = (int)(((double)iVar2 * (double)*(float *)(param_1 + 0x6c)) / DOUBLE_00364840);
  }
  dVar6 = (double)*(float *)(param_1 + 0x70);
  if (dVar6 != 0.0) {
    if ((dVar6 != DOUBLE_00364840) || (NAN(dVar6) || NAN(DOUBLE_00364840))) {
      iVar2 = func_0x001ab7c0(iVar4);
      iVar2 = (int)(((double)iVar2 * (double)*(float *)(param_1 + 0x70)) / DOUBLE_00364840);
      goto code_r0x0014afaf;
    }
  }
  iVar2 = func_0x001ab7c0(iVar4);
  iVar2 = iVar2 + -1;
code_r0x0014afaf:
  if (iStack_20 == iVar2) {
    if (iVar2 == 0) {
      iVar2 = func_0x001ab7c0(iVar4);
      iVar2 = iVar2 + -1;
    }
    else {
      iVar2 = iVar2 + -1;
    }
  }
  func_0x0014ad4e(param_1,iStack_20,iVar2);
  *(int *)(param_1 + 0x94) = iStack_20;
  *(int *)(param_1 + 0x98) = iVar2;
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 * FUN_00031a5c(char *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 uVar1;
  char *pcVar2;
  int iVar3;
  undefined4 uVar4;
  char *pcVar5;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  bool bVar9;
  longdouble lVar10;
  undefined8 uVar11;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  
  pcVar2 = (char *)FUN_00041c54(param_3,param_2);
  if (*pcVar2 == '@') {
    iVar3 = _strchr(param_1,0x2a);
    bVar9 = iVar3 == 0;
    if (bVar9) {
      uVar4 = **(undefined4 **)(pcVar2 + 8);
      iVar3 = 5;
      pcVar5 = param_1;
      pcVar7 = "bool";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        iVar3 = func_0x000410a8();
        uVar1 = func_0x001826f2(uVar4);
        *(undefined1 *)(iVar3 + 0x2c) = uVar1;
        return (undefined4 *)(iVar3 + 0x2c);
      }
      iVar3 = 5;
      pcVar5 = param_1;
      pcVar7 = "char";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        iVar3 = func_0x000410a8();
        uVar1 = func_0x001829dc(uVar4);
        *(undefined1 *)(iVar3 + 0x2c) = uVar1;
        return (undefined4 *)(iVar3 + 0x2c);
      }
      iVar3 = 4;
      pcVar5 = param_1;
      pcVar7 = "int";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        iVar3 = func_0x000410a8();
        uVar4 = func_0x00182806(uVar4);
        *(undefined4 *)(iVar3 + 0x2c) = uVar4;
        return (undefined4 *)(iVar3 + 0x2c);
      }
      iVar3 = 6;
      pcVar5 = param_1;
      pcVar7 = "float";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        iVar3 = func_0x000410a8();
        lVar10 = (longdouble)func_0x0018287e(uVar4);
        *(float *)(iVar3 + 0x2c) = (float)lVar10;
        return (undefined4 *)(iVar3 + 0x2c);
      }
      iVar3 = 7;
      pcVar5 = param_1;
      pcVar7 = "double";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        iVar3 = func_0x000410a8();
        lVar10 = (longdouble)func_0x001828f6(uVar4);
        *(double *)(iVar3 + 0x2c) = (double)lVar10;
        return (undefined4 *)(iVar3 + 0x2c);
      }
      iVar3 = 7;
      pcVar5 = param_1;
      pcVar7 = "GNRect";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        iVar3 = func_0x000410a8();
        func_0x00182a52(&uStack_2c,uVar4);
        *(undefined4 *)(iVar3 + 0x2c) = uStack_2c;
        *(undefined4 *)(iVar3 + 0x30) = uStack_28;
        *(undefined4 *)(iVar3 + 0x34) = uStack_24;
        *(undefined4 *)(iVar3 + 0x38) = uStack_20;
        return (undefined4 *)(iVar3 + 0x2c);
      }
      iVar3 = 7;
      pcVar5 = param_1;
      pcVar7 = "GNSize";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        iVar3 = func_0x000410a8();
        uVar11 = func_0x00182be8(uVar4);
        *(undefined8 *)(iVar3 + 0x2c) = uVar11;
        return (undefined4 *)(iVar3 + 0x2c);
      }
      iVar3 = 8;
      pcVar5 = param_1;
      pcVar7 = "GNPoint";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        iVar3 = func_0x000410a8();
        uVar11 = func_0x00182b2e(uVar4);
        *(undefined8 *)(iVar3 + 0x2c) = uVar11;
        return (undefined4 *)(iVar3 + 0x2c);
      }
      iVar3 = 8;
      pcVar5 = "GNRange";
      do {
        pcVar7 = param_1;
        pcVar6 = pcVar5;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar6 = pcVar5 + 1;
        pcVar7 = param_1 + 1;
        bVar9 = *param_1 == *pcVar5;
        param_1 = pcVar7;
        pcVar5 = pcVar6;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar6[-1];
      }
      if (iVar3 != 0) {
        return *(undefined4 **)(pcVar2 + 8);
      }
      iVar3 = func_0x000410a8();
      uVar11 = func_0x00182ca2(uVar4);
      *(undefined8 *)(iVar3 + 0x2c) = uVar11;
      return (undefined4 *)(iVar3 + 0x2c);
    }
  }
  return *(undefined4 **)(pcVar2 + 8);
}


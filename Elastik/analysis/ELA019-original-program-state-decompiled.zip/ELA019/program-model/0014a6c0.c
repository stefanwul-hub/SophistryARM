
bool FUN_0014a6c0(int param_1)

{
  return *(int *)(param_1 + 0x24) == 0;
}


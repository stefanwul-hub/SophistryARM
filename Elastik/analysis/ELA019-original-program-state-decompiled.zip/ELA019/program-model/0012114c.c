
void FUN_0012114c(int *param_1,undefined4 param_2)

{
  code *UNRECOVERED_JUMPTABLE;
  int iVar1;
  int *piVar2;
  undefined4 uStack_10;
  
  uStack_10 = param_2;
  iVar1 = (**(code **)(*param_1 + 0x2a4))(param_1);
  if (iVar1 != 0) {
    piVar2 = (int *)(**(code **)(*param_1 + 0x2a4))(param_1);
    uStack_10 = (**(code **)(*piVar2 + 0x1a8))(piVar2,param_2);
  }
  UNRECOVERED_JUMPTABLE = *(code **)(*param_1 + 0x2ac);
  FUN_001210b4(uStack_10);
                    /* WARNING: Could not recover jumptable at 0x001211ad. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)();
  return;
}



void FUN_0014a256(int param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x68) = param_2;
  return;
}


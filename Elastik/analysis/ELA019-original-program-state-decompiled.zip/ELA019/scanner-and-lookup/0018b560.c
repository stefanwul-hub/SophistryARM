
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0018b560(int *param_1,double *param_2)

{
  int iVar1;
  bool bVar2;
  bool bVar3;
  bool bVar4;
  char cVar5;
  short sVar6;
  uint uVar7;
  uint uVar8;
  longdouble lVar9;
  ushort uStack_3e;
  double dStack_3c;
  int iStack_34;
  int aiStack_20 [4];
  
  iVar1 = param_1[5];
  cVar5 = (**(code **)(*param_1 + 0x1b4))(param_1);
  if (cVar5 != '\0') {
    return 0;
  }
  (**(code **)(*param_1 + 0x1c4))(param_1);
  uVar8 = param_1[5];
  uVar7 = (**(code **)(*param_1 + 0x1b8))(param_1);
  if (uVar7 <= uVar8) goto LAB_0018b5ad;
  uVar8 = param_1[5];
  uVar7 = (**(code **)(*param_1 + 0x1b8))(param_1);
  if (uVar8 < uVar7) {
    sVar6 = FUN_00035d80(param_1[3],param_1[5]);
    if (sVar6 == 0x2b) {
      uVar8 = param_1[5] + 1;
      param_1[5] = uVar8;
      bVar2 = false;
    }
    else {
      if (sVar6 != 0x2d) goto LAB_0018b5cb;
      uVar8 = param_1[5] + 1;
      param_1[5] = uVar8;
      bVar2 = true;
    }
  }
  else {
LAB_0018b5cb:
    bVar2 = false;
    uVar8 = param_1[5];
  }
  uStack_3e = 0;
  dStack_3c = 0.0;
  iStack_34 = 0;
  bVar3 = false;
  bVar4 = false;
  while (uVar7 = (**(code **)(*param_1 + 0x1b8))(param_1), uVar8 < uVar7) {
    uStack_3e = FUN_00035d80(param_1[3],param_1[5]);
    if ((ushort)(uStack_3e - 0x30) < 10) {
      if (dStack_3c < DOUBLE_003648f0) {
        dStack_3c = (double)(int)(uStack_3e - 0x30) + dStack_3c * DOUBLE_003648f8;
        bVar4 = true;
      }
      else {
        iStack_34 = iStack_34 + 1;
      }
      if (bVar3) {
        iStack_34 = iStack_34 + -1;
      }
    }
    else {
      if ((bVar3) || (uStack_3e != 0x2e)) break;
      bVar3 = true;
    }
    uVar8 = param_1[5] + 1;
    param_1[5] = uVar8;
  }
  if (!bVar4) {
LAB_0018b5ad:
    param_1[5] = iVar1;
    return 0;
  }
  uVar8 = param_1[5];
  uVar7 = (**(code **)(*param_1 + 0x1b8))(param_1);
  if ((uVar8 < uVar7) && ((uStack_3e == 0x65 || (uStack_3e == 0x45)))) {
    param_1[5] = param_1[5] + 1;
    cVar5 = (**(code **)(*param_1 + 0x1e8))(param_1,aiStack_20);
    if (cVar5 == '\0') goto LAB_0018b5ad;
    if (dStack_3c != DOUBLE_00364718) {
      if (iStack_34 < 1) {
        if ((iStack_34 != 0) && (aiStack_20[0] < -0x80000000 - iStack_34)) {
          iStack_34 = -0x80000000;
          goto LAB_0018b6b3;
        }
      }
      else if (0x7fffffff - iStack_34 < aiStack_20[0]) {
        iStack_34 = 0x7fffffff;
        goto LAB_0018b6b3;
      }
      iStack_34 = iStack_34 + aiStack_20[0];
    }
  }
LAB_0018b6b3:
  if (param_2 != (double *)0x0) {
    if ((dStack_3c != DOUBLE_00364718) && (iStack_34 != 0)) {
      lVar9 = (longdouble)_pow(0,0x40240000,(double)iStack_34);
      dStack_3c = dStack_3c * (double)lVar9;
    }
    if (bVar2) {
      dStack_3c = -dStack_3c;
      *param_2 = dStack_3c;
      return 1;
    }
    *param_2 = dStack_3c;
  }
  return 1;
}


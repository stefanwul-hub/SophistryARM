
undefined4 FUN_0009af5e(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  
  if (param_1 != 0) {
    uVar1 = __Znwm(0x24);
    func_0x00068fe8(uVar1);
    piVar2 = (int *)FUN_0002dfa6(uVar1);
    piVar2 = (int *)(**(code **)(*piVar2 + 0x48))(piVar2);
    uVar1 = (**(code **)(*piVar2 + 0x1a4))(piVar2,param_1);
    return uVar1;
  }
  return 0;
}


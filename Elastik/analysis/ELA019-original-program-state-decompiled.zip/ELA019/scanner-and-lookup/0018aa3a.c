
void FUN_0018aa3a(int *param_1,int *param_2)

{
  int *piVar1;
  
  piVar1 = (int *)param_1[3];
  if (piVar1 != param_2) {
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    param_1[3] = (int)param_2;
    if (param_2 != (int *)0x0) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
  }
                    /* WARNING: Could not recover jumptable at 0x0018aa82. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x1ac))();
  return;
}


001adefe  55  PUSH EBP
001adeff  89e5  MOV EBP,ESP
001adf01  57  PUSH EDI
001adf02  56  PUSH ESI
001adf03  83ec70  SUB ESP,0x70
001adf06  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001adf09  85c0  TEST EAX,EAX
001adf0b  747f  JZ 0x001adf8c
001adf0d  c7042474000000  MOV dword ptr [ESP],0x74
001adf14  e88cc12200  CALL 0x003da0a5
001adf19  89c7  MOV EDI,EAX
001adf1b  890424  MOV dword ptr [ESP],EAX
001adf1e  e8f5d3ffff  CALL 0x001ab318
001adf23  893c24  MOV dword ptr [ESP],EDI
001adf26  e87b00e8ff  CALL 0x0002dfa6
001adf2b  8b10  MOV EDX,dword ptr [EAX]
001adf2d  890424  MOV dword ptr [ESP],EAX
001adf30  ff5248  CALL dword ptr [EDX + 0x48]
001adf33  8945a4  MOV dword ptr [EBP + -0x5c],EAX
001adf36  8d75a8  LEA ESI,[EBP + -0x58]
001adf39  893424  MOV dword ptr [ESP],ESI
001adf3c  e861dfe5ff  CALL 0x0000bea2
001adf41  893424  MOV dword ptr [ESP],ESI
001adf44  e82ac12200  CALL 0x003da073
001adf49  85c0  TEST EAX,EAX
001adf4b  752e  JNZ 0x001adf7b
001adf4d  8b7da4  MOV EDI,dword ptr [EBP + -0x5c]
001adf50  85ff  TEST EDI,EDI
001adf52  7412  JZ 0x001adf66
001adf54  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001adf57  89442404  MOV dword ptr [ESP + 0x4],EAX
001adf5b  8b45a4  MOV EAX,dword ptr [EBP + -0x5c]
001adf5e  890424  MOV dword ptr [ESP],EAX
001adf61  e850fcffff  CALL 0x001adbb6
001adf66  8d45a8  LEA EAX,[EBP + -0x58]
001adf69  890424  MOV dword ptr [ESP],EAX
001adf6c  e84fdfe5ff  CALL 0x0000bec0
001adf71  8b45a4  MOV EAX,dword ptr [EBP + -0x5c]
001adf74  83c470  ADD ESP,0x70
001adf77  5e  POP ESI
001adf78  5f  POP EDI
001adf79  5d  POP EBP
001adf7a  c3  RET
001adf7b  c745a400000000  MOV dword ptr [EBP + -0x5c],0x0
001adf82  8b45a4  MOV EAX,dword ptr [EBP + -0x5c]
001adf85  83c470  ADD ESP,0x70
001adf88  5e  POP ESI
001adf89  5f  POP EDI
001adf8a  5d  POP EBP
001adf8b  c3  RET
001adf8c  c745a400000000  MOV dword ptr [EBP + -0x5c],0x0
001adf93  eba1  JMP 0x001adf36

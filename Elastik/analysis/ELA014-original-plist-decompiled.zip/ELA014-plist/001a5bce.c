
int * FUN_001a5bce(int param_1)

{
  short sVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  
  uVar2 = __Znwm(0x18);
  FUN_000630b6(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  do {
    piVar4 = (int *)FUN_001a56c6(param_1);
    if (piVar4 == (int *)0x0) {
      return piVar3;
    }
    FUN_001a4ffc(param_1);
    sVar1 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
    if (sVar1 == 0x3b) {
      (**(code **)(*piVar4 + 0x40))(piVar4);
      FUN_00066284(piVar3,piVar4,piVar4);
      (**(code **)(*piVar4 + 0x44))(piVar4);
    }
    else {
      sVar1 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
      if (sVar1 != 0x3d) {
LAB_001a5cfc:
        (**(code **)(*piVar4 + 0x44))(piVar4);
        if (piVar3 == (int *)0x0) {
          return (int *)0x0;
        }
        (**(code **)(*piVar3 + 0x44))(piVar3);
        return (int *)0x0;
      }
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
      piVar5 = (int *)FUN_001a59d8(param_1);
      if (piVar5 == (int *)0x0) goto LAB_001a5cfc;
      FUN_00066284(piVar3,piVar5,piVar4);
      (**(code **)(*piVar4 + 0x44))(piVar4);
      piVar4 = piVar5;
    }
    if (piVar4 != (int *)0x0) {
      (**(code **)(*piVar4 + 0x44))(piVar4);
    }
    FUN_001a4ffc(param_1);
    sVar1 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
    if (sVar1 != 0x3b) {
      return piVar3;
    }
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  } while( true );
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

char * FUN_0019cbaa(int param_1,char *param_2,undefined4 *param_3,int param_4)

{
  char cVar1;
  char *pcVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  char *pcStack_24;
  undefined4 uStack_20;
  
  *(undefined1 *)(param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  func_0x00217052(param_1 + 0x3c,"");
  *(undefined4 *)(param_1 + 0x50) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  if ((param_2 == (char *)0x0) || (*param_2 == '\0')) {
    func_0x0019c1ea(param_1,0xd,0,0,0);
    return (char *)0x0;
  }
  *(undefined4 *)(param_1 + 8) = 0xffffffff;
  *(undefined4 *)(param_1 + 4) = 0xffffffff;
  if (param_3 == (undefined4 *)0x0) {
    *(undefined4 *)(param_1 + 4) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
  }
  else {
    *(undefined4 *)(param_1 + 4) = *param_3;
    *(undefined4 *)(param_1 + 8) = param_3[1];
  }
  uStack_28 = *(undefined4 *)(param_1 + 8);
  uStack_2c = *(undefined4 *)(param_1 + 4);
  uStack_20 = *(undefined4 *)(param_1 + 0x48);
  pcStack_24 = param_2;
  *(undefined4 *)(param_1 + 4) = uStack_2c;
  *(undefined4 *)(param_1 + 8) = uStack_28;
  if (param_4 != 0) goto LAB_0019cc6b;
  if (*param_2 == -0x11) goto LAB_0019cd86;
LAB_0019cc64:
  param_4 = 0;
LAB_0019cc6b:
  pcVar2 = (char *)func_0x0019c638(param_2,param_4);
  if (pcVar2 == (char *)0x0) {
    func_0x0019c1ea(param_1,0xd,0,0,0);
    return (char *)0x0;
  }
  do {
    if (*pcVar2 == '\0') {
      return pcVar2;
    }
    piVar3 = (int *)func_0x0019c916(param_1,pcVar2,param_4);
    if (piVar3 == (int *)0x0) {
      return pcVar2;
    }
    uVar4 = (**(code **)(*piVar3 + 0xc))(piVar3,pcVar2,&uStack_2c,param_4);
    func_0x0019e806(param_1,piVar3);
    if ((param_4 == 0) && (piVar3[5] == 5)) {
      pcVar2 = "";
      if ((piVar3[0x11] != 0) &&
         (pcVar2 = (char *)piVar3[0x10], (char *)piVar3[0x10] == (char *)0x0)) break;
      if (((*pcVar2 == '\0') || (cVar1 = func_0x0019c35e(pcVar2,"UTF-8",1,0), cVar1 != '\0')) ||
         (cVar1 = func_0x0019c35e(pcVar2,"UTF8",1,0), cVar1 != '\0')) {
        param_4 = 1;
      }
      else {
        param_4 = 2;
      }
    }
    pcVar2 = (char *)func_0x0019c638(uVar4,param_4);
    if (pcVar2 == (char *)0x0) {
      return (char *)0x0;
    }
  } while( true );
  func_0x002171c2("%s:%u: failed assertion `%s\'\n",
                  "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/tinyxml/tinyxmlparser.cpp"
                  ,0x2e4,"enc");
  param_2 = (char *)0x0;
LAB_0019cd86:
  if ((((param_2[1] == '\0') || (param_2[1] != -0x45)) || (param_2[2] == '\0')) ||
     (param_2[2] != -0x41)) goto LAB_0019cc64;
  param_4 = 1;
  goto LAB_0019cc6b;
}


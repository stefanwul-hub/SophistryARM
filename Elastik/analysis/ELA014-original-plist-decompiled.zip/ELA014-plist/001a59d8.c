
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_001a59d8(int param_1)

{
  int iVar1;
  int iVar2;
  undefined *puVar3;
  byte bVar4;
  char cVar5;
  char cVar6;
  short sVar7;
  uint uVar8;
  int iVar9;
  char *pcVar10;
  int *piVar11;
  undefined4 uVar12;
  int *piVar13;
  uint uVar14;
  longdouble lVar15;
  uint uStack_24;
  
  FUN_001a4ffc(param_1);
  sVar7 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  iVar2 = *(int *)(param_1 + 0x10);
  *(int *)(param_1 + 0x10) = iVar2 + 1;
  if (sVar7 == 0x7b) {
    piVar11 = (int *)FUN_001a5bce(param_1);
    if (piVar11 != (int *)0x0) {
      FUN_001a4ffc(param_1);
      sVar7 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
      if (sVar7 == 0x7d) {
        *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
        return piVar11;
      }
      (**(code **)(*piVar11 + 0x44))(piVar11);
      return (int *)0x0;
    }
  }
  else {
    if (sVar7 == 0x28) {
      uVar12 = __Znwm(0x20);
      FUN_00029d44(uVar12);
      piVar11 = (int *)FUN_0002dfa6(uVar12);
      while (piVar13 = (int *)FUN_001a59d8(param_1), piVar13 != (int *)0x0) {
        FUN_0002bb40(piVar11,piVar13);
        (**(code **)(*piVar13 + 0x44))(piVar13);
        FUN_001a4ffc(param_1);
        sVar7 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
        if (sVar7 != 0x2c) break;
        *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
      }
      FUN_001a4ffc(param_1);
      sVar7 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
      if (sVar7 == 0x29) {
        *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
      }
      else if (piVar11 != (int *)0x0) {
        (**(code **)(*piVar11 + 0x44))(piVar11);
        piVar11 = (int *)0x0;
      }
      return piVar11;
    }
    if (sVar7 == 0x3c) {
      uVar12 = __Znwm(0x20);
      FUN_0002765e(uVar12);
      piVar13 = (int *)FUN_0002dfa6(uVar12);
      FUN_001a4ffc(param_1);
      piVar11 = (int *)FUN_001a55b8(param_1);
      iVar2 = 0;
      do {
        if (piVar11 == (int *)0x0) {
          sVar7 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
          if (sVar7 == 0x3e) {
            *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
          }
          else {
joined_r0x001a59a1:
            if (piVar13 == (int *)0x0) {
              return (int *)0x0;
            }
            (**(code **)(*piVar13 + 0x44))(piVar13);
            piVar13 = (int *)0x0;
          }
          return piVar13;
        }
        uVar8 = FUN_000349f4(piVar11);
        if ((uVar8 & 1) != 0) {
          (**(code **)(*piVar11 + 0x44))(piVar11);
          goto joined_r0x001a59a1;
        }
        iVar1 = iVar2 + (uVar8 >> 1);
        (**(code **)(*piVar13 + 0x1a4))(piVar13,iVar1);
        iVar9 = FUN_00027abc(piVar13);
        puVar3 = PTR_003db0a2;
        pcVar10 = (char *)(iVar9 + iVar2);
        if (uVar8 != 0) {
          uStack_24 = 0;
          do {
            bVar4 = FUN_00034a88(piVar11,uStack_24);
            uVar14 = (uint)bVar4;
            if ((uVar14 < 0x100) && ((PTR_003db0a2[uVar14 * 4 + 0x35] & 4) != 0)) {
              cVar6 = bVar4 - 0x30;
LAB_001a583b:
              bVar4 = FUN_00034a88(piVar11,uStack_24 + 1);
              uVar14 = (uint)bVar4;
              cVar5 = cVar6;
              if (0xff < uVar14) goto LAB_001a58f4;
LAB_001a585c:
              cVar6 = cVar5;
              if ((puVar3[uVar14 * 4 + 0x35] & 4) == 0) goto LAB_001a58f4;
              cVar5 = bVar4 - 0x30;
            }
            else {
              cVar6 = ___tolower(uVar14);
              if ((byte)(cVar6 + 0x9fU) < 6) {
                cVar6 = cVar6 + -0x57;
                goto LAB_001a583b;
              }
              cVar6 = -1;
              bVar4 = FUN_00034a88(piVar11,uStack_24 + 1);
              uVar14 = (uint)bVar4;
              cVar5 = -1;
              if (uVar14 < 0x100) goto LAB_001a585c;
LAB_001a58f4:
              cVar5 = ___tolower(uVar14);
              if ((byte)(cVar5 + 0x9fU) < 6) {
                cVar5 = cVar5 + -0x57;
              }
              else {
                cVar5 = -1;
              }
            }
            if ((cVar6 == -1) || (cVar5 == -1)) {
              (**(code **)(*piVar11 + 0x44))(piVar11);
              (**(code **)(*piVar13 + 0x44))(piVar13);
              return (int *)0x0;
            }
            *pcVar10 = cVar6 * '\x10' + cVar5;
            pcVar10 = pcVar10 + 1;
            uStack_24 = uStack_24 + 2;
          } while (uStack_24 < uVar8);
        }
        (**(code **)(*piVar11 + 0x44))(piVar11);
        FUN_001a4ffc(param_1);
        piVar11 = (int *)FUN_001a55b8(param_1);
        iVar2 = iVar1;
      } while( true );
    }
    if ((sVar7 == 0x27) || (sVar7 == 0x22)) {
      piVar11 = (int *)FUN_001a54f4(param_1,sVar7);
      return piVar11;
    }
    if ((((((ushort)(sVar7 - 0x61U) < 0x1a) || ((ushort)(sVar7 - 0x41U) < 0x1a)) ||
         ((ushort)(sVar7 - 0x30U) < 10)) || ((sVar7 == 0x5f || (sVar7 == 0x24)))) ||
       ((sVar7 == 0x2f || ((sVar7 == 0x3a || (sVar7 == 0x2e)))))) {
      *(int *)(param_1 + 0x10) = iVar2;
      piVar11 = (int *)FUN_001a55b8(param_1);
      uVar12 = FUN_00033b90("-+.0123456789");
      cVar6 = FUN_000377ae(piVar11,uVar12);
      if (cVar6 == '\0') {
        return piVar11;
      }
      cVar6 = FUN_000342c6(piVar11,0x2e);
      if (cVar6 != '\0') {
        uVar12 = __Znwm(0x14);
        FUN_00084dba(uVar12);
        piVar13 = (int *)FUN_0002dfa6(uVar12);
        lVar15 = (longdouble)FUN_00034496(piVar11);
        FUN_0008563a(piVar13,(float)lVar15);
        return piVar13;
      }
      uVar12 = __Znwm(0x14);
      FUN_00084dba(uVar12);
      piVar13 = (int *)FUN_0002dfa6(uVar12);
      uVar12 = FUN_00034584(piVar11);
      FUN_000854fe(piVar13,uVar12);
      return piVar13;
    }
    *(int *)(param_1 + 0x10) = iVar2;
  }
  return (int *)0x0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00038d00(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  
  puVar1 = (undefined4 *)__Znwm(0x20);
  func_0x0002dc66(puVar1);
  *puVar1 = &UNK_0036ec68;
  *(undefined1 *)(puVar1 + 6) = 1;
  puVar1[3] = 0;
  puVar1[4] = 0;
  puVar1[5] = 0xffffffff;
  puVar1[7] = 0xffffffff;
  piVar2 = (int *)FUN_0002dfa6(puVar1);
  uVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
  iVar4 = FUN_00038aa0(uVar3,param_1,param_2);
  if (iVar4 != 0) {
    *(undefined1 *)(iVar4 + 0x18) = 0;
    return iVar4;
  }
  uVar3 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                         );
  uVar5 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xd8,uVar3,"this != 0");
  mach_header_00000000.flags._0_1_ = 0;
  return 0;
}


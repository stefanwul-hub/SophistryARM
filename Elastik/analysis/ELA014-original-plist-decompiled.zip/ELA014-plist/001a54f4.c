
undefined4 FUN_001a54f4(int param_1,short param_2)

{
  uint uVar1;
  undefined4 uVar2;
  uint uVar3;
  short sStack_e;
  
  uVar2 = __Znwm(0x20);
  FUN_000332e2(uVar2);
  uVar2 = FUN_0002dfa6(uVar2);
  while( true ) {
    uVar1 = *(uint *)(param_1 + 0x10);
    uVar3 = FUN_000349f4(*(undefined4 *)(param_1 + 0xc));
    if (uVar3 <= uVar1) break;
    sStack_e = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
    if (sStack_e == param_2) break;
    if (sStack_e == 0x5c) {
      sStack_e = FUN_001a515a(param_1);
    }
    FUN_0003788a(uVar2,&sStack_e,1);
  }
  FUN_00034b8e(uVar2);
  return uVar2;
}


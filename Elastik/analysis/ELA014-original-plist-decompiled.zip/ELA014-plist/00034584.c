
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00034584(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 auStack_20 [4];
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x1db,uVar2,"this != 0");
  }
  if (piRam003d4040 != (int *)0x0) {
    uVar2 = (**(code **)(*piRam003d4040 + 0x1a8))(piRam003d4040,param_1);
    return uVar2;
  }
  if ((*(int *)(param_1 + 0xc) == 0) && (*(int *)(param_1 + 0x14) != -1)) {
    func_0x000340ba(param_1);
  }
  if (*(int *)(param_1 + 0xc) != 0) {
    piVar3 = (int *)func_0x0018bc7c(param_1);
    cVar1 = (**(code **)(*piVar3 + 0x1e8))(piVar3,auStack_20);
    if (cVar1 != '\0') {
      return auStack_20[0];
    }
  }
  return 0;
}


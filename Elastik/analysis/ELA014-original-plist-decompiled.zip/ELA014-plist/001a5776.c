
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_001a5776(int param_1)

{
  int iVar1;
  int iVar2;
  undefined *puVar3;
  byte bVar4;
  char cVar5;
  char cVar6;
  short sVar7;
  undefined4 uVar8;
  int *piVar9;
  int *piVar10;
  uint uVar11;
  int iVar12;
  uint uVar13;
  char *pcStack_28;
  uint uStack_24;
  
  uVar8 = __Znwm(0x20);
  FUN_0002765e(uVar8);
  piVar9 = (int *)FUN_0002dfa6(uVar8);
  FUN_001a4ffc(param_1);
  piVar10 = (int *)FUN_001a55b8(param_1);
  iVar2 = 0;
  do {
    if (piVar10 == (int *)0x0) {
      sVar7 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
      if (sVar7 == 0x3e) {
        *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
      }
      else {
joined_r0x001a59a1:
        if (piVar9 == (int *)0x0) {
          return (int *)0x0;
        }
        (**(code **)(*piVar9 + 0x44))(piVar9);
        piVar9 = (int *)0x0;
      }
      return piVar9;
    }
    uVar11 = FUN_000349f4(piVar10);
    if ((uVar11 & 1) != 0) {
      (**(code **)(*piVar10 + 0x44))(piVar10);
      goto joined_r0x001a59a1;
    }
    iVar1 = iVar2 + (uVar11 >> 1);
    (**(code **)(*piVar9 + 0x1a4))(piVar9,iVar1);
    iVar12 = FUN_00027abc(piVar9);
    puVar3 = PTR_003db0a2;
    pcStack_28 = (char *)(iVar12 + iVar2);
    if (uVar11 != 0) {
      uStack_24 = 0;
      do {
        bVar4 = FUN_00034a88(piVar10,uStack_24);
        uVar13 = (uint)bVar4;
        if ((uVar13 < 0x100) && ((PTR_003db0a2[uVar13 * 4 + 0x35] & 4) != 0)) {
          cVar5 = bVar4 - 0x30;
LAB_001a583b:
          bVar4 = FUN_00034a88(piVar10,uStack_24 + 1);
          uVar13 = (uint)bVar4;
          cVar6 = cVar5;
          if (0xff < uVar13) goto LAB_001a58f4;
LAB_001a585c:
          cVar5 = cVar6;
          if ((puVar3[uVar13 * 4 + 0x35] & 4) == 0) goto LAB_001a58f4;
          cVar6 = bVar4 - 0x30;
        }
        else {
          cVar5 = ___tolower(uVar13);
          if ((byte)(cVar5 + 0x9fU) < 6) {
            cVar5 = cVar5 + -0x57;
            goto LAB_001a583b;
          }
          cVar5 = -1;
          bVar4 = FUN_00034a88(piVar10,uStack_24 + 1);
          uVar13 = (uint)bVar4;
          cVar6 = -1;
          if (uVar13 < 0x100) goto LAB_001a585c;
LAB_001a58f4:
          cVar6 = ___tolower(uVar13);
          if ((byte)(cVar6 + 0x9fU) < 6) {
            cVar6 = cVar6 + -0x57;
          }
          else {
            cVar6 = -1;
          }
        }
        if ((cVar5 == -1) || (cVar6 == -1)) {
          (**(code **)(*piVar10 + 0x44))(piVar10);
          (**(code **)(*piVar9 + 0x44))(piVar9);
          return (int *)0x0;
        }
        *pcStack_28 = cVar5 * '\x10' + cVar6;
        pcStack_28 = pcStack_28 + 1;
        uStack_24 = uStack_24 + 2;
      } while (uStack_24 < uVar11);
    }
    (**(code **)(*piVar10 + 0x44))(piVar10);
    FUN_001a4ffc(param_1);
    piVar10 = (int *)FUN_001a55b8(param_1);
    iVar2 = iVar1;
  } while( true );
}


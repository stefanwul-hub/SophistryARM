
undefined4 FUN_001a4cb0(int *param_1)

{
  char cVar1;
  int *piVar2;
  char cStack_d;
  
  cStack_d = '\0';
  piVar2 = (int *)(**(code **)(*param_1 + 0x248))(param_1);
  if (piVar2 == (int *)0x0) {
    return 0;
  }
LAB_001a4cd7:
  do {
    do {
      cVar1 = FUN_00180086(piVar2,&cStack_d);
      if (cVar1 == '\0') {
        (**(code **)(*piVar2 + 0x1a4))(piVar2);
        return 0;
      }
    } while ((((cStack_d == '\0') || (cStack_d == ' ')) || (cStack_d == '\r')) ||
            ((cStack_d == '\t' || (cStack_d == '\n'))));
    if (cStack_d == -1) {
      cVar1 = FUN_00180086(piVar2,&cStack_d);
      if ((cVar1 == '\0') || (cStack_d != -2)) goto LAB_001a4dd7;
      goto LAB_001a4cd7;
    }
    if (cStack_d == -2) {
      cVar1 = FUN_00180086(piVar2,&cStack_d);
      if ((cVar1 == '\0') || (cStack_d != -1)) goto LAB_001a4dd7;
    }
    else {
      if (cStack_d != '/') {
LAB_001a4d7b:
        (**(code **)(*piVar2 + 0x1a4))(piVar2);
        if (cStack_d != '{') {
          return 0;
        }
        return 1;
      }
      cVar1 = FUN_00180086(piVar2,&cStack_d);
      if (cVar1 == '\0') {
LAB_001a4dd7:
        (**(code **)(*piVar2 + 0x1a4))(piVar2);
        return 0;
      }
      if (cStack_d != '/') {
        if (cStack_d == '*') {
          do {
            cVar1 = FUN_00180086(piVar2,&cStack_d);
            while( true ) {
              if (cVar1 == '\0') goto LAB_001a4d7b;
              if (cStack_d != '*') break;
              cVar1 = FUN_00180086(piVar2,&cStack_d);
              if (cVar1 == '\0') goto LAB_001a4dd7;
              if (cStack_d == '/') goto LAB_001a4cd7;
              cVar1 = FUN_00180086(piVar2,&cStack_d);
            }
          } while( true );
        }
        goto LAB_001a4dd7;
      }
      do {
        cVar1 = FUN_00180086(piVar2,&cStack_d);
        if (cVar1 == '\0') goto LAB_001a4d7b;
      } while (cStack_d != '\n');
    }
  } while( true );
}


001a5bce  55  PUSH EBP
001a5bcf  89e5  MOV EBP,ESP
001a5bd1  57  PUSH EDI
001a5bd2  56  PUSH ESI
001a5bd3  83ec20  SUB ESP,0x20
001a5bd6  c7042418000000  MOV dword ptr [ESP],0x18
001a5bdd  e8c3442300  CALL 0x003da0a5
001a5be2  89c7  MOV EDI,EAX
001a5be4  890424  MOV dword ptr [ESP],EAX
001a5be7  e8cad4ebff  CALL 0x000630b6
001a5bec  893c24  MOV dword ptr [ESP],EDI
001a5bef  e8b283e8ff  CALL 0x0002dfa6
001a5bf4  8945f4  MOV dword ptr [EBP + -0xc],EAX
001a5bf7  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001a5bfa  890424  MOV dword ptr [ESP],EAX
001a5bfd  e8c4faffff  CALL 0x001a56c6
001a5c02  89c7  MOV EDI,EAX
001a5c04  85c0  TEST EAX,EAX
001a5c06  0f84af000000  JZ 0x001a5cbb
001a5c0c  8b5508  MOV EDX,dword ptr [EBP + 0x8]
001a5c0f  891424  MOV dword ptr [ESP],EDX
001a5c12  e8e5f3ffff  CALL 0x001a4ffc
001a5c17  8b5508  MOV EDX,dword ptr [EBP + 0x8]
001a5c1a  8b4210  MOV EAX,dword ptr [EDX + 0x10]
001a5c1d  89442404  MOV dword ptr [ESP + 0x4],EAX
001a5c21  8b420c  MOV EAX,dword ptr [EDX + 0xc]
001a5c24  890424  MOV dword ptr [ESP],EAX
001a5c27  e85401e9ff  CALL 0x00035d80
001a5c2c  6683f83b  CMP AX,0x3b
001a5c30  0f848f000000  JZ 0x001a5cc5
001a5c36  8b5508  MOV EDX,dword ptr [EBP + 0x8]
001a5c39  8b4210  MOV EAX,dword ptr [EDX + 0x10]
001a5c3c  89442404  MOV dword ptr [ESP + 0x4],EAX
001a5c40  8b420c  MOV EAX,dword ptr [EDX + 0xc]
001a5c43  890424  MOV dword ptr [ESP],EAX
001a5c46  e83501e9ff  CALL 0x00035d80
001a5c4b  6683f83d  CMP AX,0x3d
001a5c4f  0f85a7000000  JNZ 0x001a5cfc
001a5c55  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001a5c58  83401001  ADD dword ptr [EAX + 0x10],0x1
001a5c5c  890424  MOV dword ptr [ESP],EAX
001a5c5f  e874fdffff  CALL 0x001a59d8
001a5c64  89c6  MOV ESI,EAX
001a5c66  85c0  TEST EAX,EAX
001a5c68  0f848e000000  JZ 0x001a5cfc
001a5c6e  897c2408  MOV dword ptr [ESP + 0x8],EDI
001a5c72  89742404  MOV dword ptr [ESP + 0x4],ESI
001a5c76  8b55f4  MOV EDX,dword ptr [EBP + -0xc]
001a5c79  891424  MOV dword ptr [ESP],EDX
001a5c7c  e80306ecff  CALL 0x00066284
001a5c81  8b07  MOV EAX,dword ptr [EDI]
001a5c83  893c24  MOV dword ptr [ESP],EDI
001a5c86  ff5044  CALL dword ptr [EAX + 0x44]
001a5c89  85f6  TEST ESI,ESI
001a5c8b  7408  JZ 0x001a5c95
001a5c8d  8b06  MOV EAX,dword ptr [ESI]
001a5c8f  893424  MOV dword ptr [ESP],ESI
001a5c92  ff5044  CALL dword ptr [EAX + 0x44]
001a5c95  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001a5c98  890424  MOV dword ptr [ESP],EAX
001a5c9b  e85cf3ffff  CALL 0x001a4ffc
001a5ca0  8b5508  MOV EDX,dword ptr [EBP + 0x8]
001a5ca3  8b4210  MOV EAX,dword ptr [EDX + 0x10]
001a5ca6  89442404  MOV dword ptr [ESP + 0x4],EAX
001a5caa  8b420c  MOV EAX,dword ptr [EDX + 0xc]
001a5cad  890424  MOV dword ptr [ESP],EAX
001a5cb0  e8cb00e9ff  CALL 0x00035d80
001a5cb5  6683f83b  CMP AX,0x3b
001a5cb9  7435  JZ 0x001a5cf0
001a5cbb  8b45f4  MOV EAX,dword ptr [EBP + -0xc]
001a5cbe  83c420  ADD ESP,0x20
001a5cc1  5e  POP ESI
001a5cc2  5f  POP EDI
001a5cc3  5d  POP EBP
001a5cc4  c3  RET
001a5cc5  8b07  MOV EAX,dword ptr [EDI]
001a5cc7  893c24  MOV dword ptr [ESP],EDI
001a5cca  ff5040  CALL dword ptr [EAX + 0x40]
001a5ccd  89fe  MOV ESI,EDI
001a5ccf  897c2408  MOV dword ptr [ESP + 0x8],EDI
001a5cd3  89742404  MOV dword ptr [ESP + 0x4],ESI
001a5cd7  8b55f4  MOV EDX,dword ptr [EBP + -0xc]
001a5cda  891424  MOV dword ptr [ESP],EDX
001a5cdd  e8a205ecff  CALL 0x00066284
001a5ce2  8b07  MOV EAX,dword ptr [EDI]
001a5ce4  893c24  MOV dword ptr [ESP],EDI
001a5ce7  ff5044  CALL dword ptr [EAX + 0x44]
001a5cea  85f6  TEST ESI,ESI
001a5cec  759f  JNZ 0x001a5c8d
001a5cee  eba5  JMP 0x001a5c95
001a5cf0  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001a5cf3  83401001  ADD dword ptr [EAX + 0x10],0x1
001a5cf7  e9fefeffff  JMP 0x001a5bfa
001a5cfc  8b07  MOV EAX,dword ptr [EDI]
001a5cfe  893c24  MOV dword ptr [ESP],EDI
001a5d01  ff5044  CALL dword ptr [EAX + 0x44]
001a5d04  8b7df4  MOV EDI,dword ptr [EBP + -0xc]
001a5d07  85ff  TEST EDI,EDI
001a5d09  74b0  JZ 0x001a5cbb
001a5d0b  8b55f4  MOV EDX,dword ptr [EBP + -0xc]
001a5d0e  8b02  MOV EAX,dword ptr [EDX]
001a5d10  891424  MOV dword ptr [ESP],EDX
001a5d13  ff5044  CALL dword ptr [EAX + 0x44]
001a5d16  c745f400000000  MOV dword ptr [EBP + -0xc],0x0
001a5d1d  eb9c  JMP 0x001a5cbb


/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined2 FUN_00035d80(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x107,uVar1,"this != 0");
  }
  if (*(int *)(param_1 + 0x14) == -1) {
    FUN_000358be(param_1);
  }
  if (*(int *)(param_1 + 0x10) == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x109,uVar1,"_uniChars");
  }
  if (param_2 < 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x109,uVar1,"i >= 0");
  }
  if (param_2 < *(int *)(param_1 + 0x14)) {
    return *(undefined2 *)(*(int *)(param_1 + 0x10) + param_2 * 2);
  }
  uVar1 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                         );
  uVar2 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x109,uVar1,"i < _uniCharLength");
  return *(undefined2 *)(*(int *)(param_1 + 0x10) + param_2 * 2);
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_000377ae(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  char *pcVar7;
  int iStack_20;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x10f,uVar3,"this != 0");
  }
  iStack_20 = *(int *)(param_1 + 0x14);
  if (iStack_20 == -1) {
    if (*(char **)(param_1 + 0xc) == (char *)0x0) {
      return 1;
    }
    uVar5 = 0xffffffff;
    pcVar7 = *(char **)(param_1 + 0xc);
    do {
      if (uVar5 == 0) break;
      uVar5 = uVar5 - 1;
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    iStack_20 = ~uVar5 - 1;
  }
  if (0 < iStack_20) {
    iVar6 = 0;
    do {
      uVar2 = FUN_00035d80(param_1,iVar6);
      cVar1 = func_0x000376dc(param_2,uVar2);
      if (cVar1 == '\0') {
        return 0;
      }
      iVar6 = iVar6 + 1;
    } while (iStack_20 != iVar6);
  }
  return 1;
}


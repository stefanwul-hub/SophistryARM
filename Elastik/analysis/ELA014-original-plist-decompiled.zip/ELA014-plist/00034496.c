
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

longdouble FUN_00034496(int param_1)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longdouble lVar5;
  double adStack_24 [2];
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x1f0,uVar3,"this != 0");
  }
  if (piRam003d4040 != (int *)0x0) {
    lVar5 = (longdouble)(**(code **)(*piRam003d4040 + 0x1b0))(piRam003d4040,param_1);
    return lVar5;
  }
  if ((*(int *)(param_1 + 0xc) == 0) && (*(int *)(param_1 + 0x14) != -1)) {
    func_0x000340ba(param_1);
  }
  if (*(int *)(param_1 + 0xc) != 0) {
    piVar2 = (int *)func_0x0018bc7c(param_1);
    if (piVar2 != (int *)0x0) {
      cVar1 = (**(code **)(*piVar2 + 500))(piVar2,adStack_24);
      if (cVar1 != '\0') {
        return (longdouble)(float)adStack_24[0];
      }
    }
  }
  return (longdouble)0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0002926c(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    puVar1 = (undefined4 *)__Znwm(0x20);
    func_0x0002dc66(puVar1);
    *puVar1 = &UNK_0036e728;
    puVar1[3] = 0;
    puVar1[4] = 0;
    *(undefined1 *)(puVar1 + 5) = 0;
    *(undefined1 *)((int)puVar1 + 0x15) = 0;
    *(undefined1 *)((int)puVar1 + 0x16) = 1;
    puVar1[7] = 0;
    puVar1[6] = 0;
    piVar2 = (int *)FUN_0002dfa6(puVar1);
    uVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
    uVar3 = func_0x00029080(uVar3,param_1);
    return uVar3;
  }
  return 0;
}


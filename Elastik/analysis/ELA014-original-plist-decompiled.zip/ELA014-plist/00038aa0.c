
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00038aa0(int param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  short *psVar5;
  int iVar6;
  undefined *puVar7;
  int iVar8;
  int iStack_24;
  undefined *apuStack_20 [4];
  
  apuStack_20[0] = &UNK_0000270f;
  iStack_24 = 0;
  FUN_00027b4e(param_2);
  uVar2 = FUN_000278d6(param_2);
  uVar3 = FUN_00027abc(param_2);
  cVar1 = FUN_001891e8(uVar3,uVar2,apuStack_20,&iStack_24);
  puVar7 = &UNK_0000270f;
  if (cVar1 != '\0') {
    puVar7 = apuStack_20[0];
  }
  apuStack_20[0] = puVar7;
  if ((puVar7 == &UNK_0000270f) && (param_3 == 5)) {
    apuStack_20[0] = (undefined *)0x5;
    iStack_24 = 0;
  }
  if (apuStack_20[0] == (undefined *)0x5) {
    if (iStack_24 != 0) {
      iVar4 = FUN_000278d6(param_2);
      iVar6 = FUN_00027abc(param_2);
      if (iVar4 / 2 != 0) {
        iVar8 = 0;
        do {
          func_0x0000a824(iVar6);
          iVar6 = iVar6 + 2;
          iVar8 = iVar8 + 1;
        } while (iVar4 / 2 != iVar8);
      }
    }
    iVar4 = FUN_000278d6(param_2);
    if ((iVar4 < 2) ||
       ((psVar5 = (short *)FUN_00027abc(param_2), *psVar5 != -2 &&
        (psVar5 = (short *)FUN_00027abc(param_2), *psVar5 != -0x101)))) {
      iVar4 = FUN_000278d6(param_2);
      uVar2 = FUN_00027abc(param_2);
      FUN_0003788a(param_1,uVar2,iVar4 / 2);
      FUN_00027bec(param_2);
      goto joined_r0x00038bfd;
    }
    iVar4 = FUN_000278d6(param_2);
    iVar6 = FUN_00027abc(param_2);
    FUN_0003788a(param_1,iVar6 + 2,iVar4 / 2 + -1);
  }
  else {
    uVar2 = FUN_000278d6(param_2);
    uVar3 = FUN_00027abc(param_2);
    FUN_000384d4(param_1,uVar3,uVar2,param_3);
  }
  FUN_00027bec(param_2);
joined_r0x00038bfd:
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xd8,uVar2,"this != 0");
    mach_header_00000000.flags._0_1_ = 0;
    return 0;
  }
  *(undefined1 *)(param_1 + 0x18) = 0;
  return param_1;
}



undefined4 FUN_001a56c6(int param_1)

{
  int iVar1;
  uint uVar2;
  short sVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  
  FUN_001a4ffc(param_1);
  uVar2 = *(uint *)(param_1 + 0x10);
  uVar7 = FUN_000349f4(*(undefined4 *)(param_1 + 0xc));
  if (uVar2 < uVar7) {
    sVar3 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
    if ((sVar3 == 0x27) || (sVar3 == 0x22)) {
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
      uVar5 = FUN_001a54f4(param_1,sVar3);
      return uVar5;
    }
    if ((((((ushort)(sVar3 - 0x61U) < 0x1a) || ((ushort)(sVar3 - 0x41U) < 0x1a)) ||
         ((ushort)(sVar3 - 0x30U) < 10)) || ((sVar3 == 0x5f || (sVar3 == 0x24)))) ||
       ((sVar3 == 0x2f || ((sVar3 == 0x3a || (sVar3 == 0x2e)))))) {
      uVar2 = *(uint *)(param_1 + 0x10);
      uVar7 = uVar2;
      while( true ) {
        uVar4 = FUN_000349f4(*(undefined4 *)(param_1 + 0xc));
        if (uVar4 <= uVar7) break;
        sVar3 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
        if ((((0x19 < (ushort)(sVar3 - 0x61U)) && (0x19 < (ushort)(sVar3 - 0x41U))) &&
            (9 < (ushort)(sVar3 - 0x30U))) &&
           (((sVar3 != 0x5f && (sVar3 != 0x24)) &&
            ((sVar3 != 0x2f && ((sVar3 != 0x3a && (sVar3 != 0x2e)))))))) break;
        uVar7 = *(int *)(param_1 + 0x10) + 1;
        *(uint *)(param_1 + 0x10) = uVar7;
      }
      if (uVar2 != *(uint *)(param_1 + 0x10)) {
        uVar5 = __Znwm(0x20);
        FUN_000332e2(uVar5);
        uVar5 = FUN_0002dfa6(uVar5);
        iVar1 = *(int *)(param_1 + 0x10);
        iVar6 = FUN_00036896(*(undefined4 *)(param_1 + 0xc));
        FUN_0003788a(uVar5,iVar6 + uVar2 * 2,iVar1 - uVar2);
        FUN_00034b8e(uVar5);
        return uVar5;
      }
      return 0;
    }
  }
  return 0;
}


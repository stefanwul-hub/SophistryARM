
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001891e8(short *param_1,uint param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (((param_2 == 0) || ((int)param_2 < 2)) || ((param_2 & 1) != 0)) {
LAB_0018921e:
    uVar1 = 0;
  }
  else {
    if (param_1 == (short *)0x0) {
      uVar1 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStringEncoding.cpp"
                             );
      uVar2 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x267,uVar1,"dataSource");
    }
    if (*param_1 == -0x101) {
      if (param_3 != (undefined4 *)0x0) {
        *param_3 = 5;
      }
      if (param_4 != (undefined4 *)0x0) {
        *param_4 = 0;
        return 1;
      }
    }
    else {
      if (*param_1 != -2) goto LAB_0018921e;
      if (param_3 != (undefined4 *)0x0) {
        *param_3 = 5;
      }
      if (param_4 != (undefined4 *)0x0) {
        *param_4 = 1;
        return 1;
      }
    }
    uVar1 = 1;
  }
  return uVar1;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_001a5eb8(undefined4 param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int *piVar3;
  int *piVar4;
  
  piVar1 = (int *)FUN_00038f0c(param_1);
  puVar2 = (undefined4 *)__Znwm(0x14);
  func_0x0002dc66(puVar2);
  *puVar2 = &UNK_003929a8;
  puVar2[3] = 0;
  puVar2[4] = 0;
  piVar3 = (int *)FUN_0002dfa6(puVar2);
  piVar4 = (int *)piVar3[3];
  if (piVar1 != piVar4) {
    if (piVar4 != (int *)0x0) {
      (**(code **)(*piVar4 + 0x44))(piVar4);
    }
    piVar3[3] = (int)piVar1;
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x40))(piVar1);
    }
  }
  piVar3[4] = 0;
  piVar4 = (int *)FUN_001a59d8(piVar3);
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 0x48))(piVar4);
  }
  (**(code **)(*piVar3 + 0x44))(piVar3);
  return piVar4;
}


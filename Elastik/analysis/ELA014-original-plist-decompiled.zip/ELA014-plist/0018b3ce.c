
undefined4 FUN_0018b3ce(int *param_1,uint *param_2)

{
  int iVar1;
  bool bVar2;
  bool bVar3;
  bool bVar4;
  char cVar5;
  ushort uVar6;
  short sVar7;
  uint uVar8;
  uint uVar9;
  uint uStack_14;
  
  iVar1 = param_1[5];
  cVar5 = (**(code **)(*param_1 + 0x1b4))(param_1);
  if (cVar5 != '\0') {
    return 0;
  }
  (**(code **)(*param_1 + 0x1c4))(param_1);
  uVar9 = param_1[5];
  uVar8 = (**(code **)(*param_1 + 0x1b8))(param_1);
  if (uVar8 <= uVar9) goto LAB_0018b414;
  uVar9 = param_1[5];
  uVar8 = (**(code **)(*param_1 + 0x1b8))(param_1);
  if (uVar9 < uVar8) {
    sVar7 = FUN_00035d80(param_1[3],param_1[5]);
    if (sVar7 == 0x2b) {
      uVar9 = param_1[5] + 1;
      param_1[5] = uVar9;
      bVar3 = false;
    }
    else {
      if (sVar7 != 0x2d) goto LAB_0018b432;
      uVar9 = param_1[5] + 1;
      param_1[5] = uVar9;
      bVar3 = true;
    }
  }
  else {
LAB_0018b432:
    bVar3 = false;
    uVar9 = param_1[5];
  }
  uStack_14 = 0;
  bVar4 = false;
  bVar2 = false;
  while ((uVar8 = (**(code **)(*param_1 + 0x1b8))(param_1), uVar9 < uVar8 &&
         (uVar6 = FUN_00035d80(param_1[3],param_1[5]), (ushort)(uVar6 - 0x30) < 10))) {
    if (!bVar4) {
      if (uStack_14 < 0x19999999) {
        uStack_14 = (uVar6 - 0x30) + uStack_14 * 10;
      }
      else {
        bVar4 = true;
      }
    }
    uVar9 = param_1[5] + 1;
    param_1[5] = uVar9;
    bVar2 = true;
  }
  if (bVar2) {
    if (param_2 != (uint *)0x0) {
      if ((bVar4) || (0x80000000 - !bVar3 < uStack_14)) {
        *param_2 = 0x80000000 - !bVar3;
        return 1;
      }
      if (bVar3) {
        *param_2 = -uStack_14;
        return 1;
      }
      *param_2 = uStack_14;
    }
    return 1;
  }
LAB_0018b414:
  param_1[5] = iVar1;
  return 0;
}


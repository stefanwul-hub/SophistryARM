
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

uint FUN_001a515a(int param_1)

{
  ushort uVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uStack_24;
  int iStack_20;
  
  uStack_24 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  uVar5 = *(int *)(param_1 + 0x10) + 1;
  *(uint *)(param_1 + 0x10) = uVar5;
  uStack_24 = uStack_24 & 0xffff;
  switch(uStack_24) {
  case 10:
  case 0x6e:
    uStack_24 = 10;
    break;
  case 0x22:
    uStack_24 = 0x22;
    break;
  case 0x30:
  case 0x31:
  case 0x32:
  case 0x33:
  case 0x34:
  case 0x35:
  case 0x36:
  case 0x37:
    uVar1 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),uVar5);
    if ((0x2f < uVar1) && (uVar1 < 0x38)) {
      uVar3 = *(int *)(param_1 + 0x10) + 1;
      *(uint *)(param_1 + 0x10) = uVar3;
      uVar5 = FUN_000349f4(*(undefined4 *)(param_1 + 0xc));
      if ((uVar3 < uVar5) &&
         ((uVar1 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10)),
          0x2f < uVar1 && (uVar1 < 0x38)))) {
        *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
      }
    }
    uVar2 = FUN_00033b90("GNNotImplementedException");
    FUN_0000bfd6(uVar2,"Function %s not implemented yet in %s.","getSlashedChar",
                 "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNPropertyListParser.cpp"
                );
    uStack_24 = 0;
    break;
  case 0x55:
    uStack_24 = 0;
    iStack_20 = 4;
    while ((uVar3 = FUN_000349f4(*(undefined4 *)(param_1 + 0xc)), uVar5 < uVar3 &&
           (iStack_20 = iStack_20 + -1, iStack_20 != -1))) {
      uVar1 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
      if ((uVar1 < 0x80) &&
         ((uVar3 = (uint)uVar1, uVar3 < 0x100 && ((PTR_003db0a2[uVar3 * 4 + 0x36] & 1) != 0)))) {
        uVar5 = *(int *)(param_1 + 0x10) + 1;
        *(uint *)(param_1 + 0x10) = uVar5;
        if (uVar1 < 0x3a) {
          iVar4 = uVar3 - 0x30;
        }
        else if (uVar1 < 0x47) {
          iVar4 = uVar3 - 0x37;
        }
        else {
          iVar4 = uVar3 - 0x57;
        }
        uStack_24 = iVar4 + uStack_24 * 0x10;
      }
      else {
        uVar5 = *(uint *)(param_1 + 0x10);
      }
    }
    uStack_24 = uStack_24 & 0xffff;
    break;
  case 0x61:
    uStack_24 = 7;
    break;
  case 0x62:
    uStack_24 = 8;
    break;
  case 0x66:
    uStack_24 = 0xc;
    break;
  case 0x72:
    uStack_24 = 0xd;
    break;
  case 0x74:
    uStack_24 = 9;
    break;
  case 0x76:
    uStack_24 = 0xb;
  }
  return uStack_24;
}


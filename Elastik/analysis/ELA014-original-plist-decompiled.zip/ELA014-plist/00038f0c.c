
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00038f0c(undefined4 param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  
  puVar1 = (undefined4 *)__Znwm(0x20);
  func_0x0002dc66(puVar1);
  *puVar1 = &UNK_0036ec68;
  *(undefined1 *)(puVar1 + 6) = 1;
  puVar1[3] = 0;
  puVar1[4] = 0;
  puVar1[5] = 0xffffffff;
  puVar1[7] = 0xffffffff;
  piVar2 = (int *)FUN_0002dfa6(puVar1);
  uVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
  func_0x00038dec(uVar3,param_1,&UNK_0000270f);
  return;
}



void FUN_001a4ffc(int param_1)

{
  int iVar1;
  ushort uVar2;
  short sVar3;
  uint uVar4;
  uint uVar5;
  
  uVar5 = *(uint *)(param_1 + 0x10);
LAB_001a500a:
  do {
    while( true ) {
      do {
        uVar4 = FUN_000349f4(*(undefined4 *)(param_1 + 0xc));
        if (uVar4 <= uVar5) {
          return;
        }
        uVar2 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
        iVar1 = *(int *)(param_1 + 0x10);
        uVar5 = iVar1 + 1;
        *(uint *)(param_1 + 0x10) = uVar5;
      } while (uVar2 == 10);
      if (uVar2 == 0x2f) break;
      if ((0x77 < (ushort)(uVar2 - 9)) || ((uVar2 != 0x20 && (0xd < uVar2)))) {
        *(int *)(param_1 + 0x10) = iVar1;
        return;
      }
    }
    uVar4 = FUN_000349f4(*(undefined4 *)(param_1 + 0xc));
    if (uVar4 <= uVar5) {
LAB_001a5151:
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + -1;
      return;
    }
    sVar3 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
    if (sVar3 == 0x2f) {
      do {
        uVar4 = *(int *)(param_1 + 0x10) + 1;
        *(uint *)(param_1 + 0x10) = uVar4;
        uVar5 = FUN_000349f4(*(undefined4 *)(param_1 + 0xc));
        if (uVar5 <= uVar4) break;
        sVar3 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
      } while (sVar3 != 10);
    }
    else {
      sVar3 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
      if (sVar3 != 0x2a) goto LAB_001a5151;
      uVar5 = *(int *)(param_1 + 0x10) + 1;
      *(uint *)(param_1 + 0x10) = uVar5;
      while (uVar4 = FUN_000349f4(*(undefined4 *)(param_1 + 0xc)), uVar5 < uVar4) {
        sVar3 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
        uVar5 = *(int *)(param_1 + 0x10) + 1;
        *(uint *)(param_1 + 0x10) = uVar5;
        if (sVar3 == 0x2a) {
          uVar4 = FUN_000349f4(*(undefined4 *)(param_1 + 0xc));
          if ((uVar5 < uVar4) &&
             (sVar3 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10)),
             sVar3 == 0x2f)) {
            uVar5 = *(int *)(param_1 + 0x10) + 1;
            *(uint *)(param_1 + 0x10) = uVar5;
            goto LAB_001a500a;
          }
          uVar5 = *(uint *)(param_1 + 0x10);
        }
      }
    }
    uVar5 = *(uint *)(param_1 + 0x10);
  } while( true );
}


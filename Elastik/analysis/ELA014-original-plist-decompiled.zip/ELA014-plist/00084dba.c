
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00084dba(undefined4 *param_1)

{
  func_0x001821dc(param_1);
  *param_1 = &UNK_00374468;
  *(undefined1 *)(param_1 + 4) = 0;
  param_1[3] = 0;
  return;
}


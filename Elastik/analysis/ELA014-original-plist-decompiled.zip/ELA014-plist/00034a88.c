
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00034a88(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0xf6,uVar1,"this != 0");
  }
  if (param_2 < 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0xf6,uVar1,"i >= 0");
  }
  if ((*(int *)(param_1 + 0xc) == 0) && (*(int *)(param_1 + 0x14) != -1)) {
    func_0x000340ba(param_1);
  }
  if (*(int *)(param_1 + 0xc) != 0) {
    return (int)*(char *)(*(int *)(param_1 + 0xc) + param_2);
  }
  func_0x0000acae("GNString::getCharAtIndex(). Index needs to be positive.");
  return (int)*(char *)(*(int *)(param_1 + 0xc) + param_2);
}


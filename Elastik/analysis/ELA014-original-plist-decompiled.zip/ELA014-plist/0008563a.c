
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0008563a(int param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNNumber.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xaf,uVar2,"this != 0");
  }
  *(undefined1 *)(param_1 + 0x10) = 0x66;
  if (*(int *)(param_1 + 0xc) != 0) {
    **(undefined4 **)(param_1 + 0xc) = param_2;
    return param_1;
  }
  puVar1 = (undefined4 *)FUN_0000aecc(4);
  *(undefined4 **)(param_1 + 0xc) = puVar1;
  *puVar1 = param_2;
  return param_1;
}


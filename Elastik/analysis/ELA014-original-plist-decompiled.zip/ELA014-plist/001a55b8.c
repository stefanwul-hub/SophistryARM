
undefined4 FUN_001a55b8(int param_1)

{
  uint uVar1;
  int iVar2;
  short sVar3;
  uint uVar4;
  uint uVar5;
  undefined4 uVar6;
  int iVar7;
  
  uVar1 = *(uint *)(param_1 + 0x10);
  uVar4 = uVar1;
  while( true ) {
    uVar5 = FUN_000349f4(*(undefined4 *)(param_1 + 0xc));
    if (uVar5 <= uVar4) break;
    sVar3 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
    if (((((0x19 < (ushort)(sVar3 - 0x61U)) && (0x19 < (ushort)(sVar3 - 0x41U))) &&
         (9 < (ushort)(sVar3 - 0x30U))) && ((sVar3 != 0x5f && (sVar3 != 0x24)))) &&
       ((sVar3 != 0x2f && ((sVar3 != 0x3a && (sVar3 != 0x2e)))))) break;
    uVar4 = *(int *)(param_1 + 0x10) + 1;
    *(uint *)(param_1 + 0x10) = uVar4;
  }
  if (uVar1 != *(uint *)(param_1 + 0x10)) {
    uVar6 = __Znwm(0x20);
    FUN_000332e2(uVar6);
    uVar6 = FUN_0002dfa6(uVar6);
    iVar2 = *(int *)(param_1 + 0x10);
    iVar7 = FUN_00036896(*(undefined4 *)(param_1 + 0xc));
    FUN_0003788a(uVar6,iVar7 + uVar1 * 2,iVar2 - uVar1);
    FUN_00034b8e(uVar6);
    return uVar6;
  }
  return 0;
}


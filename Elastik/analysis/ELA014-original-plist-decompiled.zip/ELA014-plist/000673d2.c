
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_000673d2(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  char *pcVar5;
  int iVar6;
  uint uVar7;
  char *pcVar8;
  char *pcVar9;
  char *pcVar10;
  char *pcVar11;
  bool bVar12;
  float fVar13;
  uint uStack_3c;
  int iStack_38;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 auStack_20 [4];
  
  bVar12 = *(int *)(param_1 + 0x24) == 0;
  if (bVar12) {
    pcVar5 = "";
    iVar6 = 5;
    pcVar9 = "dict";
    pcVar10 = pcVar5;
    do {
      pcVar8 = pcVar9;
      pcVar11 = pcVar10;
      if (iVar6 == 0) break;
      iVar6 = iVar6 + -1;
      pcVar11 = pcVar10 + 1;
      pcVar8 = pcVar9 + 1;
      bVar12 = *pcVar9 == *pcVar10;
      pcVar9 = pcVar8;
      pcVar10 = pcVar11;
    } while (bVar12);
    iVar6 = 0;
    if (!bVar12) {
      iVar6 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
    }
  }
  else {
    pcVar5 = *(char **)(param_1 + 0x20);
    iVar6 = 5;
    pcVar9 = "dict";
    pcVar10 = pcVar5;
    do {
      pcVar8 = pcVar9;
      pcVar11 = pcVar10;
      if (iVar6 == 0) break;
      iVar6 = iVar6 + -1;
      pcVar11 = pcVar10 + 1;
      pcVar8 = pcVar9 + 1;
      bVar12 = *pcVar9 == *pcVar10;
      pcVar9 = pcVar8;
      pcVar10 = pcVar11;
    } while (bVar12);
    iVar6 = 0;
    if (!bVar12) {
      iVar6 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
    }
  }
  bVar12 = iVar6 == 0;
  if (bVar12) {
    uVar2 = FUN_00066e46(param_1);
    return uVar2;
  }
  iVar6 = 6;
  pcVar9 = "array";
  pcVar10 = pcVar5;
  do {
    pcVar8 = pcVar9;
    pcVar11 = pcVar10;
    if (iVar6 == 0) break;
    iVar6 = iVar6 + -1;
    pcVar11 = pcVar10 + 1;
    pcVar8 = pcVar9 + 1;
    bVar12 = *pcVar9 == *pcVar10;
    pcVar9 = pcVar8;
    pcVar10 = pcVar11;
  } while (bVar12);
  iVar6 = 0;
  if (!bVar12) {
    iVar6 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
  }
  bVar12 = iVar6 == 0;
  if (bVar12) {
    uVar2 = func_0x00067a06(param_1);
    return uVar2;
  }
  iVar6 = 5;
  pcVar9 = "date";
  pcVar10 = pcVar5;
  do {
    pcVar8 = pcVar9;
    pcVar11 = pcVar10;
    if (iVar6 == 0) break;
    iVar6 = iVar6 + -1;
    pcVar11 = pcVar10 + 1;
    pcVar8 = pcVar9 + 1;
    bVar12 = *pcVar9 == *pcVar10;
    pcVar9 = pcVar8;
    pcVar10 = pcVar11;
  } while (bVar12);
  iVar6 = 0;
  if (!bVar12) {
    iVar6 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
  }
  bVar12 = iVar6 == 0;
  if (bVar12) {
    auStack_20[0] = 0;
    uStack_24 = 0;
    uStack_28 = 0;
    uStack_2c = 0;
    uStack_30 = 0;
    uStack_3c = 0;
    iVar6 = *(int *)(param_1 + 0x18);
    if (iVar6 != 0) {
      if (*(int *)(iVar6 + 0x24) == 0) {
        pcVar5 = "";
      }
      else {
        pcVar5 = *(char **)(iVar6 + 0x20);
      }
      _sscanf(pcVar5,"%d.%d.%d %d:%d:%d",&uStack_24,&uStack_28,auStack_20,&uStack_30,&uStack_3c,
              &uStack_2c);
      uVar2 = func_0x001a7df0(auStack_20[0],uStack_28,uStack_24,uStack_30,uStack_2c,uStack_3c);
      return uVar2;
    }
    uVar2 = __Znwm(0x14);
    func_0x001a7cfa(uVar2);
LAB_0006765e:
    piVar4 = (int *)FUN_0002dfa6(uVar2);
    uVar2 = (**(code **)(*piVar4 + 0x48))(piVar4);
    return uVar2;
  }
  iVar6 = 5;
  pcVar9 = "data";
  pcVar10 = pcVar5;
  do {
    pcVar8 = pcVar9;
    pcVar11 = pcVar10;
    if (iVar6 == 0) break;
    iVar6 = iVar6 + -1;
    pcVar11 = pcVar10 + 1;
    pcVar8 = pcVar9 + 1;
    bVar12 = *pcVar9 == *pcVar10;
    pcVar9 = pcVar8;
    pcVar10 = pcVar11;
  } while (bVar12);
  iVar6 = 0;
  if (!bVar12) {
    iVar6 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
  }
  bVar12 = iVar6 == 0;
  if (bVar12) {
    iVar6 = *(int *)(param_1 + 0x18);
    if (iVar6 != 0) {
      if (*(int *)(iVar6 + 0x24) == 0) {
        pcVar5 = "";
      }
      else {
        pcVar5 = *(char **)(iVar6 + 0x20);
      }
      uVar7 = 0xffffffff;
      do {
        if (uVar7 == 0) break;
        uVar7 = uVar7 - 1;
        cVar1 = *pcVar5;
        pcVar5 = pcVar5 + 1;
      } while (cVar1 != '\0');
      if (*(int *)(iVar6 + 0x24) == 0) {
        pcVar5 = "";
      }
      else {
        pcVar5 = *(char **)(iVar6 + 0x20);
      }
      uVar2 = func_0x0002803a(pcVar5,~uVar7 - 1);
      uVar2 = FUN_00038d00(uVar2,1000);
      uVar3 = FUN_00033b90("\n\t");
      uVar2 = func_0x0003e8aa(uVar2,uVar3);
      uVar2 = func_0x000281e8(uVar2);
      return uVar2;
    }
    uVar2 = __Znwm(0x20);
    FUN_0002765e(uVar2);
    goto LAB_0006765e;
  }
  iVar6 = 5;
  pcVar9 = "real";
  pcVar10 = pcVar5;
  do {
    pcVar8 = pcVar9;
    pcVar11 = pcVar10;
    if (iVar6 == 0) break;
    iVar6 = iVar6 + -1;
    pcVar11 = pcVar10 + 1;
    pcVar8 = pcVar9 + 1;
    bVar12 = *pcVar9 == *pcVar10;
    pcVar9 = pcVar8;
    pcVar10 = pcVar11;
  } while (bVar12);
  iVar6 = 0;
  if (!bVar12) {
    iVar6 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
  }
  bVar12 = iVar6 == 0;
  if (!bVar12) {
    iVar6 = 8;
    pcVar9 = "integer";
    pcVar10 = pcVar5;
    do {
      pcVar8 = pcVar9;
      pcVar11 = pcVar10;
      if (iVar6 == 0) break;
      iVar6 = iVar6 + -1;
      pcVar11 = pcVar10 + 1;
      pcVar8 = pcVar9 + 1;
      bVar12 = *pcVar9 == *pcVar10;
      pcVar9 = pcVar8;
      pcVar10 = pcVar11;
    } while (bVar12);
    iVar6 = 0;
    if (!bVar12) {
      iVar6 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
    }
    bVar12 = iVar6 == 0;
    if (bVar12) {
      uStack_3c = 0;
      iStack_38 = 0;
      iVar6 = *(int *)(param_1 + 0x18);
      if (iVar6 != 0) {
        if (*(int *)(iVar6 + 0x24) == 0) {
          pcVar5 = "";
        }
        else {
          pcVar5 = *(char **)(iVar6 + 0x20);
        }
        _sscanf(pcVar5,"%lld",&uStack_3c);
      }
      if ((iStack_38 + (uint)(0x80000000 < uStack_3c) == 0) && (uStack_3c != 0x80000000)) {
        uVar2 = func_0x000858da(uStack_3c);
        return uVar2;
      }
      uVar2 = func_0x000859a8(uStack_3c,iStack_38);
      return uVar2;
    }
    iVar6 = 7;
    pcVar9 = "string";
    pcVar10 = pcVar5;
    do {
      pcVar8 = pcVar9;
      pcVar11 = pcVar10;
      if (iVar6 == 0) break;
      iVar6 = iVar6 + -1;
      pcVar11 = pcVar10 + 1;
      pcVar8 = pcVar9 + 1;
      bVar12 = *pcVar9 == *pcVar10;
      pcVar9 = pcVar8;
      pcVar10 = pcVar11;
    } while (bVar12);
    iVar6 = 0;
    if (!bVar12) {
      iVar6 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
    }
    bVar12 = iVar6 == 0;
    if (!bVar12) {
      iVar6 = 5;
      pcVar9 = "true";
      pcVar10 = pcVar5;
      do {
        pcVar8 = pcVar9;
        pcVar11 = pcVar10;
        if (iVar6 == 0) break;
        iVar6 = iVar6 + -1;
        pcVar11 = pcVar10 + 1;
        pcVar8 = pcVar9 + 1;
        bVar12 = *pcVar9 == *pcVar10;
        pcVar9 = pcVar8;
        pcVar10 = pcVar11;
      } while (bVar12);
      iVar6 = 0;
      if (!bVar12) {
        iVar6 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar11[-1];
      }
      bVar12 = iVar6 == 0;
      if (bVar12) {
        uVar2 = func_0x00085800(1);
        return uVar2;
      }
      iVar6 = 6;
      pcVar9 = "false";
      do {
        pcVar10 = pcVar9;
        pcVar8 = pcVar5;
        if (iVar6 == 0) break;
        iVar6 = iVar6 + -1;
        pcVar8 = pcVar5 + 1;
        pcVar10 = pcVar9 + 1;
        bVar12 = *pcVar9 == *pcVar5;
        pcVar9 = pcVar10;
        pcVar5 = pcVar8;
      } while (bVar12);
      iVar6 = 0;
      if (!bVar12) {
        iVar6 = (uint)(byte)pcVar10[-1] - (uint)(byte)pcVar8[-1];
      }
      if (iVar6 == 0) {
        uVar2 = func_0x00085800(0);
        return uVar2;
      }
      uVar2 = FUN_00033b90("GNNotImplementedException");
      FUN_0000bfd6(uVar2,"Function %s not implemented yet in %s.","GetObjectForNode",
                   "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                  );
      return 0;
    }
    iVar6 = *(int *)(param_1 + 0x18);
    if (iVar6 == 0) {
      uVar2 = func_0x0003dd2a("");
      return uVar2;
    }
    if (*(int *)(iVar6 + 0x24) == 0) {
      pcVar5 = "";
    }
    else {
      pcVar5 = *(char **)(iVar6 + 0x20);
    }
    uVar7 = 0xffffffff;
    do {
      if (uVar7 == 0) break;
      uVar7 = uVar7 - 1;
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    if (*(int *)(iVar6 + 0x24) == 0) {
      pcVar5 = "";
    }
    else {
      pcVar5 = *(char **)(iVar6 + 0x20);
    }
    uVar2 = FUN_0003887c(pcVar5,~uVar7 - 1,1000);
    return uVar2;
  }
  iVar6 = *(int *)(param_1 + 0x18);
  if (iVar6 != 0) {
    if (piRam003d42c8 == (int *)0x0) {
      uVar2 = __Znwm(0x18);
      func_0x0018a902(uVar2);
      piRam003d42c8 = (int *)FUN_0002dfa6(uVar2);
      if (piRam003d42c8 == (int *)0x0) goto LAB_000677a9;
    }
    if (*(int *)(iVar6 + 0x24) == 0) {
      pcVar5 = "";
    }
    else {
      pcVar5 = *(char **)(iVar6 + 0x20);
    }
    uVar7 = 0xffffffff;
    do {
      if (uVar7 == 0) break;
      uVar7 = uVar7 - 1;
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    if (*(int *)(iVar6 + 0x24) == 0) {
      pcVar5 = "";
    }
    else {
      pcVar5 = *(char **)(iVar6 + 0x20);
    }
    iVar6 = func_0x00039d7a(pcVar5,~uVar7 - 1);
    if (iVar6 != 0) {
      (**(code **)(*piRam003d42c8 + 0x1a4))(piRam003d42c8,iVar6);
      cVar1 = (**(code **)(*piRam003d42c8 + 500))(piRam003d42c8,&uStack_3c);
      if (cVar1 != '\0') {
        fVar13 = (float)(double)CONCAT44(iStack_38,uStack_3c);
        goto LAB_00067753;
      }
    }
  }
LAB_000677a9:
  fVar13 = 0.0;
LAB_00067753:
  uVar2 = func_0x00085a2c(fVar13);
  return uVar2;
}


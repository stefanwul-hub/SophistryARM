
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000384d4(int param_1,char *param_2,int param_3,undefined *param_4)

{
  char cVar1;
  char *pcVar2;
  undefined4 uVar3;
  undefined1 *puVar4;
  int iVar5;
  uint uVar6;
  char *pcVar7;
  undefined *puVar8;
  undefined1 auStack_410 [944];
  undefined4 uStack_60;
  char *pcStack_5c;
  char *pcStack_58;
  undefined *puStack_54;
  int iStack_50;
  int *piStack_4c;
  char *pcStack_48;
  undefined4 *puStack_44;
  int iStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  undefined4 *puStack_20;
  int iStack_1c;
  int iStack_18;
  
  puVar8 = param_4;
  uStack_60 = 0x384e2;
  iStack_2c = param_1;
  uStack_30 = param_2;
  iStack_34 = param_3;
  if (param_1 == 0) {
    pcStack_5c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
    uStack_60 = 0x386e8;
    uVar3 = func_0x0000a930();
    pcStack_5c = "GNAssertionException";
    uStack_60 = 0x386f8;
    pcStack_5c = (char *)FUN_00033b90();
    piStack_4c = (int *)0x2c3b8c;
    puStack_54 = (undefined *)0x97f;
    pcStack_58 = "Assertion failed in line %d of %s: %s.";
    uStack_60 = 0x38720;
    iStack_50 = uVar3;
    FUN_0000bfd6();
  }
  if (iStack_34 < 0) {
    pcStack_5c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
    uStack_60 = 0x3869d;
    uVar3 = func_0x0000a930();
    pcStack_5c = "GNAssertionException";
    uStack_60 = 0x386ad;
    pcStack_5c = (char *)FUN_00033b90();
    piStack_4c = (int *)0x2c7114;
    puStack_54 = (undefined *)0x97f;
    pcStack_58 = "Assertion failed in line %d of %s: %s.";
    uStack_60 = 0x386d5;
    iStack_50 = uVar3;
    FUN_0000bfd6();
  }
  if (*(char *)(iStack_2c + 0x18) == '\0') {
    if ((*(int *)(iStack_2c + 0xc) == 0) && (*(int *)(iStack_2c + 0x14) != -1)) {
      pcStack_5c = (char *)iStack_2c;
      uStack_60 = 0x3867f;
      func_0x000340ba();
    }
    param_2 = *(char **)(iStack_2c + 0xc);
    if (param_2 == (char *)0x0) {
      param_2 = "";
    }
    if (cRam003d3f10 == '\0') {
      cRam003d3f10 = '\x01';
      _vsprintf(auStack_410,"Cannot modify an immutable string %s",&param_2);
      FUN_0000ab14(auStack_410);
      if (pcRam003d3f04 != (code *)0x0) {
        (*pcRam003d3f04)(auStack_410);
      }
      if (pcRam003d3f00 != (code *)0x0) {
        (*pcRam003d3f00)();
      }
      if (cRam003d3f08 == '\0') {
        uVar3 = func_0x00084aa2();
        func_0x00084bb6(uVar3);
        return;
      }
    }
    return;
  }
  if (iStack_34 != 0) {
    if (uStack_30 == (char *)0x0) {
      pcStack_5c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
      uStack_60 = 0x38743;
      uVar3 = func_0x0000a930();
      pcStack_5c = "GNAssertionException";
      uStack_60 = 0x38753;
      pcStack_5c = (char *)FUN_00033b90();
      piStack_4c = (int *)0x2c70dc;
      puStack_54 = (undefined *)0x987;
      pcStack_58 = "Assertion failed in line %d of %s: %s.";
      uStack_60 = 0x3877b;
      iStack_50 = uVar3;
      FUN_0000bfd6();
    }
    if ((*(int *)(iStack_2c + 0x14) != -1) || (puVar8 != (undefined *)0x0)) {
      if (*(int *)(iStack_2c + 0x14) == -1) {
        pcStack_5c = (char *)iStack_2c;
        uStack_60 = 0x38730;
        FUN_000358be();
      }
      if (*(int *)(iStack_2c + 0x10) == 0) {
        pcStack_5c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
        uStack_60 = 0x387f4;
        uVar3 = func_0x0000a930();
        pcStack_5c = "GNAssertionException";
        uStack_60 = 0x38804;
        pcStack_5c = (char *)FUN_00033b90();
        piStack_4c = (int *)0x2c709c;
        puStack_54 = (undefined *)0x9a9;
        pcStack_58 = "Assertion failed in line %d of %s: %s.";
        uStack_60 = 0x3882c;
        iStack_50 = uVar3;
        FUN_0000bfd6();
      }
      if (puVar8 == &UNK_0000270f) {
        puVar8 = (undefined *)0x3e8;
      }
      pcStack_5c = (char *)(iStack_34 * 4 + 4);
      uStack_60 = 0x3862f;
      iVar5 = FUN_0000aecc();
      iStack_50 = iStack_34;
      pcStack_5c = uStack_30;
      uStack_60 = 0x3864b;
      pcStack_58 = (char *)iVar5;
      puStack_54 = puVar8;
      puStack_54 = (undefined *)FUN_00189376();
      pcStack_5c = (char *)iStack_2c;
      uStack_60 = 0x3865e;
      pcStack_58 = (char *)iVar5;
      FUN_0003788a();
      puStack_20 = (undefined4 *)0xb12f;
      if (iVar5 != 0) {
        if (cRam003d3f09 == '\0') {
          cRam003d3f09 = 1;
          iStack_1c = iRam003d3ee8;
          if (iRam003d3ee8 != 0) {
            puStack_20 = (undefined4 *)0xb15c;
            iStack_18 = iVar5;
            func_0x000424ac();
          }
        }
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      pcVar7 = "GNFree(0)";
      if (cRam003d3ef8 == '\0') {
        uVar6 = 0xffffffff;
        pcVar2 = pcVar7;
        do {
          if (uVar6 == 0) break;
          uVar6 = uVar6 - 1;
          cVar1 = *pcVar2;
          pcVar2 = pcVar2 + 1;
        } while (cVar1 != '\0');
        if (~uVar6 - 1 < 0x2000) {
          piStack_4c = (int *)((~uVar6 - 1) * 3 + 0x400);
          iStack_50 = 0xabe9;
          pcVar2 = (char *)FUN_0000aecc();
          puStack_44 = &param_2;
          iStack_50 = 0xac04;
          piStack_4c = (int *)pcVar2;
          pcStack_48 = pcVar7;
          puStack_20 = puStack_44;
          _vsprintf();
          uStack_30 = (char *)CONCAT13(1,(undefined3)uStack_30);
        }
        else {
          uStack_30 = (char *)((uint)uStack_30 & 0xffffff);
          pcVar2 = pcVar7;
        }
        if (piRam003d3f0c == (int *)0x0) {
          piStack_4c = (int *)0x38;
          iStack_50 = 0xac19;
          uVar3 = __Znwm();
          iStack_50 = 0xac23;
          piStack_4c = (int *)uVar3;
          func_0x0006f04a();
          iStack_50 = 0xac2b;
          piStack_4c = (int *)uVar3;
          piRam003d3f0c = (int *)FUN_0002dfa6();
        }
        iStack_50 = 0xab76;
        piStack_4c = piRam003d3f0c;
        (**(code **)(*piRam003d3f0c + 0x1a4))();
        iStack_50 = 0xab7e;
        piStack_4c = (int *)pcVar2;
        _puts();
        piStack_4c = piRam003d3f0c;
        iStack_50 = 0xab8f;
        (**(code **)(*piRam003d3f0c + 0x1ac))();
        if (uStack_30._3_1_ != '\0') {
          if (pcVar2 != (char *)0x0) {
            if (cRam003d3f09 == '\0') {
              cRam003d3f09 = 1;
              piStack_4c = (int *)iRam003d3ee8;
              if (iRam003d3ee8 != 0) {
                iStack_50 = 0xabc3;
                pcStack_48 = pcVar2;
                func_0x000424ac();
              }
              cRam003d3f09 = '\0';
            }
            iStack_50 = 0xabd2;
            piStack_4c = (int *)pcVar2;
            _free();
            return;
          }
          piStack_4c = (int *)0x2c3dc0;
          iStack_50 = 0xac44;
          FUN_0000ab14();
        }
      }
      return;
    }
    if (*(char **)(iStack_2c + 0xc) == (char *)0x0) {
      iStack_24 = 0;
    }
    else {
      uVar6 = 0xffffffff;
      pcVar7 = *(char **)(iStack_2c + 0xc);
      do {
        if (uVar6 == 0) break;
        uVar6 = uVar6 - 1;
        cVar1 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar1 != '\0');
      iStack_24 = ~uVar6 - 1;
    }
    puStack_20 = (undefined4 *)0;
    if (uStack_30 != (char *)0x0) {
      puStack_20 = (undefined4 *)iStack_34;
    }
    iStack_28 = iStack_24 + (int)puStack_20;
    pcStack_5c = (char *)(iStack_28 + 1);
    uStack_60 = 0x385b1;
    puVar4 = (undefined1 *)FUN_0000aecc();
    if (puVar4 == (undefined1 *)0x0) {
      pcStack_5c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
      uStack_60 = 0x3883f;
      uVar3 = func_0x0000a930();
      pcStack_5c = "GNAssertionException";
      uStack_60 = 0x3884f;
      pcStack_5c = (char *)FUN_00033b90();
      piStack_4c = (int *)0x2c70e4;
      puStack_54 = (undefined *)0x994;
      pcStack_58 = "Assertion failed in line %d of %s: %s.";
      uStack_60 = 0x38877;
      iStack_50 = uVar3;
      FUN_0000bfd6();
    }
    *puVar4 = 0;
    if (iStack_24 != 0) {
      puStack_54 = (undefined *)iStack_24;
      pcStack_58 = *(char **)(iStack_2c + 0xc);
      uStack_60 = 0x387da;
      pcStack_5c = puVar4;
      _strncpy();
      puVar4[iStack_24] = 0;
    }
    if (puStack_20 != (undefined4 *)0x0) {
      puStack_54 = (undefined *)puStack_20;
      pcStack_58 = uStack_30;
      pcStack_5c = puVar4 + iStack_24;
      uStack_60 = 0x387b5;
      _strncpy();
      puVar4[iStack_28] = 0;
    }
    pcStack_5c = *(char **)(iStack_2c + 0xc);
    if (pcStack_5c == (char *)0x0) {
      *(undefined1 **)(iStack_2c + 0xc) = puVar4;
    }
    else {
      uStack_60 = 0x385ea;
      FUN_0000b122();
      *(undefined1 **)(iStack_2c + 0xc) = puVar4;
    }
  }
  return;
}



int * FUN_001a5d8a(int param_1)

{
  short sVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  
  uVar2 = __Znwm(0x20);
  FUN_00029d44(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  while( true ) {
    piVar4 = (int *)FUN_001a59d8(param_1);
    if (piVar4 == (int *)0x0) break;
    FUN_0002bb40(piVar3,piVar4);
    (**(code **)(*piVar4 + 0x44))(piVar4);
    FUN_001a4ffc(param_1);
    sVar1 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
    if (sVar1 != 0x2c) break;
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  }
  FUN_001a4ffc(param_1);
  sVar1 = FUN_00035d80(*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 0x10));
  if (sVar1 == 0x29) {
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  }
  else if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x44))(piVar3);
    piVar3 = (int *)0x0;
  }
  return piVar3;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000854fe(int param_1,dword param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 != 0) {
    *(undefined1 *)(param_1 + 0x10) = 0x69;
    *(dword *)(param_1 + 0xc) = param_2;
    return param_1;
  }
  uVar1 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNNumber.cpp"
                         );
  uVar2 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x9e,uVar1,"this != 0");
  mach_header_00000000.ncmds._0_1_ = 0x69;
  mach_header_00000000.filetype = param_2;
  return 0;
}


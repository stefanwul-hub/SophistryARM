
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00249b18(int param_1,undefined2 *param_2,int param_3,int param_4,int param_5,int param_6)

{
  byte bVar1;
  int iVar2;
  undefined2 uVar3;
  float fVar4;
  float fVar5;
  ushort uVar6;
  short sVar7;
  ushort uVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  short sVar12;
  ushort uVar13;
  ushort *puVar14;
  undefined2 *puVar15;
  uint uVar16;
  int iVar17;
  ushort *puStack_64;
  int iStack_50;
  uint uStack_4c;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int iStack_38;
  int iStack_34;
  uint uStack_30;
  ushort auStack_20 [8];
  
  _memset(*(undefined4 *)(param_1 + 0x44),0,
          (int)*(short *)(param_1 + 0x1a) * (int)*(short *)(param_1 + 0x3e) * 2);
  sVar7 = *(short *)(param_1 + 0x1a);
  iStack_44 = (int)sVar7;
  if (0 < sVar7) {
    iStack_50 = 0;
    puStack_64 = auStack_20;
    puVar15 = param_2;
    do {
      uVar3 = *puVar15;
      bVar1 = *(byte *)(puVar15 + 1);
      *puStack_64 = (ushort)bVar1;
      uVar6 = 0x58;
      if (bVar1 < 0x59) {
        uVar6 = (ushort)bVar1;
      }
      *puStack_64 = uVar6;
      if (*(char *)((int)puVar15 + 3) != '\0') {
        FUN_0000ab14("IMA ADPCM synchronisation error.");
      }
      *(undefined2 *)(*(int *)(param_1 + 0x44) + iStack_50 * 2) = uVar3;
      iStack_50 = iStack_50 + 1;
      puVar15 = puVar15 + 2;
      puStack_64 = puStack_64 + 1;
      iStack_44 = (int)*(short *)(param_1 + 0x1a);
    } while (iStack_50 < iStack_44);
    sVar7 = *(short *)(param_1 + 0x1a);
  }
  iStack_48 = iStack_44 * 4;
  iVar10 = (int)*(short *)(param_1 + 0x40);
  if (iStack_48 < iVar10) {
    do {
      iVar17 = (int)sVar7;
      if (0 < sVar7) {
        iStack_38 = iStack_48 + (int)param_2;
        iStack_34 = 0;
        do {
          iVar10 = iStack_44 + iStack_34;
          iVar9 = 0;
          do {
            bVar1 = *(byte *)(iStack_38 + iVar9);
            *(ushort *)(*(int *)(param_1 + 0x44) + iVar10 * 2) = bVar1 & 0xf;
            iVar10 = *(short *)(param_1 + 0x1a) + iVar10;
            *(ushort *)(*(int *)(param_1 + 0x44) + iVar10 * 2) = (ushort)(bVar1 >> 4);
            iVar17 = (int)*(short *)(param_1 + 0x1a);
            iVar10 = iVar10 + iVar17;
            iVar9 = iVar9 + 1;
          } while (iVar9 != 4);
          iStack_48 = iStack_48 + 4;
          iStack_34 = iStack_34 + 1;
          iStack_38 = iStack_38 + 4;
        } while (iStack_34 < iVar17);
        sVar7 = *(short *)(param_1 + 0x1a);
        iVar10 = (int)*(short *)(param_1 + 0x40);
      }
      iStack_44 = iStack_44 + iVar17 * 8;
    } while (iStack_48 < iVar10);
  }
  uVar16 = (uint)sVar7;
  iVar10 = (int)*(short *)(param_1 + 0x3e);
  if ((int)uVar16 < (int)(uVar16 * iVar10)) {
    iStack_3c = uVar16 * 2;
    uStack_4c = uVar16;
    if (sVar7 < 2) goto LAB_00249eae;
LAB_00249dc2:
    uStack_30 = uStack_4c & 0x80000001;
    if ((int)uStack_30 < 0) {
      uStack_30 = (uStack_30 - 1 | 0xfffffffe) + 1;
    }
    do {
      puVar14 = (ushort *)(iStack_3c + *(int *)(param_1 + 0x44));
      uVar6 = *puVar14;
      uVar8 = auStack_20[uStack_30];
      sVar7 = *(short *)((short)uVar8 * 4 + 0x367220);
      sVar12 = sVar7 >> 3;
      uVar11 = (uint)(short)(uVar6 & 0xf);
      if ((uVar11 & 1) != 0) {
        sVar12 = sVar12 + (sVar7 >> 2);
      }
      if ((uVar6 & 2) != 0) {
        sVar12 = sVar12 + (sVar7 >> 1);
      }
      if ((uVar11 & 4) != 0) {
        sVar12 = sVar12 + sVar7;
      }
      if ((uVar6 & 8) != 0) {
        sVar12 = -sVar12;
      }
      iVar10 = (int)*(short *)(*(int *)(param_1 + 0x44) + (uStack_4c - uVar16) * 2) + (int)sVar12;
      if (iVar10 < 0x8000) {
        iVar17 = -0x8000;
        if (-0x8001 < iVar10) {
          iVar17 = iVar10;
        }
        uVar13 = (ushort)iVar17;
        uVar8 = uVar8 + *(short *)(uVar11 * 4 + 0x3671e0);
        auStack_20[uStack_30] = uVar8;
        uVar6 = uVar13;
        if ((short)uVar8 < 0) goto LAB_00249ef4;
LAB_00249e6a:
        uVar13 = uVar6;
        if (0x58 < (short)uVar8) {
          auStack_20[uStack_30] = 0x58;
        }
      }
      else {
        uVar13 = 0x7fff;
        uVar8 = uVar8 + *(short *)(uVar11 * 4 + 0x3671e0);
        auStack_20[uStack_30] = uVar8;
        uVar6 = 0x7fff;
        if (-1 < (short)uVar8) goto LAB_00249e6a;
LAB_00249ef4:
        auStack_20[uStack_30] = 0;
      }
      *puVar14 = uVar13;
      uStack_4c = uStack_4c + 1;
      uVar16 = (uint)*(short *)(param_1 + 0x1a);
      iStack_3c = iStack_3c + 2;
      iVar10 = (int)*(short *)(param_1 + 0x3e);
      if ((int)(iVar10 * uVar16) <= (int)uStack_4c) break;
      if (1 < *(short *)(param_1 + 0x1a)) goto LAB_00249dc2;
LAB_00249eae:
      uStack_30 = 0;
    } while( true );
  }
  fVar5 = FLOAT_00365ee8;
  fVar4 = FLOAT_00365df4;
  if (0 < *(short *)(param_1 + 0x3e)) {
    iVar17 = (param_6 - param_3) * 4;
    iStack_40 = 0;
    do {
      if (((param_3 <= iStack_40) && (iStack_40 < param_4)) &&
         (iVar9 = (int)*(short *)(param_1 + 0x1a), 0 < iVar9)) {
        iVar10 = 0;
LAB_00249c99:
        do {
          iVar2 = *(int *)(param_5 + iVar10 * 4);
          if (iVar2 != 0) {
            sVar7 = *(short *)(*(int *)(param_1 + 0x44) + (iVar10 + iVar9 * iStack_40) * 2);
            if (sVar7 < 1) {
              *(float *)(iVar2 + iVar17) = (float)(int)sVar7 * fVar4;
              iVar9 = (int)*(short *)(param_1 + 0x1a);
              iVar10 = iVar10 + 1;
              if (iVar9 <= iVar10) break;
              goto LAB_00249c99;
            }
            *(float *)(iVar2 + iVar17) = (float)(int)sVar7 / fVar5;
            iVar9 = (int)*(short *)(param_1 + 0x1a);
          }
          iVar10 = iVar10 + 1;
        } while (iVar10 < iVar9);
        iVar10 = (int)*(short *)(param_1 + 0x3e);
      }
      iStack_40 = iStack_40 + 1;
      iVar17 = iVar17 + 4;
    } while (iStack_40 < iVar10);
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0017f560(int param_1,dword param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 != 0) {
    *(dword *)(param_1 + 0x14) = param_2;
    return;
  }
  uVar1 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                         );
  uVar2 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x2fd,uVar1,"this != 0");
  mach_header_00000000.sizeofcmds = param_2;
  return;
}


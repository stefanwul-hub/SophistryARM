
undefined * FUN_00249976(int param_1)

{
  short sVar1;
  
  sVar1 = *(short *)(param_1 + 0x1e);
  if (sVar1 == 2) {
    return (undefined *)0x49;
  }
  if (sVar1 < 3) {
    if (sVar1 == 1) {
      sVar1 = *(short *)(param_1 + 0x1c);
      if (sVar1 == 0x10) {
        return (undefined *)0x10;
      }
      if (sVar1 < 0x11) {
        if (sVar1 == 8) {
          return (undefined *)0x45;
        }
      }
      else {
        if (sVar1 == 0x18) {
          return (undefined *)0x11;
        }
        if (sVar1 == 0x20) {
          return (undefined *)0x12;
        }
      }
    }
  }
  else if (sVar1 == 3) {
    if (*(short *)(param_1 + 0x1c) == 0x20) {
      return (undefined *)0x13;
    }
  }
  else if (sVar1 == 0x11) {
    return (undefined *)0x48;
  }
  return &UNK_0000270f;
}


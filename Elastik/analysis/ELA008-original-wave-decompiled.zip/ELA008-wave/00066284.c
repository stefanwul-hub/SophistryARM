
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00066284(int param_1,int *param_2,int param_3)

{
  char cVar1;
  char *pcVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  int *piVar8;
  uint uVar9;
  char *pcVar10;
  int iStack_14;
  
  iVar3 = param_3;
  piVar6 = param_2;
  if (param_1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xfe,uVar4,"this != 0");
  }
  if (*(int *)(param_1 + 0xc) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xfe,uVar4,"_keys");
  }
  if (*(int *)(param_1 + 0x10) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xfe,uVar4,"_objects");
  }
  if (iVar3 == 0) {
    func_0x0000acae("GNDictionary: key is 0");
  }
  if ((piVar6 == (int *)0x0) && (cVar1 = func_0x000639f0(param_1), cVar1 == '\0')) {
    pcVar2 = "Attempt to insert 0 as an object into a dictionary";
    if (cRam003d3ef8 == '\0') {
      uVar9 = 0xffffffff;
      pcVar10 = pcVar2;
      do {
        if (uVar9 == 0) break;
        uVar9 = uVar9 - 1;
        cVar1 = *pcVar10;
        pcVar10 = pcVar10 + 1;
      } while (cVar1 != '\0');
      cVar1 = ~uVar9 - 1 < 0x2000;
      if ((bool)cVar1) {
        pcVar2 = (char *)FUN_0000aecc((~uVar9 - 1) * 3 + 0x400);
        _vsprintf(pcVar2,"Attempt to insert 0 as an object into a dictionary",&param_2);
      }
      if (piRam003d3f0c == (int *)0x0) {
        uVar4 = __Znwm(0x38);
        FUN_0006f04a(uVar4);
        piRam003d3f0c = (int *)FUN_0002dfa6(uVar4);
      }
      (**(code **)(*piRam003d3f0c + 0x1a4))(piRam003d3f0c);
      _puts(pcVar2);
      (**(code **)(*piRam003d3f0c + 0x1ac))(piRam003d3f0c);
      if (cVar1 != '\0') {
        if (pcVar2 != (char *)0x0) {
          if (cRam003d3f09 == '\0') {
            cRam003d3f09 = 1;
            if (iRam003d3ee8 != 0) {
              func_0x000424ac(iRam003d3ee8,pcVar2);
            }
            cRam003d3f09 = '\0';
          }
          _free(pcVar2);
          return;
        }
        FUN_0000ab14("GNFree(0)");
      }
    }
    return;
  }
  if (*(int *)(param_1 + 0x14) == 0) {
    iVar7 = func_0x0002a9ba(*(undefined4 *)(param_1 + 0xc),iVar3);
  }
  else {
    iVar7 = func_0x0006440e(param_1,iVar3);
  }
  if (iVar7 != -1) {
    piVar8 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0x10),iVar7);
    if (piVar6 == piVar8) {
      return;
    }
    FUN_0002a62c(*(undefined4 *)(param_1 + 0x10),iVar7);
    piVar8 = *(int **)(param_1 + 0x10);
    param_2 = piVar6;
    param_3 = iVar7;
    if (piVar8 == (int *)0x0) {
      uVar4 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                             );
      uVar5 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x18c,uVar4,"this != 0");
    }
    if ((param_2 == (int *)0x0) && (*(char *)((int)piVar8 + 0x19) == '\0')) {
      uVar4 = (**(code **)(*piVar8 + 0xc))(piVar8);
      uVar4 = FUN_00034962(uVar4);
      func_0x0000acae("GNList::insertObjectAtIndex(): Cannot insert nil object into %s.",uVar4);
    }
    if ((piVar8[4] < param_3) || (param_3 < 0)) {
      uVar4 = (**(code **)(*piVar8 + 0xc))(piVar8);
      uVar4 = FUN_00034962(uVar4);
      func_0x0000acae("GNList::insertObjectAtIndex(): Index %i out of range of %s.",param_3,uVar4);
      iVar3 = piVar8[4] + 1;
      piVar8[4] = iVar3;
    }
    else {
      iVar3 = piVar8[4] + 1;
      piVar8[4] = iVar3;
    }
    iVar7 = iVar3 * 0x10 + 1;
    if (iVar7 < 0) {
      iVar7 = iVar3 * 0x10 + 0x10;
    }
    FUN_0002a14a(piVar8,iVar7 >> 4);
    iVar3 = piVar8[4] + -1;
    if (param_3 < iVar3) {
      iVar7 = iVar3 * 4;
      do {
        *(undefined4 *)(iVar7 + piVar8[3]) = ((undefined4 *)(iVar7 + piVar8[3]))[-1];
        iVar3 = iVar3 + -1;
        iVar7 = iVar7 + -4;
      } while (param_3 < iVar3);
    }
    *(int **)(piVar8[3] + param_3 * 4) = param_2;
    if (((char)piVar8[6] == '\0') && (param_2 != (int *)0x0)) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
    return;
  }
  FUN_0002bb40(*(undefined4 *)(param_1 + 0xc),iVar3);
  FUN_0002bb40(*(undefined4 *)(param_1 + 0x10),piVar6);
  iVar3 = FUN_00029ddc(*(undefined4 *)(param_1 + 0xc));
  param_2 = (int *)(iVar3 + -1);
  if (*(int *)(param_1 + 0x14) != 0) {
    piVar6 = (int *)func_0x000427b6(*(int *)(param_1 + 0x14));
    iVar3 = FUN_00041be2(*(undefined4 *)(param_1 + 0x14));
    piVar8 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0xc),param_2);
    iStack_14 = (**(code **)(*piVar8 + 0x90))(piVar8);
    if (iVar3 < 1) {
code_r0x00066056:
      func_0x00042ffe(*(undefined4 *)(param_1 + 0x14),&iStack_14);
      return;
    }
    if (*piVar6 == iStack_14 || *piVar6 - iStack_14 < 0) {
      iVar7 = 0;
      do {
        piVar6 = piVar6 + 2;
        iVar7 = iVar7 + 1;
        if (iVar3 == iVar7) goto code_r0x00066056;
      } while (*piVar6 == iStack_14 || *piVar6 - iStack_14 < 0);
    }
    else {
      iVar7 = 0;
    }
    func_0x00042dcc(*(undefined4 *)(param_1 + 0x14),&iStack_14,iVar7);
  }
  return;
}


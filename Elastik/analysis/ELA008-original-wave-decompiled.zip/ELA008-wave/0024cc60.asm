0024cc60  55  PUSH EBP
0024cc61  89e5  MOV EBP,ESP
0024cc63  57  PUSH EDI
0024cc64  56  PUSH ESI
0024cc65  53  PUSH EBX
0024cc66  83ec5c  SUB ESP,0x5c
0024cc69  e8ae830900  CALL 0x002e501c
0024cc6e  8b5508  MOV EDX,dword ptr [EBP + 0x8]
0024cc71  0fb7421e  MOVZX EAX,word ptr [EDX + 0x1e]
0024cc75  6683f802  CMP AX,0x2
0024cc79  7447  JZ 0x0024ccc2
0024cc7b  7e33  JLE 0x0024ccb0
0024cc7d  6683f803  CMP AX,0x3
0024cc81  0f845c010000  JZ 0x0024cde3
0024cc87  6683f811  CMP AX,0x11
0024cc8b  752d  JNZ 0x0024ccba
0024cc8d  8b5508  MOV EDX,dword ptr [EBP + 0x8]
0024cc90  0fbf723e  MOVSX ESI,word ptr [EDX + 0x3e]
0024cc94  0fbf521a  MOVSX EDX,word ptr [EDX + 0x1a]
0024cc98  89f0  MOV EAX,ESI
0024cc9a  89d1  MOV ECX,EDX
0024cc9c  99  CDQ
0024cc9d  f7f9  IDIV ECX
0024cc9f  8945c8  MOV dword ptr [EBP + -0x38],EAX
0024cca2  8b7508  MOV ESI,dword ptr [EBP + 0x8]
0024cca5  0fbf7640  MOVSX ESI,word ptr [ESI + 0x40]
0024cca9  8975cc  MOV dword ptr [EBP + -0x34],ESI
0024ccac  89f0  MOV EAX,ESI
0024ccae  eb20  JMP 0x0024ccd0
0024ccb0  6683e801  SUB AX,0x1
0024ccb4  0f8429010000  JZ 0x0024cde3
0024ccba  83c45c  ADD ESP,0x5c
0024ccbd  5b  POP EBX
0024ccbe  5e  POP ESI
0024ccbf  5f  POP EDI
0024ccc0  5d  POP EBP
0024ccc1  c3  RET
0024ccc2  0fbf7238  MOVSX ESI,word ptr [EDX + 0x38]
0024ccc6  8975c8  MOV dword ptr [EBP + -0x38],ESI
0024ccc9  0fbf423a  MOVSX EAX,word ptr [EDX + 0x3a]
0024cccd  8945cc  MOV dword ptr [EBP + -0x34],EAX
0024ccd0  890424  MOV dword ptr [ESP],EAX
0024ccd3  e8f4e1dbff  CALL 0x0000aecc
0024ccd8  8945d0  MOV dword ptr [EBP + -0x30],EAX
0024ccdb  8b4510  MOV EAX,dword ptr [EBP + 0x10]
0024ccde  99  CDQ
0024ccdf  f77dc8  IDIV dword ptr [EBP + -0x38]
0024cce2  89d7  MOV EDI,EDX
0024cce4  89c6  MOV ESI,EAX
0024cce6  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
0024cce9  8b5114  MOV EDX,dword ptr [ECX + 0x14]
0024ccec  8b0a  MOV ECX,dword ptr [EDX]
0024ccee  8b45cc  MOV EAX,dword ptr [EBP + -0x34]
0024ccf1  0fafc6  IMUL EAX,ESI
0024ccf4  8b7508  MOV ESI,dword ptr [EBP + 0x8]
0024ccf7  034630  ADD EAX,dword ptr [ESI + 0x30]
0024ccfa  89442404  MOV dword ptr [ESP + 0x4],EAX
0024ccfe  891424  MOV dword ptr [ESP],EDX
0024cd01  ff91c0010000  CALL dword ptr [ECX + 0x1c0]
0024cd07  c745c400000000  MOV dword ptr [EBP + -0x3c],0x0
0024cd0e  8d45e4  LEA EAX,[EBP + -0x1c]
0024cd11  8945bc  MOV dword ptr [EBP + -0x44],EAX
0024cd14  eb5c  JMP 0x0024cd72
0024cd16  8b55c8  MOV EDX,dword ptr [EBP + -0x38]
0024cd19  8955c0  MOV dword ptr [EBP + -0x40],EDX
0024cd1c  8b45cc  MOV EAX,dword ptr [EBP + -0x34]
0024cd1f  8945e4  MOV dword ptr [EBP + -0x1c],EAX
0024cd22  8b5508  MOV EDX,dword ptr [EBP + 0x8]
0024cd25  8b4214  MOV EAX,dword ptr [EDX + 0x14]
0024cd28  8b10  MOV EDX,dword ptr [EAX]
0024cd2a  8b4dbc  MOV ECX,dword ptr [EBP + -0x44]
0024cd2d  894c2408  MOV dword ptr [ESP + 0x8],ECX
0024cd31  8b4dd0  MOV ECX,dword ptr [EBP + -0x30]
0024cd34  894c2404  MOV dword ptr [ESP + 0x4],ECX
0024cd38  890424  MOV dword ptr [ESP],EAX
0024cd3b  ff92ac010000  CALL dword ptr [EDX + 0x1ac]
0024cd41  84c0  TEST AL,AL
0024cd43  7408  JZ 0x0024cd4d
0024cd45  8b45cc  MOV EAX,dword ptr [EBP + -0x34]
0024cd48  3b45e4  CMP EAX,dword ptr [EBP + -0x1c]
0024cd4b  743d  JZ 0x0024cd8a
0024cd4d  8d83b2730700  LEA EAX,[EBX + 0x773b2]
0024cd53  890424  MOV dword ptr [ESP],EAX
0024cd56  e8356edeff  CALL 0x00033b90
0024cd5b  890424  MOV dword ptr [ESP],EAX
0024cd5e  e8d1f1dbff  CALL 0x0000bf34
0024cd63  0175c4  ADD dword ptr [EBP + -0x3c],ESI
0024cd66  297514  SUB dword ptr [EBP + 0x14],ESI
0024cd69  8b4514  MOV EAX,dword ptr [EBP + 0x14]
0024cd6c  85c0  TEST EAX,EAX
0024cd6e  7e60  JLE 0x0024cdd0
0024cd70  31ff  XOR EDI,EDI
0024cd72  8b75c8  MOV ESI,dword ptr [EBP + -0x38]
0024cd75  29fe  SUB ESI,EDI
0024cd77  397514  CMP dword ptr [EBP + 0x14],ESI
0024cd7a  7f9a  JG 0x0024cd16
0024cd7c  8b4d14  MOV ECX,dword ptr [EBP + 0x14]
0024cd7f  01f9  ADD ECX,EDI
0024cd81  894dc0  MOV dword ptr [EBP + -0x40],ECX
0024cd84  89ce  MOV ESI,ECX
0024cd86  29fe  SUB ESI,EDI
0024cd88  eb92  JMP 0x0024cd1c
0024cd8a  8b5508  MOV EDX,dword ptr [EBP + 0x8]
0024cd8d  66837a1e02  CMP word ptr [EDX + 0x1e],0x2
0024cd92  0f84ad000000  JZ 0x0024ce45
0024cd98  8b55c4  MOV EDX,dword ptr [EBP + -0x3c]
0024cd9b  89542414  MOV dword ptr [ESP + 0x14],EDX
0024cd9f  8b4d0c  MOV ECX,dword ptr [EBP + 0xc]
0024cda2  894c2410  MOV dword ptr [ESP + 0x10],ECX
0024cda6  8b45c0  MOV EAX,dword ptr [EBP + -0x40]
0024cda9  8944240c  MOV dword ptr [ESP + 0xc],EAX
0024cdad  897c2408  MOV dword ptr [ESP + 0x8],EDI
0024cdb1  8b55d0  MOV EDX,dword ptr [EBP + -0x30]
0024cdb4  89542404  MOV dword ptr [ESP + 0x4],EDX
0024cdb8  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
0024cdbb  890c24  MOV dword ptr [ESP],ECX
0024cdbe  e855cdffff  CALL 0x00249b18
0024cdc3  0175c4  ADD dword ptr [EBP + -0x3c],ESI
0024cdc6  297514  SUB dword ptr [EBP + 0x14],ESI
0024cdc9  8b4514  MOV EAX,dword ptr [EBP + 0x14]
0024cdcc  85c0  TEST EAX,EAX
0024cdce  7fa0  JG 0x0024cd70
0024cdd0  8b75d0  MOV ESI,dword ptr [EBP + -0x30]
0024cdd3  893424  MOV dword ptr [ESP],ESI
0024cdd6  e847e3dbff  CALL 0x0000b122
0024cddb  83c45c  ADD ESP,0x5c
0024cdde  5b  POP EBX
0024cddf  5e  POP ESI
0024cde0  5f  POP EDI
0024cde1  5d  POP EBP
0024cde2  c3  RET
0024cde3  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
0024cde6  8b7914  MOV EDI,dword ptr [ECX + 0x14]
0024cde9  8b7130  MOV ESI,dword ptr [ECX + 0x30]
0024cdec  8975d4  MOV dword ptr [EBP + -0x2c],ESI
0024cdef  8b01  MOV EAX,dword ptr [ECX]
0024cdf1  890c24  MOV dword ptr [ESP],ECX
0024cdf4  ff90b4010000  CALL dword ptr [EAX + 0x1b4]
0024cdfa  89c6  MOV ESI,EAX
0024cdfc  8b5508  MOV EDX,dword ptr [EBP + 0x8]
0024cdff  8b02  MOV EAX,dword ptr [EDX]
0024ce01  891424  MOV dword ptr [ESP],EDX
0024ce04  ff90b0010000  CALL dword ptr [EAX + 0x1b0]
0024ce0a  897c241c  MOV dword ptr [ESP + 0x1c],EDI
0024ce0e  8b4dd4  MOV ECX,dword ptr [EBP + -0x2c]
0024ce11  894c2418  MOV dword ptr [ESP + 0x18],ECX
0024ce15  89742414  MOV dword ptr [ESP + 0x14],ESI
0024ce19  89442410  MOV dword ptr [ESP + 0x10],EAX
0024ce1d  8b7514  MOV ESI,dword ptr [EBP + 0x14]
0024ce20  8974240c  MOV dword ptr [ESP + 0xc],ESI
0024ce24  8b4510  MOV EAX,dword ptr [EBP + 0x10]
0024ce27  89442408  MOV dword ptr [ESP + 0x8],EAX
0024ce2b  8b550c  MOV EDX,dword ptr [EBP + 0xc]
0024ce2e  89542404  MOV dword ptr [ESP + 0x4],EDX
0024ce32  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
0024ce35  890c24  MOV dword ptr [ESP],ECX
0024ce38  e8e3c9fcff  CALL 0x00219820
0024ce3d  83c45c  ADD ESP,0x5c
0024ce40  5b  POP EBX
0024ce41  5e  POP ESI
0024ce42  5f  POP EDI
0024ce43  5d  POP EBP
0024ce44  c3  RET
0024ce45  8b4dc4  MOV ECX,dword ptr [EBP + -0x3c]
0024ce48  894c2414  MOV dword ptr [ESP + 0x14],ECX
0024ce4c  8b450c  MOV EAX,dword ptr [EBP + 0xc]
0024ce4f  89442410  MOV dword ptr [ESP + 0x10],EAX
0024ce53  8b55c0  MOV EDX,dword ptr [EBP + -0x40]
0024ce56  8954240c  MOV dword ptr [ESP + 0xc],EDX
0024ce5a  897c2408  MOV dword ptr [ESP + 0x8],EDI
0024ce5e  8b4dd0  MOV ECX,dword ptr [EBP + -0x30]
0024ce61  894c2404  MOV dword ptr [ESP + 0x4],ECX
0024ce65  8b4508  MOV EAX,dword ptr [EBP + 0x8]
0024ce68  890424  MOV dword ptr [ESP],EAX
0024ce6b  e8c8f7ffff  CALL 0x0024c638
0024ce70  e9eefeffff  JMP 0x0024cd63

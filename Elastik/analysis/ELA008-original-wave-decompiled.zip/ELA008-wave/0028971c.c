
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0028971c(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  func_0x0002dc66(param_1);
  *param_1 = &UNK_003b3988;
  FUN_0028983c();
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  *param_1 = &UNK_003b4408;
  if (iRam003d9e98 != 0) {
    return;
  }
  uVar1 = FUN_00033b90("GNSoundFileInstrumentChunk");
  uVar2 = FUN_00033b90("GNSoundFileAifInstrumentChunk");
  iRam003d9e98 = FUN_0001fe74(uVar2,&UNK_00289802,uVar1);
  return;
}


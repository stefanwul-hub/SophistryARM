
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_00180166(int *param_1,int param_2)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 uVar5;
  int aiStack_20 [4];
  
  aiStack_20[0] = 0;
  if (param_1 == (int *)0x0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x457,uVar3,"this != 0");
  }
  if (param_2 < 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x457,uVar3,"length >= 0");
  }
  uVar3 = __Znwm(0x20);
  FUN_0002765e(uVar3);
  piVar4 = (int *)FUN_0002dfa6(uVar3);
  piVar4 = (int *)(**(code **)(*piVar4 + 0x48))(piVar4);
  if (param_2 != 0) {
    (**(code **)(*piVar4 + 0x1a4))(piVar4,param_2);
    FUN_00027b4e(piVar4);
    aiStack_20[0] = param_2;
    pcVar1 = *(code **)(*param_1 + 0x1ac);
    uVar3 = FUN_00027abc(piVar4);
    cVar2 = (*pcVar1)(param_1,uVar3,aiStack_20);
    if (cVar2 != '\0') {
      FUN_00027bec(piVar4);
      (**(code **)(*piVar4 + 0x1a4))(piVar4,aiStack_20[0]);
      return piVar4;
    }
    FUN_00027bec(piVar4);
    piVar4 = (int *)0x0;
  }
  return piVar4;
}


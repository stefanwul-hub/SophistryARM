
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0028983c(void)

{
  int *piVar1;
  int iVar2;
  
  iRam003d9eb0 = iRam003d9eb0 + 1;
  if (iRam003d9eb0 != 1) {
    return;
  }
  piVar1 = (int *)__Znwm(0xc);
  func_0x0002dc66(piVar1);
  *piVar1 = (int)&UNK_003b3988;
  FUN_0028983c();
  (**(code **)(*piVar1 + 8))(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + 1;
  (**(code **)(*piVar1 + 4))(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + -1;
  piVar1 = (int *)__Znwm(0x24);
  func_0x0002dc66(piVar1);
  *piVar1 = (int)&UNK_003b3988;
  FUN_0028983c();
  *piVar1 = (int)&UNK_003b3b48;
  piVar1[6] = 0;
  *(undefined1 *)(piVar1 + 3) = 0;
  piVar1[7] = 0;
  piVar1[4] = 0;
  piVar1[5] = 0;
  piVar1[8] = 0;
  (*_UNK_003b3b50)(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + 1;
  (**(code **)(*piVar1 + 4))(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + -1;
  piVar1 = (int *)__Znwm(0x28);
  func_0x0002dc66(piVar1);
  *piVar1 = (int)&UNK_003b3988;
  FUN_0028983c();
  *piVar1 = (int)&UNK_003b4088;
  piVar1[3] = 0;
  piVar1[4] = 0;
  piVar1[5] = 0;
  piVar1[6] = 0;
  piVar1[7] = 0;
  piVar1[8] = 0;
  piVar1[9] = 0;
  (*_UNK_003b4090)(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + 1;
  (**(code **)(*piVar1 + 4))(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + -1;
  piVar1 = (int *)__Znwm(0x28);
  func_0x0002dc66(piVar1);
  *piVar1 = (int)&UNK_003b3988;
  FUN_0028983c();
  piVar1[3] = 0;
  piVar1[4] = 0;
  piVar1[5] = 0;
  piVar1[6] = 0;
  piVar1[7] = 0;
  piVar1[8] = 0;
  piVar1[9] = 0;
  *piVar1 = (int)&UNK_003b4248;
  (*_UNK_003b4250)(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + 1;
  (**(code **)(*piVar1 + 4))(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + -1;
  piVar1 = (int *)__Znwm(0x28);
  FUN_0028971c(piVar1);
  (**(code **)(*piVar1 + 8))(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + 1;
  (**(code **)(*piVar1 + 4))(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + -1;
  piVar1 = (int *)__Znwm(0x24);
  func_0x0002dc66(piVar1);
  *piVar1 = (int)&UNK_003b3988;
  FUN_0028983c();
  piVar1[6] = 0;
  *(undefined1 *)(piVar1 + 3) = 0;
  piVar1[7] = 0;
  piVar1[4] = 0;
  piVar1[5] = 0;
  piVar1[8] = 0;
  *piVar1 = (int)&UNK_003b3d08;
  (*_UNK_003b3d10)(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + 1;
  (**(code **)(*piVar1 + 4))(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + -1;
  piVar1 = (int *)__Znwm(0x24);
  FUN_0028a128(piVar1);
  (**(code **)(*piVar1 + 8))(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + 1;
  (**(code **)(*piVar1 + 4))(piVar1);
  iVar2 = func_0x000410a8();
  *(int *)(iVar2 + 0x20) = *(int *)(iVar2 + 0x20) + -1;
  return;
}


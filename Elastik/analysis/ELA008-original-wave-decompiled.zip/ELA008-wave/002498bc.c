
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_002498bc(int param_1,int param_2)

{
  char cVar1;
  char *pcVar2;
  undefined4 uVar3;
  uint uVar4;
  char *pcVar5;
  int aiStack_20 [4];
  
  aiStack_20[0] = param_2;
  pcVar2 = (char *)__Znam(param_2 + 1);
  _memset(pcVar2,0,param_2 + 1);
  cVar1 = (**(code **)(**(int **)(param_1 + 0x14) + 0x1ac))
                    (*(int **)(param_1 + 0x14),pcVar2,aiStack_20);
  if (cVar1 == '\0') {
    uVar3 = FUN_00033b90("GNSoundFileCannotReadFileException");
    FUN_0000bf34(uVar3);
  }
  uVar4 = 0xffffffff;
  pcVar5 = pcVar2;
  do {
    if (uVar4 == 0) break;
    uVar4 = uVar4 - 1;
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  uVar3 = FUN_0003887c(pcVar2,~uVar4 - 1,4);
  __ZdlPv(pcVar2);
  return uVar3;
}


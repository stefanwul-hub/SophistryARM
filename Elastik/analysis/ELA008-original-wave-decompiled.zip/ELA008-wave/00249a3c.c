
undefined4 FUN_00249a3c(int param_1)

{
  return *(undefined4 *)(param_1 + 0x28);
}


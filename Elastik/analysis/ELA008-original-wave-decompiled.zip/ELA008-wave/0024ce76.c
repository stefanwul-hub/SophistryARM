
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0024ce76(int *param_1,int *param_2)

{
  short sVar1;
  code *pcVar2;
  short sVar3;
  bool bVar4;
  char cVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 uVar10;
  int iVar11;
  uint uVar12;
  undefined4 uVar13;
  char *pcVar14;
  int *piVar15;
  int iVar16;
  undefined4 uVar17;
  uint uVar18;
  int iVar19;
  char *pcVar20;
  int iVar21;
  char *pcVar22;
  char *pcVar23;
  undefined1 uVar24;
  bool bVar25;
  bool bVar26;
  undefined8 uVar27;
  char *pcStack_ec;
  int *piStack_b4;
  uint uStack_b0;
  int iStack_9c;
  int iStack_98;
  int iStack_94;
  int iStack_90;
  int iStack_8c;
  int iStack_88;
  int iStack_80;
  int iStack_6c;
  int *piStack_58;
  int *piStack_54;
  int iStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  char cStack_41;
  undefined1 uStack_40;
  undefined1 uStack_3f;
  undefined1 uStack_3e;
  undefined1 uStack_3d;
  uint uStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  uint uStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  char acStack_24 [4];
  undefined1 auStack_20 [3];
  undefined1 auStack_1d [13];
  
  cStack_41 = '\0';
  uStack_40 = 0;
  uStack_3f = 0;
  uStack_3e = 0;
  uStack_3d = 0;
  uVar6 = __Znwm(0x18);
  FUN_000630b6(uVar6);
  piVar7 = (int *)FUN_0002dfa6(uVar6);
  uVar6 = (**(code **)(*piVar7 + 0x48))(piVar7);
  uVar8 = __Znwm(0x20);
  FUN_00029d44(uVar8);
  piVar7 = (int *)FUN_0002dfa6(uVar8);
  uVar8 = (**(code **)(*piVar7 + 0x48))(piVar7);
  iVar9 = (**(code **)(*param_2 + 0x248))(param_2);
  param_1[5] = iVar9;
  if (iVar9 == 0) {
    uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
    FUN_0000bf34(uVar10);
  }
  piVar7 = (int *)param_1[5];
  if (piVar7 != (int *)0x0) {
    (**(code **)(*piVar7 + 0x40))(piVar7);
    piVar7 = (int *)param_1[5];
  }
  FUN_0017f560(piVar7,0);
  uStack_28 = 4;
  cVar5 = (**(code **)(*(int *)param_1[5] + 0x1ac))((int *)param_1[5],&cStack_41,&uStack_28);
  uVar24 = cVar5 == '\0';
  if ((bool)uVar24) {
    uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
    FUN_0000bf34(uVar10);
  }
  iVar9 = 4;
  pcVar14 = &cStack_41;
  pcVar22 = "RIFF";
  do {
    pcVar20 = pcVar14;
    pcVar23 = pcVar22;
    if (iVar9 == 0) break;
    iVar9 = iVar9 + -1;
    pcVar23 = pcVar22 + 1;
    pcVar20 = pcVar14 + 1;
    uVar24 = *pcVar14 == *pcVar22;
    pcVar14 = pcVar20;
    pcVar22 = pcVar23;
  } while ((bool)uVar24);
  iVar9 = 0;
  if (!(bool)uVar24) {
    iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
  }
  if (iVar9 != 0) {
    uVar10 = FUN_00033b90("GNSoundFileFormatNotSupportedException");
    FUN_0000bf34(uVar10);
  }
  cVar5 = FUN_0017fb68(param_1[5],&iStack_2c);
  if (cVar5 == '\0') {
    uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
    FUN_0000bf34(uVar10);
  }
  cVar5 = (**(code **)(*(int *)param_1[5] + 0x1ac))((int *)param_1[5],&cStack_41,&uStack_28);
  uVar24 = cVar5 == '\0';
  if ((bool)uVar24) {
    uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
    FUN_0000bf34(uVar10);
  }
  iVar9 = 4;
  pcVar14 = &cStack_41;
  pcVar22 = "WAVE";
  do {
    pcVar20 = pcVar14;
    pcVar23 = pcVar22;
    if (iVar9 == 0) break;
    iVar9 = iVar9 + -1;
    pcVar23 = pcVar22 + 1;
    pcVar20 = pcVar14 + 1;
    uVar24 = *pcVar14 == *pcVar22;
    pcVar14 = pcVar20;
    pcVar22 = pcVar23;
  } while ((bool)uVar24);
  iVar9 = 0;
  if (!(bool)uVar24) {
    iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
  }
  if (iVar9 != 0) {
    uVar10 = FUN_00033b90("GNSoundFileFormatNotSupportedException");
    FUN_0000bf34(uVar10);
  }
  bVar4 = false;
  bVar26 = false;
  uStack_b0 = 0;
LAB_0024d032:
  do {
    iVar9 = (**(code **)(*(int *)param_1[5] + 0x1b8))((int *)param_1[5]);
    if (iVar9 < iStack_2c + -1) goto LAB_0024d18a;
LAB_0024d051:
    uVar24 = !bVar26;
    if ((!(bool)uVar24) && (uVar24 = !bVar4, !(bool)uVar24)) {
      uVar10 = FUN_00063426(uVar6);
      iVar9 = FUN_00029ddc(uVar10);
      if (iVar9 != 0) {
        uVar10 = FUN_00033b90("chunks");
        FUN_00066284(param_1[0xd],uVar6,uVar10);
      }
      iVar9 = FUN_00029ddc(uVar8);
      if (iVar9 != 0) {
        uVar6 = FUN_00033b90("privateChunks");
        FUN_00066284(param_1[0xd],uVar8,uVar6);
      }
      return;
    }
    uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
    FUN_0000bf34(uVar10);
LAB_0024d07d:
    iVar9 = 4;
    pcVar14 = &cStack_41;
    pcVar22 = "fmt ";
    do {
      pcVar20 = pcVar14;
      pcVar23 = pcVar22;
      if (iVar9 == 0) break;
      iVar9 = iVar9 + -1;
      pcVar23 = pcVar22 + 1;
      pcVar20 = pcVar14 + 1;
      uVar24 = *pcVar14 == *pcVar22;
      pcVar14 = pcVar20;
      pcVar22 = pcVar23;
    } while ((bool)uVar24);
    iVar9 = 0;
    if (!(bool)uVar24) {
      iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
    }
joined_r0x0024d0a6:
    bVar25 = iVar9 == 0;
    if (!bVar25) {
      iVar9 = 4;
      pcVar14 = &cStack_41;
      pcVar22 = "data";
      break;
    }
    cVar5 = FUN_0017fc6e(param_1[5],(int)param_1 + 0x1e);
    if (cVar5 == '\0') {
      uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
      FUN_0000bf34(uVar10);
    }
    cVar5 = FUN_0017fc6e(param_1[5],(int)param_1 + 0x1a);
    if ((((cVar5 == '\0') || (cVar5 = FUN_0017fb68(param_1[5],param_1 + 9), cVar5 == '\0')) ||
        (cVar5 = FUN_0017fb68(param_1[5],param_1 + 0xb), cVar5 == '\0')) ||
       ((cVar5 = FUN_0017fc6e(param_1[5],param_1 + 6), cVar5 == '\0' ||
        (cVar5 = FUN_0017fc6e(param_1[5],param_1 + 7), cVar5 == '\0')))) {
      uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
      FUN_0000bf34(uVar10);
    }
    sVar1 = *(short *)((int)param_1 + 0x1e);
    if (sVar1 != 2) {
      if (sVar1 < 3) {
        if (sVar1 == 1) {
LAB_0024d4b7:
          iVar9 = (short)param_1[7] + 7;
          if (iVar9 < 0) {
            iVar9 = (short)param_1[7] + 0xe;
          }
          param_1[8] = iVar9 >> 3;
          if (uStack_b0 != 0) {
            param_1[10] = ((int)uStack_b0 / (int)*(short *)((int)param_1 + 0x1a)) / (iVar9 >> 3);
          }
          iVar9 = *(int *)param_1[5];
          pcVar2 = *(code **)(iVar9 + 0x1c0);
          iVar9 = (**(code **)(iVar9 + 0x1b8))((int *)param_1[5]);
          (*pcVar2)(param_1[5],iVar9 + uStack_30 + -0x10);
          bVar4 = true;
          goto LAB_0024d032;
        }
      }
      else {
        if (sVar1 == 3) goto LAB_0024d4b7;
        if (sVar1 == 0x11) {
          cVar5 = FUN_0017fc6e(param_1[5],auStack_20);
          if ((cVar5 == '\0') ||
             (cVar5 = FUN_0017fc6e(param_1[5],(int)param_1 + 0x3e), cVar5 == '\0')) {
            uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar10);
          }
          *(short *)(param_1 + 0x10) = (short)param_1[6];
          bVar4 = true;
          goto LAB_0024d032;
        }
      }
      FUN_0000ab14("Wave format %i not supported",(int)sVar1);
      uVar10 = FUN_00033b90("GNSoundFileFormatNotSupportedException");
      FUN_0000bf34(uVar10);
      bVar4 = true;
      iVar9 = (**(code **)(*(int *)param_1[5] + 0x1b8))((int *)param_1[5]);
      if (iStack_2c + -1 <= iVar9) goto LAB_0024d051;
LAB_0024d18a:
      cVar5 = FUN_0024bfce(param_1[5],iStack_2c + 8,&cStack_41,&uStack_30,0x3673a0,0x15,"data");
      if (cVar5 == '\0') goto LAB_0024d051;
      uVar24 = uStack_30 == 0;
      if (-1 < (int)uStack_30) {
        (**(code **)(*(int *)param_1[5] + 0x1b8))((int *)param_1[5]);
        iVar9 = 4;
        pcVar14 = &cStack_41;
        pcVar22 = "fmt ";
        do {
          pcVar20 = pcVar14;
          pcVar23 = pcVar22;
          if (iVar9 == 0) break;
          iVar9 = iVar9 + -1;
          pcVar23 = pcVar22 + 1;
          pcVar20 = pcVar14 + 1;
          uVar24 = *pcVar14 == *pcVar22;
          pcVar14 = pcVar20;
          pcVar22 = pcVar23;
        } while ((bool)uVar24);
        iVar9 = 0;
        if (!(bool)uVar24) {
          iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
        }
        goto joined_r0x0024d0a6;
      }
      goto LAB_0024d07d;
    }
    cVar5 = FUN_0017fc6e(param_1[5],auStack_20);
    if (((cVar5 == '\0') || (cVar5 = FUN_0017fc6e(param_1[5],param_1 + 0xe), cVar5 == '\0')) ||
       (cVar5 = FUN_0017fc6e(param_1[5],param_1 + 0xf), cVar5 == '\0')) {
      uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
      FUN_0000bf34(uVar10);
    }
    if (((ushort)(*(short *)((int)param_1 + 0x1a) - 1U) < 2) &&
       ((ushort)((short)param_1[0xf] - 7U) < 0xf9)) {
      sVar1 = (short)param_1[0xf];
    }
    else {
      uVar10 = FUN_00033b90("GNSoundFileFormatNotSupportedException");
      FUN_0000bf34(uVar10);
      sVar1 = (short)param_1[0xf];
    }
    if (0 < sVar1) {
      iVar9 = 0;
      piVar7 = param_1;
      do {
        cVar5 = FUN_0017fc6e(param_1[5],&uStack_4c);
        if ((cVar5 == '\0') || (cVar5 = FUN_0017fc6e(param_1[5],&uStack_3c), cVar5 == '\0')) {
          uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
          FUN_0000bf34(uVar10);
        }
        piVar7[0x12] = (int)(short)uStack_4c;
        piVar7[0x13] = (int)(short)uStack_3c;
        iVar9 = iVar9 + 1;
        piVar7 = piVar7 + 2;
      } while (iVar9 < (short)param_1[0xf]);
    }
    *(short *)((int)param_1 + 0x3a) = (short)param_1[6];
    bVar4 = true;
  } while( true );
  while( true ) {
    iVar9 = iVar9 + -1;
    pcVar23 = pcVar22 + 1;
    pcVar20 = pcVar14 + 1;
    bVar25 = *pcVar14 == *pcVar22;
    pcVar14 = pcVar20;
    pcVar22 = pcVar23;
    if (!bVar25) break;
    pcVar20 = pcVar14;
    pcVar23 = pcVar22;
    if (iVar9 == 0) break;
  }
  iVar9 = 0;
  if (!bVar25) {
    iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
  }
  bVar25 = iVar9 == 0;
  if (bVar25) {
    piVar7 = (int *)(**(code **)(*(int *)param_1[5] + 0x1a8))((int *)param_1[5]);
    iVar9 = (**(code **)(*piVar7 + 0x1d8))(piVar7);
    if (iStack_2c + 8 < iVar9) {
      iVar9 = iStack_2c + 8;
    }
    iVar11 = (**(code **)(*(int *)param_1[5] + 0x1b8))((int *)param_1[5]);
    uVar12 = uStack_30;
    param_1[0xc] = iVar11;
    uVar18 = iVar9 - iVar11;
    if ((int)uVar18 < (int)uStack_30) {
      iVar9 = (**(code **)(*param_2 + 0x1bc))(param_2);
      if (iVar9 == 0) {
        pcVar14 = "";
      }
      else {
        uVar10 = (**(code **)(*param_2 + 0x1bc))(param_2);
        pcVar14 = (char *)FUN_00034962(uVar10);
      }
      FUN_0000ab14("Wave: File \'%s\' seems to be damaged. dataSize only %d expected %d ",pcVar14,
                   uVar18,uVar12);
      sVar1 = *(short *)((int)param_1 + 0x1e);
      sVar3 = sVar1 + -2;
      bVar26 = sVar3 == 0;
      uStack_30 = uVar18;
    }
    else {
      sVar1 = *(short *)((int)param_1 + 0x1e);
      sVar3 = sVar1 + -2;
      bVar26 = sVar1 == 2;
    }
    if (bVar26) {
      uVar12 = (uint)(short)param_1[0xe];
      iVar9 = ___udivdi3((int)((ulonglong)uVar12 * (ulonglong)uStack_30),
                         ((int)uVar12 >> 0x1f) * uStack_30 +
                         (int)((ulonglong)uVar12 * (ulonglong)uStack_30 >> 0x20) +
                         uVar12 * ((int)uStack_30 >> 0x1f),(int)*(short *)((int)param_1 + 0x3a),
                         (int)*(short *)((int)param_1 + 0x3a) >> 0x1f);
      param_1[10] = iVar9;
    }
    else {
      if (bVar26 || SBORROW2(sVar1,2) != sVar3 < 0) {
        if (sVar1 != 1) goto LAB_0024d2b9;
      }
      else if (sVar1 != 3) {
        if (sVar1 == 0x11) {
          uVar12 = (uint)*(short *)((int)param_1 + 0x3e);
          uVar27 = ___udivdi3((int)((ulonglong)uVar12 * (ulonglong)uStack_30),
                              ((int)uVar12 >> 0x1f) * uStack_30 +
                              (int)((ulonglong)uVar12 * (ulonglong)uStack_30 >> 0x20) +
                              uVar12 * ((int)uStack_30 >> 0x1f),(int)(short)param_1[0x10],
                              (int)(short)param_1[0x10] >> 0x1f);
          iVar9 = ___udivdi3(uVar27,(int)*(short *)((int)param_1 + 0x1a),
                             (int)*(short *)((int)param_1 + 0x1a) >> 0x1f);
          param_1[10] = iVar9;
          iVar9 = FUN_0000aecc((int)*(short *)((int)param_1 + 0x1a) *
                               (int)*(short *)((int)param_1 + 0x3e) * 2);
          param_1[0x11] = iVar9;
          if (iVar9 == 0) {
            uVar10 = func_0x0000a930(
                                    "/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNSoundFileWAVE.cpp"
                                    );
            uVar13 = FUN_00033b90("GNAssertionException");
            FUN_0000bfd6(uVar13,"Assertion failed in line %d of %s: %s.",0x17c,uVar10,"_dviSamples")
            ;
          }
        }
        goto LAB_0024d2b9;
      }
      param_1[10] = ((int)uStack_30 / (int)*(short *)((int)param_1 + 0x1a)) / param_1[8];
      uStack_b0 = uStack_30;
    }
LAB_0024d2b9:
    iVar9 = *(int *)param_1[5];
    pcVar2 = *(code **)(iVar9 + 0x1c0);
    iVar9 = (**(code **)(iVar9 + 0x1b8))((int *)param_1[5]);
    (*pcVar2)(param_1[5],iVar9 + uStack_30);
    bVar26 = true;
    goto LAB_0024d032;
  }
  iVar9 = 4;
  pcVar14 = &cStack_41;
  pcVar22 = "plst";
  do {
    pcVar20 = pcVar14;
    pcVar23 = pcVar22;
    if (iVar9 == 0) break;
    iVar9 = iVar9 + -1;
    pcVar23 = pcVar22 + 1;
    pcVar20 = pcVar14 + 1;
    bVar25 = *pcVar14 == *pcVar22;
    pcVar14 = pcVar20;
    pcVar22 = pcVar23;
  } while (bVar25);
  iVar9 = 0;
  if (!bVar25) {
    iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
  }
  bVar25 = iVar9 == 0;
  if (bVar25) {
    pcVar14 = "Wave playlists not supported";
LAB_0024d320:
    FUN_0000ab14(pcVar14);
    iVar9 = (**(code **)(*(int *)param_1[5] + 0x1b8))((int *)param_1[5]);
    (**(code **)(*(int *)param_1[5] + 0x1c0))((int *)param_1[5],iVar9 + uStack_30);
    goto LAB_0024d032;
  }
  iVar9 = 4;
  pcVar14 = &cStack_41;
  pcVar22 = "wavl";
  do {
    pcVar20 = pcVar14;
    pcVar23 = pcVar22;
    if (iVar9 == 0) break;
    iVar9 = iVar9 + -1;
    pcVar23 = pcVar22 + 1;
    pcVar20 = pcVar14 + 1;
    bVar25 = *pcVar14 == *pcVar22;
    pcVar14 = pcVar20;
    pcVar22 = pcVar23;
  } while (bVar25);
  iVar9 = 0;
  if (!bVar25) {
    iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
  }
  bVar25 = iVar9 == 0;
  if (bVar25) {
    pcVar14 = "Wave wavelists not supported";
    goto LAB_0024d320;
  }
  iVar9 = 4;
  pcVar14 = &cStack_41;
  pcVar22 = "cue ";
  do {
    pcVar20 = pcVar14;
    pcVar23 = pcVar22;
    if (iVar9 == 0) break;
    iVar9 = iVar9 + -1;
    pcVar23 = pcVar22 + 1;
    pcVar20 = pcVar14 + 1;
    bVar25 = *pcVar14 == *pcVar22;
    pcVar14 = pcVar20;
    pcVar22 = pcVar23;
  } while (bVar25);
  iVar9 = 0;
  if (!bVar25) {
    iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
  }
  bVar25 = iVar9 == 0;
  if (bVar25) {
    iVar9 = (**(code **)(*(int *)param_1[5] + 0x1b8))((int *)param_1[5]);
    iVar9 = iVar9 + uStack_30;
    uVar10 = __Znwm(0x20);
    FUN_00029d44(uVar10);
    piVar7 = (int *)FUN_0002dfa6(uVar10);
    cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
    if (cVar5 == '\0') {
      uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
      FUN_0000bf34(uVar10);
    }
    if ((int)uStack_30 < iStack_38 * 0x18 + 4) {
      uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
      FUN_0000bf34(uVar10);
    }
    if (0 < iStack_38) {
      iStack_9c = 0;
      do {
        uVar10 = __Znwm(0x18);
        FUN_000630b6(uVar10);
        piVar15 = (int *)FUN_0002dfa6(uVar10);
        cVar5 = FUN_0017fb68(param_1[5],&uStack_34);
        if (cVar5 == '\0') {
          uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
          FUN_0000bf34(uVar10);
          cVar5 = FUN_0017fb68(param_1[5],&uStack_3c);
          if (cVar5 == '\0') goto LAB_0024d95a;
LAB_0024d842:
          iVar11 = FUN_00180166(param_1[5],0x10);
        }
        else {
          cVar5 = FUN_0017fb68(param_1[5],&uStack_3c);
          if (cVar5 != '\0') goto LAB_0024d842;
LAB_0024d95a:
          uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
          FUN_0000bf34(uVar10);
          iVar11 = FUN_00180166(param_1[5],0x10);
        }
        if (iVar11 == 0) {
          uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
          FUN_0000bf34(uVar10);
        }
        uVar10 = FUN_00033b90("cuePointID");
        uVar13 = FUN_000858da(uStack_34);
        FUN_00066284(piVar15,uVar13,uVar10);
        uVar10 = FUN_00033b90("cuePointPosition");
        uVar13 = FUN_000858da(uStack_3c);
        FUN_00066284(piVar15,uVar13,uVar10);
        FUN_0002bb40(piVar7,piVar15);
        if (piVar15 != (int *)0x0) {
          (**(code **)(*piVar15 + 0x44))(piVar15);
        }
        iStack_9c = iStack_9c + 1;
      } while (iStack_9c < iStack_38);
    }
    uVar10 = FUN_00033b90("cuePoints");
    FUN_00066284(uVar6,piVar7,uVar10);
    if (piVar7 != (int *)0x0) {
      (**(code **)(*piVar7 + 0x44))(piVar7);
    }
    (**(code **)(*(int *)param_1[5] + 0x1c0))((int *)param_1[5],iVar9);
    goto LAB_0024d032;
  }
  iVar9 = 4;
  pcVar14 = &cStack_41;
  pcVar22 = "list";
  do {
    pcVar20 = pcVar14;
    pcVar23 = pcVar22;
    if (iVar9 == 0) break;
    iVar9 = iVar9 + -1;
    pcVar23 = pcVar22 + 1;
    pcVar20 = pcVar14 + 1;
    bVar25 = *pcVar14 == *pcVar22;
    pcVar14 = pcVar20;
    pcVar22 = pcVar23;
  } while (bVar25);
  iVar9 = 0;
  if (!bVar25) {
    iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
  }
  bVar25 = iVar9 == 0;
  if (bVar25) {
LAB_0024db46:
    uStack_28 = 4;
    cVar5 = (**(code **)(*(int *)param_1[5] + 0x1ac))((int *)param_1[5],acStack_24,&uStack_28);
    uVar24 = cVar5 == '\0';
    if ((bool)uVar24) {
      uVar10 = FUN_00033b90("GNSoundFileFormatNotSupportedException");
      FUN_0000bf34(uVar10);
    }
    uStack_28 = 4;
    iVar9 = 4;
    pcVar14 = acStack_24;
    pcVar22 = "adtl";
    do {
      pcVar20 = pcVar14;
      pcVar23 = pcVar22;
      if (iVar9 == 0) break;
      iVar9 = iVar9 + -1;
      pcVar23 = pcVar22 + 1;
      pcVar20 = pcVar14 + 1;
      uVar24 = *pcVar14 == *pcVar22;
      pcVar14 = pcVar20;
      pcVar22 = pcVar23;
    } while ((bool)uVar24);
    iVar9 = 0;
    if (!(bool)uVar24) {
      iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
    }
    if (iVar9 == 0) {
      uVar10 = FUN_00033b90("dataList");
      iStack_94 = FUN_00064626(uVar6,uVar10);
      if (iStack_94 == 0) {
        uVar10 = __Znwm(0x20);
        FUN_00029d44(uVar10);
        piVar7 = (int *)FUN_0002dfa6(uVar10);
        iStack_94 = (**(code **)(*piVar7 + 0x48))(piVar7);
        uVar10 = FUN_00033b90("dataList");
        FUN_00066284(uVar6,iStack_94,uVar10);
      }
      iStack_50 = 4;
      while (iStack_50 < (int)uStack_30) {
        cVar5 = (**(code **)(*(int *)param_1[5] + 0x1ac))((int *)param_1[5],&cStack_41,&uStack_28);
        if (cVar5 == '\0') {
          uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
          FUN_0000bf34(uVar10);
        }
        cVar5 = FUN_0017fb68(param_1[5],&uStack_3c);
        if (cVar5 == '\0') {
          uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
          FUN_0000bf34(uVar10);
        }
        iStack_98 = iStack_50 + 8;
        bVar25 = iStack_98 == 0;
        iVar9 = 4;
        pcVar14 = &cStack_41;
        pcVar22 = "labl";
        do {
          pcVar20 = pcVar14;
          pcVar23 = pcVar22;
          if (iVar9 == 0) break;
          iVar9 = iVar9 + -1;
          pcVar23 = pcVar22 + 1;
          pcVar20 = pcVar14 + 1;
          bVar25 = *pcVar14 == *pcVar22;
          pcVar14 = pcVar20;
          pcVar22 = pcVar23;
        } while (bVar25);
        iVar9 = 0;
        if (!bVar25) {
          iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
        }
        bVar25 = iVar9 == 0;
        if (bVar25) {
          cVar5 = FUN_0017fb68(param_1[5],&uStack_34);
          if (cVar5 == '\0') {
            uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar10);
          }
          iStack_98 = iStack_50 + 0xc;
          if ((int)(uStack_3c - 4) < 1) {
            if (uStack_3c == 4) goto LAB_0024e124;
            uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar10);
            piStack_b4 = (int *)0x0;
            piStack_58 = piStack_b4;
          }
          else {
            piStack_58 = (int *)FUN_00180166(param_1[5],uStack_3c - 4);
            if (piStack_58 == (int *)0x0) {
              uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
              FUN_0000bf34(uVar10);
            }
            iStack_98 = iStack_98 + uStack_3c;
            iVar9 = FUN_000278d6(piStack_58);
            if (iVar9 < 2) {
LAB_0024e124:
              piStack_b4 = (int *)0x0;
              piStack_58 = piStack_b4;
            }
            else {
              pcVar2 = *(code **)(*piStack_58 + 0x1a4);
              iVar9 = FUN_000278d6(piStack_58);
              (*pcVar2)(piStack_58,iVar9 + -1);
            }
          }
          if ((uStack_3c & 1) != 0) {
            cVar5 = FUN_00180086(param_1[5],auStack_1d);
            if (cVar5 == '\0') {
              uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
              FUN_0000bf34(uVar10);
            }
            iStack_98 = iStack_98 + 1;
          }
          uVar10 = __Znwm(0x18);
          FUN_000630b6(uVar10);
          piVar7 = (int *)FUN_0002dfa6(uVar10);
          uVar10 = FUN_00033b90("cuePointID");
          uVar13 = FUN_000858da(uStack_34);
          FUN_00066284(piVar7,uVar13,uVar10);
          if (piStack_58 == (int *)0x0) {
            pcStack_ec = "label";
LAB_0024e1b3:
            uVar10 = FUN_00033b90(pcStack_ec);
            uVar13 = FUN_00033b90("");
            FUN_00066284(piVar7,uVar13,uVar10);
          }
          else {
            uVar10 = FUN_00033b90("label");
LAB_0024dd99:
            uVar13 = FUN_00038d00(piStack_58,4);
            FUN_00066284(piVar7,uVar13,uVar10);
          }
LAB_0024ddae:
          FUN_0002bb40(iStack_94,piVar7);
          if (piVar7 != (int *)0x0) {
            (**(code **)(*piVar7 + 0x44))(piVar7);
          }
        }
        else {
          iVar9 = 4;
          pcVar14 = &cStack_41;
          pcVar22 = "note";
          do {
            pcVar20 = pcVar14;
            pcVar23 = pcVar22;
            if (iVar9 == 0) break;
            iVar9 = iVar9 + -1;
            pcVar23 = pcVar22 + 1;
            pcVar20 = pcVar14 + 1;
            bVar25 = *pcVar14 == *pcVar22;
            pcVar14 = pcVar20;
            pcVar22 = pcVar23;
          } while (bVar25);
          iVar9 = 0;
          if (!bVar25) {
            iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
          }
          bVar25 = iVar9 == 0;
          if (bVar25) {
            cVar5 = FUN_0017fb68(param_1[5],&uStack_34);
            if (cVar5 == '\0') {
              uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
              FUN_0000bf34(uVar10);
            }
            pcStack_ec = "note";
            iStack_98 = iStack_50 + 0xc;
            if ((int)(uStack_3c - 4) < 1) {
              if (uStack_3c != 4) {
                uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
                FUN_0000bf34(uVar10);
                piStack_58 = (int *)0x0;
                goto LAB_0024de7f;
              }
              piStack_58 = (int *)0x0;
            }
            else {
              piStack_58 = (int *)FUN_00180166(param_1[5],uStack_3c - 4);
              if (piStack_58 == (int *)0x0) {
                uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
                FUN_0000bf34(uVar10);
              }
              iStack_98 = iStack_98 + uStack_3c;
              iVar9 = FUN_000278d6(piStack_58);
              if (iVar9 != 0) {
                pcVar2 = *(code **)(*piStack_58 + 0x1a4);
                iVar9 = FUN_000278d6(piStack_58);
                (*pcVar2)(piStack_58,iVar9 + -1);
              }
LAB_0024de7f:
              if ((uStack_3c & 1) != 0) {
                cVar5 = FUN_00180086(param_1[5],auStack_1d);
                if (cVar5 == '\0') {
                  uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
                  FUN_0000bf34(uVar10);
                }
                iStack_98 = iStack_98 + 1;
              }
            }
            uVar10 = __Znwm(0x18);
            FUN_000630b6(uVar10);
            piVar7 = (int *)FUN_0002dfa6(uVar10);
            uVar10 = FUN_00033b90("cuePointID");
            uVar13 = FUN_000858da(uStack_34);
            FUN_00066284(piVar7,uVar13,uVar10);
            if (piStack_58 == (int *)0x0) goto LAB_0024e1b3;
            uVar10 = FUN_00033b90("note");
            goto LAB_0024dd99;
          }
          iVar9 = 4;
          pcVar14 = &cStack_41;
          pcVar22 = "ltxt";
          do {
            pcVar20 = pcVar14;
            pcVar23 = pcVar22;
            if (iVar9 == 0) break;
            iVar9 = iVar9 + -1;
            pcVar23 = pcVar22 + 1;
            pcVar20 = pcVar14 + 1;
            bVar25 = *pcVar14 == *pcVar22;
            pcVar14 = pcVar20;
            pcVar22 = pcVar23;
          } while (bVar25);
          iVar9 = 0;
          if (!bVar25) {
            iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
          }
          if (iVar9 == 0) {
            cVar5 = FUN_0017fb68(param_1[5],&uStack_34);
            if (cVar5 == '\0') {
              uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
              FUN_0000bf34(uVar10);
            }
            cVar5 = FUN_0017fb68(param_1[5],&uStack_4c);
            if (cVar5 == '\0') {
              uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
              FUN_0000bf34(uVar10);
              iVar9 = FUN_00180166(param_1[5],0xc);
            }
            else {
              iVar9 = FUN_00180166(param_1[5],0xc);
            }
            if (iVar9 == 0) {
              uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
              FUN_0000bf34(uVar10);
            }
            iStack_98 = iStack_50 + 0x1c;
            if ((int)(uStack_3c - 0x14) < 1) {
              if (uStack_3c != 0x14) {
                uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
                FUN_0000bf34(uVar10);
                piStack_54 = (int *)0x0;
                goto LAB_0024e01f;
              }
              piStack_54 = (int *)0x0;
            }
            else {
              piStack_54 = (int *)FUN_00180166(param_1[5],uStack_3c - 0x14);
              if (piStack_54 == (int *)0x0) {
                uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
                FUN_0000bf34(uVar10);
              }
              iStack_98 = iStack_98 + uStack_3c + -0x14;
              iVar9 = FUN_000278d6(piStack_54);
              if (iVar9 != 0) {
                pcVar2 = *(code **)(*piStack_54 + 0x1a4);
                iVar9 = FUN_000278d6(piStack_54);
                (*pcVar2)(piStack_54,iVar9 + -1);
              }
LAB_0024e01f:
              if ((uStack_3c & 1) != 0) {
                cVar5 = FUN_00180086(param_1[5],auStack_1d);
                if (cVar5 == '\0') {
                  uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
                  FUN_0000bf34(uVar10);
                }
                iStack_98 = iStack_98 + 1;
              }
            }
            uVar10 = __Znwm(0x18);
            FUN_000630b6(uVar10);
            piVar7 = (int *)FUN_0002dfa6(uVar10);
            uVar10 = FUN_00033b90("cuePointID");
            uVar13 = FUN_000858da(uStack_34);
            FUN_00066284(piVar7,uVar13,uVar10);
            uVar10 = FUN_00033b90("sampleLength");
            uVar13 = FUN_000858da(uStack_4c);
            FUN_00066284(piVar7,uVar13,uVar10);
            if (piStack_54 != (int *)0x0) {
              uVar10 = FUN_00033b90("labeledText");
              piStack_58 = piStack_54;
              goto LAB_0024dd99;
            }
            goto LAB_0024ddae;
          }
          uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
          FUN_0000bf34(uVar10);
        }
        iStack_50 = iStack_98;
      }
    }
    else {
      iVar9 = *(int *)param_1[5];
      pcVar2 = *(code **)(iVar9 + 0x1c0);
      iVar9 = (**(code **)(iVar9 + 0x1b8))((int *)param_1[5]);
      (*pcVar2)(param_1[5],iVar9 + -4);
      if ((0 < (int)uStack_30) && (iVar9 = FUN_00180166(param_1[5],uStack_30), iVar9 != 0)) {
        uVar10 = FUN_0003887c(&cStack_41,4,4);
        FUN_0002bb40(uVar8,uVar10);
        FUN_0002bb40(uVar8,iVar9);
      }
    }
    goto LAB_0024d032;
  }
  iVar9 = 4;
  pcVar14 = &cStack_41;
  pcVar22 = "LIST";
  do {
    pcVar20 = pcVar14;
    pcVar23 = pcVar22;
    if (iVar9 == 0) break;
    iVar9 = iVar9 + -1;
    pcVar23 = pcVar22 + 1;
    pcVar20 = pcVar14 + 1;
    bVar25 = *pcVar14 == *pcVar22;
    pcVar14 = pcVar20;
    pcVar22 = pcVar23;
  } while (bVar25);
  iVar9 = 0;
  if (!bVar25) {
    iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
  }
  bVar25 = iVar9 == 0;
  if (bVar25) goto LAB_0024db46;
  iVar9 = 4;
  pcVar14 = &cStack_41;
  pcVar22 = "JNUK";
  do {
    pcVar20 = pcVar14;
    pcVar23 = pcVar22;
    if (iVar9 == 0) break;
    iVar9 = iVar9 + -1;
    pcVar23 = pcVar22 + 1;
    pcVar20 = pcVar14 + 1;
    bVar25 = *pcVar14 == *pcVar22;
    pcVar14 = pcVar20;
    pcVar22 = pcVar23;
  } while (bVar25);
  iVar9 = 0;
  if (!bVar25) {
    iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
  }
  bVar25 = iVar9 == 0;
  if (bVar25) {
LAB_0024e54e:
    iVar9 = *(int *)param_1[5];
    pcVar2 = *(code **)(iVar9 + 0x1c0);
    iVar9 = (**(code **)(iVar9 + 0x1b8))((int *)param_1[5]);
    (*pcVar2)(param_1[5],iVar9 + uStack_30);
    goto LAB_0024d032;
  }
  iVar9 = 4;
  pcVar14 = &cStack_41;
  pcVar22 = "PAD ";
  do {
    pcVar20 = pcVar14;
    pcVar23 = pcVar22;
    if (iVar9 == 0) break;
    iVar9 = iVar9 + -1;
    pcVar23 = pcVar22 + 1;
    pcVar20 = pcVar14 + 1;
    bVar25 = *pcVar14 == *pcVar22;
    pcVar14 = pcVar20;
    pcVar22 = pcVar23;
  } while (bVar25);
  iVar9 = 0;
  if (!bVar25) {
    iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
  }
  bVar25 = iVar9 == 0;
  if (bVar25) goto LAB_0024e54e;
  iVar9 = 4;
  pcVar14 = &cStack_41;
  pcVar22 = "inst";
  do {
    pcVar20 = pcVar14;
    pcVar23 = pcVar22;
    if (iVar9 == 0) break;
    iVar9 = iVar9 + -1;
    pcVar23 = pcVar22 + 1;
    pcVar20 = pcVar14 + 1;
    bVar25 = *pcVar14 == *pcVar22;
    pcVar14 = pcVar20;
    pcVar22 = pcVar23;
  } while (bVar25);
  iVar9 = 0;
  if (!bVar25) {
    iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
  }
  bVar25 = iVar9 == 0;
  if (bVar25) {
    iVar9 = (**(code **)(*(int *)param_1[5] + 0x1b8))((int *)param_1[5]);
    iVar9 = iVar9 + uStack_30;
    if (uStack_30 == 0) goto LAB_0024eb8a;
    uVar10 = FUN_00180166(param_1[5],uStack_30);
    uVar13 = (**(code **)(*param_1 + 0x1ac))(param_1);
    piVar7 = (int *)FUN_00289de8(uVar13,uVar10);
  }
  else {
    iVar9 = 4;
    pcVar14 = &cStack_41;
    pcVar22 = "smpl";
    do {
      pcVar20 = pcVar14;
      pcVar23 = pcVar22;
      if (iVar9 == 0) break;
      iVar9 = iVar9 + -1;
      pcVar23 = pcVar22 + 1;
      pcVar20 = pcVar14 + 1;
      bVar25 = *pcVar14 == *pcVar22;
      pcVar14 = pcVar20;
      pcVar22 = pcVar23;
    } while (bVar25);
    iVar9 = 0;
    if (!bVar25) {
      iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
    }
    bVar25 = iVar9 == 0;
    if (bVar25) {
      iVar9 = (**(code **)(*(int *)param_1[5] + 0x1b8))((int *)param_1[5]);
      iVar9 = iVar9 + uStack_30;
      uVar10 = __Znwm(0x18);
      FUN_000630b6(uVar10);
      piVar7 = (int *)FUN_0002dfa6(uVar10);
      uVar10 = FUN_00033b90("manufacturerId");
      cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
      if (cVar5 == '\0') {
        uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar13);
      }
      uVar13 = FUN_000858da(iStack_38);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("productId");
      cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
      if (cVar5 == '\0') {
        uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar13);
      }
      uVar13 = FUN_000858da(iStack_38);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("samplePeriod");
      cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
      if (cVar5 == '\0') {
        uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar13);
      }
      uVar13 = FUN_000858da(iStack_38);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("midiUnityNote");
      cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
      if (cVar5 == '\0') {
        uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar13);
      }
      uVar13 = FUN_000858da(iStack_38);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("midiPitchFraction");
      cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
      if (cVar5 == '\0') {
        uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar13);
      }
      uVar13 = FUN_000858da(iStack_38);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("smpteFormat");
      cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
      if (cVar5 == '\0') {
        uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar13);
      }
      uVar13 = FUN_000858da(iStack_38);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("smpteOffset");
      cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
      if (cVar5 == '\0') {
        uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar13);
      }
      uVar13 = FUN_000858da(iStack_38);
      FUN_00066284(piVar7,uVar13,uVar10);
      cVar5 = FUN_0017fb68(param_1[5],&uStack_4c);
      if (cVar5 == '\0') {
        uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar10);
      }
      cVar5 = FUN_0017fb68(param_1[5],&uStack_3c);
      if (cVar5 == '\0') {
        uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar10);
      }
      if (uStack_4c == 0) {
        iStack_90 = 0;
      }
      else {
        uVar10 = __Znwm(0x20);
        FUN_00029d44(uVar10);
        iStack_90 = FUN_0002dfa6(uVar10);
      }
      if (0 < (int)uStack_4c) {
        iStack_8c = 0;
        do {
          uVar10 = __Znwm(0x18);
          FUN_000630b6(uVar10);
          piVar15 = (int *)FUN_0002dfa6(uVar10);
          uVar10 = FUN_00033b90("cuePointID");
          cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
          if (cVar5 == '\0') {
            uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar13);
          }
          uVar13 = FUN_000858da(iStack_38);
          FUN_00066284(piVar15,uVar13,uVar10);
          uVar10 = FUN_00033b90("type");
          cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
          if (cVar5 == '\0') {
            uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar13);
          }
          uVar13 = FUN_000858da(iStack_38);
          FUN_00066284(piVar15,uVar13,uVar10);
          uVar10 = FUN_00033b90("start");
          cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
          if (cVar5 == '\0') {
            uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar13);
          }
          uVar13 = FUN_000858da(iStack_38);
          FUN_00066284(piVar15,uVar13,uVar10);
          uVar10 = FUN_00033b90("end");
          cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
          if (cVar5 == '\0') {
            uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar13);
          }
          uVar13 = FUN_000858da(iStack_38);
          FUN_00066284(piVar15,uVar13,uVar10);
          uVar10 = FUN_00033b90("fraction");
          cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
          if (cVar5 == '\0') {
            uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar13);
          }
          uVar13 = FUN_000858da(iStack_38);
          FUN_00066284(piVar15,uVar13,uVar10);
          uVar10 = FUN_00033b90("playCount");
          cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
          if (cVar5 == '\0') {
            uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar13);
          }
          uVar13 = FUN_000858da(iStack_38);
          FUN_00066284(piVar15,uVar13,uVar10);
          FUN_0002bb40(iStack_90,piVar15);
          if (piVar15 != (int *)0x0) {
            (**(code **)(*piVar15 + 0x44))(piVar15);
          }
          iStack_8c = iStack_8c + 1;
        } while (iStack_8c < (int)uStack_4c);
      }
      if (iStack_90 != 0) {
        uVar10 = FUN_00033b90("loops");
        FUN_00066284(piVar7,iStack_90,uVar10);
      }
      if (uStack_3c != 0) {
        iVar11 = FUN_00180166(param_1[5],uStack_3c);
        if (iVar11 == 0) {
          uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
          FUN_0000bf34(uVar10);
        }
        uVar10 = FUN_00033b90("samplerData");
        FUN_00066284(piVar7,iVar11,uVar10);
      }
      uVar10 = FUN_00033b90("sample");
      FUN_00066284(uVar6,piVar7,uVar10);
      if (piVar7 != (int *)0x0) {
        (**(code **)(*piVar7 + 0x44))(piVar7);
      }
      (**(code **)(*(int *)param_1[5] + 0x1c0))((int *)param_1[5],iVar9);
      goto LAB_0024d032;
    }
    iVar9 = 4;
    pcVar14 = &cStack_41;
    pcVar22 = "regn";
    do {
      pcVar20 = pcVar14;
      pcVar23 = pcVar22;
      if (iVar9 == 0) break;
      iVar9 = iVar9 + -1;
      pcVar23 = pcVar22 + 1;
      pcVar20 = pcVar14 + 1;
      bVar25 = *pcVar14 == *pcVar22;
      pcVar14 = pcVar20;
      pcVar22 = pcVar23;
    } while (bVar25);
    iVar9 = 0;
    if (!bVar25) {
      iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
    }
    bVar25 = iVar9 == 0;
    if (bVar25) {
      iVar9 = (**(code **)(*(int *)param_1[5] + 0x1b8))((int *)param_1[5]);
      iVar9 = iVar9 + uStack_30;
      cVar5 = FUN_0017fb68(param_1[5],&iStack_38);
      if (cVar5 == '\0') {
        uVar10 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar10);
      }
      uVar10 = __Znwm(0x18);
      FUN_000630b6(uVar10);
      piVar7 = (int *)FUN_0002dfa6(uVar10);
      uVar10 = (**(code **)(*piVar7 + 0x48))(piVar7);
      if (0 < iStack_38) {
        iStack_88 = 0;
        iStack_80 = 0;
        do {
          uVar13 = __Znwm(0x18);
          FUN_000630b6(uVar13);
          piVar7 = (int *)FUN_0002dfa6(uVar13);
          if (iStack_88 == 0) {
            uVar13 = __Znwm(0x20);
            FUN_00029d44(uVar13);
            piVar15 = (int *)FUN_0002dfa6(uVar13);
            iStack_88 = (**(code **)(*piVar15 + 0x48))(piVar15);
            uVar13 = FUN_00033b90("regions");
            FUN_00066284(uVar10,iStack_88,uVar13);
          }
          iVar11 = FUN_00180166(param_1[5],0x10);
          if (iVar11 == 0) {
            uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar13);
          }
          uVar13 = FUN_00033b90("DigiDesign umid");
          FUN_00066284(piVar7,iVar11,uVar13);
          uVar13 = FUN_00033b90("startFrame");
          uStack_4c = 0;
          uStack_48 = 0;
          cVar5 = FUN_0017ff80(param_1[5],&uStack_4c);
          if (cVar5 == '\0') {
            uVar17 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar17);
          }
          uVar17 = FUN_000859a8(uStack_4c,uStack_48);
          FUN_00066284(piVar7,uVar17,uVar13);
          uVar13 = FUN_00033b90("stopFrame");
          uStack_4c = 0;
          uStack_48 = 0;
          cVar5 = FUN_0017ff80(param_1[5],&uStack_4c);
          if (cVar5 == '\0') {
            uVar17 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar17);
          }
          uVar17 = FUN_000859a8(uStack_4c,uStack_48);
          FUN_00066284(piVar7,uVar17,uVar13);
          uVar13 = FUN_00033b90("syncFrame");
          uStack_4c = 0;
          uStack_48 = 0;
          cVar5 = FUN_0017ff80(param_1[5],&uStack_4c);
          if (cVar5 == '\0') {
            uVar17 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar17);
          }
          uVar17 = FUN_000859a8(uStack_4c,uStack_48);
          FUN_00066284(piVar7,uVar17,uVar13);
          uVar13 = FUN_00033b90("userTimeStamp");
          uStack_4c = 0;
          uStack_48 = 0;
          cVar5 = FUN_0017ff80(param_1[5],&uStack_4c);
          if (cVar5 == '\0') {
            uVar17 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar17);
          }
          uVar17 = FUN_000859a8(uStack_4c,uStack_48);
          FUN_00066284(piVar7,uVar17,uVar13);
          uVar13 = FUN_00033b90("timeStamp");
          uStack_4c = 0;
          uStack_48 = 0;
          cVar5 = FUN_0017ff80(param_1[5],&uStack_4c);
          if (cVar5 == '\0') {
            uVar17 = FUN_00033b90("GNSoundFileCannotReadFileException");
            FUN_0000bf34(uVar17);
          }
          uVar17 = FUN_000859a8(uStack_4c,uStack_48);
          FUN_00066284(piVar7,uVar17,uVar13);
          FUN_00180086(param_1[5],&uStack_3c);
          if ((((char)uStack_3c != '\0') &&
              (iVar11 = FUN_00180166(param_1[5],uStack_3c & 0xff), iVar11 != 0)) &&
             (iVar11 = FUN_00038d00(iVar11,4), iVar11 != 0)) {
            uVar13 = FUN_00033b90("name");
            FUN_00066284(piVar7,iVar11,uVar13);
          }
          if (-(uStack_3c & 0xff) != -0x1f && -1 < (int)(-(uStack_3c & 0xff) + 0x1f)) {
            iVar11 = 0;
            do {
              FUN_00180086(param_1[5],&uStack_4c);
              iVar11 = iVar11 + 1;
            } while (iVar11 < (int)(0x1f - (uStack_3c & 0xff)));
          }
          FUN_0002bb40(iStack_88,piVar7);
          if (piVar7 != (int *)0x0) {
            (**(code **)(*piVar7 + 0x44))(piVar7);
          }
          iStack_80 = iStack_80 + 1;
        } while (iStack_80 < iStack_38);
      }
      uVar13 = FUN_00033b90("regionList");
      FUN_00066284(uVar6,uVar10,uVar13);
      (**(code **)(*(int *)param_1[5] + 0x1c0))((int *)param_1[5],iVar9);
      goto LAB_0024d032;
    }
    iVar9 = 4;
    pcVar14 = &cStack_41;
    pcVar22 = "bext";
    do {
      pcVar20 = pcVar14;
      pcVar23 = pcVar22;
      if (iVar9 == 0) break;
      iVar9 = iVar9 + -1;
      pcVar23 = pcVar22 + 1;
      pcVar20 = pcVar14 + 1;
      bVar25 = *pcVar14 == *pcVar22;
      pcVar14 = pcVar20;
      pcVar22 = pcVar23;
    } while (bVar25);
    iVar9 = 0;
    if (!bVar25) {
      iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
    }
    bVar25 = iVar9 == 0;
    if (bVar25) {
      iVar11 = uStack_30 - 0x25a;
      iVar9 = (**(code **)(*(int *)param_1[5] + 0x1b8))((int *)param_1[5]);
      iVar9 = iVar9 + uStack_30;
      uVar10 = __Znwm(0x18);
      FUN_000630b6(uVar10);
      piVar7 = (int *)FUN_0002dfa6(uVar10);
      uVar10 = FUN_00033b90("Broadcast Audio Extension");
      FUN_00066284(uVar6,piVar7,uVar10);
      uVar10 = FUN_00033b90("Description");
      uVar13 = FUN_002498bc(param_1,0x100);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("Originator");
      uVar13 = FUN_002498bc(param_1,0x20);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("OriginatorRef");
      uVar13 = FUN_002498bc(param_1,0x20);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("Date");
      uVar13 = FUN_002498bc(param_1,10);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("Time");
      uVar13 = FUN_002498bc(param_1,8);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("TimeRef");
      uStack_4c = 0;
      uStack_48 = 0;
      cVar5 = FUN_0017ff80(param_1[5],&uStack_4c);
      if (cVar5 == '\0') {
        uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar13);
      }
      uVar13 = FUN_000859a8(uStack_4c,uStack_48);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("Version");
      uStack_4c = uStack_4c & 0xffff0000;
      cVar5 = FUN_0017fc6e(param_1[5],&uStack_4c);
      if (cVar5 == '\0') {
        uVar13 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar13);
      }
      uVar13 = FUN_000858da((int)(short)uStack_4c);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("UMID");
      uVar13 = FUN_00180166(param_1[5],0x40);
      FUN_00066284(piVar7,uVar13,uVar10);
      uVar10 = FUN_00033b90("Reserved");
      uVar13 = FUN_00180166(param_1[5],0xbe);
      FUN_00066284(piVar7,uVar13,uVar10);
      if (0 < iVar11) {
        uVar10 = __Znwm(0x20);
        FUN_00029d44(uVar10);
        piVar15 = (int *)FUN_0002dfa6(uVar10);
        uVar10 = (**(code **)(*piVar15 + 0x48))(piVar15);
        uVar13 = FUN_00180166(param_1[5],iVar11);
        FUN_00027b4e(uVar13);
        iVar16 = FUN_00027abc(uVar13);
        iVar19 = 0;
        iVar21 = 0;
        iStack_6c = 0;
        do {
          if (((iVar21 == iVar11) || (*(char *)(iVar16 + iVar21) == ',')) ||
             (*(char *)(iVar16 + iVar21) == '\r')) {
            if (iStack_6c < iVar21) {
              if (iVar19 == 0) {
                uVar17 = __Znwm(0x20);
                FUN_00029d44(uVar17);
                piVar15 = (int *)FUN_0002dfa6(uVar17);
                iVar19 = (**(code **)(*piVar15 + 0x48))(piVar15);
                FUN_0002bb40(uVar10,iVar19);
              }
              uVar17 = FUN_00039d7a(iVar16 + iStack_6c,iVar21 - iStack_6c);
              FUN_0002bb40(iVar19,uVar17);
            }
            if ((iVar21 < iVar11) && (*(char *)(iVar16 + iVar21) == '\r')) {
              iVar21 = iVar21 + 1;
              if ((iVar11 == iVar21) || (*(char *)(iVar16 + iVar21) != '\n')) {
                uVar17 = FUN_00033b90("GNSoundFileCannotReadFileException");
                FUN_0000bf34(uVar17);
              }
              iVar19 = 0;
            }
            iVar21 = iVar21 + 1;
            iStack_6c = iVar21;
          }
          else {
            iVar21 = iVar21 + 1;
          }
        } while (iVar21 <= iVar11);
        FUN_00027bec(uVar13);
        uVar13 = FUN_00033b90("CodingHistory");
        FUN_00066284(piVar7,uVar10,uVar13);
      }
      if (piVar7 != (int *)0x0) {
        (**(code **)(*piVar7 + 0x44))(piVar7);
      }
      (**(code **)(*(int *)param_1[5] + 0x1c0))((int *)param_1[5],iVar9);
      goto LAB_0024d032;
    }
    iVar9 = 4;
    pcVar14 = &cStack_41;
    pcVar22 = "acid";
    do {
      pcVar20 = pcVar14;
      pcVar23 = pcVar22;
      if (iVar9 == 0) break;
      iVar9 = iVar9 + -1;
      pcVar23 = pcVar22 + 1;
      pcVar20 = pcVar14 + 1;
      bVar25 = *pcVar14 == *pcVar22;
      pcVar14 = pcVar20;
      pcVar22 = pcVar23;
    } while (bVar25);
    iVar9 = 0;
    if (!bVar25) {
      iVar9 = (uint)(byte)pcVar20[-1] - (uint)(byte)pcVar23[-1];
    }
    if (iVar9 != 0) {
      if ((0 < (int)uStack_30) && (iVar9 = FUN_00180166(param_1[5],uStack_30), iVar9 != 0)) {
        uVar10 = FUN_0003887c(&cStack_41,4,4);
        FUN_0002bb40(uVar8,uVar10);
        FUN_0002bb40(uVar8,iVar9);
      }
      goto LAB_0024d032;
    }
    iVar9 = (**(code **)(*(int *)param_1[5] + 0x1b8))((int *)param_1[5]);
    iVar9 = iVar9 + uStack_30;
    if (uStack_30 == 0) goto LAB_0024eb8a;
    uVar10 = FUN_00180166(param_1[5],uStack_30);
    uVar13 = (**(code **)(*param_1 + 0x1ac))(param_1);
    piVar7 = (int *)FUN_0028a322(uVar13,uVar10);
  }
  if (piVar7 != (int *)0x0) {
    uVar10 = (**(code **)(*piVar7 + 0x1a4))(piVar7);
    FUN_00066284(uVar6,piVar7,uVar10);
  }
LAB_0024eb8a:
  (**(code **)(*(int *)param_1[5] + 0x1c0))((int *)param_1[5],iVar9);
  goto LAB_0024d032;
}


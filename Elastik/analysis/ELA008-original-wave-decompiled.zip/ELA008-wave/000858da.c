
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000858da(dword param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  puVar1 = (undefined4 *)__Znwm(0x14);
  func_0x001821dc(puVar1);
  *puVar1 = &UNK_00374468;
  *(undefined1 *)(puVar1 + 4) = 0;
  puVar1[3] = 0;
  piVar2 = (int *)FUN_0002dfa6(puVar1);
  iVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
  if (iVar3 != 0) {
    *(undefined1 *)(iVar3 + 0x10) = 0x69;
    *(dword *)(iVar3 + 0xc) = param_1;
    return iVar3;
  }
  uVar4 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNNumber.cpp"
                         );
  uVar5 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x9e,uVar4,"this != 0");
  mach_header_00000000.ncmds._0_1_ = 0x69;
  mach_header_00000000.filetype = param_1;
  return 0;
}


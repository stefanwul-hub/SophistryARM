
int FUN_002499f8(int param_1)

{
  short sVar1;
  
  sVar1 = *(short *)(param_1 + 0x1a);
  if (sVar1 == 1) {
    return 1;
  }
  if (sVar1 != 2) {
    return sVar1 + 0x100;
  }
  return 2;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0024cc60(int *param_1,undefined4 param_2,int param_3,int param_4)

{
  short sVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  int aiStack_20 [4];
  
  sVar1 = *(short *)((int)param_1 + 0x1e);
  if (sVar1 == 2) {
    iStack_3c = (int)(short)param_1[0xe];
    sVar1 = *(short *)((int)param_1 + 0x3a);
LAB_0024ccd0:
    iVar3 = (int)sVar1;
    uVar4 = FUN_0000aecc(iVar3);
    iVar6 = param_3 % iStack_3c;
    (**(code **)(*(int *)param_1[5] + 0x1c0))
              ((int *)param_1[5],iVar3 * (param_3 / iStack_3c) + param_1[0xc]);
    iStack_40 = 0;
    while( true ) {
      iVar7 = iStack_3c - iVar6;
      if (iVar7 < param_4) {
        iStack_44 = iStack_3c;
      }
      else {
        iStack_44 = param_4 + iVar6;
        iVar7 = iStack_44 - iVar6;
      }
      aiStack_20[0] = iVar3;
      cVar2 = (**(code **)(*(int *)param_1[5] + 0x1ac))((int *)param_1[5],uVar4,aiStack_20);
      if ((cVar2 == '\0') || (iVar3 != aiStack_20[0])) {
        uVar5 = FUN_00033b90("GNSoundFileCannotReadFileException");
        FUN_0000bf34(uVar5);
      }
      else if (*(short *)((int)param_1 + 0x1e) == 2) {
        func_0x0024c638(param_1,uVar4,iVar6,iStack_44,param_2,iStack_40);
      }
      else {
        FUN_00249b18(param_1,uVar4,iVar6,iStack_44,param_2,iStack_40);
      }
      param_4 = param_4 - iVar7;
      if (param_4 < 1) break;
      iStack_40 = iStack_40 + iVar7;
      iVar6 = 0;
    }
    FUN_0000b122(uVar4);
    return;
  }
  if (sVar1 < 3) {
    if (sVar1 != 1) {
      return;
    }
  }
  else if (sVar1 != 3) {
    if (sVar1 != 0x11) {
      return;
    }
    iStack_3c = (int)*(short *)((int)param_1 + 0x3e) / (int)*(short *)((int)param_1 + 0x1a);
    sVar1 = (short)param_1[0x10];
    goto LAB_0024ccd0;
  }
  iVar3 = param_1[5];
  iVar6 = param_1[0xc];
  uVar4 = (**(code **)(*param_1 + 0x1b4))(param_1);
  uVar5 = (**(code **)(*param_1 + 0x1b0))(param_1);
  FUN_00219820(param_1,param_2,param_3,param_4,uVar5,uVar4,iVar6,iVar3);
  return;
}


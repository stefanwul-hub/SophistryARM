
/* WARNING: Type propagation algorithm not settling */

int FUN_0024bfce(int *param_1,int param_2,undefined4 *param_3,int *param_4,int param_5,int param_6,
                undefined4 param_7)

{
  int iVar1;
  int iVar2;
  int iVar3;
  char cStack_2d;
  undefined4 uStack_2b;
  int iStack_27;
  undefined1 uStack_23;
  undefined4 uStack_22;
  undefined1 uStack_1e;
  undefined4 uStack_1d;
  undefined1 uStack_19;
  int iStack_18;
  int aiStack_14 [2];
  
  aiStack_14[1] = 8;
  cStack_2d = (**(code **)(*param_1 + 0x1ac))(param_1,&uStack_2b,aiStack_14 + 1);
  if (cStack_2d != '\0') {
    uStack_19 = 0;
    uStack_1e = 0;
    iStack_18 = -1;
    uStack_1d = uStack_2b;
    uStack_22 = CONCAT13((undefined1)iStack_27,uStack_2b._1_3_);
    aiStack_14[0] = iStack_27;
    iVar1 = FUN_0017f5d8(param_1);
    if (iVar1 != 0) {
      func_0x0000a838(aiStack_14);
    }
    if (0 < param_6) {
      iVar3 = 0;
      iVar1 = param_5;
      do {
        iVar2 = _strncmp(iVar1,&uStack_1d,4);
        if (iVar2 == 0) goto LAB_0024c12b;
        iVar3 = iVar3 + 1;
        iVar1 = iVar1 + 5;
      } while (param_6 != iVar3);
      if (0 < param_6) {
        iVar1 = 0;
        do {
          iVar3 = _strncmp(param_5,&uStack_22,4);
          if (iVar3 == 0) goto LAB_0024c089;
          iVar1 = iVar1 + 1;
          param_5 = param_5 + 5;
        } while (param_6 != iVar1);
      }
    }
    if ((aiStack_14[0] < 1) ||
       (iVar1 = (**(code **)(*param_1 + 0x1b8))(param_1), param_2 < iVar1 + aiStack_14[0])) {
LAB_0024c089:
      aiStack_14[1] = 1;
      cStack_2d = (**(code **)(*param_1 + 0x1ac))(param_1,&uStack_23,aiStack_14 + 1);
      iStack_18 = CONCAT13(uStack_23,iStack_27._1_3_);
      iVar1 = FUN_0017f5d8(param_1);
      if (iVar1 != 0) {
        func_0x0000a838(&iStack_18);
      }
      *param_3 = uStack_22;
      *param_4 = iStack_18;
    }
    else {
LAB_0024c12b:
      *param_3 = uStack_1d;
      *param_4 = aiStack_14[0];
    }
    if ((-1 < *param_4) &&
       ((iVar1 = (**(code **)(*param_1 + 0x1b8))(param_1), iVar1 + *param_4 <= param_2 ||
        (iVar1 = _strcmp(param_3,param_7), iVar1 == 0)))) {
      return (int)cStack_2d;
    }
  }
  return 0;
}


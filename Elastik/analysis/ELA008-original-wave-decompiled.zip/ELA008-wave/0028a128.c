
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0028a128(undefined4 *param_1)

{
  func_0x0002dc66(param_1);
  *param_1 = &UNK_003b3988;
  FUN_0028983c();
  param_1[6] = 0;
  *(undefined1 *)(param_1 + 3) = 0;
  param_1[7] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[8] = 0;
  *param_1 = &UNK_003b3ec8;
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_002447c2(undefined4 *param_1)

{
  FUN_00219446(param_1);
  *param_1 = &UNK_003a91c8;
  param_1[0xd] = 0;
  param_1[5] = 0;
  *(undefined1 *)(param_1 + 0xc) = 0;
  *(undefined1 *)((int)param_1 + 0x31) = 0;
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00218aa6(undefined4 *param_1)

{
  func_0x00217cd2(param_1);
  *param_1 = &UNK_003a1f28;
  param_1[0x12] = 0;
  param_1[0x15] = 0;
  return;
}


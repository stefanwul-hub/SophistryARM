ELA010: 26 selected functions, 3 newly decompiled, 284 distinct overall.
Pinned original: 5b313e738d92c438253927e8d57969ddfd99302b1d978372ac9e045490698920.
Ghidra 11.3.2, read-only project, AuditElastikFunctions roots, direct-call depth 1.
Raw C/assembly unchanged; audit checkpoint/scope labels updated from generic script defaults.
Five valid-domain native ports are in OriginalFileOpen.cpp, other dependencies remain explicit bindings or previous ports.
No original executable, installer or user bank is included.

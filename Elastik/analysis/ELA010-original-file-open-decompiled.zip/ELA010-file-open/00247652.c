
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00247652(undefined4 *param_1)

{
  FUN_00219446(param_1);
  *param_1 = &UNK_003a9568;
  param_1[0xb] = 0;
  param_1[5] = 0;
  return;
}


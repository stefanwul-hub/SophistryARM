
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001ab318(undefined4 *param_1)

{
  func_0x0002dc66(param_1);
  *param_1 = &UNK_00392ee8;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[4] = 0;
  param_1[9] = 0;
  param_1[3] = 0;
  param_1[10] = 0;
  param_1[0x11] = 0;
  param_1[0xb] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0x40e58880;
  param_1[8] = &UNK_0000270f;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x13] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  dRam003d4a58 = (double)(~-(ulonglong)(dRam003d4a58 != 0.0) & (ulonglong)DOUBLE_00364730 |
                         (ulonglong)dRam003d4a58 & -(ulonglong)(dRam003d4a58 != 0.0));
  if (((double)CONCAT44(uRam003d4a54,uRam003d4a50) == 0.0) &&
     (!NAN((double)CONCAT44(uRam003d4a54,uRam003d4a50)))) {
    uRam003d4a50 = 0;
    uRam003d4a54 = 0x40100000;
  }
  param_1[0x12] = 0;
  return;
}


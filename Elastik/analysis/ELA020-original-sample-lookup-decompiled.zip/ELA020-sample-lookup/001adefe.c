
int FUN_001adefe(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  int iStack_60;
  undefined1 auStack_5c [80];
  
  if (param_1 == 0) {
    iStack_60 = 0;
  }
  else {
    uVar1 = __Znwm(0x74);
    FUN_001ab318(uVar1);
    piVar2 = (int *)FUN_0002dfa6(uVar1);
    iStack_60 = (**(code **)(*piVar2 + 0x48))(piVar2);
  }
  FUN_0000bea2(auStack_5c);
  iVar3 = _setjmp(auStack_5c);
  if (iVar3 == 0) {
    if (iStack_60 != 0) {
      FUN_001adbb6(iStack_60,param_1);
    }
    FUN_0000bec0(auStack_5c);
    return iStack_60;
  }
  return 0;
}


001aaeba  55  PUSH EBP
001aaebb  89e5  MOV EBP,ESP
001aaebd  83ec18  SUB ESP,0x18
001aaec0  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001aaec3  890424  MOV dword ptr [ESP],EAX
001aaec6  e8fbfaffff  CALL 0x001aa9c6
001aaecb  85c0  TEST EAX,EAX
001aaecd  0f95c0  SETNZ AL
001aaed0  0fb6c0  MOVZX EAX,AL
001aaed3  c9  LEAVE
001aaed4  c3  RET

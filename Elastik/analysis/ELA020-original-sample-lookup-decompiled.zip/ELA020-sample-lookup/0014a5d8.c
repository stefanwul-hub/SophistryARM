
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0014a5d8(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  double dStack_2c;
  undefined4 auStack_20 [4];
  
  uVar2 = FUN_00033b90("0123456789.");
  auStack_20[0] = 0;
  if (*(int *)(param_1 + 0x24) != 0) {
    uVar3 = func_0x0003a99a(*(int *)(param_1 + 0x24));
    piVar4 = (int *)func_0x0018bc7c(uVar3);
    (**(code **)(*piVar4 + 0x1d8))(piVar4,3,0);
    (**(code **)(*piVar4 + 0x1d4))(piVar4,uVar2,0);
    cVar1 = (**(code **)(*piVar4 + 0x1e0))(piVar4,uVar2,auStack_20);
    if (cVar1 != '\0') {
      piVar4 = (int *)func_0x0018bc7c(auStack_20[0]);
      (**(code **)(*piVar4 + 500))(piVar4,&dStack_2c);
    }
    if ((dStack_2c != DOUBLE_00364718) || (NAN(dStack_2c) || NAN(DOUBLE_00364718))) {
      return;
    }
  }
  func_0x0015f258(*(undefined4 *)(param_1 + 0x78));
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000df2aa(undefined4 *param_1)

{
  undefined4 *puVar1;
  int iVar2;
  
  func_0x0002dc66(param_1);
  *param_1 = &UNK_0037b2c8;
  *(undefined1 *)(param_1 + 6) = 1;
  param_1[4] = 0;
  param_1[3] = 0;
  puVar1 = (undefined4 *)FUN_0000aecc(0x2d);
  param_1[5] = puVar1;
  for (iVar2 = 0xb; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar1 = 0;
    puVar1 = puVar1 + 1;
  }
  *(undefined1 *)puVar1 = 0;
  *(undefined1 *)(param_1[5] + 0x2c) = 1;
  *(undefined4 **)(param_1[5] + 0x28) = param_1;
  return;
}


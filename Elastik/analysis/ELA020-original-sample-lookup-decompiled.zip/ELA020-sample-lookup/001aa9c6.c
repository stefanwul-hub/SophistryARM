
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001aa9c6(int param_1)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  char *pcVar6;
  int *piVar7;
  int *piVar8;
  longdouble lVar9;
  undefined1 auStack_6c [92];
  
  piVar2 = (int *)FUN_001a9c28(param_1);
  if (((*(int *)(param_1 + 0x24) == 0) && (piVar2 != (int *)0x0)) &&
     (cVar1 = (**(code **)(*piVar2 + 0x1d0))(piVar2), cVar1 != '\0')) {
    piVar5 = *(int **)(param_1 + 0x10);
    if (piVar5 != (int *)0x0) {
      (**(code **)(*piVar5 + 0x44))(piVar5);
      *(undefined4 *)(param_1 + 0x10) = 0;
    }
    uVar3 = __Znwm(0x1c);
    FUN_000df2aa(uVar3);
    uVar3 = FUN_0002dfa6(uVar3);
    *(undefined4 *)(param_1 + 0x24) = uVar3;
    FUN_0000bea2(auStack_6c);
    iVar4 = _setjmp(auStack_6c);
    if (iVar4 == 0) {
      FUN_000e13de(*(undefined4 *)(param_1 + 0x24),piVar2);
      FUN_0000bec0(auStack_6c);
    }
    else {
      piVar5 = *(int **)(param_1 + 0x24);
      if (piVar5 != (int *)0x0) {
        (**(code **)(*piVar5 + 0x44))(piVar5);
      }
      *(undefined4 *)(param_1 + 0x24) = 0;
    }
    if (*(int *)(param_1 + 0x24) == 0) {
      return 0;
    }
    uVar3 = FUN_00033b90("/Info.plist");
    piVar5 = (int *)FUN_000e1a68(*(undefined4 *)(param_1 + 0x24),uVar3);
    if ((piVar5 == (int *)0x0) || (cVar1 = (**(code **)(*piVar5 + 0x1d0))(piVar5), cVar1 == '\0')) {
      iVar4 = (**(code **)(*piVar2 + 0x1c8))(piVar2);
      if (iVar4 == 0) {
        pcVar6 = "";
      }
      else {
        uVar3 = (**(code **)(*piVar2 + 0x1c8))(piVar2);
        pcVar6 = (char *)FUN_00034962(uVar3);
      }
      FUN_0000ab14("Info.plist not found in %s",pcVar6);
    }
    else {
      piVar5 = (int *)FUN_0006739a(piVar5);
      if (piVar5 == (int *)0x0) {
        iVar4 = (**(code **)(*piVar2 + 0x1c8))(piVar2);
        if (iVar4 == 0) {
          pcVar6 = "";
        }
        else {
          uVar3 = (**(code **)(*piVar2 + 0x1c8))(piVar2);
          pcVar6 = (char *)FUN_00034962(uVar3);
        }
        FUN_0000ab14("Info.plist cannot be parsed from %s",pcVar6);
      }
      else {
        iVar4 = (**(code **)(*piVar5 + 0xc))(piVar5);
        if (iVar4 == 0) {
          pcVar6 = "";
        }
        else {
          uVar3 = (**(code **)(*piVar5 + 0xc))(piVar5);
          pcVar6 = (char *)FUN_00034962(uVar3);
        }
        FUN_0000ab14("Loaded archive %s",pcVar6);
        uVar3 = FUN_00033b90("identifier");
        piVar7 = (int *)FUN_00064626(piVar5,uVar3);
        if ((piVar7 != (int *)0x0) && (cVar1 = (**(code **)(*piVar7 + 0x80))(piVar7), cVar1 != '\0')
           ) {
          piVar7 = (int *)FUN_0003b448(piVar7);
        }
        piVar8 = *(int **)(param_1 + 0x10);
        if (piVar7 != piVar8) {
          if (piVar8 != (int *)0x0) {
            (**(code **)(*piVar8 + 0x44))(piVar8);
          }
          *(int **)(param_1 + 0x10) = piVar7;
          if (piVar7 != (int *)0x0) {
            (**(code **)(*piVar7 + 0x40))(piVar7);
          }
        }
        uVar3 = FUN_00033b90("title");
        piVar8 = (int *)FUN_00064626(piVar5,uVar3);
        piVar7 = *(int **)(param_1 + 0xc);
        if (piVar8 != piVar7) {
          if (piVar7 != (int *)0x0) {
            (**(code **)(*piVar7 + 0x44))(piVar7);
          }
          *(int **)(param_1 + 0xc) = piVar8;
          if (piVar8 != (int *)0x0) {
            (**(code **)(*piVar8 + 0x40))(piVar8);
          }
        }
        uVar3 = FUN_00033b90("serial");
        piVar8 = (int *)FUN_00064626(piVar5,uVar3);
        piVar7 = *(int **)(param_1 + 0x14);
        if (piVar8 != piVar7) {
          if (piVar7 != (int *)0x0) {
            (**(code **)(*piVar7 + 0x44))(piVar7);
          }
          *(int **)(param_1 + 0x14) = piVar8;
          if (piVar8 != (int *)0x0) {
            (**(code **)(*piVar8 + 0x40))(piVar8);
          }
        }
        uVar3 = FUN_00033b90("color");
        piVar8 = (int *)FUN_00064626(piVar5,uVar3);
        piVar7 = *(int **)(param_1 + 0x28);
        if (piVar8 != piVar7) {
          if (piVar7 != (int *)0x0) {
            (**(code **)(*piVar7 + 0x44))(piVar7);
          }
          *(int **)(param_1 + 0x28) = piVar8;
          if (piVar8 != (int *)0x0) {
            (**(code **)(*piVar8 + 0x40))(piVar8);
          }
        }
        uVar3 = FUN_00033b90("gracePeriode");
        iVar4 = FUN_00064626(piVar5,uVar3);
        if (iVar4 != 0) {
          lVar9 = (longdouble)FUN_00034496(iVar4);
          *(double *)(param_1 + 0x34) = (double)(float)lVar9;
        }
      }
    }
    if (*(int *)(param_1 + 0x10) == 0) {
      piVar5 = (int *)(**(code **)(*piVar2 + 0x1bc))(piVar2);
      if ((piVar5 != (int *)0x0) && (cVar1 = (**(code **)(*piVar5 + 0x80))(piVar5), cVar1 != '\0'))
      {
        piVar5 = (int *)FUN_0003b448(piVar5);
      }
      piVar7 = *(int **)(param_1 + 0x10);
      if (piVar5 != piVar7) {
        if (piVar7 != (int *)0x0) {
          (**(code **)(*piVar7 + 0x44))(piVar7);
        }
        *(int **)(param_1 + 0x10) = piVar5;
        if (piVar5 != (int *)0x0) {
          (**(code **)(*piVar5 + 0x40))(piVar5);
        }
      }
    }
    if (*(int *)(param_1 + 0xc) == 0) {
      piVar5 = (int *)(**(code **)(*piVar2 + 0x1c8))(piVar2);
      piVar2 = *(int **)(param_1 + 0xc);
      if (piVar5 != piVar2) {
        if (piVar2 != (int *)0x0) {
          (**(code **)(*piVar2 + 0x44))(piVar2);
        }
        *(int **)(param_1 + 0xc) = piVar5;
        if (piVar5 != (int *)0x0) {
          (**(code **)(*piVar5 + 0x40))(piVar5);
        }
      }
    }
  }
  return *(undefined4 *)(param_1 + 0x24);
}


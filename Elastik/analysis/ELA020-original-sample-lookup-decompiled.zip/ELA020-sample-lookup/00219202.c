
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_00219202(undefined4 param_1)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  int *piStack_78;
  int iStack_74;
  undefined1 auStack_6c [76];
  int *piStack_20;
  
  iStack_74 = 0;
LAB_00219217:
  uVar3 = __Znwm(0x38);
  func_0x002447c2(uVar3);
LAB_0021922d:
  piVar4 = (int *)FUN_0002dfa6(uVar3);
  piStack_78 = (int *)(**(code **)(*piVar4 + 0x48))(piVar4);
  FUN_0000bea2(auStack_6c);
  iVar5 = _setjmp(auStack_6c);
  if (iVar5 != 0) goto LAB_002192e4;
LAB_0021925b:
  if (piStack_78 != (int *)0x0) {
    (**(code **)(*piStack_78 + 0x1a4))(piStack_78,param_1);
  }
  FUN_0000bec0(auStack_6c);
  do {
    if (piStack_78 != (int *)0x0) {
      return piStack_78;
    }
    do {
      iStack_74 = iStack_74 + 1;
      if (4 < iStack_74) {
        uVar3 = FUN_00033b90("GNSoundFileFormatNotSupportedException");
        FUN_0000bf34(uVar3);
        return (int *)0x0;
      }
      if (iStack_74 == 1) {
        uVar3 = __Znwm(0x840);
        func_0x0024940e(uVar3);
        goto LAB_0021922d;
      }
      if (iStack_74 < 2) {
        if (iStack_74 == 0) goto LAB_00219217;
      }
      else {
        if (iStack_74 == 2) {
          uVar3 = __Znwm(0x34);
          func_0x00243c6a(uVar3);
          goto LAB_0021922d;
        }
        if (iStack_74 == 3) {
          uVar3 = __Znwm(0x30);
          func_0x00247652(uVar3);
          goto LAB_0021922d;
        }
      }
      piStack_78 = (int *)0x0;
      FUN_0000bea2(auStack_6c);
      iVar5 = _setjmp(auStack_6c);
      if (iVar5 == 0) goto LAB_0021925b;
LAB_002192e4:
      piVar4 = piStack_20;
      piVar6 = (int *)(**(code **)(*piStack_20 + 0x1ac))(piStack_20);
      pcVar1 = *(code **)(*piVar6 + 0x88);
      uVar3 = FUN_00033b90("GNSoundFileFormatNotSupportedException");
      cVar2 = (*pcVar1)(piVar6,uVar3);
    } while (cVar2 != '\0');
    (**(code **)(*piVar4 + 0x1a8))(piVar4);
  } while( true );
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0015f48c(undefined4 param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  
  if (param_3 == 0) {
    return 0;
  }
  if (iRam003d47d8 == 0) {
    uVar4 = __Znwm(0x18);
    FUN_000630b6(uVar4);
    iRam003d47d8 = FUN_0002dfa6(uVar4);
    iVar2 = FUN_00064626(iRam003d47d8,param_3);
  }
  else {
    iVar2 = FUN_00064626(iRam003d47d8,param_3);
  }
  if (iVar2 != 0) {
    return iVar2;
  }
  piVar3 = (int *)FUN_0009af5e(param_3);
  if ((piVar3 == (int *)0x0) || (cVar1 = (**(code **)(*piVar3 + 0x1d0))(piVar3), cVar1 == '\0')) {
    if (param_2 == 0) {
      return 0;
    }
    uVar4 = func_0x0000cfca();
    iVar2 = FUN_00068b5e(uVar4,param_2);
    if (iVar2 == 0) {
      return 0;
    }
    uVar4 = FUN_001aa9c6(iVar2);
    iVar2 = FUN_000e1a68(uVar4,param_3);
    if (iVar2 == 0) {
      return 0;
    }
    iVar2 = FUN_001adefe(iVar2);
    if (iVar2 == 0) {
      return 0;
    }
  }
  else {
    iVar2 = FUN_001adefe(piVar3);
    if (iVar2 == 0) {
      return 0;
    }
    FUN_00066284(iRam003d47d8,iVar2,param_3);
  }
  FUN_00066284(iRam003d47d8,iVar2,param_3);
  return iVar2;
}


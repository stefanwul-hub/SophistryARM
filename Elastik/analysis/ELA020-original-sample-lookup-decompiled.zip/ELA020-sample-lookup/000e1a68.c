
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000e1a68(int param_1,int *param_2)

{
  int iVar1;
  short sVar2;
  undefined4 *puVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  
  iVar1 = *(int *)(param_1 + 0x14);
  puVar3 = (undefined4 *)__Znwm(0x1c);
  func_0x0009a1a2(puVar3);
  *puVar3 = &UNK_0037b668;
  puVar3[4] = 0;
  puVar3[5] = 0;
  puVar3[6] = 0;
  piVar4 = (int *)FUN_0002dfa6(puVar3);
  iVar5 = (**(code **)(*piVar4 + 0x48))(piVar4);
  iVar6 = FUN_000349f4(param_2);
  if (iVar6 < 1) {
    uVar7 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                           );
    uVar8 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar8,"Assertion failed in line %d of %s: %s.",0x69d,uVar7,
                 "posixPath->getLength() > 0");
  }
  sVar2 = FUN_00035d80(param_2,0);
  if (sVar2 != 0x2f) {
    uVar7 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                           );
    uVar8 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar8,"Assertion failed in line %d of %s: %s.",0x69e,uVar7,
                 "posixPath->getCharacterAtIndex(0) == \'/\'");
  }
  *(int *)(iVar5 + 0x10) = iVar1;
  *(undefined4 *)(iVar5 + 0x14) = 0;
  uVar7 = (**(code **)(*param_2 + 0x40))(param_2);
  *(undefined4 *)(iVar5 + 0x18) = uVar7;
  (**(code **)(**(int **)(iVar1 + 0x20) + 0x1a4))(*(int **)(iVar1 + 0x20));
  if (*(int *)(iVar1 + 0x24) != 0) {
    func_0x000df8d2(iVar5);
    (**(code **)(**(int **)(iVar1 + 0x20) + 0x1ac))(*(int **)(iVar1 + 0x20));
    (**(code **)(**(int **)(iVar1 + 0x28) + 0x40))(*(int **)(iVar1 + 0x28));
    return iVar5;
  }
  (**(code **)(**(int **)(iVar1 + 0x20) + 0x1ac))(*(int **)(iVar1 + 0x20));
  (**(code **)(**(int **)(iVar1 + 0x28) + 0x40))(*(int **)(iVar1 + 0x28));
  return iVar5;
}


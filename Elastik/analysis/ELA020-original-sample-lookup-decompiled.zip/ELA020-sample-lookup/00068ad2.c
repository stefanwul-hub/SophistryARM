
undefined4 FUN_00068ad2(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  
  iVar5 = 0;
  iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x60));
  if (0 < iVar2) {
    do {
      uVar3 = FUN_0002a364(*(undefined4 *)(param_1 + 0x60),iVar5);
      cVar1 = FUN_001aaeba(uVar3);
      if ((cVar1 != '\0') && (iVar2 = func_0x001a9bce(uVar3), iVar2 != 0)) {
        piVar4 = (int *)func_0x001a9bce(uVar3);
        cVar1 = (**(code **)(*piVar4 + 0x88))(piVar4,param_2);
        if (cVar1 != '\0') {
          return uVar3;
        }
      }
      iVar5 = iVar5 + 1;
      iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x60));
    } while (iVar5 < iVar2);
  }
  return 0;
}


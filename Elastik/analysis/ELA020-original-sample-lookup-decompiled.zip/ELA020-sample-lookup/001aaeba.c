
bool FUN_001aaeba(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_001aa9c6(param_1);
  return iVar1 != 0;
}


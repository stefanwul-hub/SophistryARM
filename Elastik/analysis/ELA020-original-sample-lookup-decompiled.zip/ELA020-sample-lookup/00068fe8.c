
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00068fe8(undefined4 *param_1)

{
  func_0x0009a1a2(param_1);
  *param_1 = &UNK_00371fa8;
  param_1[5] = 0x20202020;
  param_1[4] = 0x20202020;
  param_1[8] = 0xffffffff;
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}


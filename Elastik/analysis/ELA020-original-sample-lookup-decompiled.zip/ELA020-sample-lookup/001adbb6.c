
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001adbb6(int param_1,int *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  longdouble lVar8;
  longdouble lVar9;
  int aiStack_20 [4];
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930("/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNSoundFile.cpp");
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x28b,uVar2,"this != 0");
  }
  if (*(int *)(param_1 + 0x54) != 0) {
    uVar2 = func_0x0000a930("/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNSoundFile.cpp");
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x28b,uVar2,"_reader == 0");
  }
  piVar4 = (int *)FUN_00219202(param_2);
  *(int **)(param_1 + 0x54) = piVar4;
  if (piVar4 == (int *)0x0) {
    uVar2 = FUN_00033b90("GNSoundFileFormatNotSupportedException");
    FUN_0000bf34(uVar2);
    piVar4 = *(int **)(param_1 + 0x54);
  }
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 0x40))(piVar4);
    piVar4 = *(int **)(param_1 + 0x54);
  }
  uVar2 = (**(code **)(*piVar4 + 0x1b4))(piVar4);
  *(undefined4 *)(param_1 + 0x14) = uVar2;
  lVar8 = (longdouble)(**(code **)(**(int **)(param_1 + 0x54) + 0x1b8))(*(int **)(param_1 + 0x54));
  *(double *)(param_1 + 0x18) = (double)lVar8;
  uVar2 = (**(code **)(**(int **)(param_1 + 0x54) + 0x1b0))(*(int **)(param_1 + 0x54));
  *(undefined4 *)(param_1 + 0x20) = uVar2;
  uVar2 = (**(code **)(**(int **)(param_1 + 0x54) + 0x1ac))(*(int **)(param_1 + 0x54));
  *(undefined4 *)(param_1 + 0x10) = uVar2;
  (**(code **)(**(int **)(param_1 + 0x54) + 0x1c4))
            (*(int **)(param_1 + 0x54),*(undefined4 *)(param_1 + 0x48));
  piVar4 = *(int **)(param_1 + 0x50);
  if (param_2 != piVar4) {
    if (piVar4 != (int *)0x0) {
      (**(code **)(*piVar4 + 0x44))(piVar4);
    }
    *(int **)(param_1 + 0x50) = param_2;
    if (param_2 != (int *)0x0) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
  }
  if (*(int *)(param_1 + 0x14) == 1) {
    aiStack_20[0] = 0;
    piVar4 = (int *)FUN_001ac468(param_2,aiStack_20,0);
    if ((piVar4 != (int *)0x0) && (cVar1 = (**(code **)(*piVar4 + 0x1d0))(piVar4), cVar1 != '\0')) {
      piVar5 = (int *)FUN_00219202(piVar4);
      *(int **)(param_1 + 0x60) = piVar5;
      if (piVar5 != (int *)0x0) {
        lVar8 = (longdouble)(**(code **)(*piVar5 + 0x1b8))(piVar5);
        lVar9 = (longdouble)
                (**(code **)(**(int **)(param_1 + 0x54) + 0x1b8))(*(int **)(param_1 + 0x54));
        if (((double)lVar8 == (double)lVar9) && (!NAN((double)lVar8) && !NAN((double)lVar9))) {
          iVar6 = (**(code **)(**(int **)(param_1 + 0x60) + 0x1b0))(*(int **)(param_1 + 0x60));
          iVar7 = (**(code **)(**(int **)(param_1 + 0x54) + 0x1b0))(*(int **)(param_1 + 0x54));
          if (iVar6 == iVar7) {
            iVar6 = (**(code **)(**(int **)(param_1 + 0x60) + 0x1bc))(*(int **)(param_1 + 0x60));
            iVar7 = (**(code **)(**(int **)(param_1 + 0x54) + 0x1bc))(*(int **)(param_1 + 0x54));
            if (iVar6 == iVar7) {
              if (aiStack_20[0] == 1) {
                *(undefined4 *)(param_1 + 0x5c) = *(undefined4 *)(param_1 + 0x60);
                *(undefined4 *)(param_1 + 0x60) = *(undefined4 *)(param_1 + 0x54);
                piVar5 = *(int **)(param_1 + 0x6c);
                if (piVar4 != piVar5) {
                  if (piVar5 != (int *)0x0) {
                    (**(code **)(*piVar5 + 0x44))(piVar5);
                  }
                  *(int **)(param_1 + 0x6c) = piVar4;
                  (**(code **)(*piVar4 + 0x40))(piVar4);
                }
                piVar4 = *(int **)(param_1 + 0x70);
                if (param_2 != piVar4) {
                  if (piVar4 != (int *)0x0) {
                    (**(code **)(*piVar4 + 0x44))(piVar4);
                  }
                  *(int **)(param_1 + 0x70) = param_2;
                  if (param_2 != (int *)0x0) {
                    (**(code **)(*param_2 + 0x40))(param_2);
                  }
                }
              }
              else {
                *(undefined4 *)(param_1 + 0x5c) = *(undefined4 *)(param_1 + 0x54);
                piVar5 = *(int **)(param_1 + 0x6c);
                if (param_2 != piVar5) {
                  if (piVar5 != (int *)0x0) {
                    (**(code **)(*piVar5 + 0x44))(piVar5);
                  }
                  *(int **)(param_1 + 0x6c) = param_2;
                  if (param_2 != (int *)0x0) {
                    (**(code **)(*param_2 + 0x40))(param_2);
                  }
                }
                piVar5 = *(int **)(param_1 + 0x70);
                if (piVar4 != piVar5) {
                  if (piVar5 != (int *)0x0) {
                    (**(code **)(*piVar5 + 0x44))(piVar5);
                  }
                  *(int **)(param_1 + 0x70) = piVar4;
                  (**(code **)(*piVar4 + 0x40))(piVar4);
                }
              }
              *(undefined4 *)(param_1 + 0x4c) = 1;
              *(undefined4 *)(param_1 + 0x14) = 2;
              piVar4 = *(int **)(param_1 + 0x60);
              if (piVar4 != (int *)0x0) {
                (**(code **)(*piVar4 + 0x40))(piVar4);
              }
              piVar4 = *(int **)(param_1 + 0x5c);
              if (piVar4 == (int *)0x0) {
                return;
              }
              (**(code **)(*piVar4 + 0x40))(piVar4);
              return;
            }
          }
        }
        *(undefined4 *)(param_1 + 0x60) = 0;
      }
    }
  }
  return;
}


000dfab4  55  PUSH EBP
000dfab5  89e5  MOV EBP,ESP
000dfab7  8b4508  MOV EAX,dword ptr [EBP + 0x8]
000dfaba  8b502c  MOV EDX,dword ptr [EAX + 0x2c]
000dfabd  85d2  TEST EDX,EDX
000dfabf  7405  JZ 0x000dfac6
000dfac1  8b4030  MOV EAX,dword ptr [EAX + 0x30]
000dfac4  5d  POP EBP
000dfac5  c3  RET
000dfac6  5d  POP EBP
000dfac7  e99c0f0a00  JMP 0x00180a68

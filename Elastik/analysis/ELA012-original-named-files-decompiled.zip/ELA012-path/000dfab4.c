
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_000dfab4(int param_1)

{
  short sVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 auStack_24 [5];
  
  if (*(int *)(param_1 + 0x2c) != 0) {
    return *(undefined4 *)(param_1 + 0x30);
  }
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x591,uVar2,"this != 0");
  }
  if (*(int *)(param_1 + 0xc) != 0) {
    return *(undefined4 *)(param_1 + 0x1c);
  }
  if (*(short *)(param_1 + 0x10) == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x5a6,uVar2,"_private");
  }
  sVar1 = _FSGetForkPosition((int)*(short *)(param_1 + 0x10),auStack_24);
  uVar2 = 0;
  if (sVar1 == 0) {
    uVar2 = auStack_24[0];
  }
  return uVar2;
}



void FUN_00039a08(undefined4 param_1,undefined4 param_2)

{
  FUN_000395f6(param_1,param_2,1);
  return;
}


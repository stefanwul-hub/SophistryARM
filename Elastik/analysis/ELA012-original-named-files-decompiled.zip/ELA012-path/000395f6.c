
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Type propagation algorithm not settling */

int * FUN_000395f6(int param_1,int param_2,char param_3)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  char *pcVar4;
  int iVar5;
  undefined4 *puVar6;
  int *piVar7;
  undefined4 uVar8;
  uint uVar9;
  char *pcVar10;
  char *pcStack_24;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar8 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar8,"Assertion failed in line %d of %s: %s.",0x50b,uVar2,"this != 0");
  }
  if (param_2 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar8 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar8,"Assertion failed in line %d of %s: %s.",0x50b,uVar2,"separator");
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar8 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar8,"Assertion failed in line %d of %s: %s.",0x10f,uVar2,"this != 0");
  }
  iVar5 = *(int *)(param_2 + 0x14);
  if (iVar5 == -1) {
    if (*(char **)(param_2 + 0xc) != (char *)0x0) {
      uVar9 = 0xffffffff;
      pcVar4 = *(char **)(param_2 + 0xc);
      do {
        if (uVar9 == 0) break;
        uVar9 = uVar9 - 1;
        cVar1 = *pcVar4;
        pcVar4 = pcVar4 + 1;
      } while (cVar1 != '\0');
      iVar5 = ~uVar9 - 1;
      goto LAB_00039630;
    }
  }
  else {
LAB_00039630:
    if (iVar5 != 0) {
      iVar5 = *(int *)(param_1 + 0xc);
      goto joined_r0x00039810;
    }
  }
  uVar2 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                         );
  uVar8 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar8,"Assertion failed in line %d of %s: %s.",0x50b,uVar2,"separator->getLength()");
  iVar5 = *(int *)(param_1 + 0xc);
joined_r0x00039810:
  if ((iVar5 == 0) && (*(int *)(param_1 + 0x14) != -1)) {
    FUN_000340ba(param_1);
  }
  uVar2 = __Znwm(0x20);
  FUN_00029d44(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  pcStack_24 = *(char **)(param_1 + 0xc);
  pcVar4 = pcStack_24;
joined_r0x0003966f:
  do {
    if (pcVar4 == (char *)0x0) {
LAB_0003979a:
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 0x48))(piVar3);
      }
      return piVar3;
    }
    uVar9 = 0xffffffff;
    pcVar10 = pcVar4;
    do {
      if (uVar9 == 0) break;
      uVar9 = uVar9 - 1;
      cVar1 = *pcVar10;
      pcVar10 = pcVar10 + 1;
    } while (cVar1 != '\0');
    if (pcVar4 + (~uVar9 - 1) <= pcStack_24) goto LAB_0003979a;
    if ((*(int *)(param_2 + 0xc) == 0) && (*(int *)(param_2 + 0x14) != -1)) {
      FUN_000340ba(param_2);
      iVar5 = *(int *)(param_2 + 0xc);
      if (iVar5 != 0) goto LAB_000396bf;
LAB_000398c1:
      pcVar4 = (char *)_strstr(pcStack_24,"");
    }
    else {
      iVar5 = *(int *)(param_2 + 0xc);
      if (iVar5 == 0) goto LAB_000398c1;
LAB_000396bf:
      pcVar4 = (char *)_strstr(pcStack_24,iVar5);
    }
    if (pcVar4 == (char *)0x0) {
      uVar2 = func_0x00039354(pcStack_24);
      FUN_0002bb40(piVar3,uVar2);
      goto LAB_0003979a;
    }
    iVar5 = (int)pcVar4 - (int)pcStack_24;
    if ((iVar5 != 0) || (param_3 == '\0')) {
      puVar6 = (undefined4 *)__Znwm(0x20);
      func_0x0002dc66(puVar6);
      *puVar6 = &UNK_0036ec68;
      *(undefined1 *)(puVar6 + 6) = 1;
      puVar6[3] = 0;
      puVar6[4] = 0;
      puVar6[5] = 0xffffffff;
      puVar6[7] = 0xffffffff;
      piVar7 = (int *)FUN_0002dfa6(puVar6);
      if (iVar5 == 0) {
        FUN_0002bb40(piVar3,piVar7);
      }
      else {
        func_0x0003948e(piVar7,pcStack_24,iVar5);
        FUN_0002bb40(piVar3,piVar7);
      }
      if (piVar7 == (int *)0x0) {
        uVar2 = func_0x0000a930(
                               "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                               );
        uVar8 = FUN_00033b90("GNAssertionException");
        FUN_0000bfd6(uVar8,"Assertion failed in line %d of %s: %s.",0xd8,uVar2,"this != 0");
      }
      *(undefined1 *)(piVar7 + 6) = 0;
      (**(code **)(*piVar7 + 0x44))(piVar7);
      pcStack_24 = pcVar4;
    }
    iVar5 = *(int *)(param_2 + 0x14);
    if (iVar5 == -1) {
      if (*(char **)(param_2 + 0xc) != (char *)0x0) {
        uVar9 = 0xffffffff;
        pcVar4 = *(char **)(param_2 + 0xc);
        do {
          if (uVar9 == 0) break;
          uVar9 = uVar9 - 1;
          cVar1 = *pcVar4;
          pcVar4 = pcVar4 + 1;
        } while (cVar1 != '\0');
        pcStack_24 = pcStack_24 + (~uVar9 - 1);
        pcVar4 = *(char **)(param_1 + 0xc);
        goto joined_r0x0003966f;
      }
      iVar5 = 0;
    }
    pcStack_24 = pcStack_24 + iVar5;
    pcVar4 = *(char **)(param_1 + 0xc);
  } while( true );
}


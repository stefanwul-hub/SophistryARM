
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0017e5fa(undefined4 *param_1)

{
  int iVar1;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  
  func_0x0002dc66(param_1);
  *param_1 = &UNK_0038fca8;
  *(undefined2 *)(param_1 + 4) = 0;
  param_1[5] = 1;
  param_1[6] = 0;
  param_1[3] = 0;
  if (cRam003d4958 != '\0') {
    return;
  }
  iVar1 = _getrlimit(8,&uStack_2c);
  if (iVar1 == 0) {
    uStack_2c = 0xffffffff;
    uStack_28 = 0x7fffffff;
    _setrlimit(8,&uStack_2c);
  }
  else {
    FUN_0000ab14("Increasing number of open files limit failed.");
  }
  cRam003d4958 = 1;
  return;
}


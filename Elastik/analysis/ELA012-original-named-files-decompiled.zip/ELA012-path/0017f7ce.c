
void FUN_0017f7ce(int param_1,int *param_2)

{
  undefined4 uVar1;
  int *piVar2;
  
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 != param_2) {
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0x44))(piVar2);
    }
    *(int **)(param_1 + 0xc) = param_2;
    if (param_2 == (int *)0x0) {
      FUN_00027b4e(0);
      uVar1 = FUN_000278d6(0);
      *(undefined4 *)(param_1 + 0x1c) = uVar1;
      uVar1 = FUN_000278d6(0);
      *(undefined4 *)(param_1 + 0x20) = uVar1;
      return;
    }
    (**(code **)(*param_2 + 0x40))(param_2);
    piVar2 = *(int **)(param_1 + 0xc);
  }
  FUN_00027b4e(piVar2);
  uVar1 = FUN_000278d6(param_2);
  *(undefined4 *)(param_1 + 0x1c) = uVar1;
  uVar1 = FUN_000278d6(param_2);
  *(undefined4 *)(param_1 + 0x20) = uVar1;
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000e3e38(int param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iStack_20;
  
  if (*(char *)(*(int *)(*(int *)(*(int *)(param_1 + 0x28) + 0x10) + 0x28) + 0x18) == '\0') {
    iVar1 = (**(code **)(*param_2 + 0x1c4))(param_2);
    if (iVar1 != 0) {
      if (*(int *)(*(int *)(*(int *)(param_1 + 0x28) + 0x10) + 0x24) == 0) {
        iStack_20 = 0;
LAB_000e3f5a:
        uVar2 = func_0x0000a930(
                               "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                               );
        uVar3 = FUN_00033b90("GNAssertionException");
        FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x558,uVar2,"desc != 0");
      }
      else {
        FUN_000df8d2(*(int *)(param_1 + 0x28));
        iVar1 = *(int *)(param_1 + 0x28);
        if (*(int *)(iVar1 + 0x18) != 0) {
          uVar2 = func_0x0000a930(
                                 "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                                 );
          uVar3 = FUN_00033b90("GNAssertionException");
          FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x630,uVar2,
                       "_fileArchiveFilePath->_posixPath == 0");
          iVar1 = *(int *)(param_1 + 0x28);
        }
        iStack_20 = *(int *)(iVar1 + 0x14) * 0x240 + *(int *)(*(int *)(iVar1 + 0x10) + 0x14) +
                    -0x240;
        if (iStack_20 == 0) goto LAB_000e3f5a;
      }
      piVar4 = (int *)(**(code **)(*param_2 + 0x1a8))(param_2);
      piVar4 = (int *)(**(code **)(*piVar4 + 0x248))(piVar4);
      *(int **)(param_1 + 0x2c) = piVar4;
      if (piVar4 == (int *)0x0) {
        uVar2 = func_0x0000a930(
                               "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                               );
        uVar3 = FUN_00033b90("GNAssertionException");
        FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x55c,uVar2,"_readingFile != 0")
        ;
        piVar4 = *(int **)(param_1 + 0x2c);
      }
      (**(code **)(*piVar4 + 0x1c0))(piVar4,*(undefined4 *)(iStack_20 + 0x234));
      *(undefined1 *)(param_1 + 0x38) = 0;
      param_2 = *(int **)(param_1 + 0x2c);
      goto LAB_000e3e64;
    }
  }
  *(int **)(param_1 + 0x2c) = param_2;
  *(undefined1 *)(param_1 + 0x38) = 1;
LAB_000e3e64:
  if (param_2 != (int *)0x0) {
    (**(code **)(*param_2 + 0x40))(param_2);
  }
  return;
}


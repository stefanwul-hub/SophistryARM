
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0017f918(int param_1,int param_2,int *param_3)

{
  short sVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int aiStack_20 [4];
  
  if (param_1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x361,uVar4,"this != 0");
  }
  if (param_2 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x361,uVar4,"bytes");
  }
  if (param_3 == (int *)0x0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x361,uVar4,"length");
  }
  if (*param_3 < 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x361,uVar4,"*length >= 0");
  }
  if (*(int *)(param_1 + 0xc) == 0) {
    if (*(short *)(param_1 + 0x10) != 0) {
      aiStack_20[0] = *param_3;
      sVar1 = _FSReadFork((int)*(short *)(param_1 + 0x10),0,0,0,aiStack_20[0],param_2,aiStack_20);
      if (sVar1 == 0) {
        return 1;
      }
      *param_3 = 0;
    }
    return 0;
  }
  iVar3 = *param_3;
  if (*(int *)(param_1 + 0x20) < *(int *)(param_1 + 0x1c) + iVar3) {
    iVar3 = *(int *)(param_1 + 0x20) - *(int *)(param_1 + 0x1c);
    *param_3 = iVar3;
  }
  if (0 < iVar3) {
    iVar2 = FUN_00027abc(*(undefined4 *)(param_1 + 0xc));
    _memcpy(param_2,iVar2 + *(int *)(param_1 + 0x1c),iVar3);
    *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + *param_3;
    return 1;
  }
  *param_3 = 0;
  return 0;
}


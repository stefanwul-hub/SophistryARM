
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000e3ff4(int *param_1)

{
  int iVar1;
  bool bVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  undefined4 uVar7;
  
  (**(code **)(**(int **)(param_1[4] + 0x20) + 0x1a4))(*(int **)(param_1[4] + 0x20));
  iVar6 = param_1[4];
  if (*(int *)(iVar6 + 0x24) != 0) {
    FUN_000df8d2(param_1);
    if (param_1[5] == 0) {
      iVar6 = param_1[4];
    }
    else {
      iVar6 = param_1[4];
      iVar3 = param_1[5] * 0x240 + *(int *)(iVar6 + 0x14);
      bVar2 = true;
      iVar1 = *(int *)(iVar3 + -0x234);
      if ((iVar1 < 1) && ((iVar1 < 0 || (*(int *)(iVar3 + -0x238) == 0)))) {
        bVar2 = false;
      }
      if (bVar2) {
        puVar4 = (undefined4 *)__Znwm(0x3c);
        FUN_0017e5fa(puVar4);
        *puVar4 = &UNK_0037b488;
        puVar4[0xc] = 0;
        puVar4[0xd] = 0;
        puVar4[0xb] = 0;
        puVar4[10] = 0;
        *(undefined1 *)(puVar4 + 9) = 0;
        *(undefined1 *)(puVar4 + 0xe) = 0;
        piVar5 = (int *)FUN_0002dfa6(puVar4);
        iVar6 = (**(code **)(*piVar5 + 0x48))(piVar5);
        uVar7 = (**(code **)(*param_1 + 0x40))(param_1);
        *(undefined4 *)(iVar6 + 0x28) = uVar7;
        if (*(char *)(param_1[4] + 0x2c) != '\0') {
          FUN_000e3e38(iVar6,*(undefined4 *)(param_1[4] + 0x24));
          (**(code **)(**(int **)(param_1[4] + 0x20) + 0x1ac))(*(int **)(param_1[4] + 0x20));
          return iVar6;
        }
        uVar7 = FUN_000e063c();
        FUN_0017f8a0(iVar6,uVar7);
        (**(code **)(**(int **)(param_1[4] + 0x20) + 0x1ac))(*(int **)(param_1[4] + 0x20));
        return iVar6;
      }
    }
  }
  (**(code **)(**(int **)(iVar6 + 0x20) + 0x1ac))(*(int **)(iVar6 + 0x20));
  return 0;
}


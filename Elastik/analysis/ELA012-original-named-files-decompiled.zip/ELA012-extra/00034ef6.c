
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00034ef6(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (cRam003d404c != '\0') {
    return 0;
  }
  if (iRam003d4048 == 0) {
    cRam003d404c = 1;
    uVar1 = FUN_00033b90("GNObject");
    uVar2 = FUN_00033b90("GNString");
    iRam003d4048 = FUN_0001fe74(uVar2,&UNK_00033a3e,uVar1);
    cRam003d404c = '\0';
  }
  return iRam003d4048;
}


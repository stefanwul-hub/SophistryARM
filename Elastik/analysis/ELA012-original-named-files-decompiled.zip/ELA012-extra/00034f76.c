
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00034f76(int param_1)

{
  byte bVar1;
  int iVar2;
  char *pcVar3;
  
  if ((*(char *)(param_1 + 0x18) != '\0') || (*(int *)(param_1 + 0x1c) == -1)) {
    if ((*(int *)(param_1 + 0xc) == 0) && (*(int *)(param_1 + 0x14) != -1)) {
      FUN_000340ba(param_1);
    }
    pcVar3 = *(char **)(param_1 + 0xc);
    if ((byte *)pcVar3 == (byte *)0x0) {
      pcVar3 = "";
    }
    bVar1 = *pcVar3;
    if (bVar1 == 0) {
      iVar2 = 0;
    }
    else {
      iVar2 = 0;
      do {
        pcVar3 = (char *)((byte *)pcVar3 + 1);
        iVar2 = iVar2 * 0x1003f + (uint)bVar1;
        bVar1 = *pcVar3;
      } while (bVar1 != 0);
    }
    if (*(char *)(param_1 + 0x18) == '\0') {
      *(int *)(param_1 + 0x1c) = iVar2;
      return;
    }
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00189b58(ushort *param_1,byte *param_2,undefined *param_3,int param_4)

{
  ushort *puVar1;
  ushort uVar2;
  byte bVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  byte *pbVar9;
  byte *pbVar10;
  int iVar11;
  byte *pbVar12;
  undefined *puVar13;
  byte *pbStack_60;
  byte *pbStack_48;
  ushort *puStack_34;
  byte *pbStack_28;
  int iStack_24;
  int iStack_20;
  
  if (param_3 == &UNK_0000270f) {
    uVar7 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStringEncoding.cpp"
                           );
    uVar8 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar8,"Assertion failed in line %d of %s: %s.",0x1e9,uVar7,
                 "destEncoding != GNStringEncodingUndefined");
LAB_00189b8a:
    pbStack_48 = (byte *)0x0;
  }
  else {
    if (param_3 == (undefined *)0x3e9) {
      pbVar9 = (byte *)FUN_0000aecc(param_4 * 2 + 1);
      FUN_00189b58(param_1,pbVar9,2,param_4);
      bVar3 = *pbVar9;
      pbStack_60 = pbVar9 + 1;
      pbVar10 = param_2;
      if ((bVar3 == 0) || (param_4 < 1)) {
        iVar6 = 0;
LAB_00189f70:
        *pbVar10 = 0;
        if (-1 < iVar6) goto LAB_00189f77;
      }
      else {
        pbVar12 = pbStack_60 + param_4;
        do {
          if (bVar3 == 0x20) {
            *pbVar10 = 0x2b;
            pbVar10 = pbVar10 + 1;
          }
          else if ((((byte)(bVar3 + 0x9f) < 0x1a) || ((byte)(bVar3 + 0xbf) < 0x1a)) ||
                  ((byte)(bVar3 - 0x30) < 10)) {
            *pbVar10 = bVar3;
            pbVar10 = pbVar10 + 1;
          }
          else {
            *pbVar10 = 0x25;
            bVar4 = (bVar3 >> 4) + 0x30;
            if (0x39 < bVar4) {
              bVar4 = (bVar3 >> 4) + 0x37;
            }
            pbVar10[1] = bVar4;
            bVar4 = (bVar3 & 0xf) + 0x30;
            if (0x39 < bVar4) {
              bVar4 = (bVar3 & 0xf) + 0x37;
            }
            pbVar10[2] = bVar4;
            pbVar10 = pbVar10 + 3;
          }
          bVar3 = *pbStack_60;
          pbStack_60 = pbStack_60 + 1;
          if ((bVar3 == 0) || (pbStack_60 == pbVar12)) {
            iVar6 = (int)pbVar10 - (int)param_2;
            goto LAB_00189f70;
          }
        } while (pbVar10 <= param_2 + param_4 * 3 + -3);
        *pbVar10 = 0;
      }
      FUN_0000ab14("Cannot encode URL string");
      *param_2 = 0;
      iVar6 = 0;
LAB_00189f77:
      FUN_0000b122(pbVar9);
      return iVar6;
    }
    switch(param_3) {
    case (undefined *)0x0:
      pbStack_48 = (byte *)0x366b20;
      break;
    case (undefined *)0x1:
      pbStack_48 = (byte *)0x3668a0;
      break;
    case (undefined *)0x2:
      pbStack_48 = (byte *)0x366600;
      break;
    case (undefined *)0x3:
      pbStack_48 = (byte *)0x366380;
      break;
    case (undefined *)0x4:
      pbStack_48 = (byte *)0x366300;
      break;
    default:
      goto LAB_00189b8a;
    }
  }
  if (param_3 != (undefined *)0x3e8) {
    if (param_4 < 1) {
      param_4 = 0;
    }
    else {
      iStack_24 = 0;
      do {
        uVar5 = *param_1;
        param_1 = param_1 + 1;
        if ((ushort)(uVar5 - 0x20) < 0x5f) {
          *param_2 = (byte)uVar5;
        }
        else {
          if ((pbStack_48 == (byte *)0x0) || (bVar3 = *pbStack_48, bVar3 == 0)) {
LAB_00189c48:
            bVar3 = 0x1a;
          }
          else {
            uVar2 = *(ushort *)(pbStack_48 + 2);
            pbVar10 = pbStack_48;
            while (uVar5 != uVar2) {
              bVar3 = pbVar10[4];
              if (bVar3 == 0) goto LAB_00189c48;
              uVar2 = *(ushort *)(pbVar10 + 6);
              pbVar10 = pbVar10 + 4;
            }
          }
          *param_2 = bVar3;
        }
        param_2 = param_2 + 1;
        iStack_24 = iStack_24 + 1;
      } while (param_4 != iStack_24);
    }
    *param_2 = 0;
    return param_4;
  }
  puVar1 = param_1 + param_4;
  pbVar10 = param_2 + param_4 * 4;
  pbStack_28 = param_2;
  if (param_1 < puVar1) {
    iStack_20 = 0;
    do {
      puVar13 = (undefined *)(uint)*param_1;
      puStack_34 = param_1 + 1;
      if (((puVar13 + -0xd800 < (undefined *)0x400) && (puStack_34 < puVar1)) &&
         (param_1[1] - 0xdc00 < 0x400)) {
        puVar13 = &UNK_00002400 + (int)(puVar13 + -0xd800) * 0x400 + (uint)param_1[1];
        puStack_34 = param_1 + 2;
      }
      if (puVar13 < (undefined *)0x80) {
        iVar6 = 1;
        iVar11 = 1;
      }
      else if (puVar13 < (undefined *)0x800) {
        iVar6 = 2;
        iVar11 = 2;
      }
      else if (puVar13 < (undefined *)0x10000) {
        iVar6 = 3;
        iVar11 = 3;
      }
      else if (puVar13 < (undefined *)0x200000) {
        iVar6 = 4;
        iVar11 = 4;
      }
      else {
        iVar6 = 2;
        puVar13 = &UNK_0000fffd;
        iVar11 = 2;
      }
      pbStack_28 = pbStack_28 + iVar11;
      if (pbVar10 < pbStack_28) {
        return 0;
      }
      uVar5 = (ushort)iVar6;
      if (uVar5 == 2) {
LAB_00189dc0:
        pbStack_28 = pbStack_28 + -1;
        *pbStack_28 = (byte)puVar13 & 0xbf | 0x80;
        puVar13 = (undefined *)((uint)puVar13 >> 6);
LAB_00189dce:
        pbStack_28 = pbStack_28 + -1;
        *pbStack_28 = (&UNK_00365120)[iVar6] | (byte)puVar13;
      }
      else {
        if (2 < uVar5) {
          if (uVar5 != 3) {
            if (uVar5 != 4) goto LAB_00189cb2;
            pbStack_28 = pbStack_28 + -1;
            *pbStack_28 = (byte)puVar13 & 0xbf | 0x80;
            puVar13 = (undefined *)((uint)puVar13 >> 6);
          }
          pbStack_28 = pbStack_28 + -1;
          *pbStack_28 = (byte)puVar13 & 0xbf | 0x80;
          puVar13 = (undefined *)((uint)puVar13 >> 6);
          goto LAB_00189dc0;
        }
        if (uVar5 == 1) goto LAB_00189dce;
      }
LAB_00189cb2:
      param_2 = pbStack_28 + iVar11;
      iStack_20 = iStack_20 + iVar6;
      param_1 = puStack_34;
      pbStack_28 = param_2;
    } while (puStack_34 < puVar1);
  }
  else {
    iStack_20 = 0;
  }
  *param_2 = 0;
  return iStack_20;
}


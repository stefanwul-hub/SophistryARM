
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00180b54(int param_1)

{
  short sVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 auStack_24 [5];
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x609,uVar2,"this != 0");
  }
  if (*(int *)(param_1 + 0xc) == 0) {
    if (*(short *)(param_1 + 0x10) == 0) {
      uVar2 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                             );
      uVar3 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x61b,uVar2,"_private");
    }
    sVar1 = _FSSetForkPosition((int)*(short *)(param_1 + 0x10),2,0,0);
    if ((sVar1 != 0) ||
       (sVar1 = _FSGetForkPosition((int)*(short *)(param_1 + 0x10),auStack_24), sVar1 != 0)) {
      return 0;
    }
  }
  else {
    auStack_24[0] = *(undefined4 *)(param_1 + 0x20);
    *(undefined4 *)(param_1 + 0x1c) = auStack_24[0];
  }
  return auStack_24[0];
}


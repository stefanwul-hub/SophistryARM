
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0003696a(int param_1,int param_2,byte param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  char cVar3;
  ushort uVar4;
  char cVar5;
  ushort uVar6;
  char *pcVar7;
  char *pcStack_2c;
  ushort *puStack_28;
  ushort *puStack_24;
  char *pcStack_20;
  
  if ((*(int *)(param_1 + 0x14) == -1) || (*(int *)(param_2 + 0x14) == -1)) {
    if ((*(int *)(param_1 + 0xc) == 0) && (*(int *)(param_1 + 0x14) != -1)) {
      FUN_000340ba(param_1);
    }
    pcStack_2c = *(char **)(param_1 + 0xc);
    if (pcStack_2c == (char *)0x0) {
      pcStack_2c = "";
    }
    if (param_2 == 0) {
      uVar1 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                             );
      uVar2 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x119,uVar1,"this != 0");
    }
    if ((*(int *)(param_2 + 0xc) == 0) && (*(int *)(param_2 + 0x14) != -1)) {
      FUN_000340ba(param_2);
    }
    pcVar7 = *(char **)(param_2 + 0xc);
    if (pcVar7 == (char *)0x0) {
      pcVar7 = "";
    }
    cVar3 = *pcStack_2c;
    if (cVar3 != '\0') {
      cVar5 = *pcVar7;
      if (cVar5 != '\0') {
        if ((param_3 & 1) == 0) {
          do {
            if (cVar3 < cVar5) {
              return 0xffffffff;
            }
            if (cVar5 < cVar3) {
              return 1;
            }
            pcVar7 = pcVar7 + 1;
            cVar3 = pcStack_2c[1];
            if (cVar3 == '\0') goto LAB_000369f8;
            cVar5 = *pcVar7;
            pcStack_2c = pcStack_2c + 1;
          } while (cVar5 != '\0');
        }
        else {
          pcStack_20 = pcStack_2c;
          do {
            if ((byte)(cVar3 + 0x9fU) < 0x1a) {
              cVar3 = cVar3 + -0x20;
            }
            if ((byte)(cVar5 + 0x9fU) < 0x1a) {
              cVar5 = cVar5 + -0x20;
            }
            if (cVar3 < cVar5) {
              return 0xffffffff;
            }
            if (cVar5 < cVar3) {
              return 1;
            }
            pcVar7 = pcVar7 + 1;
            cVar3 = pcStack_20[1];
            if (cVar3 == '\0') goto LAB_000369f8;
            cVar5 = *pcVar7;
            pcStack_20 = pcStack_20 + 1;
          } while (cVar5 != '\0');
        }
      }
      return 1;
    }
LAB_000369f8:
    if (*pcVar7 == '\0') {
      return 0;
    }
  }
  else {
    puStack_24 = (ushort *)func_0x00036896(param_1);
    puStack_28 = (ushort *)func_0x00036896(param_2);
    uVar4 = *puStack_24;
    if (uVar4 == 0) {
LAB_000369a9:
      if (*puStack_28 == 0) {
        return 0;
      }
    }
    else {
      uVar6 = *puStack_28;
      if (uVar6 == 0) {
        return 1;
      }
      if ((param_3 & 1) == 0) {
        while (uVar6 <= uVar4) {
          if (uVar6 < uVar4) {
            return 1;
          }
          puStack_28 = puStack_28 + 1;
          uVar4 = puStack_24[1];
          if (uVar4 == 0) goto LAB_000369a9;
          uVar6 = *puStack_28;
          puStack_24 = puStack_24 + 1;
          if (uVar6 == 0) {
            return 1;
          }
        }
      }
      else {
        while( true ) {
          if ((ushort)(uVar4 - 0x61) < 0x1a) {
            uVar4 = uVar4 - 0x20;
          }
          if ((ushort)(uVar6 - 0x61) < 0x1a) {
            uVar6 = uVar6 - 0x20;
          }
          if (uVar4 < uVar6) break;
          if (uVar4 >= uVar6 && uVar4 != uVar6) {
            return 1;
          }
          puStack_28 = puStack_28 + 1;
          uVar4 = puStack_24[1];
          if (uVar4 == 0) goto LAB_000369a9;
          uVar6 = *puStack_28;
          puStack_24 = puStack_24 + 1;
          if (uVar6 == 0) {
            return 1;
          }
        }
      }
    }
  }
  return 0xffffffff;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0003788a(int param_1,char *param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined1 auStack_410 [944];
  undefined4 uStack_60;
  char *pcStack_5c;
  char *pcStack_58;
  int iStack_54;
  undefined4 uStack_50;
  char *pcStack_4c;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  undefined2 *puStack_24;
  int iStack_20;
  
  uStack_60 = 0x37898;
  iStack_2c = (int)param_2;
  iStack_30 = param_3;
  if (param_1 == 0) {
    pcStack_5c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
    uStack_60 = 0x379ed;
    uVar2 = func_0x0000a930();
    pcStack_5c = "GNAssertionException";
    uStack_60 = 0x379fd;
    pcStack_5c = (char *)FUN_00033b90();
    pcStack_4c = "this != 0";
    iStack_54 = 0x95a;
    pcStack_58 = "Assertion failed in line %d of %s: %s.";
    uStack_60 = 0x37a25;
    uStack_50 = uVar2;
    FUN_0000bfd6();
  }
  if (*(char *)(param_1 + 0x18) != '\0') {
    if (iStack_30 != 0) {
      if (iStack_2c == 0) {
        pcStack_5c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
        uStack_60 = 0x37a45;
        uVar2 = func_0x0000a930();
        pcStack_5c = "GNAssertionException";
        uStack_60 = 0x37a55;
        pcStack_5c = (char *)FUN_00033b90();
        pcStack_4c = "chars";
        iStack_54 = 0x965;
        pcStack_58 = "Assertion failed in line %d of %s: %s.";
        uStack_60 = 0x37a7d;
        uStack_50 = uVar2;
        FUN_0000bfd6();
      }
      if (*(int *)(param_1 + 0x14) == -1) {
        pcStack_5c = (char *)param_1;
        uStack_60 = 0x37a32;
        FUN_000358be();
      }
      if (*(int *)(param_1 + 0x10) == 0) {
        pcStack_5c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
        uStack_60 = 0x37a90;
        uVar2 = func_0x0000a930();
        pcStack_5c = "GNAssertionException";
        uStack_60 = 0x37aa0;
        pcStack_5c = (char *)FUN_00033b90();
        pcStack_4c = "_uniChars";
        iStack_54 = 0x967;
        pcStack_58 = "Assertion failed in line %d of %s: %s.";
        uStack_60 = 0x37ac8;
        uStack_50 = uVar2;
        FUN_0000bfd6();
      }
      iStack_20 = *(int *)(param_1 + 0x14);
      iStack_28 = iStack_30 + iStack_20;
      pcStack_5c = (char *)(iStack_28 * 2 + 2);
      uStack_60 = 0x37928;
      puStack_24 = (undefined2 *)FUN_0000aecc();
      if (puStack_24 == (undefined2 *)0x0) {
        pcStack_5c = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp";
        uStack_60 = 0x37adb;
        uVar2 = func_0x0000a930();
        pcStack_5c = "GNAssertionException";
        uStack_60 = 0x37aeb;
        pcStack_5c = (char *)FUN_00033b90();
        pcStack_4c = "c";
        iStack_54 = 0x96c;
        pcStack_58 = "Assertion failed in line %d of %s: %s.";
        uStack_60 = 0x37b13;
        uStack_50 = uVar2;
        FUN_0000bfd6();
      }
      iVar1 = iStack_20;
      pcStack_5c = (char *)puStack_24;
      if (iStack_20 != 0) {
        iStack_54 = iStack_20 * 2;
        pcStack_58 = *(char **)(param_1 + 0x10);
        uStack_60 = 0x379d0;
        _memcpy();
        puStack_24[iVar1] = 0;
        pcStack_5c = (char *)(puStack_24 + iVar1);
      }
      iStack_54 = iStack_30 * 2;
      pcStack_58 = (char *)iStack_2c;
      uStack_60 = 0x37955;
      _memcpy();
      puStack_24[iStack_28] = 0;
      *(int *)(param_1 + 0x14) = iStack_28;
      pcStack_5c = *(char **)(param_1 + 0x10);
      uStack_60 = 0x3796f;
      FUN_0000b122();
      *(undefined2 **)(param_1 + 0x10) = puStack_24;
      pcStack_5c = *(char **)(param_1 + 0xc);
      if (pcStack_5c != (char *)0x0) {
        uStack_60 = 0x37984;
        FUN_0000b122();
      }
      *(undefined4 *)(param_1 + 0xc) = 0;
    }
    return;
  }
  if ((*(int *)(param_1 + 0xc) == 0) && (*(int *)(param_1 + 0x14) != -1)) {
    pcStack_5c = (char *)param_1;
    uStack_60 = 0x379b0;
    FUN_000340ba();
  }
  param_2 = *(char **)(param_1 + 0xc);
  if (param_2 == (char *)0x0) {
    param_2 = "";
  }
  if (cRam003d3f10 == '\0') {
    cRam003d3f10 = '\x01';
    _vsprintf(auStack_410,"Cannot modify an immutable string %s",&param_2);
    FUN_0000ab14(auStack_410);
    if (pcRam003d3f04 != (code *)0x0) {
      (*pcRam003d3f04)(auStack_410);
    }
    if (pcRam003d3f00 != (code *)0x0) {
      (*pcRam003d3f00)();
    }
    if (cRam003d3f08 == '\0') {
      uVar2 = func_0x00084aa2();
      func_0x00084bb6(uVar2);
      return;
    }
  }
  return;
}


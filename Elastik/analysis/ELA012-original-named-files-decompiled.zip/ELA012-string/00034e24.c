
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00034e24(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 == (int *)0x0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x59,uVar3,"this != 0");
  }
  if (param_1 == param_2) {
    return 1;
  }
  if (param_2 != (int *)0x0) {
    iVar1 = (**(code **)(*param_1 + 0x90))(param_1);
    iVar2 = (**(code **)(*param_2 + 0x90))(param_2);
    if (iVar1 == iVar2) {
      iVar1 = (**(code **)(*param_1 + 8))(param_1);
      iVar2 = (**(code **)(*param_2 + 8))(param_2);
      if ((iVar1 == iVar2) && (iVar1 = (**(code **)(*param_1 + 0x94))(param_1,param_2), iVar1 == 0))
      {
        return 1;
      }
    }
  }
  return 0;
}


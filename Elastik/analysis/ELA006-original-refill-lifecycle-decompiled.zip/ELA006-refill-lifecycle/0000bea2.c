
void FUN_0000bea2(int param_1)

{
  int iVar1;
  
  iVar1 = func_0x000410a8();
  *(undefined4 *)(param_1 + 0x48) = *(undefined4 *)(iVar1 + 0x28);
  *(int *)(iVar1 + 0x28) = param_1;
  return;
}


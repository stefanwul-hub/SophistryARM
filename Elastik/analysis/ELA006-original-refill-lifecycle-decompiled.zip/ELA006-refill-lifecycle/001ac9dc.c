
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001ac9dc(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  
  if (*(int *)(param_1 + 0xc) != 0) {
    return;
  }
  uVar2 = __Znwm(0x58);
  FUN_00218aa6(uVar2);
  uVar2 = FUN_0002dfa6(uVar2);
  *(undefined4 *)(param_1 + 0xc) = uVar2;
  FUN_00218b82(uVar2,param_1);
  iVar1 = *(int *)(param_1 + 0xc);
  if (*(int *)(iVar1 + 0x2c) != 0) {
    return;
  }
  piVar3 = (int *)FUN_00070218(FUN_00217fd0,iVar1,0x9999999a,0x3fc99999,1);
  *(int **)(iVar1 + 0x2c) = piVar3;
  (**(code **)(*piVar3 + 0x40))(piVar3);
  return;
}


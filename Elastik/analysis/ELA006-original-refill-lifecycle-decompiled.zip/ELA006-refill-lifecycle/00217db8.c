
void FUN_00217db8(int param_1,int param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  int iStack_10;
  
  *(int *)(param_1 + 0x20) = param_2;
  *(undefined4 *)(param_1 + 0x24) = param_3;
  if (param_2 == 0) {
    *(int *)(param_1 + 0x20) = (int)(0x40000000 / (longlong)*(int *)(param_1 + 0x18)) * 2;
  }
  else {
    *(int *)(param_1 + 0x20) = param_2 / *(int *)(param_1 + 0x18);
  }
  *(int *)(param_1 + 0x20) = *(int *)(param_1 + 0x20) + 2;
  if (*(int *)(param_1 + 0x24) == 0) {
    *(undefined **)(param_1 + 0x24) = &UNK_00005000;
  }
  uVar1 = FUN_0000aecc(*(int *)(param_1 + 0x20) << 3);
  *(undefined4 *)(param_1 + 0x10) = uVar1;
  uVar1 = FUN_0000aecc(*(int *)(param_1 + 0x20) << 2);
  *(undefined4 *)(param_1 + 0x14) = uVar1;
  if (0 < *(int *)(param_1 + 0x20)) {
    iVar2 = 0;
    do {
      *(undefined4 *)(*(int *)(param_1 + 0x10) + iVar2 * 8) = 0xffffffff;
      *(undefined4 *)(*(int *)(param_1 + 0x14) + iVar2 * 4) = 0xffffffff;
      iVar2 = iVar2 + 1;
    } while (iVar2 < *(int *)(param_1 + 0x20));
  }
  if (0 < *(int *)(param_1 + 0x1c)) {
    iStack_10 = 0;
    do {
      iVar2 = *(int *)(param_1 + 0x10);
      uVar1 = FUN_0000aecc(*(undefined4 *)(param_1 + 0x18));
      *(undefined4 *)(iVar2 + iStack_10 * 8 + 4) = uVar1;
      iStack_10 = iStack_10 + 1;
    } while (iStack_10 < *(int *)(param_1 + 0x1c));
  }
  uVar1 = FUN_0000aecc(*(int *)(param_1 + 0x24) * 0xc);
  *(undefined4 *)(param_1 + 0x40) = uVar1;
  *(undefined4 *)(param_1 + 0x44) = 0;
  if (0 < *(int *)(param_1 + 0x24)) {
    iVar2 = 0;
    iVar3 = 0;
    do {
      *(undefined1 *)(*(int *)(param_1 + 0x40) + iVar3) = 0;
      *(undefined4 *)(*(int *)(param_1 + 0x40) + 4 + iVar3) = 0xffffffff;
      *(undefined4 *)(*(int *)(param_1 + 0x40) + 8 + iVar3) = 0xffffffff;
      iVar2 = iVar2 + 1;
      iVar3 = iVar3 + 0xc;
    } while (iVar2 < *(int *)(param_1 + 0x24));
  }
  return;
}


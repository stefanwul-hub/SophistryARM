
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00218102(int param_1,int param_2)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar1 = *(int *)(*(int *)(param_1 + 0x14) + param_2 * 4);
  iVar3 = iVar1;
  if ((iVar1 != -1) && (piVar2 = *(int **)(param_1 + 0x10), param_2 != piVar2[iVar1 * 2])) {
    if (*(int *)(param_1 + 0x1c) < 1) {
LAB_0021817d:
      iVar3 = -1;
    }
    else {
      if (param_2 == *piVar2) {
        iVar3 = 0;
      }
      else {
        iVar3 = 0;
        do {
          piVar2 = piVar2 + 2;
          iVar3 = iVar3 + 1;
          if (*(int *)(param_1 + 0x1c) == iVar3) goto LAB_0021817d;
        } while (param_2 != *piVar2);
      }
      FUN_0000ab14("_cache[%i].block = %i | _blocks[%i] = %i",iVar3,param_2,param_2,iVar1);
    }
  }
  return iVar3;
}


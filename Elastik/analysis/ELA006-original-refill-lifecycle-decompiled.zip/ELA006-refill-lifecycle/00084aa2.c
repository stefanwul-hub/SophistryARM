
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00084aa2(void)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 *puVar3;
  
  if (iRam003d43f4 != 0) {
    return iRam003d43f4;
  }
  puVar1 = (undefined4 *)__Znwm(0x30);
  func_0x0002dc66(puVar1);
  *puVar1 = &UNK_003740e8;
  puVar3 = puVar1 + 3;
  for (iVar2 = 9; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar3 = 0;
    puVar3 = puVar3 + 1;
  }
  iRam003d43f4 = FUN_0002dfa6(puVar1);
  return iRam003d43f4;
}


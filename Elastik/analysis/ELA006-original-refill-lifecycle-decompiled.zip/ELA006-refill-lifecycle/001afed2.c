
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001afed2(int param_1,int param_2,int param_3,int param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  int iStack_70;
  undefined1 auStack_6c [92];
  
  iVar3 = param_3;
  uVar6 = *(uint *)(param_1 + 0x14);
  if ((uVar6 & 0x100) != 0) {
    uVar6 = uVar6 & 0xff;
  }
  iStack_70 = *(int *)(param_1 + 0x24);
  if ((iStack_70 == 0) && (piVar1 = *(int **)(param_1 + 0x54), piVar1 != (int *)0x0)) {
    iStack_70 = (**(code **)(*piVar1 + 0x1bc))(piVar1);
  }
  if ((param_3 < 0) || (iStack_70 < param_3 + param_4)) {
    if (0 < (int)uVar6) {
      uVar5 = 0;
      do {
        iVar2 = *(int *)(param_2 + uVar5 * 4);
        if (iVar2 != 0) {
          _memset(iVar2,0,param_4 << 2);
        }
        uVar5 = uVar5 + 1;
      } while (uVar6 != uVar5);
    }
    iVar2 = param_4;
    if (param_3 < 0) {
      iVar2 = param_4 + param_3;
      if (iVar2 < 1) {
        return 1;
      }
      param_3 = 0;
    }
    iVar3 = param_4 + iVar3;
    param_4 = iVar2;
    if (iStack_70 < iVar3) {
      if (iStack_70 <= param_3) {
        return 1;
      }
      param_4 = iStack_70 - param_3;
      FUN_0000bea2(auStack_6c);
      iVar3 = _setjmp(auStack_6c);
      goto joined_r0x001b006d;
    }
  }
  FUN_0000bea2(auStack_6c);
  iVar3 = _setjmp(auStack_6c);
joined_r0x001b006d:
  if (iVar3 == 0) {
    if (piRam003d4a90 == (int *)0x0) {
      uVar4 = __Znwm(0x38);
      FUN_0006f04a(uVar4);
      piRam003d4a90 = (int *)FUN_0002dfa6(uVar4);
    }
    (**(code **)(*piRam003d4a90 + 0x1a4))(piRam003d4a90);
    if (*(int *)(param_1 + 0x4c) == 1) {
      (**(code **)(**(int **)(param_1 + 0x5c) + 0x1c8))
                (*(int **)(param_1 + 0x5c),param_2,param_3,param_4);
      (**(code **)(**(int **)(param_1 + 0x60) + 0x1c8))
                (*(int **)(param_1 + 0x60),param_2 + 4,param_3,param_4);
    }
    else {
      (**(code **)(**(int **)(param_1 + 0x54) + 0x1c8))
                (*(int **)(param_1 + 0x54),param_2,param_3,param_4);
    }
    if (piRam003d4a90 == (int *)0x0) {
      uVar4 = __Znwm(0x38);
      FUN_0006f04a(uVar4);
      piRam003d4a90 = (int *)FUN_0002dfa6(uVar4);
    }
    (**(code **)(*piRam003d4a90 + 0x1ac))(piRam003d4a90);
    FUN_0000bec0(auStack_6c);
    return 1;
  }
  if (piRam003d4a90 == (int *)0x0) {
    uVar4 = __Znwm(0x38);
    FUN_0006f04a(uVar4);
    piRam003d4a90 = (int *)FUN_0002dfa6(uVar4);
  }
  (**(code **)(*piRam003d4a90 + 0x1ac))(piRam003d4a90);
  return 0;
}


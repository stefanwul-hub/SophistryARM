
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00084bb6(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_00084aa2();
  if (iVar1 == param_1) goto LAB_00084c0e;
  uVar2 = FUN_00033b90("GNFunctionIsObsoleteException");
  FUN_0000bfd6(uVar2,"Function %s in %s is obsolete.","exitTask",
               "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTask.cpp");
  do {
    _exit(*(undefined4 *)(param_1 + 0x18));
LAB_00084c0e:
    func_0x00083b58(param_1);
  } while( true );
}


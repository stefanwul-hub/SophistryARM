
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00218b82(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  if (param_1 == (int *)0x0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNSoundFileCache.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x25,uVar4,"this != 0");
  }
  if (param_2 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNSoundFileCache.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x25,uVar4,"soundFile");
  }
  param_1[0x12] = param_2;
  iVar1 = func_0x001ab7ac(param_2);
  param_1[0x15] = iVar1;
  param_1[0x14] = 0x4000;
  param_1[6] = iVar1 << 0x10;
  iVar1 = func_0x001ab7c0(param_1[0x12]);
  param_1[0x13] = iVar1;
  (**(code **)(*param_1 + 0x1a4))(param_1,iVar1 * param_1[0x15] * 4,0);
  iVar1 = param_1[0x14];
  iVar2 = func_0x001adb3c(param_1[0x12]);
  iVar3 = func_0x001ab7ac(param_1[0x12]);
  iVar3 = iVar1 * iVar2 * iVar3;
  if (iVar3 - iRam003d9078 != 0 && iRam003d9078 <= iVar3) {
    if (iRam003d9074 != 0) {
      FUN_0000b122(iRam003d9074);
    }
    iRam003d9078 = iVar3;
    iRam003d9074 = FUN_0000aecc(iVar3);
  }
  return;
}



void FUN_0000bec0(void)

{
  int iVar1;
  
  iVar1 = func_0x000410a8();
  *(undefined4 *)(iVar1 + 0x28) = *(undefined4 *)(*(int *)(iVar1 + 0x28) + 0x48);
  return;
}


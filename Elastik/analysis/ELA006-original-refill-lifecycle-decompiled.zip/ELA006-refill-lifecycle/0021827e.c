
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0021827e(int cache)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar3 = *(int *)(cache + 0x1c);
  if (*(int *)(cache + 0x20) <= iVar3) {
    FUN_0000acae("GNFileCache: Buffer block count to low.");
    iVar3 = *(int *)(cache + 0x1c);
  }
  iVar1 = *(int *)(cache + 0x10);
  uVar2 = FUN_0000aecc(*(undefined4 *)(cache + 0x18));
  *(undefined4 *)(iVar1 + iVar3 * 8 + 4) = uVar2;
  iVar3 = *(int *)(cache + 0x1c);
  *(int *)(cache + 0x1c) = iVar3 + 1;
  return iVar3;
}



void FUN_00218d5e(int param_1)

{
  double dVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  longdouble lVar12;
  int iStack_470;
  int iStack_460;
  int iStack_424;
  char *pcStack_41c;
  int iStack_418;
  int aiStack_408 [255];
  
  if (*(char *)(param_1 + 0x30) == '\0') {
    cVar2 = *(char *)(param_1 + 0x31);
  }
  else {
    *(undefined1 *)(param_1 + 0x30) = 0;
    cVar2 = *(char *)(param_1 + 0x31);
  }
  if (cVar2 != '\0') {
    dVar1 = *(double *)(param_1 + 0x34);
    lVar12 = (longdouble)FUN_0000a8fe();
    *(double *)(param_1 + 0x34) = dVar1 - (double)lVar12;
  }
  *(undefined1 *)(param_1 + 0x3c) = 1;
  pcStack_41c = *(char **)(param_1 + 0x40);
  if (0 < *(int *)(param_1 + 0x44)) {
    iStack_424 = 0;
    do {
      if (((*pcStack_41c != '\0') && (iVar11 = *(int *)(pcStack_41c + 4), iVar11 != -1)) &&
         (iVar3 = *(int *)(pcStack_41c + 8), iVar11 <= iVar3)) {
        iStack_418 = iVar11 * 4;
        do {
          iVar8 = FUN_00218102(param_1,iVar11);
          if (iVar8 == -1) {
            iVar8 = func_0x002181d6(param_1);
            if (iVar8 == -1) {
              iVar8 = FUN_0021827e(param_1);
            }
            iVar9 = iVar8 * 8;
            iStack_460 = *(int *)(param_1 + 0x10);
            if (*(int *)(iStack_460 + iVar9) != -1) {
              *(undefined4 *)(*(int *)(param_1 + 0x14) + *(int *)(iStack_460 + iVar9) * 4) =
                   0xffffffff;
              iStack_460 = *(int *)(param_1 + 0x10);
            }
            *(undefined4 *)(iVar9 + iStack_460) = 0xffffffff;
            iVar4 = *(int *)(param_1 + 0x50);
            if (0 < *(int *)(param_1 + 0x54)) {
              iVar10 = 0;
              iVar5 = *(int *)(param_1 + 0x10);
              iVar6 = *(int *)(param_1 + 0x50);
              iVar7 = *(int *)(param_1 + 0x54);
              iStack_470 = 0;
              do {
                aiStack_408[iVar10] = iStack_470 + *(int *)(iVar9 + 4 + iVar5);
                iVar10 = iVar10 + 1;
                iStack_470 = iStack_470 + iVar6 * 4;
              } while (iVar10 < iVar7);
            }
            FUN_001afed2(*(undefined4 *)(param_1 + 0x48),aiStack_408,iVar11 * iVar4,
                         *(undefined4 *)(param_1 + 0x50));
            *(int *)(iVar9 + *(int *)(param_1 + 0x10)) = iVar11;
            *(int *)(iStack_418 + *(int *)(param_1 + 0x14)) = iVar8;
          }
          iVar11 = iVar11 + 1;
          iStack_418 = iStack_418 + 4;
        } while (iVar11 <= iVar3);
      }
      pcStack_41c = pcStack_41c + 0xc;
      iStack_424 = iStack_424 + 1;
    } while (iStack_424 < *(int *)(param_1 + 0x44));
  }
  *(undefined1 *)(param_1 + 0x3c) = 0;
  if (*(char *)(param_1 + 0x31) != '\0') {
    dVar1 = *(double *)(param_1 + 0x34);
    lVar12 = (longdouble)FUN_0000a8fe();
    *(double *)(param_1 + 0x34) = dVar1 + (double)lVar12;
  }
  return;
}


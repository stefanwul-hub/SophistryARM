
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00217cd2(undefined4 *param_1)

{
  undefined4 uVar1;
  
  func_0x0002dc66(param_1);
  *param_1 = &UNK_003a1d68;
  param_1[3] = 0;
  param_1[0xb] = 0;
  uVar1 = func_0x001804c8();
  param_1[6] = uVar1;
  param_1[7] = 0;
  *(undefined1 *)(param_1 + 0xc) = 0;
  *(undefined1 *)((int)param_1 + 0x31) = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  *(undefined1 *)(param_1 + 0xf) = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  return;
}


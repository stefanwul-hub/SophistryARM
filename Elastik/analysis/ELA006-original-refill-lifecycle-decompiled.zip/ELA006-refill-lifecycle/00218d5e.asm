00218d5e  55  PUSH EBP
00218d5f  89e5  MOV EBP,ESP
00218d61  57  PUSH EDI
00218d62  56  PUSH ESI
00218d63  81ec80040000  SUB ESP,0x480
00218d69  8b4508  MOV EAX,dword ptr [EBP + 0x8]
00218d6c  80783000  CMP byte ptr [EAX + 0x30],0x0
00218d70  0f84be000000  JZ 0x00218e34
00218d76  c6403000  MOV byte ptr [EAX + 0x30],0x0
00218d7a  8b5508  MOV EDX,dword ptr [EBP + 0x8]
00218d7d  807a3100  CMP byte ptr [EDX + 0x31],0x0
00218d81  0f85b9000000  JNZ 0x00218e40
00218d87  c6423c01  MOV byte ptr [EDX + 0x3c],0x1
00218d8b  8b4a40  MOV ECX,dword ptr [EDX + 0x40]
00218d8e  898de8fbffff  MOV dword ptr [EBP + 0xfffffbe8],ECX
00218d94  8b7244  MOV ESI,dword ptr [EDX + 0x44]
00218d97  85f6  TEST ESI,ESI
00218d99  0f8e90000000  JLE 0x00218e2f
00218d9f  c785e0fbffff00000000  MOV dword ptr [EBP + 0xfffffbe0],0x0
00218da9  8bbde8fbffff  MOV EDI,dword ptr [EBP + 0xfffffbe8]
00218daf  803f00  CMP byte ptr [EDI],0x0
00218db2  7419  JZ 0x00218dcd
00218db4  8b7704  MOV ESI,dword ptr [EDI + 0x4]
00218db7  83feff  CMP ESI,-0x1
00218dba  7411  JZ 0x00218dcd
00218dbc  8b4708  MOV EAX,dword ptr [EDI + 0x8]
00218dbf  8985e4fbffff  MOV dword ptr [EBP + 0xfffffbe4],EAX
00218dc5  39c6  CMP ESI,EAX
00218dc7  0f8eab000000  JLE 0x00218e78
00218dcd  8385e8fbffff0c  ADD dword ptr [EBP + 0xfffffbe8],0xc
00218dd4  8385e0fbffff01  ADD dword ptr [EBP + 0xfffffbe0],0x1
00218ddb  8b95e0fbffff  MOV EDX,dword ptr [EBP + 0xfffffbe0]
00218de1  8b4508  MOV EAX,dword ptr [EBP + 0x8]
00218de4  3b5044  CMP EDX,dword ptr [EAX + 0x44]
00218de7  7cc0  JL 0x00218da9
00218de9  89c1  MOV ECX,EAX
00218deb  c6413c00  MOV byte ptr [ECX + 0x3c],0x0
00218def  80793100  CMP byte ptr [ECX + 0x31],0x0
00218df3  7430  JZ 0x00218e25
00218df5  f20f104134  MOVSD XMM0,qword ptr [ECX + 0x34]
00218dfa  f20f1185b8fbffff  MOVSD qword ptr [EBP + 0xfffffbb8],XMM0
00218e02  e8f71adfff  CALL 0x0000a8fe
00218e07  dd9dd0fbffff  FSTP qword ptr [EBP + 0xfffffbd0]
00218e0d  f20f1085b8fbffff  MOVSD XMM0,qword ptr [EBP + 0xfffffbb8]
00218e15  f20f5885d0fbffff  ADDSD XMM0,qword ptr [EBP + 0xfffffbd0]
00218e1d  8b4508  MOV EAX,dword ptr [EBP + 0x8]
00218e20  f20f114034  MOVSD qword ptr [EAX + 0x34],XMM0
00218e25  81c480040000  ADD ESP,0x480
00218e2b  5e  POP ESI
00218e2c  5f  POP EDI
00218e2d  5d  POP EBP
00218e2e  c3  RET
00218e2f  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
00218e32  ebb7  JMP 0x00218deb
00218e34  89c2  MOV EDX,EAX
00218e36  807a3100  CMP byte ptr [EDX + 0x31],0x0
00218e3a  0f8447ffffff  JZ 0x00218d87
00218e40  f20f104234  MOVSD XMM0,qword ptr [EDX + 0x34]
00218e45  f20f1185f0fbffff  MOVSD qword ptr [EBP + 0xfffffbf0],XMM0
00218e4d  e8ac1adfff  CALL 0x0000a8fe
00218e52  dd9dc0fbffff  FSTP qword ptr [EBP + 0xfffffbc0]
00218e58  f20f1085f0fbffff  MOVSD XMM0,qword ptr [EBP + 0xfffffbf0]
00218e60  f20f5c85c0fbffff  SUBSD XMM0,qword ptr [EBP + 0xfffffbc0]
00218e68  8b4508  MOV EAX,dword ptr [EBP + 0x8]
00218e6b  f20f114034  MOVSD qword ptr [EAX + 0x34],XMM0
00218e70  8b5508  MOV EDX,dword ptr [EBP + 0x8]
00218e73  e90fffffff  JMP 0x00218d87
00218e78  8d14b500000000  LEA EDX,[ESI*0x4 + 0x0]
00218e7f  8995ecfbffff  MOV dword ptr [EBP + 0xfffffbec],EDX
00218e85  eb16  JMP 0x00218e9d
00218e87  83c601  ADD ESI,0x1
00218e8a  8385ecfbffff04  ADD dword ptr [EBP + 0xfffffbec],0x4
00218e91  39b5e4fbffff  CMP dword ptr [EBP + 0xfffffbe4],ESI
00218e97  0f8c30ffffff  JL 0x00218dcd
00218e9d  89742404  MOV dword ptr [ESP + 0x4],ESI
00218ea1  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
00218ea4  890c24  MOV dword ptr [ESP],ECX
00218ea7  e856f2ffff  CALL 0x00218102
00218eac  83c001  ADD EAX,0x1
00218eaf  75d6  JNZ 0x00218e87
00218eb1  8b7d08  MOV EDI,dword ptr [EBP + 0x8]
00218eb4  893c24  MOV dword ptr [ESP],EDI
00218eb7  e81af3ffff  CALL 0x002181d6
00218ebc  8985dcfbffff  MOV dword ptr [EBP + 0xfffffbdc],EAX
00218ec2  83f8ff  CMP EAX,-0x1
00218ec5  0f842e010000  JZ 0x00218ff9
00218ecb  c1e003  SHL EAX,0x3
00218ece  8985ccfbffff  MOV dword ptr [EBP + 0xfffffbcc],EAX
00218ed4  8b5508  MOV EDX,dword ptr [EBP + 0x8]
00218ed7  8b5210  MOV EDX,dword ptr [EDX + 0x10]
00218eda  8995a4fbffff  MOV dword ptr [EBP + 0xfffffba4],EDX
00218ee0  8b1402  MOV EDX,dword ptr [EDX + EAX*0x1]
00218ee3  83faff  CMP EDX,-0x1
00218ee6  0f8400010000  JZ 0x00218fec
00218eec  8b7d08  MOV EDI,dword ptr [EBP + 0x8]
00218eef  8b4714  MOV EAX,dword ptr [EDI + 0x14]
00218ef2  c70490ffffffff  MOV dword ptr [EAX + EDX*0x4],0xffffffff
00218ef9  8b4710  MOV EAX,dword ptr [EDI + 0x10]
00218efc  8985a4fbffff  MOV dword ptr [EBP + 0xfffffba4],EAX
00218f02  8b95ccfbffff  MOV EDX,dword ptr [EBP + 0xfffffbcc]
00218f08  89c1  MOV ECX,EAX
00218f0a  c7040affffffff  MOV dword ptr [EDX + ECX*0x1],0xffffffff
00218f11  89f0  MOV EAX,ESI
00218f13  8b7d08  MOV EDI,dword ptr [EBP + 0x8]
00218f16  0faf4750  IMUL EAX,dword ptr [EDI + 0x50]
00218f1a  8985d8fbffff  MOV dword ptr [EBP + 0xfffffbd8],EAX
00218f20  8b4f54  MOV ECX,dword ptr [EDI + 0x54]
00218f23  85c9  TEST ECX,ECX
00218f25  0f8ebb000000  JLE 0x00218fe6
00218f2b  89f8  MOV EAX,EDI
00218f2d  31c9  XOR ECX,ECX
00218f2f  8b5710  MOV EDX,dword ptr [EDI + 0x10]
00218f32  8995a4fbffff  MOV dword ptr [EBP + 0xfffffba4],EDX
00218f38  8b7f50  MOV EDI,dword ptr [EDI + 0x50]
00218f3b  89bdb4fbffff  MOV dword ptr [EBP + 0xfffffbb4],EDI
00218f41  8b4054  MOV EAX,dword ptr [EAX + 0x54]
00218f44  8985b0fbffff  MOV dword ptr [EBP + 0xfffffbb0],EAX
00218f4a  c78594fbffff00000000  MOV dword ptr [EBP + 0xfffffb94],0x0
00218f54  8b8594fbffff  MOV EAX,dword ptr [EBP + 0xfffffb94]
00218f5a  89d7  MOV EDI,EDX
00218f5c  eb08  JMP 0x00218f66
00218f5e  89f8  MOV EAX,EDI
00218f60  8bbda4fbffff  MOV EDI,dword ptr [EBP + 0xfffffba4]
00218f66  8b95ccfbffff  MOV EDX,dword ptr [EBP + 0xfffffbcc]
00218f6c  03443a04  ADD EAX,dword ptr [EDX + EDI*0x1 + 0x4]
00218f70  89848dfcfbffff  MOV dword ptr [EBP + ECX*0x4 + 0xfffffbfc],EAX
00218f77  83c101  ADD ECX,0x1
00218f7a  8bbd94fbffff  MOV EDI,dword ptr [EBP + 0xfffffb94]
00218f80  8b95b4fbffff  MOV EDX,dword ptr [EBP + 0xfffffbb4]
00218f86  8d3c97  LEA EDI,[EDI + EDX*0x4]
00218f89  89bd94fbffff  MOV dword ptr [EBP + 0xfffffb94],EDI
00218f8f  3b8db0fbffff  CMP ECX,dword ptr [EBP + 0xfffffbb0]
00218f95  7cc7  JL 0x00218f5e
00218f97  8b5508  MOV EDX,dword ptr [EBP + 0x8]
00218f9a  8b8dd8fbffff  MOV ECX,dword ptr [EBP + 0xfffffbd8]
00218fa0  8b4250  MOV EAX,dword ptr [EDX + 0x50]
00218fa3  8944240c  MOV dword ptr [ESP + 0xc],EAX
00218fa7  894c2408  MOV dword ptr [ESP + 0x8],ECX
00218fab  8d85fcfbffff  LEA EAX,[EBP + 0xfffffbfc]
00218fb1  89442404  MOV dword ptr [ESP + 0x4],EAX
00218fb5  8b4248  MOV EAX,dword ptr [EDX + 0x48]
00218fb8  890424  MOV dword ptr [ESP],EAX
00218fbb  e8126ff9ff  CALL 0x001afed2
00218fc0  8b7d08  MOV EDI,dword ptr [EBP + 0x8]
00218fc3  8b4710  MOV EAX,dword ptr [EDI + 0x10]
00218fc6  8b95ccfbffff  MOV EDX,dword ptr [EBP + 0xfffffbcc]
00218fcc  893402  MOV dword ptr [EDX + EAX*0x1],ESI
00218fcf  8b4714  MOV EAX,dword ptr [EDI + 0x14]
00218fd2  8bbddcfbffff  MOV EDI,dword ptr [EBP + 0xfffffbdc]
00218fd8  8b8decfbffff  MOV ECX,dword ptr [EBP + 0xfffffbec]
00218fde  893c01  MOV dword ptr [ECX + EAX*0x1],EDI
00218fe1  e9a1feffff  JMP 0x00218e87
00218fe6  89fa  MOV EDX,EDI
00218fe8  89c1  MOV ECX,EAX
00218fea  ebb4  JMP 0x00218fa0
00218fec  89c2  MOV EDX,EAX
00218fee  8b8da4fbffff  MOV ECX,dword ptr [EBP + 0xfffffba4]
00218ff4  e911ffffff  JMP 0x00218f0a
00218ff9  893c24  MOV dword ptr [ESP],EDI
00218ffc  e87df2ffff  CALL 0x0021827e
00219001  8985dcfbffff  MOV dword ptr [EBP + 0xfffffbdc],EAX
00219007  e9bffeffff  JMP 0x00218ecb

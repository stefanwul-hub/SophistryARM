
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00070218(int param_1,undefined4 param_2,undefined8 param_3,char param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x13f,uVar3,"function != 0");
  }
  puVar1 = (undefined4 *)__Znwm(0x24);
  func_0x0002dc66(puVar1);
  *puVar1 = &UNK_00372d08;
  *(undefined1 *)(puVar1 + 4) = 0;
  *(undefined1 *)((int)puVar1 + 0x11) = 0;
  puVar1[5] = 0;
  puVar1[6] = 0;
  puVar1[7] = 0;
  puVar1[8] = 0;
  puVar1[3] = 0;
  piVar2 = (int *)FUN_0002dfa6(puVar1);
  uVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
  FUN_0006fdb4(uVar3,param_1,param_2,param_3,(int)param_4);
  return uVar3;
}



void FUN_0000a8fe(void)

{
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00085a2c(undefined4 param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  puVar1 = (undefined4 *)__Znwm(0x14);
  FUN_001821dc(puVar1);
  *puVar1 = &UNK_00374468;
  *(undefined1 *)(puVar1 + 4) = 0;
  puVar1[3] = 0;
  piVar2 = (int *)FUN_0002dfa6(puVar1);
  iVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
  if (iVar3 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNNumber.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xaf,uVar4,"this != 0");
  }
  *(undefined1 *)(iVar3 + 0x10) = 0x66;
  if (*(int *)(iVar3 + 0xc) != 0) {
    **(undefined4 **)(iVar3 + 0xc) = param_1;
    return iVar3;
  }
  puVar1 = (undefined4 *)FUN_0000aecc(4);
  *(undefined4 **)(iVar3 + 0xc) = puVar1;
  *puVar1 = param_1;
  return iVar3;
}


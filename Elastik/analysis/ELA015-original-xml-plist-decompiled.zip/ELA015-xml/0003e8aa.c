
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0003e8aa(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined2 uVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  uint uVar9;
  char *pcVar10;
  int iStack_2c;
  int iStack_28;
  
  puVar3 = (undefined4 *)__Znwm(0x20);
  func_0x0002dc66(puVar3);
  *puVar3 = &UNK_0036ec68;
  *(undefined1 *)(puVar3 + 6) = 1;
  puVar3[3] = 0;
  puVar3[4] = 0;
  puVar3[5] = 0xffffffff;
  puVar3[7] = 0xffffffff;
  piVar4 = (int *)FUN_0002dfa6(puVar3);
  uVar5 = (**(code **)(*piVar4 + 0x48))(piVar4);
  if (param_1 == 0) {
    uVar7 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar8 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar8,"Assertion failed in line %d of %s: %s.",0x10f,uVar7,"this != 0");
  }
  iVar6 = *(int *)(param_1 + 0x14);
  if (iVar6 == -1) {
    if (*(char **)(param_1 + 0xc) == (char *)0x0) {
      iVar6 = 0;
    }
    else {
      uVar9 = 0xffffffff;
      pcVar10 = *(char **)(param_1 + 0xc);
      do {
        if (uVar9 == 0) break;
        uVar9 = uVar9 - 1;
        cVar1 = *pcVar10;
        pcVar10 = pcVar10 + 1;
      } while (cVar1 != '\0');
      iVar6 = ~uVar9 - 1;
    }
  }
  iVar6 = FUN_0000aecc(iVar6 * 2);
  iStack_2c = 0;
  iStack_28 = 0;
  uVar9 = *(uint *)(param_1 + 0x14);
  if (uVar9 == 0xffffffff) goto LAB_0003e998;
LAB_0003e94a:
  do {
    if ((int)uVar9 <= iStack_2c) {
LAB_0003e9b0:
      FUN_0003788a(uVar5,iVar6,iStack_28);
      FUN_0000b122(iVar6);
      return uVar5;
    }
    while( true ) {
      uVar2 = FUN_00035d80(param_1,iStack_2c);
      cVar1 = FUN_000376dc(param_2,uVar2);
      if (cVar1 == '\0') {
        *(undefined2 *)(iVar6 + iStack_28 * 2) = uVar2;
        iStack_28 = iStack_28 + 1;
      }
      iStack_2c = iStack_2c + 1;
      uVar9 = *(uint *)(param_1 + 0x14);
      if (uVar9 != 0xffffffff) goto LAB_0003e94a;
LAB_0003e998:
      pcVar10 = *(char **)(param_1 + 0xc);
      if (pcVar10 == (char *)0x0) break;
      do {
        if (uVar9 == 0) break;
        uVar9 = uVar9 - 1;
        cVar1 = *pcVar10;
        pcVar10 = pcVar10 + 1;
      } while (cVar1 != '\0');
      if ((int)(~uVar9 - 1) <= iStack_2c) goto LAB_0003e9b0;
    }
    uVar9 = 0;
  } while( true );
}


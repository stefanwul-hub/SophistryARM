
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 * FUN_0019c916(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  byte bVar1;
  char cVar2;
  char *pcVar3;
  int iVar4;
  undefined4 *puVar5;
  uint uVar6;
  int iVar7;
  
  pcVar3 = (char *)FUN_0019c638(param_2,param_3);
  if (((pcVar3 == (char *)0x0) || (*pcVar3 == '\0')) || (*pcVar3 != '<')) {
    return (undefined4 *)0x0;
  }
  iVar4 = func_0x0019f1e2(param_1);
  pcVar3 = (char *)FUN_0019c638(pcVar3,param_3);
  if (pcVar3 == (char *)0x0) {
    return (undefined4 *)0x0;
  }
  if (*pcVar3 == '\0') {
    return (undefined4 *)0x0;
  }
  cVar2 = FUN_0019c35e(pcVar3,"<?xml",1,param_3);
  if (cVar2 != '\0') {
    puVar5 = (undefined4 *)__Znwm(0x58);
    func_0x0019fc54(puVar5,5);
    *puVar5 = PTR_DAT_003db096 + 8;
    puVar5[0xe] = 0;
    puVar5[0xd] = 0;
    puVar5[0xf] = 0;
    puVar5[0x11] = 0;
    puVar5[0x10] = 0;
    puVar5[0x12] = 0;
    puVar5[0x14] = 0;
    puVar5[0x13] = 0;
    puVar5[0x15] = 0;
    goto LAB_0019ca0b;
  }
  cVar2 = FUN_0019c35e(pcVar3,"<!--",0,param_3);
  if (cVar2 != '\0') {
    puVar5 = (undefined4 *)__Znwm(0x34);
    func_0x0019fc54(puVar5,2);
    *puVar5 = PTR_DAT_003db09a + 8;
    goto LAB_0019ca0b;
  }
  cVar2 = FUN_0019c35e(pcVar3,"<!",0,param_3);
  if (cVar2 == '\0') {
    bVar1 = pcVar3[1];
    if (bVar1 < 0x7f) {
      if ((bVar1 & 0x80) == 0) {
        uVar6 = *(uint *)(PTR_003db0a2 + (uint)bVar1 * 4 + 0x34) >> 8 & 1;
      }
      else {
        iVar7 = ___maskrune((uint)bVar1,0x100);
        uVar6 = (uint)(iVar7 != 0);
      }
      if ((uVar6 == 0) && (pcVar3[1] != '_')) {
        puVar5 = (undefined4 *)__Znwm(0x34);
        func_0x0019fc54(puVar5,3);
        goto LAB_0019cb52;
      }
    }
    puVar5 = (undefined4 *)__Znwm(0x68);
    func_0x001a2a02(puVar5,"");
    if (puVar5 == (undefined4 *)0x0) {
      if (iVar4 != 0) {
        FUN_0019c1ea(iVar4,3,0,0,0);
        return (undefined4 *)0x0;
      }
      return (undefined4 *)0x0;
    }
  }
  else {
    puVar5 = (undefined4 *)__Znwm(0x34);
    func_0x0019fc54(puVar5,3);
LAB_0019cb52:
    *puVar5 = PTR_DAT_003db092 + 8;
  }
LAB_0019ca0b:
  puVar5[4] = param_1;
  return puVar5;
}


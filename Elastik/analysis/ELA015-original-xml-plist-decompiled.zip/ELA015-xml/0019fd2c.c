
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0019fd2c(undefined4 *param_1)

{
  int *piVar1;
  int *piVar2;
  
  *param_1 = &UNK_00392828;
  piVar2 = (int *)param_1[6];
  while (piVar2 != (int *)0x0) {
    piVar1 = (int *)piVar2[0xc];
    (**(code **)(*piVar2 + 4))(piVar2);
    piVar2 = piVar1;
  }
  if (param_1[8] != 0) {
    FUN_0000b122(param_1[8]);
  }
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  *param_1 = PTR_DAT_003db0a6 + 8;
  return;
}


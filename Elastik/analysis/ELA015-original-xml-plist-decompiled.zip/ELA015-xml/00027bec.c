
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00027bec(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNData.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x162,uVar3,"this != 0");
  }
  if ((*(int *)(param_1 + 0x18) == 0) && (iVar1 = *(int *)(param_1 + 0xc), iVar1 != 0)) {
    if (iVar1 == 0) {
      func_0x0000acae("GNMemoryHandle is nil.");
    }
    iVar2 = *(int *)(iVar1 + 8) + -1;
    *(int *)(iVar1 + 8) = iVar2;
    if (iVar2 == 0) {
      if (iRam003d3ef0 == 0) {
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      func_0x0004313e(iRam003d3ef0,iVar1);
      iRam003d3ef4 = iRam003d3ef4 + 1;
    }
    return;
  }
  return;
}


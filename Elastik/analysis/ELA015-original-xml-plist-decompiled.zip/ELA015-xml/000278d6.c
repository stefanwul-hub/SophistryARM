
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

dword FUN_000278d6(int param_1)

{
  dword dVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNData.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x14a,uVar2,"this != 0");
  }
  if (*(int *)(param_1 + 0x18) == 0) {
    dVar1 = *(dword *)(param_1 + 0xc);
    if (dVar1 != 0) {
      if (dVar1 != 0) {
        return *(dword *)(dVar1 + 4);
      }
      func_0x0000acae("GNMemoryHandle is nil.");
      return mach_header_00000000.cputype;
    }
  }
  else {
    dVar1 = *(dword *)(param_1 + 0x1c);
  }
  return dVar1;
}


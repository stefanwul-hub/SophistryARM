
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0017d67a(byte *param_1)

{
  byte bVar1;
  byte *pbVar2;
  
  pbVar2 = param_1;
  do {
    bVar1 = *pbVar2;
    pbVar2 = pbVar2 + 1;
  } while ((byte)(&UNK_00365020)[bVar1] < 0x40);
  if (-1 < (int)(pbVar2 + (2 - (int)param_1))) {
    return ((int)(pbVar2 + (2 - (int)param_1)) >> 2) * 3 + 1;
  }
  return ((int)(pbVar2 + (5 - (int)param_1)) >> 2) * 3 + 1;
}


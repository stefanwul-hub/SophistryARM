
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_001a5f6c(undefined4 param_1)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int *piVar4;
  int *piVar5;
  
  uVar1 = func_0x00033482();
  piVar2 = (int *)FUN_00038d00(param_1,uVar1);
  puVar3 = (undefined4 *)__Znwm(0x14);
  func_0x0002dc66(puVar3);
  *puVar3 = &UNK_003929a8;
  puVar3[3] = 0;
  puVar3[4] = 0;
  piVar4 = (int *)FUN_0002dfa6(puVar3);
  piVar5 = (int *)piVar4[3];
  if (piVar2 != piVar5) {
    if (piVar5 != (int *)0x0) {
      (**(code **)(*piVar5 + 0x44))(piVar5);
    }
    piVar4[3] = (int)piVar2;
    if (piVar2 != (int *)0x0) {
      (**(code **)(*piVar2 + 0x40))(piVar2);
    }
  }
  piVar4[4] = 0;
  piVar5 = (int *)FUN_001a59d8(piVar4);
  if (piVar5 != (int *)0x0) {
    (**(code **)(*piVar5 + 0x48))(piVar5);
  }
  (**(code **)(*piVar4 + 0x44))(piVar4);
  return piVar5;
}


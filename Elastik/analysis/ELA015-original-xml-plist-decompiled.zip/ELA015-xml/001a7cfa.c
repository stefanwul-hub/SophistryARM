
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001a7cfa(undefined4 *param_1)

{
  longdouble lVar1;
  longdouble lVar2;
  
  func_0x0002dc66(param_1);
  *param_1 = &UNK_00392b68;
  lVar1 = (longdouble)_CFAbsoluteTimeGetCurrent();
  if (iRam003d4a24 == 0) {
    iRam003d4a24 = _CFTimeZoneCopySystem();
    _CFRetain(iRam003d4a24);
  }
  lVar2 = (longdouble)_CFTimeZoneGetSecondsFromGMT(iRam003d4a24,(double)lVar1);
  *(double *)(param_1 + 3) = (double)lVar1 + (double)lVar2;
  return;
}


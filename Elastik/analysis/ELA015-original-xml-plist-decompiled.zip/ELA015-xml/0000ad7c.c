
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0000ad7c(int param_1)

{
  int iVar1;
  
  if (param_1 == 0) {
    func_0x0000acae("GNMemoryHandle is nil.");
  }
  iVar1 = *(int *)(param_1 + 8) + -1;
  *(int *)(param_1 + 8) = iVar1;
  if (iVar1 == 0) {
    if (iRam003d3ef0 == 0) {
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    func_0x0004313e(iRam003d3ef0,param_1);
    iRam003d3ef4 = iRam003d3ef4 + 1;
  }
  return;
}


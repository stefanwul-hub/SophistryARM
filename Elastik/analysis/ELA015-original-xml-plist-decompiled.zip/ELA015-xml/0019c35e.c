
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0019c35e(char *param_1,char *param_2,char param_3,int param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  char *extraout_ECX;
  undefined4 uVar4;
  char *pcVar5;
  char *pcStack_20;
  
  if (param_1 == (char *)0x0) {
    pcVar5 = "p";
    uVar4 = 0x1fe;
  }
  else if (param_2 == (char *)0x0) {
    pcVar5 = "tag";
    uVar4 = 0x1ff;
  }
  else {
    cVar1 = *param_1;
    if (cVar1 != '\0') {
      if (param_3 == '\0') {
        if (*param_2 == '\0') {
          return 1;
        }
        if (cVar1 != *param_2) {
          return 0;
        }
        while( true ) {
          param_2 = param_2 + 1;
          pcVar5 = param_1 + 1;
          if (*pcVar5 == '\0') break;
          if (*param_2 == '\0') {
            return 1;
          }
          param_1 = param_1 + 1;
          if (*pcVar5 != *param_2) {
            return 0;
          }
        }
LAB_0019c462:
        if (*param_2 == '\0') {
          return 1;
        }
        return 0;
      }
      goto LAB_0019c3d3;
    }
    pcVar5 = "0";
    uVar4 = 0x202;
  }
  cVar1 = func_0x002171c2("%s:%u: failed assertion `%s\'\n",
                          "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/tinyxml/tinyxmlparser.cpp"
                          ,uVar4,pcVar5);
  param_1 = extraout_ECX;
LAB_0019c3d3:
  if (*param_2 != '\0') {
    pcStack_20 = param_1;
    if (param_4 == 1) {
      do {
        iVar3 = ___tolower((int)cVar1);
        iVar2 = (int)*param_2;
        if (iVar2 < 0x80) {
          iVar2 = ___tolower(iVar2);
        }
        if (iVar3 != iVar2) goto LAB_0019c462;
        param_2 = param_2 + 1;
        cVar1 = pcStack_20[1];
        if (cVar1 == '\0') goto LAB_0019c462;
        pcStack_20 = pcStack_20 + 1;
      } while (*param_2 != '\0');
    }
    else {
      do {
        iVar2 = ___tolower((int)cVar1);
        iVar3 = ___tolower((int)*param_2);
        if (iVar2 != iVar3) goto LAB_0019c462;
        param_2 = param_2 + 1;
        cVar1 = pcStack_20[1];
        if (cVar1 == '\0') goto LAB_0019c462;
        pcStack_20 = pcStack_20 + 1;
      } while (*param_2 != '\0');
    }
  }
  return 1;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00027abc(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNData.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x13f,uVar1,"this != 0");
  }
  iVar3 = *(int *)(param_1 + 0x18);
  if (iVar3 == 0) {
    if (*(int *)(param_1 + 0xc) != 0) {
      return **(int **)(*(int *)(param_1 + 0xc) + 0xc);
    }
    FUN_0000ab14("GNData::bytes(). Data object doesn\'t have alloced memory yet.");
    iVar3 = 0;
  }
  return iVar3;
}


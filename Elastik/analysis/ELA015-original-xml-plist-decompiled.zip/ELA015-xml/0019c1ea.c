
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

uint __regparm1
FUN_0019c1ea(uint param_1,int param_2,int param_3,int param_4,uint *param_5,undefined4 param_6)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  char *pcVar4;
  
  if (*(char *)(param_2 + 0x34) == '\0') {
    if (0xd < param_3 - 1U) {
      pcVar4 = 
      "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/tinyxml/tinyxmlparser.cpp";
      func_0x002171c2("%s:%u: failed assertion `%s\'\n",
                      "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/tinyxml/tinyxmlparser.cpp"
                      ,0x2fd,"err > 0 && err < TIXML_ERROR_STRING_COUNT");
      if (0x7e < (byte)pcVar4) {
        return 1;
      }
      if (((uint)pcVar4 & 0x80) == 0) {
        return *(uint *)(PTR_003db0a2 + ((uint)pcVar4 & 0xff) * 4 + 0x34) >> 8 & 1;
      }
      iVar3 = ___maskrune((uint)pcVar4 & 0xff,0x100);
      return (uint)(iVar3 != 0);
    }
    *(undefined1 *)(param_2 + 0x34) = 1;
    *(int *)(param_2 + 0x38) = param_3;
    param_1 = FUN_00217052(param_2 + 0x3c,*(undefined4 *)(PTR_DAT_003db0aa + param_3 * 4));
    *(undefined4 *)(param_2 + 0x50) = 0xffffffff;
    *(undefined4 *)(param_2 + 0x4c) = 0xffffffff;
    if ((param_4 != 0) && (param_5 != (uint *)0x0)) {
      func_0x0019bef2(param_5,param_4,param_6);
      uVar1 = *param_5;
      uVar2 = param_5[1];
      *(uint *)(param_2 + 0x4c) = uVar1;
      *(uint *)(param_2 + 0x50) = uVar2;
      return uVar1;
    }
  }
  return param_1;
}


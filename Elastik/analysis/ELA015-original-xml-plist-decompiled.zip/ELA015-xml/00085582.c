
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00085582(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if (param_1 != 0) {
    *(undefined1 *)(param_1 + 0x10) = 0x6c;
    puVar1 = (undefined4 *)FUN_0000aecc(8);
    *(undefined4 **)(param_1 + 0xc) = puVar1;
    *puVar1 = param_2;
    puVar1[1] = param_3;
    return param_1;
  }
  uVar2 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNNumber.cpp"
                         );
  uVar3 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xa6,uVar2,"this != 0");
  mach_header_00000000.ncmds._0_1_ = 0x6c;
  puVar1 = (undefined4 *)FUN_0000aecc(8);
  mach_header_00000000.filetype = (dword)puVar1;
  *puVar1 = param_2;
  puVar1[1] = param_3;
  return 0;
}



int FUN_0019f0dc(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x18);
  while( true ) {
    if (iVar1 == 0) {
      return 0;
    }
    if (*(int *)(iVar1 + 0x14) == 1) break;
    iVar1 = *(int *)(iVar1 + 0x30);
  }
  return iVar1;
}


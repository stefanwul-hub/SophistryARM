
int FUN_001a143a(int param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int aiStack_24 [6];
  
  iVar2 = *(int *)(param_1 + 0x18);
  if (iVar2 != 0) {
    do {
      func_0x00216af2(aiStack_24,param_2);
      cVar1 = func_0x00216c82(iVar2 + 0x20,aiStack_24);
      if (aiStack_24[0] != 0) {
        FUN_0000b122(aiStack_24[0]);
      }
      aiStack_24[0] = 0;
      aiStack_24[1] = 0;
      aiStack_24[2] = 0;
      if (cVar1 != '\0') {
        while( true ) {
          if (iVar2 == 0) {
            return 0;
          }
          if (*(int *)(iVar2 + 0x14) == 1) break;
          iVar2 = *(int *)(iVar2 + 0x30);
          if (iVar2 == 0) {
            return 0;
          }
          while( true ) {
            func_0x00216af2(aiStack_24 + 3,param_2);
            cVar1 = func_0x00216c82(iVar2 + 0x20,aiStack_24 + 3);
            if (aiStack_24[3] != 0) {
              FUN_0000b122(aiStack_24[3]);
            }
            aiStack_24[3] = 0;
            aiStack_24[4] = 0;
            aiStack_24[5] = 0;
            if (cVar1 != '\0') break;
            iVar2 = *(int *)(iVar2 + 0x30);
            if (iVar2 == 0) {
              return 0;
            }
          }
        }
        return iVar2;
      }
      iVar2 = *(int *)(iVar2 + 0x30);
    } while (iVar2 != 0);
  }
  return 0;
}


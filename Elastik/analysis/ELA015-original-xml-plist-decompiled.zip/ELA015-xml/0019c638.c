
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

byte * FUN_0019c638(byte *param_1,int param_2)

{
  byte bVar1;
  undefined *puVar2;
  bool bVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  byte bStack_1d;
  
  puVar2 = PTR_003db0a2;
  if (param_1 != (byte *)0x0) {
    bStack_1d = *param_1;
    uVar6 = (uint)bStack_1d;
    if (bStack_1d != 0) {
      if (param_2 != 1) {
        if ((bStack_1d & 0x80) != 0) goto LAB_0019c6c8;
        do {
          uVar4 = *(uint *)(PTR_003db0a2 + uVar6 * 4 + 0x34) >> 0xe & 1;
          while( true ) {
            if (((uVar4 == 0) && ((char)uVar6 != '\n')) && ((char)uVar6 != '\r')) {
              bVar3 = false;
            }
            else {
              bVar3 = true;
            }
            if (bVar3) goto LAB_0019c6b2;
            uVar6 = (uint)*param_1;
            do {
              if (((char)uVar6 != '\n') && ((char)uVar6 != '\r')) {
                return param_1;
              }
LAB_0019c6b2:
              param_1 = param_1 + 1;
              bVar1 = *param_1;
              uVar6 = (uint)bVar1;
            } while (bVar1 == 0);
            if ((bVar1 & 0x80) == 0) break;
LAB_0019c6c8:
            iVar5 = ___maskrune(uVar6,0x4000);
            uVar4 = (uint)(iVar5 != 0);
          }
        } while( true );
      }
      if (bStack_1d == 0xef) goto LAB_0019c73a;
      do {
        if ((bStack_1d & 0x80) == 0) {
          uVar6 = *(uint *)(puVar2 + (uint)bStack_1d * 4 + 0x34) >> 0xe & 1;
        }
        else {
          iVar5 = ___maskrune((uint)bStack_1d,0x4000);
          uVar6 = (uint)(iVar5 != 0);
        }
        if (((uVar6 != 0) || (bStack_1d == 10)) || (bVar3 = false, bStack_1d == 0xd)) {
          bVar3 = true;
        }
        if (((!bVar3) && (*param_1 != 10)) && (*param_1 != 0xd)) {
          return param_1;
        }
        param_1 = param_1 + 1;
        while( true ) {
          bStack_1d = *param_1;
          if (bStack_1d == 0) {
            return param_1;
          }
          if (bStack_1d != 0xef) break;
LAB_0019c73a:
          if (param_1[1] == 0xbb) {
            if (param_1[2] != 0xbf) break;
            param_1 = param_1 + 3;
          }
          else {
            if ((param_1[1] != 0xbf) || ((param_1[2] != 0xbe && (param_1[2] != 0xbf)))) break;
            param_1 = param_1 + 3;
          }
        }
      } while( true );
    }
  }
  return (byte *)0x0;
}


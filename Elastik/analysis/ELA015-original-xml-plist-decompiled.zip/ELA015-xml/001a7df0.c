
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_001a7df0(undefined4 param_1,undefined1 param_2,undefined1 param_3,undefined1 param_4,
                undefined1 param_5,int param_6)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  longdouble lVar4;
  
  uVar1 = __Znwm(0x14);
  FUN_001a7cfa(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  iVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
  lVar4 = (longdouble)
          _CFGregorianDateGetAbsoluteTime
                    (param_1,CONCAT31(CONCAT21(CONCAT11(param_5,param_4),param_3),param_2),
                     (double)param_6,uRam003d4a1c);
  *(double *)(iVar3 + 0xc) = (double)lVar4;
  return iVar3;
}


0019cbaa  55  PUSH EBP
0019cbab  89e5  MOV EBP,ESP
0019cbad  57  PUSH EDI
0019cbae  56  PUSH ESI
0019cbaf  53  PUSH EBX
0019cbb0  83ec4c  SUB ESP,0x4c
0019cbb3  e864841400  CALL 0x002e501c
0019cbb8  8b750c  MOV ESI,dword ptr [EBP + 0xc]
0019cbbb  8b7d10  MOV EDI,dword ptr [EBP + 0x10]
0019cbbe  8b4508  MOV EAX,dword ptr [EBP + 0x8]
0019cbc1  c6403400  MOV byte ptr [EAX + 0x34],0x0
0019cbc5  c7403800000000  MOV dword ptr [EAX + 0x38],0x0
0019cbcc  8d93146e1200  LEA EDX,[EBX + 0x126e14]
0019cbd2  8955d4  MOV dword ptr [EBP + -0x2c],EDX
0019cbd5  89542404  MOV dword ptr [ESP + 0x4],EDX
0019cbd9  8b4508  MOV EAX,dword ptr [EBP + 0x8]
0019cbdc  83c03c  ADD EAX,0x3c
0019cbdf  890424  MOV dword ptr [ESP],EAX
0019cbe2  e86ba40700  CALL 0x00217052
0019cbe7  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
0019cbea  c7415000000000  MOV dword ptr [ECX + 0x50],0x0
0019cbf1  c7414c00000000  MOV dword ptr [ECX + 0x4c],0x0
0019cbf8  85f6  TEST ESI,ESI
0019cbfa  0f841e010000  JZ 0x0019cd1e
0019cc00  803e00  CMP byte ptr [ESI],0x0
0019cc03  0f8415010000  JZ 0x0019cd1e
0019cc09  8b4508  MOV EAX,dword ptr [EBP + 0x8]
0019cc0c  c74008ffffffff  MOV dword ptr [EAX + 0x8],0xffffffff
0019cc13  c74004ffffffff  MOV dword ptr [EAX + 0x4],0xffffffff
0019cc1a  85ff  TEST EDI,EDI
0019cc1c  0f84f8010000  JZ 0x0019ce1a
0019cc22  8b07  MOV EAX,dword ptr [EDI]
0019cc24  8b5508  MOV EDX,dword ptr [EBP + 0x8]
0019cc27  894204  MOV dword ptr [EDX + 0x4],EAX
0019cc2a  8b4704  MOV EAX,dword ptr [EDI + 0x4]
0019cc2d  894208  MOV dword ptr [EDX + 0x8],EAX
0019cc30  8b7d08  MOV EDI,dword ptr [EBP + 0x8]
0019cc33  8b4f08  MOV ECX,dword ptr [EDI + 0x8]
0019cc36  8b5704  MOV EDX,dword ptr [EDI + 0x4]
0019cc39  8b4748  MOV EAX,dword ptr [EDI + 0x48]
0019cc3c  8975e0  MOV dword ptr [EBP + -0x20],ESI
0019cc3f  8945e4  MOV dword ptr [EBP + -0x1c],EAX
0019cc42  8955d8  MOV dword ptr [EBP + -0x28],EDX
0019cc45  894ddc  MOV dword ptr [EBP + -0x24],ECX
0019cc48  8b45d8  MOV EAX,dword ptr [EBP + -0x28]
0019cc4b  8b55dc  MOV EDX,dword ptr [EBP + -0x24]
0019cc4e  894704  MOV dword ptr [EDI + 0x4],EAX
0019cc51  895708  MOV dword ptr [EDI + 0x8],EDX
0019cc54  8b4514  MOV EAX,dword ptr [EBP + 0x14]
0019cc57  85c0  TEST EAX,EAX
0019cc59  7510  JNZ 0x0019cc6b
0019cc5b  803eef  CMP byte ptr [ESI],0xef
0019cc5e  0f8422010000  JZ 0x0019cd86
0019cc64  c7451400000000  MOV dword ptr [EBP + 0x14],0x0
0019cc6b  8b4514  MOV EAX,dword ptr [EBP + 0x14]
0019cc6e  89442404  MOV dword ptr [ESP + 0x4],EAX
0019cc72  893424  MOV dword ptr [ESP],ESI
0019cc75  e8bef9ffff  CALL 0x0019c638
0019cc7a  89c7  MOV EDI,EAX
0019cc7c  85c0  TEST EAX,EAX
0019cc7e  751e  JNZ 0x0019cc9e
0019cc80  e9ab010000  JMP 0x0019ce30
0019cc85  8b5514  MOV EDX,dword ptr [EBP + 0x14]
0019cc88  89542404  MOV dword ptr [ESP + 0x4],EDX
0019cc8c  893c24  MOV dword ptr [ESP],EDI
0019cc8f  e8a4f9ffff  CALL 0x0019c638
0019cc94  89c7  MOV EDI,EAX
0019cc96  85c0  TEST EAX,EAX
0019cc98  0f84ad000000  JZ 0x0019cd4b
0019cc9e  803f00  CMP byte ptr [EDI],0x0
0019cca1  0f84a4000000  JZ 0x0019cd4b
0019cca7  8b4d14  MOV ECX,dword ptr [EBP + 0x14]
0019ccaa  894c2408  MOV dword ptr [ESP + 0x8],ECX
0019ccae  897c2404  MOV dword ptr [ESP + 0x4],EDI
0019ccb2  8b4508  MOV EAX,dword ptr [EBP + 0x8]
0019ccb5  890424  MOV dword ptr [ESP],EAX
0019ccb8  e859fcffff  CALL 0x0019c916
0019ccbd  89c6  MOV ESI,EAX
0019ccbf  85c0  TEST EAX,EAX
0019ccc1  0f8484000000  JZ 0x0019cd4b
0019ccc7  8b10  MOV EDX,dword ptr [EAX]
0019ccc9  8b4d14  MOV ECX,dword ptr [EBP + 0x14]
0019cccc  894c240c  MOV dword ptr [ESP + 0xc],ECX
0019ccd0  8d45d8  LEA EAX,[EBP + -0x28]
0019ccd3  89442408  MOV dword ptr [ESP + 0x8],EAX
0019ccd7  897c2404  MOV dword ptr [ESP + 0x4],EDI
0019ccdb  893424  MOV dword ptr [ESP],ESI
0019ccde  ff520c  CALL dword ptr [EDX + 0xc]
0019cce1  89c7  MOV EDI,EAX
0019cce3  89742404  MOV dword ptr [ESP + 0x4],ESI
0019cce7  8b4508  MOV EAX,dword ptr [EBP + 0x8]
0019ccea  890424  MOV dword ptr [ESP],EAX
0019cced  e8141b0000  CALL 0x0019e806
0019ccf2  8b4514  MOV EAX,dword ptr [EBP + 0x14]
0019ccf5  85c0  TEST EAX,EAX
0019ccf7  758c  JNZ 0x0019cc85
0019ccf9  837e1405  CMP dword ptr [ESI + 0x14],0x5
0019ccfd  7586  JNZ 0x0019cc85
0019ccff  8b4644  MOV EAX,dword ptr [ESI + 0x44]
0019cd02  85c0  TEST EAX,EAX
0019cd04  754f  JNZ 0x0019cd55
0019cd06  8b75d4  MOV ESI,dword ptr [EBP + -0x2c]
0019cd09  803e00  CMP byte ptr [ESI],0x0
0019cd0c  0f85a8000000  JNZ 0x0019cdba
0019cd12  c7451401000000  MOV dword ptr [EBP + 0x14],0x1
0019cd19  e967ffffff  JMP 0x0019cc85
0019cd1e  c744241000000000  MOV dword ptr [ESP + 0x10],0x0
0019cd26  c744240c00000000  MOV dword ptr [ESP + 0xc],0x0
0019cd2e  c744240800000000  MOV dword ptr [ESP + 0x8],0x0
0019cd36  c74424040d000000  MOV dword ptr [ESP + 0x4],0xd
0019cd3e  8b7d08  MOV EDI,dword ptr [EBP + 0x8]
0019cd41  893c24  MOV dword ptr [ESP],EDI
0019cd44  e8a1f4ffff  CALL 0x0019c1ea
0019cd49  31ff  XOR EDI,EDI
0019cd4b  89f8  MOV EAX,EDI
0019cd4d  83c44c  ADD ESP,0x4c
0019cd50  5b  POP EBX
0019cd51  5e  POP ESI
0019cd52  5f  POP EDI
0019cd53  5d  POP EBP
0019cd54  c3  RET
0019cd55  8b7640  MOV ESI,dword ptr [ESI + 0x40]
0019cd58  85f6  TEST ESI,ESI
0019cd5a  75ad  JNZ 0x0019cd09
0019cd5c  8d83f0ab1300  LEA EAX,[EBX + 0x13abf0]
0019cd62  8944240c  MOV dword ptr [ESP + 0xc],EAX
0019cd66  c7442408e4020000  MOV dword ptr [ESP + 0x8],0x2e4
0019cd6e  8d839caa1300  LEA EAX,[EBX + 0x13aa9c]
0019cd74  89442404  MOV dword ptr [ESP + 0x4],EAX
0019cd78  8d83f8aa1300  LEA EAX,[EBX + 0x13aaf8]
0019cd7e  890424  MOV dword ptr [ESP],EAX
0019cd81  e83ca40700  CALL 0x002171c2
0019cd86  0fb64601  MOVZX EAX,byte ptr [ESI + 0x1]
0019cd8a  84c0  TEST AL,AL
0019cd8c  0f84d2feffff  JZ 0x0019cc64
0019cd92  3cbb  CMP AL,0xbb
0019cd94  0f85cafeffff  JNZ 0x0019cc64
0019cd9a  0fb64602  MOVZX EAX,byte ptr [ESI + 0x2]
0019cd9e  84c0  TEST AL,AL
0019cda0  0f84befeffff  JZ 0x0019cc64
0019cda6  3cbf  CMP AL,0xbf
0019cda8  0f85b6feffff  JNZ 0x0019cc64
0019cdae  c7451401000000  MOV dword ptr [EBP + 0x14],0x1
0019cdb5  e9b1feffff  JMP 0x0019cc6b
0019cdba  c744240c00000000  MOV dword ptr [ESP + 0xc],0x0
0019cdc2  c744240801000000  MOV dword ptr [ESP + 0x8],0x1
0019cdca  8d83f4ab1300  LEA EAX,[EBX + 0x13abf4]
0019cdd0  89442404  MOV dword ptr [ESP + 0x4],EAX
0019cdd4  893424  MOV dword ptr [ESP],ESI
0019cdd7  e882f5ffff  CALL 0x0019c35e
0019cddc  84c0  TEST AL,AL
0019cdde  0f852effffff  JNZ 0x0019cd12
0019cde4  c744240c00000000  MOV dword ptr [ESP + 0xc],0x0
0019cdec  c744240801000000  MOV dword ptr [ESP + 0x8],0x1
0019cdf4  8d83fcab1300  LEA EAX,[EBX + 0x13abfc]
0019cdfa  89442404  MOV dword ptr [ESP + 0x4],EAX
0019cdfe  893424  MOV dword ptr [ESP],ESI
0019ce01  e858f5ffff  CALL 0x0019c35e
0019ce06  84c0  TEST AL,AL
0019ce08  0f8504ffffff  JNZ 0x0019cd12
0019ce0e  c7451402000000  MOV dword ptr [EBP + 0x14],0x2
0019ce15  e96bfeffff  JMP 0x0019cc85
0019ce1a  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
0019ce1d  c7410400000000  MOV dword ptr [ECX + 0x4],0x0
0019ce24  c7410800000000  MOV dword ptr [ECX + 0x8],0x0
0019ce2b  e900feffff  JMP 0x0019cc30
0019ce30  c744241000000000  MOV dword ptr [ESP + 0x10],0x0
0019ce38  c744240c00000000  MOV dword ptr [ESP + 0xc],0x0
0019ce40  c744240800000000  MOV dword ptr [ESP + 0x8],0x0
0019ce48  c74424040d000000  MOV dword ptr [ESP + 0x4],0xd
0019ce50  8b5508  MOV EDX,dword ptr [EBP + 0x8]
0019ce53  891424  MOV dword ptr [ESP],EDX
0019ce56  e88ff3ffff  CALL 0x0019c1ea
0019ce5b  e9ebfeffff  JMP 0x0019cd4b


/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0017d6b8(byte *param_1,byte *param_2)

{
  byte bVar1;
  byte *pbVar2;
  byte *pbVar3;
  byte *pbVar4;
  
  pbVar3 = param_2;
  do {
    bVar1 = *pbVar3;
    pbVar3 = pbVar3 + 1;
  } while ((byte)(&UNK_00365020)[bVar1] < 0x40);
  pbVar4 = pbVar3 + (-1 - (int)param_2);
  pbVar2 = pbVar3 + (2 - (int)param_2);
  if ((int)pbVar2 < 0) {
    pbVar2 = pbVar3 + (5 - (int)param_2);
  }
  for (; 4 < (int)pbVar4; pbVar4 = pbVar4 + -4) {
    *param_1 = (byte)(&UNK_00365020)[param_2[1]] >> 4 | (&UNK_00365020)[*param_2] << 2;
    param_1[1] = (byte)(&UNK_00365020)[param_2[2]] >> 2 | (&UNK_00365020)[param_2[1]] << 4;
    param_1[2] = (&UNK_00365020)[param_2[2]] << 6 | (&UNK_00365020)[param_2[3]];
    param_1 = param_1 + 3;
    param_2 = param_2 + 4;
  }
  if (1 < (int)pbVar4) {
    *param_1 = (byte)(&UNK_00365020)[param_2[1]] >> 4 | (&UNK_00365020)[*param_2] << 2;
    param_1 = param_1 + 1;
  }
  if (2 < (int)pbVar4) {
    *param_1 = (byte)(&UNK_00365020)[param_2[2]] >> 2 | (&UNK_00365020)[param_2[1]] << 4;
    param_1 = param_1 + 1;
  }
  if (pbVar4 == (byte *)0x4) {
    *param_1 = (&UNK_00365020)[param_2[2]] << 6 | (&UNK_00365020)[param_2[3]];
    param_1 = param_1 + 1;
  }
  *param_1 = 0;
  return ((int)pbVar2 >> 2) * 3 - (-(int)pbVar4 & 3U);
}


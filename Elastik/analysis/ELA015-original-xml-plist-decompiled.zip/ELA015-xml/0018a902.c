
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0018a902(undefined4 *param_1)

{
  undefined4 uVar1;
  
  func_0x0002dc66(param_1);
  *param_1 = &UNK_00390d88;
  param_1[3] = 0;
  param_1[5] = 0;
  uVar1 = func_0x0003401a();
  param_1[4] = uVar1;
  return;
}


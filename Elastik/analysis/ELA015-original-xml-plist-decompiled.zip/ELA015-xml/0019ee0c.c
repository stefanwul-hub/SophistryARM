
int FUN_0019ee0c(int param_1)

{
  do {
    param_1 = *(int *)(param_1 + 0x30);
    if (param_1 == 0) {
      return 0;
    }
  } while (*(int *)(param_1 + 0x14) != 1);
  return param_1;
}



undefined4 FUN_00067a06(undefined4 param_1)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  
  uVar1 = __Znwm(0x20);
  FUN_00029d44(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  uVar1 = (**(code **)(*piVar2 + 0x48))(piVar2);
  for (iVar3 = FUN_0019f0dc(param_1); iVar3 != 0; iVar3 = FUN_0019ee0c(iVar3)) {
    uVar4 = FUN_000673d2(iVar3);
    FUN_0002bb40(uVar1,uVar4);
  }
  return uVar1;
}


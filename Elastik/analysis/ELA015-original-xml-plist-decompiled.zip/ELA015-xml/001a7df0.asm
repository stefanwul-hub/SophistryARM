001a7df0  55  PUSH EBP
001a7df1  89e5  MOV EBP,ESP
001a7df3  57  PUSH EDI
001a7df4  56  PUSH ESI
001a7df5  53  PUSH EBX
001a7df6  83ec3c  SUB ESP,0x3c
001a7df9  e81ed21300  CALL 0x002e501c
001a7dfe  c7042414000000  MOV dword ptr [ESP],0x14
001a7e05  e89b222300  CALL 0x003da0a5
001a7e0a  89c7  MOV EDI,EAX
001a7e0c  890424  MOV dword ptr [ESP],EAX
001a7e0f  e8e6feffff  CALL 0x001a7cfa
001a7e14  893c24  MOV dword ptr [ESP],EDI
001a7e17  e88a61e8ff  CALL 0x0002dfa6
001a7e1c  8b10  MOV EDX,dword ptr [EAX]
001a7e1e  890424  MOV dword ptr [ESP],EAX
001a7e21  ff5248  CALL dword ptr [EDX + 0x48]
001a7e24  89c6  MOV ESI,EAX
001a7e26  f20f2a451c  CVTSI2SD XMM0,dword ptr [EBP + 0x1c]
001a7e2b  f20f1145e0  MOVSD qword ptr [EBP + -0x20],XMM0
001a7e30  8b4518  MOV EAX,dword ptr [EBP + 0x18]
001a7e33  8845df  MOV byte ptr [EBP + -0x21],AL
001a7e36  8b4514  MOV EAX,dword ptr [EBP + 0x14]
001a7e39  8845de  MOV byte ptr [EBP + -0x22],AL
001a7e3c  8b4510  MOV EAX,dword ptr [EBP + 0x10]
001a7e3f  8845dd  MOV byte ptr [EBP + -0x23],AL
001a7e42  8b450c  MOV EAX,dword ptr [EBP + 0xc]
001a7e45  8845dc  MOV byte ptr [EBP + -0x24],AL
001a7e48  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001a7e4b  8945d8  MOV dword ptr [EBP + -0x28],EAX
001a7e4e  8b831ecc2200  MOV EAX,dword ptr [EBX + 0x22cc1e]
001a7e54  89442410  MOV dword ptr [ESP + 0x10],EAX
001a7e58  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001a7e5b  890424  MOV dword ptr [ESP],EAX
001a7e5e  8b45dc  MOV EAX,dword ptr [EBP + -0x24]
001a7e61  89442404  MOV dword ptr [ESP + 0x4],EAX
001a7e65  8b45e0  MOV EAX,dword ptr [EBP + -0x20]
001a7e68  89442408  MOV dword ptr [ESP + 0x8],EAX
001a7e6c  8b45e4  MOV EAX,dword ptr [EBP + -0x1c]
001a7e6f  8944240c  MOV dword ptr [ESP + 0xc],EAX
001a7e73  e80e2d2300  CALL 0x003dab86
001a7e78  dd5e0c  FSTP qword ptr [ESI + 0xc]
001a7e7b  89f0  MOV EAX,ESI
001a7e7d  83c43c  ADD ESP,0x3c
001a7e80  5b  POP EBX
001a7e81  5e  POP ESI
001a7e82  5f  POP EDI
001a7e83  5d  POP EBP
001a7e84  c3  RET


/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_000670cc(undefined4 param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  char *pcVar6;
  int iVar7;
  char *pcVar8;
  char *pcVar9;
  char *pcVar10;
  bool bVar11;
  undefined *apuStack_70 [13];
  char cStack_3c;
  undefined4 uStack_38;
  char *pcStack_34;
  int iStack_30;
  undefined4 uStack_2c;
  int iStack_24;
  
  cVar1 = FUN_001a4e18(param_1);
  if (cVar1 != '\0') {
    uVar2 = FUN_001a5f6c(param_1);
    return uVar2;
  }
  iVar3 = FUN_000278d6(param_1);
  iVar3 = FUN_0000aecc(iVar3 + 1);
  if (iVar3 == 0) {
    FUN_0000ab14("XML Parser out of memory");
    uVar2 = 0;
    goto LAB_00067216;
  }
  FUN_001a32fa(apuStack_70);
  FUN_00027b4e(param_1);
  uVar2 = FUN_000278d6(param_1);
  uVar4 = FUN_00027abc(param_1);
  _memcpy(iVar3,uVar4,uVar2);
  FUN_00027bec(param_1);
  iVar5 = FUN_000278d6(param_1);
  *(undefined1 *)(iVar3 + iVar5) = 0;
  FUN_0019cbaa(apuStack_70,iVar3,0,0);
  if (cStack_3c == '\0') {
    iVar5 = FUN_001a143a(apuStack_70,"plist");
    if ((iVar5 == 0) || (iVar5 = FUN_0019f0dc(iVar5), iVar5 == 0)) goto LAB_000671d6;
    bVar11 = *(int *)(iVar5 + 0x24) == 0;
    if (bVar11) {
      pcVar6 = "";
    }
    else {
      pcVar6 = *(char **)(iVar5 + 0x20);
    }
    iVar7 = 5;
    pcVar9 = "dict";
    do {
      pcVar8 = pcVar6;
      pcVar10 = pcVar9;
      if (iVar7 == 0) break;
      iVar7 = iVar7 + -1;
      pcVar10 = pcVar9 + 1;
      pcVar8 = pcVar6 + 1;
      bVar11 = *pcVar6 == *pcVar9;
      pcVar6 = pcVar8;
      pcVar9 = pcVar10;
    } while (bVar11);
    iVar7 = 0;
    if (!bVar11) {
      iVar7 = (uint)(byte)pcVar8[-1] - (uint)(byte)pcVar10[-1];
    }
    if (iVar7 != 0) goto LAB_000671d6;
    uVar2 = FUN_00066e46(iVar5);
  }
  else {
    pcVar6 = pcStack_34;
    if (iStack_30 == 0) {
      pcVar6 = "";
    }
    FUN_0000ab14("XML Parser Error ID %d Row %d - %s",uStack_38,iStack_24 + 1,pcVar6);
LAB_000671d6:
    uVar2 = 0;
  }
  apuStack_70[0] = PTR_DAT_003db032 + 8;
  if (pcStack_34 != (char *)0x0) {
    FUN_0000b122(pcStack_34);
  }
  pcStack_34 = (char *)0x0;
  iStack_30 = 0;
  uStack_2c = 0;
  FUN_0019fd2c(apuStack_70);
LAB_00067216:
  FUN_0000b122(iVar3);
  return uVar2;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000859a8(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  undefined4 uVar3;
  
  puVar1 = (undefined4 *)__Znwm(0x14);
  FUN_001821dc(puVar1);
  *puVar1 = &UNK_00374468;
  *(undefined1 *)(puVar1 + 4) = 0;
  puVar1[3] = 0;
  piVar2 = (int *)FUN_0002dfa6(puVar1);
  uVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
  FUN_00085582(uVar3,param_1,param_2);
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00066e46(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  undefined4 *puVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  uint uVar10;
  char *pcVar11;
  char *pcVar12;
  char *pcVar13;
  char *pcVar14;
  bool bVar15;
  undefined4 uStack_28;
  
  puVar3 = (undefined4 *)__Znwm(0x18);
  func_0x0002dc66(puVar3);
  *puVar3 = &UNK_00371a88;
  puVar3[3] = 0;
  puVar3[4] = 0;
  puVar3[5] = 0;
  piVar4 = (int *)FUN_0002dfa6(puVar3);
  uVar5 = (**(code **)(*piVar4 + 0x48))(piVar4);
  iVar6 = FUN_0019f0dc(param_1);
  if (iVar6 != 0) {
    do {
      iVar2 = *(int *)(iVar6 + 0x18);
      if (iVar2 == 0) {
        uVar7 = func_0x0000a930(
                               "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                               );
        uVar8 = FUN_00033b90("GNAssertionException");
        FUN_0000bfd6(uVar8,"Assertion failed in line %d of %s: %s.",0x56e,uVar7,"node != 0");
      }
      bVar15 = *(int *)(iVar6 + 0x24) == 0;
      if (bVar15) {
        iVar9 = 4;
        pcVar11 = "key";
        pcVar13 = "";
        do {
          pcVar12 = pcVar11;
          pcVar14 = pcVar13;
          if (iVar9 == 0) break;
          iVar9 = iVar9 + -1;
          pcVar14 = pcVar13 + 1;
          pcVar12 = pcVar11 + 1;
          bVar15 = *pcVar11 == *pcVar13;
          pcVar11 = pcVar12;
          pcVar13 = pcVar14;
        } while (bVar15);
        iVar9 = 0;
        if (!bVar15) {
          iVar9 = (uint)(byte)pcVar12[-1] - (uint)(byte)pcVar14[-1];
        }
        if (iVar9 != 0) goto LAB_00066fe2;
LAB_00066f08:
        uStack_28 = FUN_0019ee0c(iVar6);
        if (*(int *)(iVar2 + 0x24) != 0) goto LAB_0006703e;
LAB_00066f27:
        uVar10 = 0xffffffff;
        pcVar11 = "";
        do {
          if (uVar10 == 0) break;
          uVar10 = uVar10 - 1;
          cVar1 = *pcVar11;
          pcVar11 = pcVar11 + 1;
        } while (cVar1 != '\0');
        iVar6 = ~uVar10 - 1;
        if (*(int *)(iVar2 + 0x24) != 0) goto LAB_00067062;
LAB_00066f4b:
        pcVar11 = "";
      }
      else {
        iVar9 = 4;
        pcVar11 = "key";
        pcVar13 = *(char **)(iVar6 + 0x20);
        do {
          pcVar12 = pcVar11;
          pcVar14 = pcVar13;
          if (iVar9 == 0) break;
          iVar9 = iVar9 + -1;
          pcVar14 = pcVar13 + 1;
          pcVar12 = pcVar11 + 1;
          bVar15 = *pcVar11 == *pcVar13;
          pcVar11 = pcVar12;
          pcVar13 = pcVar14;
        } while (bVar15);
        iVar9 = 0;
        if (!bVar15) {
          iVar9 = (uint)(byte)pcVar12[-1] - (uint)(byte)pcVar14[-1];
        }
        if (iVar9 == 0) goto LAB_00066f08;
LAB_00066fe2:
        uVar7 = func_0x0000a930(
                               "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                               );
        uVar8 = FUN_00033b90("GNAssertionException");
        FUN_0000bfd6(uVar8,"Assertion failed in line %d of %s: %s.",0x56f,uVar7,
                     "::strcmp(\"key\", key->Value()) == 0");
        uStack_28 = FUN_0019ee0c(iVar6);
        if (*(int *)(iVar2 + 0x24) == 0) goto LAB_00066f27;
LAB_0006703e:
        uVar10 = 0xffffffff;
        pcVar11 = *(char **)(iVar2 + 0x20);
        do {
          if (uVar10 == 0) break;
          uVar10 = uVar10 - 1;
          cVar1 = *pcVar11;
          pcVar11 = pcVar11 + 1;
        } while (cVar1 != '\0');
        iVar6 = ~uVar10 - 1;
        if (*(int *)(iVar2 + 0x24) == 0) goto LAB_00066f4b;
LAB_00067062:
        pcVar11 = *(char **)(iVar2 + 0x20);
      }
      uVar7 = FUN_0003887c(pcVar11,iVar6,1000);
      uVar8 = FUN_000673d2(uStack_28);
      FUN_00066284(uVar5,uVar8,uVar7);
      iVar6 = FUN_0019ee0c(uStack_28);
    } while (iVar6 != 0);
  }
  return uVar5;
}



undefined4 FUN_001a4e18(int param_1)

{
  int iVar1;
  int iVar2;
  char cVar3;
  int iStack_20;
  int iStack_10;
  
  if (((param_1 != 0) && (iVar1 = FUN_000278d6(param_1), iVar1 != 0)) &&
     (iVar2 = FUN_00027abc(param_1), 0 < iVar1)) {
    iStack_20 = 0;
    do {
      cVar3 = *(char *)(iVar2 + iStack_20);
      if (((cVar3 != ' ') && (cVar3 != '\r')) && ((cVar3 != '\t' && (cVar3 != '\n')))) {
        if (cVar3 == -1) {
          iStack_20 = iStack_20 + 1;
          if (iVar1 <= iStack_20) {
            return 0;
          }
          if (*(char *)(iVar2 + iStack_20) != -2) {
            return 0;
          }
        }
        else if (cVar3 == -2) {
          iStack_20 = iStack_20 + 1;
          if (iVar1 <= iStack_20) {
            return 0;
          }
          if (*(char *)(iVar2 + iStack_20) != -1) {
            return 0;
          }
        }
        else {
          if (cVar3 != '/') {
LAB_001a4ed3:
            if (cVar3 != '{') {
              return 0;
            }
            return 1;
          }
          if (iVar1 <= iStack_20 + 1) {
            return 0;
          }
          cVar3 = *(char *)(iVar2 + iStack_20 + 1);
          if (cVar3 != '/') {
            if (cVar3 != '*') {
              return 0;
            }
            iStack_20 = iStack_20 + 2;
            if (iVar1 <= iStack_20) {
              return 0;
            }
            do {
              cVar3 = *(char *)(iVar2 + iStack_20);
              if (cVar3 == '*') {
                iStack_20 = iStack_20 + 1;
                if (iVar1 <= iStack_20) {
                  return 0;
                }
                cVar3 = *(char *)(iVar2 + iStack_20);
                if (cVar3 == '/') goto LAB_001a4eb1;
              }
              iStack_20 = iStack_20 + 1;
              if (iVar1 <= iStack_20) goto LAB_001a4ed3;
            } while( true );
          }
          iStack_20 = iStack_20 + 2;
          if (iVar1 <= iStack_20) {
            return 0;
          }
          cVar3 = *(char *)(iVar2 + iStack_20);
          if (cVar3 != '\n') {
            iStack_10 = iVar2 + iStack_20;
            do {
              iStack_20 = iStack_20 + 1;
              if (iVar1 == iStack_20) goto LAB_001a4ed3;
              cVar3 = *(char *)(iStack_10 + 1);
              iStack_10 = iStack_10 + 1;
            } while (cVar3 != '\n');
          }
        }
      }
LAB_001a4eb1:
      iStack_20 = iStack_20 + 1;
    } while (iStack_20 < iVar1);
  }
  return 0;
}


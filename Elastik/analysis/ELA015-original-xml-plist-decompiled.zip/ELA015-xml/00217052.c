
void FUN_00217052(int *param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  char *pcVar4;
  
  if (param_2 == (char *)0x0) {
    if (*param_1 != 0) {
      FUN_0000b122(*param_1);
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
    return;
  }
  uVar3 = 0xffffffff;
  pcVar4 = param_2;
  do {
    if (uVar3 == 0) break;
    uVar3 = uVar3 - 1;
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  uVar3 = ~uVar3;
  iVar2 = FUN_0000aecc(uVar3);
  _memcpy(iVar2,param_2,uVar3);
  if (*param_1 != 0) {
    FUN_0000b122(*param_1);
  }
  param_1[1] = uVar3;
  *param_1 = iVar2;
  param_1[2] = uVar3 - 1;
  return;
}


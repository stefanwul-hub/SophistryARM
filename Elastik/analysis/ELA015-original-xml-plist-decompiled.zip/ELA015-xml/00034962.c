
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

char * FUN_00034962(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x119,uVar1,"this != 0");
  }
  if ((*(int *)(param_1 + 0xc) == 0) && (*(int *)(param_1 + 0x14) != -1)) {
    func_0x000340ba(param_1);
  }
  if (*(char **)(param_1 + 0xc) != (char *)0x0) {
    return *(char **)(param_1 + 0xc);
  }
  return "";
}


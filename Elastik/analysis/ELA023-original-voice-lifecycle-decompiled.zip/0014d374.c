
/* WARNING: Possible PIC construction at 0x0014d3eb: Changing call to branch */

int FUN_0014d374(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined1 *puVar4;
  undefined1 *unaff_EBP;
  undefined4 uStack_30;
  int iStack_2c;
  int iStack_10;
  
  puVar4 = &stack0xfffffffc;
  iVar3 = *(int *)(param_1 + 0x98);
  if (iVar3 < 0) {
    iStack_2c = *(int *)(param_1 + 0x8c);
    if (iStack_2c != 0) {
      uStack_30 = 0x14d461;
      iVar3 = func_0x001f0b58();
      if (iVar3 != 0) {
        iVar3 = *(int *)(param_1 + 0x98);
        iStack_2c = *(int *)(param_1 + 0x8c);
        goto LAB_0014d393;
      }
      iStack_2c = *(int *)(param_1 + 0x8c);
    }
    iVar3 = 0;
  }
  else {
    iStack_2c = *(int *)(param_1 + 0x8c);
  }
LAB_0014d393:
  iStack_10 = *(int *)(param_1 + 0x94);
  if (iStack_10 < 0) {
    if (iStack_2c != 0) {
      uStack_30 = 0x14d437;
      iVar2 = func_0x001f0b58();
      if (iVar2 != 0) {
        iStack_10 = *(int *)(param_1 + 0x94);
        iStack_2c = *(int *)(param_1 + 0x8c);
        goto LAB_0014d3a4;
      }
      iStack_2c = *(int *)(param_1 + 0x8c);
    }
    iStack_10 = 0;
  }
LAB_0014d3a4:
  if (iStack_2c != 0) {
    uStack_30 = 0x14d3b0;
    iVar2 = func_0x001f0b58();
    if (iVar2 == 0) {
      return 0;
    }
    if (iVar3 != iStack_10) {
      if (iStack_10 < iVar3) {
        return (iVar3 - iStack_10) + 1;
      }
      if (iVar3 < iStack_10) {
        iStack_2c = *(int *)(param_1 + 0x8c);
        if (iStack_2c == 0) {
LAB_0014d3f0:
          return (iVar3 + 1) - iStack_10;
        }
        uStack_30 = 0x14d3e0;
        iStack_2c = func_0x001f0b58();
        if (iStack_2c == 0) goto LAB_0014d3f0;
        register0x00000010 = (BADSPACEBASE *)&uStack_30;
        uStack_30 = 0x14d3f0;
        unaff_EBP = puVar4;
        goto code_r0x001ab7c0;
      }
    }
    iStack_2c = *(int *)(param_1 + 0x8c);
    if (iStack_2c != 0) {
      uStack_30 = 0x14d410;
      iVar3 = func_0x001f0b58();
      if (iVar3 != 0) {
code_r0x001ab7c0:
        *(undefined1 **)((int)register0x00000010 + -4) = unaff_EBP;
        iVar3 = *(int *)(*(int *)((int)register0x00000010 + 4) + 0x24);
        if ((iVar3 == 0) &&
           (piVar1 = *(int **)(*(int *)((int)register0x00000010 + 4) + 0x54), piVar1 != (int *)0x0))
        {
          iVar3 = *piVar1;
          *(int **)((int)register0x00000010 + 4) = piVar1;
                    /* WARNING: Could not recover jumptable at 0x001ab7e0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          iVar3 = (**(code **)(iVar3 + 0x1bc))();
          return iVar3;
        }
        return iVar3;
      }
    }
  }
  return 0;
}


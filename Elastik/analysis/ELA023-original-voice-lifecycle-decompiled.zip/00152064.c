
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00152064(int param_1,int *param_2,int *param_3)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  
  if (*(int *)(param_1 + 0x98) == 0) {
    return;
  }
  if (param_2 == (int *)0x0) {
    return;
  }
  if (param_3 == (int *)0x0) {
    return;
  }
  iVar1 = *(int *)(param_1 + 0x9c);
  iVar6 = *(int *)(param_1 + 0xa0);
  if (iVar1 < iVar6) {
    iVar8 = *param_2;
  }
  else {
    if (iVar1 <= iVar6) {
      uVar7 = FUN_00033b90("GNInternalInconsistencyException");
      uVar2 = __Znwm(0x20);
      FUN_000332e2(uVar2);
      piVar3 = (int *)FUN_0002dfa6(uVar2);
      uVar2 = (**(code **)(*piVar3 + 0x48))(piVar3);
      uVar4 = func_0x00039354(
                             "ETInstrumentVoice::getBackwardNextChunkStartSample failed -> startSample == stopSample"
                             );
      func_0x0003d480(uVar2,uVar4,&param_3);
      FUN_00034b8e(uVar2);
      puVar5 = (undefined4 *)__Znwm(0x18);
      func_0x0002dc66(puVar5);
      *puVar5 = &UNK_0036ce88;
      puVar5[3] = 0;
      puVar5[4] = 0;
      puVar5[5] = 0;
      piVar3 = (int *)FUN_0002dfa6(puVar5);
      piVar3 = (int *)(**(code **)(*piVar3 + 0x48))(piVar3);
      (**(code **)(*piVar3 + 0x1a4))(piVar3,uVar7,uVar2,0);
      (**(code **)(*piVar3 + 0x1a8))(piVar3);
      return;
    }
    iVar8 = *param_2;
    if (iVar8 <= iVar6) {
      iVar6 = (iVar8 - *param_3) + 1;
      if (iVar6 < 0) {
        *param_3 = iVar8 + 1;
        *param_2 = 0;
        return;
      }
      goto LAB_001520d8;
    }
    if (iVar8 < iVar1) {
      return;
    }
  }
  iVar6 = (iVar8 - *param_3) + 1;
  if (iVar6 < iVar1) {
    *param_3 = (iVar8 - iVar1) + 1;
    *param_2 = iVar1;
    return;
  }
LAB_001520d8:
  *param_2 = iVar6;
  return;
}



void FUN_00156696(int *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  func_0x0001dea8(param_1);
  if (param_1[0x25] != 0) {
    uVar1 = func_0x0001ce36(param_1);
    uVar2 = (**(code **)(*param_1 + 0x260))(param_1);
    func_0x00161776(param_1[0x25],0x44,uVar2,uVar1);
    param_1[0x25] = 0;
  }
  return;
}


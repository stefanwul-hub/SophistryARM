
void FUN_00156756(int param_1)

{
  *(undefined1 *)(param_1 + 0x91) = 0;
  *(undefined1 *)(param_1 + 0x92) = 0;
  *(undefined1 *)(param_1 + 0x84) = 0x80;
  return;
}


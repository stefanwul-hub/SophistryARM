
int FUN_0014acc6(int param_1)

{
  int iVar1;
  
  if (-1 < *(int *)(param_1 + 0x94)) {
    return *(int *)(param_1 + 0x94);
  }
  if (*(int *)(param_1 + 0x8c) != 0) {
    iVar1 = func_0x001f0b58(*(int *)(param_1 + 0x8c));
    if (iVar1 != 0) {
      return *(int *)(param_1 + 0x94);
    }
  }
  return 0;
}



void FUN_00152472(int param_1)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  uVar2 = FUN_0014acc6(*(undefined4 *)(param_1 + 0x98));
  *(undefined4 *)(param_1 + 0x9c) = uVar2;
  uVar2 = FUN_0014ad0a(*(undefined4 *)(param_1 + 0x98));
  *(undefined4 *)(param_1 + 0xa0) = uVar2;
  uVar2 = FUN_0014d374(*(undefined4 *)(param_1 + 0x98));
  *(undefined4 *)(param_1 + 0xa4) = uVar2;
  uVar2 = func_0x0014a1f4(*(undefined4 *)(param_1 + 0x98));
  *(undefined4 *)(param_1 + 0xa8) = uVar2;
  uVar2 = func_0x00149f34(*(undefined4 *)(param_1 + 0x98));
  *(undefined4 *)(param_1 + 0xb0) = uVar2;
  iVar3 = func_0x00149f34(*(undefined4 *)(param_1 + 0x98));
  if (iVar3 == 0) {
    *(undefined4 *)(param_1 + 0xb4) = *(undefined4 *)(param_1 + 0x9c);
  }
  else {
    *(undefined4 *)(param_1 + 0xb4) = *(undefined4 *)(param_1 + 0xa0);
  }
  piVar1 = *(int **)(param_1 + 0xb8);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x24c))(piVar1);
  }
  piVar1 = *(int **)(param_1 + 0xbc);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x24c))(piVar1);
  }
  piVar1 = *(int **)(param_1 + 0xc0);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x24c))(piVar1);
  }
  piVar1 = *(int **)(param_1 + 0xc4);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x24c))(piVar1);
  }
  iVar3 = func_0x0001c8ba(param_1);
  if (iVar3 < 3) {
    if (0 < iVar3) goto LAB_0015256d;
  }
  else {
    iVar3 = 2;
LAB_0015256d:
    iVar4 = 0;
    iVar5 = param_1;
    do {
      *(undefined4 *)(iVar5 + 0x100) = 0;
      *(undefined4 *)(iVar5 + 0xfc) = 0x3f800000;
      *(undefined4 *)(iVar5 + 0xf8) = 0x3f800000;
      iVar4 = iVar4 + 1;
      iVar5 = iVar5 + 0xc;
    } while (iVar3 != iVar4);
  }
  iVar3 = func_0x0001c8ba(param_1);
  if (iVar3 < 3) {
    if (iVar3 < 1) {
      iVar3 = *(int *)(param_1 + 0x9c);
      goto joined_r0x001525f4;
    }
  }
  else {
    iVar3 = 2;
  }
  iVar4 = 0;
  iVar5 = param_1;
  do {
    *(undefined4 *)(iVar5 + 0x118) = 0;
    *(undefined4 *)(iVar5 + 0x114) = 0x3f800000;
    *(undefined4 *)(iVar5 + 0x110) = 0x3f800000;
    iVar4 = iVar4 + 1;
    iVar5 = iVar5 + 0xc;
  } while (iVar3 != iVar4);
  iVar3 = *(int *)(param_1 + 0x9c);
joined_r0x001525f4:
  if (iVar3 == 0) {
    return;
  }
  iVar3 = func_0x0001c8ba(param_1);
  if (iVar3 < 3) {
    if (iVar3 < 1) {
      return;
    }
  }
  else {
    iVar3 = 2;
  }
  iVar5 = 0;
  do {
    *(undefined4 *)(param_1 + 0x118) = 0x3c23d70a;
    *(undefined4 *)(param_1 + 0x114) = 0;
    *(undefined4 *)(param_1 + 0x110) = 0x3f800000;
    iVar5 = iVar5 + 1;
    param_1 = param_1 + 0xc;
  } while (iVar3 != iVar5);
  return;
}


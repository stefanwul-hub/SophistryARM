
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00152e74(int param_1,undefined1 param_2,undefined1 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  longdouble lVar7;
  float fVar8;
  int iStack_30;
  
  iVar2 = func_0x0001c8ba(param_1);
  iVar5 = 2;
  if (iVar2 < 3) {
    iVar5 = iVar2;
  }
  piVar4 = *(int **)(param_1 + 0x80);
  if ((piVar4 == (int *)0x0) || (iVar2 = (**(code **)(*piVar4 + 0x3b8))(piVar4), iVar2 == 0))
  goto LAB_00153120;
  piVar4 = *(int **)(param_1 + 0x80);
  if (piVar4 == (int *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (**(code **)(*piVar4 + 0x3b8))(piVar4);
  }
  piVar4 = (int *)FUN_0015f296(uVar3,param_2);
  if (piVar4 == (int *)0x0) {
    return;
  }
  iVar2 = func_0x0014a466(piVar4);
  if (iVar2 == 0) {
    return;
  }
  piVar1 = *(int **)(param_1 + 0x98);
  if (piVar4 != piVar1) {
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(int **)(param_1 + 0x98) = piVar4;
    (**(code **)(*piVar4 + 0x40))(piVar4);
  }
  uVar3 = FUN_0014acc6(piVar4);
  *(undefined4 *)(param_1 + 0x9c) = uVar3;
  uVar3 = FUN_0014ad0a(piVar4);
  *(undefined4 *)(param_1 + 0xa0) = uVar3;
  uVar3 = FUN_0014d374(piVar4);
  *(undefined4 *)(param_1 + 0xa4) = uVar3;
  uVar3 = func_0x00149f34(*(undefined4 *)(param_1 + 0x98));
  *(undefined4 *)(param_1 + 0xb0) = uVar3;
  if (*(char *)(param_1 + 0x128) != '\0') {
    iVar2 = FUN_0014ac64(piVar4);
    FUN_0000ab14("voice:0x%x start note:%d start:%d stop:%d len:%d lastSample:%d",param_1,param_2,
                 *(undefined4 *)(param_1 + 0x9c),*(undefined4 *)(param_1 + 0xa0),
                 *(undefined4 *)(param_1 + 0xa4),iVar2 + -1);
  }
  uVar3 = func_0x0014a1f4(piVar4);
  *(undefined4 *)(param_1 + 0xa8) = uVar3;
  iVar2 = func_0x00149f34(piVar4);
  if (iVar2 == 0) {
    *(undefined4 *)(param_1 + 0xb4) = *(undefined4 *)(param_1 + 0x9c);
  }
  else {
    *(undefined4 *)(param_1 + 0xb4) = *(undefined4 *)(param_1 + 0xa0);
  }
  piVar4 = *(int **)(param_1 + 0xb8);
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 0x24c))(piVar4);
  }
  piVar4 = *(int **)(param_1 + 0xbc);
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 0x24c))(piVar4);
  }
  piVar4 = *(int **)(param_1 + 0xc0);
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 0x24c))(piVar4);
  }
  piVar4 = *(int **)(param_1 + 0xc4);
  if (piVar4 != (int *)0x0) {
    (**(code **)(*piVar4 + 0x24c))(piVar4);
  }
  if (0 < iVar5) {
    iStack_30 = 0;
    iVar2 = param_1;
    do {
      lVar7 = (longdouble)func_0x00149f40(*(undefined4 *)(param_1 + 0x98));
      fVar8 = (float)lVar7;
      iVar6 = func_0x0014a3b6(*(undefined4 *)(param_1 + 0x98));
      if (iStack_30 == iVar6) {
        lVar7 = (longdouble)func_0x0014a352(*(undefined4 *)(param_1 + 0x98));
        fVar8 = fVar8 * (float)lVar7;
      }
      *(float *)(iVar2 + 200) = fVar8;
      *(float *)(iVar2 + 0xcc) = fVar8;
      *(undefined4 *)(iVar2 + 0xd0) = 0;
      iStack_30 = iStack_30 + 1;
      iVar2 = iVar2 + 0xc;
    } while (iVar5 != iStack_30);
  }
  *(undefined4 *)(param_1 + 0xe0) = 0x3f800000;
  *(undefined4 *)(param_1 + 0xe4) = 0;
  lVar7 = (longdouble)func_0x00149f64(*(undefined4 *)(param_1 + 0x98));
  if (DOUBLE_00364798 < (double)(float)lVar7) {
    lVar7 = (longdouble)func_0x00149f64(*(undefined4 *)(param_1 + 0x98));
    fVar8 = 1.0 / ((float)*(int *)(param_1 + 0xa4) * (float)lVar7);
    *(float *)(param_1 + 0xe8) = fVar8;
  }
  else {
    *(undefined4 *)(param_1 + 0xe8) = 0x3f800000;
    fVar8 = *(float *)(param_1 + 0xe8);
  }
  if (FLOAT_00365ce8 <= fVar8) {
    *(float *)(param_1 + 0xe4) = FLOAT_00365ce8;
    *(undefined4 *)(param_1 + 0xe8) = 0;
  }
  *(undefined4 *)(param_1 + 0xf4) = 0;
  *(undefined4 *)(param_1 + 0xf0) = 0x3f800000;
  *(undefined4 *)(param_1 + 0xec) = 0;
  iVar5 = func_0x0001c8ba(param_1);
  if (iVar5 < 3) {
    if (0 < iVar5) goto LAB_001530a5;
  }
  else {
    iVar5 = 2;
LAB_001530a5:
    iVar6 = 0;
    iVar2 = param_1;
    do {
      *(undefined4 *)(iVar2 + 0x100) = 0;
      *(undefined4 *)(iVar2 + 0xfc) = 0x3f800000;
      *(undefined4 *)(iVar2 + 0xf8) = 0x3f800000;
      iVar6 = iVar6 + 1;
      iVar2 = iVar2 + 0xc;
    } while (iVar5 != iVar6);
  }
  iVar5 = func_0x0001c8ba(param_1);
  if (iVar5 < 3) {
    if (0 < iVar5) goto LAB_001530e7;
    iVar5 = *(int *)(param_1 + 0x9c);
  }
  else {
    iVar5 = 2;
LAB_001530e7:
    iVar6 = 0;
    iVar2 = param_1;
    do {
      *(undefined4 *)(iVar2 + 0x118) = 0;
      *(undefined4 *)(iVar2 + 0x114) = 0x3f800000;
      *(undefined4 *)(iVar2 + 0x110) = 0x3f800000;
      iVar6 = iVar6 + 1;
      iVar2 = iVar2 + 0xc;
    } while (iVar5 != iVar6);
    iVar5 = *(int *)(param_1 + 0x9c);
  }
  if (iVar5 != 0) {
    iVar5 = func_0x0001c8ba(param_1);
    if (iVar5 < 3) {
      if (iVar5 < 1) goto LAB_00153120;
    }
    else {
      iVar5 = 2;
    }
    iVar6 = 0;
    iVar2 = param_1;
    do {
      *(undefined4 *)(iVar2 + 0x118) = 0x3c23d70a;
      *(undefined4 *)(iVar2 + 0x114) = 0;
      *(undefined4 *)(iVar2 + 0x110) = 0x3f800000;
      iVar6 = iVar6 + 1;
      iVar2 = iVar2 + 0xc;
    } while (iVar5 != iVar6);
  }
LAB_00153120:
  func_0x001566f8(param_1,param_2,param_3,param_4);
  *(undefined4 *)(param_1 + 0x8c) = 0xffffffff;
  return;
}


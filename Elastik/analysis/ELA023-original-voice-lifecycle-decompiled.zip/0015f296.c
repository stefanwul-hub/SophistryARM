
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Possible PIC construction at 0x0015f2c6: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0015f2cb) */
/* WARNING: Removing unreachable block (ram,0x0015f308) */
/* WARNING: Removing unreachable block (ram,0x0015f2d8) */
/* WARNING: Removing unreachable block (ram,0x0015f2f1) */
/* WARNING: Removing unreachable block (ram,0x0015f2f4) */
/* WARNING: Removing unreachable block (ram,0x0015f2dd) */

undefined4 FUN_0015f296(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if (param_2 - 0x24U < 0x44) {
    piVar1 = *(int **)(param_1 + 0x1c);
    if (piVar1 == (int *)0x0) {
      uVar2 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                             );
      uVar3 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x15b,uVar2,"this != 0");
    }
    if (piVar1[4] < 1) {
      uVar2 = (**(code **)(*piVar1 + 0xc))(piVar1);
      uVar2 = func_0x00034962(uVar2);
      func_0x0000acae("GNList::getObjectAtIndex(): Index %i out of range of %s.",0,uVar2);
    }
    return *(undefined4 *)piVar1[3];
  }
  return 0;
}


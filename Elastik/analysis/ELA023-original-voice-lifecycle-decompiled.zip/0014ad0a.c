
int FUN_0014ad0a(int param_1)

{
  int iVar1;
  
  if (-1 < *(int *)(param_1 + 0x98)) {
    return *(int *)(param_1 + 0x98);
  }
  if (*(int *)(param_1 + 0x8c) != 0) {
    iVar1 = func_0x001f0b58(*(int *)(param_1 + 0x8c));
    if (iVar1 != 0) {
      return *(int *)(param_1 + 0x98);
    }
  }
  return 0;
}


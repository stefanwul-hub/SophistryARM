
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001521a0(int param_1,undefined1 param_2,undefined4 param_3)

{
  float fVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  longdouble lVar5;
  float fVar6;
  
  if (*(char *)(param_1 + 0x128) != '\0') {
    FUN_0000ab14("instrument:0x%x voice:0x%x stop note at sampleOffset:%d",
                 *(undefined4 *)(param_1 + 0x80),param_1,param_3);
  }
  *(undefined4 *)(param_1 + 0xf4) = 0;
  lVar5 = (longdouble)func_0x00149f70(*(undefined4 *)(param_1 + 0x98));
  if ((double)(float)lVar5 <= DOUBLE_00364798) {
    iVar2 = func_0x0001c8ba(param_1);
    if (iVar2 < 3) {
      if (iVar2 < 1) goto LAB_00156734;
    }
    else {
      iVar2 = 2;
    }
    iVar3 = 0;
    iVar4 = param_1;
    do {
      *(undefined4 *)(iVar4 + 0x100) = 0xbc23d70a;
      *(undefined4 *)(iVar4 + 0xfc) = 0x3f800000;
      *(undefined4 *)(iVar4 + 0xf8) = 0;
      iVar3 = iVar3 + 1;
      iVar4 = iVar4 + 0xc;
    } while (iVar2 != iVar3);
  }
  else {
    lVar5 = (longdouble)func_0x00149f70(*(undefined4 *)(param_1 + 0x98));
    iVar2 = FUN_0014d374(*(undefined4 *)(param_1 + 0x98));
    fVar1 = FLOAT_00365d0c;
    fVar6 = FLOAT_00365d0c / ((float)iVar2 * (float)lVar5);
    *(float *)(param_1 + 0xf4) = fVar6;
    if (fVar6 <= fVar1) {
      *(undefined4 *)(param_1 + 0xf4) = 0;
    }
  }
LAB_00156734:
  *(undefined1 *)(param_1 + 0x90) = param_2;
  *(undefined4 *)(param_1 + 0x8c) = param_3;
  *(undefined1 *)(param_1 + 0x91) = 1;
  return;
}


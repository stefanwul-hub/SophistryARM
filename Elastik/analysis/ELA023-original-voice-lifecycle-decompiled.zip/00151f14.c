
void FUN_00151f14(int param_1)

{
  int *piVar1;
  char cVar2;
  
  FUN_00156696(param_1);
  piVar1 = *(int **)(param_1 + 0xb8);
  if (piVar1 != (int *)0x0) {
    cVar2 = (**(code **)(*piVar1 + 0x250))(piVar1);
    if (cVar2 != '\0') {
      (**(code **)(**(int **)(param_1 + 0xb8) + 0x240))(*(int **)(param_1 + 0xb8));
    }
  }
  piVar1 = *(int **)(param_1 + 0xbc);
  if (piVar1 != (int *)0x0) {
    cVar2 = (**(code **)(*piVar1 + 0x250))(piVar1);
    if (cVar2 != '\0') {
      (**(code **)(**(int **)(param_1 + 0xbc) + 0x240))(*(int **)(param_1 + 0xbc));
    }
  }
  piVar1 = *(int **)(param_1 + 0xc0);
  if (piVar1 != (int *)0x0) {
    cVar2 = (**(code **)(*piVar1 + 0x250))(piVar1);
    if (cVar2 != '\0') {
      (**(code **)(**(int **)(param_1 + 0xc0) + 0x240))(*(int **)(param_1 + 0xc0));
    }
  }
  piVar1 = *(int **)(param_1 + 0xc4);
  if (piVar1 != (int *)0x0) {
    cVar2 = (**(code **)(*piVar1 + 0x250))(piVar1);
    if (cVar2 != '\0') {
      (**(code **)(**(int **)(param_1 + 0xc4) + 0x240))(*(int **)(param_1 + 0xc4));
    }
  }
  piVar1 = *(int **)(param_1 + 0xb8);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x44))(piVar1);
    *(undefined4 *)(param_1 + 0xb8) = 0;
  }
  piVar1 = *(int **)(param_1 + 0xbc);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x44))(piVar1);
    *(undefined4 *)(param_1 + 0xbc) = 0;
  }
  piVar1 = *(int **)(param_1 + 0xc0);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x44))(piVar1);
    *(undefined4 *)(param_1 + 0xc0) = 0;
  }
  piVar1 = *(int **)(param_1 + 0xc4);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x44))(piVar1);
    *(undefined4 *)(param_1 + 0xc4) = 0;
  }
  return;
}


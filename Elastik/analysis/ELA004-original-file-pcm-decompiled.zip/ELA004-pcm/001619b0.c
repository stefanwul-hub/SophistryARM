
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001619b0(float *param_1,uint param_2,int param_3,int param_4,undefined1 *param_5,
                 uint param_6,int param_7,int param_8,int param_9)

{
  uint3 uVar1;
  bool bVar2;
  bool bVar3;
  byte bVar4;
  uint uVar5;
  byte *pbVar6;
  byte *pbVar7;
  undefined2 *puVar8;
  float *pfVar9;
  float *pfVar10;
  short *psVar11;
  undefined1 uVar12;
  int iVar15;
  int iVar16;
  float fVar17;
  undefined1 in_XMM0 [16];
  float *pfStack_80;
  byte *pbStack_7c;
  undefined2 *puStack_78;
  float *pfStack_74;
  float *pfStack_70;
  float *pfStack_6c;
  float *pfStack_68;
  undefined1 *puStack_64;
  int iStack_58;
  int iStack_54;
  float *pfStack_34;
  float *pfStack_30;
  int iStack_20;
  undefined1 uVar13;
  undefined1 uVar14;
  
  fVar17 = FLOAT_00365df4;
  uVar5 = param_2 - 0x10;
  if (0x10 < uVar5) {
    uVar5 = param_2;
  }
  if ((int)uVar5 < 3) {
    iVar16 = uVar5 + 2;
    goto LAB_001619e4;
  }
  if (uVar5 == 3) goto LAB_00161bed;
  if (uVar5 == 4) {
    iVar16 = 8;
    goto LAB_001619e4;
  }
  if ((int)uVar5 < 0x40) {
LAB_00161bed:
    iVar16 = 4;
  }
  else {
    switch(uVar5) {
    case 0x40:
      iVar16 = 2;
      break;
    case 0x41:
      iVar16 = 3;
      break;
    case 0x42:
    case 0x44:
      goto LAB_00161bed;
    case 0x43:
    case 0x45:
      iVar16 = 1;
      break;
    default:
      iVar16 = 0;
    }
  }
LAB_001619e4:
  uVar5 = param_6 - 0x10;
  if (0x10 < uVar5) {
    uVar5 = param_6;
  }
  if ((int)uVar5 < 3) {
    iVar15 = uVar5 + 2;
    goto LAB_001619fc;
  }
  if (uVar5 == 3) goto LAB_00161bf7;
  if (uVar5 == 4) {
    iVar15 = 8;
    goto LAB_001619fc;
  }
  if ((int)uVar5 < 0x40) {
LAB_00161bf7:
    iVar15 = 4;
  }
  else {
    switch(uVar5) {
    case 0x40:
      iVar15 = 2;
      break;
    case 0x41:
      iVar15 = 3;
      break;
    case 0x42:
    case 0x44:
      goto LAB_00161bf7;
    case 0x43:
    case 0x45:
      iVar15 = 1;
      break;
    default:
      iVar15 = 0;
    }
  }
LAB_001619fc:
  if (((int)param_2 < 0x40) && ((int)param_2 < 0x10)) {
    bVar3 = true;
  }
  else {
    bVar3 = false;
  }
  if (((int)param_6 < 0x40) && ((int)param_6 < 0x10)) {
    bVar2 = true;
  }
  else {
    bVar2 = false;
  }
  if (((param_6 == 0x44) && (param_2 == 0)) && (!bVar3)) {
    psVar11 = (short *)((int)param_1 + param_4 * 2);
    pfVar9 = (float *)(param_5 + param_8 * 4);
    if (param_9 == 0) {
      return;
    }
    iVar16 = 0;
    do {
      *pfVar9 = (float)(int)*psVar11 * fVar17;
      pfVar9 = pfVar9 + param_7;
      psVar11 = psVar11 + param_3;
      iVar16 = iVar16 + 1;
    } while (param_9 != iVar16);
    return;
  }
  if (iVar16 == 2) {
    pfStack_30 = param_1;
    pfStack_80 = (float *)0x0;
    pfStack_74 = (float *)0x0;
    pfStack_6c = (float *)0x0;
    pfStack_68 = (float *)0x0;
    iStack_58 = 2;
  }
  else if (iVar16 < 3) {
    if (iVar16 != 1) {
LAB_00161a49:
      FUN_0000ab14("GNAudioConvertSampleFormat(): Unsupported input format.");
      return;
    }
    pfStack_80 = param_1;
    if (param_2 == 0x43) {
      pfStack_30 = (float *)0x0;
      pfStack_74 = (float *)0x0;
      pfStack_6c = (float *)0x0;
      pfStack_68 = (float *)0x0;
      iStack_58 = 1;
    }
    else {
      pfStack_30 = (float *)0x0;
      pfStack_74 = (float *)0x0;
      pfStack_6c = (float *)0x0;
      pfStack_68 = (float *)0x0;
      iStack_58 = 6;
    }
  }
  else if (iVar16 == 3) {
    pfStack_68 = param_1;
    pfStack_80 = (float *)0x0;
    pfStack_74 = (float *)0x0;
    pfStack_6c = (float *)0x0;
    iStack_58 = 3;
    pfStack_30 = pfStack_68;
  }
  else {
    if (iVar16 != 4) goto LAB_00161a49;
    if (((param_2 == 0x13) || (param_2 == 0x44)) || (param_2 == 3)) {
      pfStack_6c = param_1;
      pfStack_80 = (float *)0x0;
      pfStack_30 = (float *)0x0;
      pfStack_74 = (float *)0x0;
      pfStack_68 = (float *)0x0;
      iStack_58 = 5;
    }
    else {
      pfStack_74 = param_1;
      pfStack_80 = (float *)0x0;
      pfStack_30 = (float *)0x0;
      pfStack_6c = (float *)0x0;
      pfStack_68 = (float *)0x0;
      iStack_58 = 4;
    }
  }
  if (iVar15 == 2) {
    puStack_78 = (undefined2 *)param_5;
    pbStack_7c = (undefined1 *)0x0;
    pfStack_70 = (float *)0x0;
    pfStack_34 = (float *)0x0;
    puStack_64 = (undefined1 *)0x0;
    iStack_54 = 2;
  }
  else if (iVar15 < 3) {
    if (iVar15 != 1) {
LAB_00161c8e:
      FUN_0000ab14("GNAudioConvertSampleFormat(): Unsupported output format.");
      return;
    }
    pbStack_7c = param_5;
    if (param_6 == 0x43) {
      puStack_78 = (undefined2 *)0x0;
      pfStack_70 = (float *)0x0;
      pfStack_34 = (float *)0x0;
      puStack_64 = (undefined1 *)0x0;
      iStack_54 = 1;
    }
    else {
      puStack_78 = (undefined2 *)0x0;
      pfStack_70 = (float *)0x0;
      pfStack_34 = (float *)0x0;
      puStack_64 = (undefined1 *)0x0;
      iStack_54 = 6;
    }
  }
  else if (iVar15 == 3) {
    puStack_64 = param_5;
    pbStack_7c = (undefined1 *)0x0;
    puStack_78 = (undefined2 *)0x0;
    pfStack_70 = (float *)0x0;
    pfStack_34 = (float *)0x0;
    iStack_54 = 3;
  }
  else {
    if (iVar15 != 4) goto LAB_00161c8e;
    if (((param_6 == 0x13) || (param_6 == 0x44)) || (param_6 == 3)) {
      pfStack_34 = (float *)param_5;
      pbStack_7c = (undefined1 *)0x0;
      puStack_78 = (undefined2 *)0x0;
      pfStack_70 = (float *)0x0;
      puStack_64 = (undefined1 *)0x0;
      iStack_54 = 5;
    }
    else {
      pfStack_70 = (float *)param_5;
      pbStack_7c = (undefined1 *)0x0;
      puStack_78 = (undefined2 *)0x0;
      pfStack_34 = (float *)0x0;
      puStack_64 = (undefined1 *)0x0;
      iStack_54 = 4;
    }
  }
  pbVar6 = (byte *)((int)pfStack_80 + param_4);
  if (pfStack_80 == (float *)0x0) {
    pbVar6 = (byte *)0x0;
  }
  if (pfStack_30 != (float *)0x0) {
    pfStack_30 = (float *)((int)pfStack_30 + param_4 * 2);
  }
  if (pfStack_74 != (float *)0x0) {
    pfStack_74 = pfStack_74 + param_4;
  }
  if (pfStack_6c != (float *)0x0) {
    pfStack_6c = pfStack_6c + param_4;
  }
  if (pfStack_68 != (float *)0x0) {
    pfStack_68 = (float *)((int)pfStack_68 + iVar16 * param_4);
  }
  pbVar7 = pbStack_7c + param_8;
  if (pbStack_7c == (undefined1 *)0x0) {
    pbVar7 = (byte *)0x0;
  }
  puVar8 = (undefined2 *)((int)puStack_78 + param_8 * 2);
  if (puStack_78 == (undefined2 *)0x0) {
    puVar8 = (undefined2 *)0x0;
  }
  pfVar9 = (float *)((int)pfStack_70 + param_8 * 4);
  if (pfStack_70 == (float *)0x0) {
    pfVar9 = (float *)0x0;
  }
  pfVar10 = (float *)((int)pfStack_34 + param_8 * 4);
  if (pfStack_34 == (float *)0x0) {
    pfVar10 = (float *)0x0;
  }
  if (puStack_64 != (undefined1 *)0x0) {
    puStack_64 = puStack_64 + iVar15 * param_8;
  }
  if (bVar3) {
    if (iStack_58 == 4) {
      if (0 < param_9) {
        iVar16 = 0;
        do {
          func_0x0000a838(pfStack_74);
          pfStack_74 = pfStack_74 + param_3;
          iVar16 = iVar16 + 1;
        } while (param_9 != iVar16);
      }
      pfStack_74 = param_1 + param_4;
    }
    else if (iStack_58 == 5) {
      if (0 < param_9) {
        iVar16 = 0;
        do {
          func_0x0000a85e(pfStack_6c);
          pfStack_6c = pfStack_6c + param_3;
          iVar16 = iVar16 + 1;
        } while (param_9 != iVar16);
      }
      pfStack_6c = param_1 + param_4;
    }
    else if (iStack_58 == 2) {
      if (0 < param_9) {
        iVar16 = 0;
        do {
          func_0x0000a824(pfStack_30);
          pfStack_30 = (float *)((int)pfStack_30 + param_3 * 2);
          iVar16 = iVar16 + 1;
        } while (param_9 != iVar16);
      }
      pfStack_30 = (float *)((int)param_1 + param_4 * 2);
    }
  }
  pfStack_80 = (float *)pbVar6;
  pbStack_7c = pbVar7;
  puStack_78 = puVar8;
  pfStack_70 = pfVar9;
  pfStack_34 = pfVar10;
  if (param_2 == param_6) {
    if (0 < param_9) {
      iVar16 = 0;
      do {
        switch(iStack_58) {
        case 1:
        case 6:
          *pbStack_7c = *(byte *)pfStack_80;
          pfStack_80 = (float *)((int)pfStack_80 + param_3);
          pbStack_7c = pbStack_7c + param_7;
          break;
        case 2:
          *puStack_78 = *(undefined2 *)pfStack_30;
          pfStack_30 = (float *)((int)pfStack_30 + param_3 * 2);
          puStack_78 = puStack_78 + param_7;
          break;
        case 3:
          *puStack_64 = *(undefined1 *)pfStack_68;
          puStack_64[1] = *(undefined1 *)((int)pfStack_68 + 1);
          puStack_64[2] = *(undefined1 *)((int)pfStack_68 + 2);
          pfStack_68 = (float *)((int)pfStack_68 + param_3 * 3);
          puStack_64 = puStack_64 + param_7 * 3;
          break;
        case 4:
          *pfStack_70 = *pfStack_74;
          pfStack_74 = pfStack_74 + param_3;
          pfStack_70 = pfStack_70 + param_7;
          break;
        case 5:
          *pfStack_34 = *pfStack_6c;
          pfStack_6c = pfStack_6c + param_3;
          pfStack_34 = pfStack_34 + param_7;
        }
        iVar16 = iVar16 + 1;
      } while (param_9 != iVar16);
    }
  }
  else if (0 < param_9) {
    iVar16 = 0;
    do {
      switch(iStack_58) {
      default:
        in_XMM0 = (undefined1  [16])0x0;
        break;
      case 1:
        in_XMM0._0_4_ = (float)(int)(char)*(byte *)pfStack_80 * FLOAT_00365df8;
        pfStack_80 = (float *)((int)pfStack_80 + param_3);
        break;
      case 2:
        in_XMM0._0_4_ = (float)(int)*(short *)pfStack_30 * FLOAT_00365df4;
        pfStack_30 = (float *)((int)pfStack_30 + param_3 * 2);
        break;
      case 3:
        if (bVar3) {
          uVar1 = CONCAT21(CONCAT11(*(undefined1 *)pfStack_68,*(undefined1 *)((int)pfStack_68 + 1)),
                           *(undefined1 *)((int)pfStack_68 + 2));
        }
        else {
          uVar1 = *(uint3 *)pfStack_68;
        }
        iStack_20 = (uint)uVar1 << 8;
        in_XMM0._0_4_ = (float)iStack_20 * FLOAT_00365cf8;
        pfStack_68 = (float *)((int)pfStack_68 + param_3 * 3);
        break;
      case 4:
        in_XMM0._0_4_ = (float)(int)*pfStack_74 * FLOAT_00365cf8;
        pfStack_74 = pfStack_74 + param_3;
        break;
      case 5:
        in_XMM0 = ZEXT416((uint)*pfStack_6c);
        pfStack_6c = pfStack_6c + param_3;
        break;
      case 6:
        in_XMM0._0_4_ =
             ((float)*(byte *)pfStack_80 + (float)*(byte *)pfStack_80) / FLOAT_00365dfc -
             FLOAT_00365ce8;
        pfStack_80 = (float *)((int)pfStack_80 + param_3);
      }
      fVar17 = in_XMM0._0_4_;
      switch(iStack_54) {
      case 1:
        in_XMM0._0_8_ = (double)fVar17 * DOUBLE_00364880;
        bVar4 = (byte)(int)in_XMM0._0_8_;
        goto code_r0x00161f06;
      case 2:
        in_XMM0._0_8_ = (double)fVar17 * DOUBLE_00364888;
        *puStack_78 = (short)(int)in_XMM0._0_8_;
        puStack_78 = puStack_78 + param_7;
        break;
      case 3:
        in_XMM0._0_8_ = (double)fVar17 * DOUBLE_00364890;
        iVar15 = (int)in_XMM0._0_8_;
        uVar12 = (undefined1)((uint)iVar15 >> 8);
        uVar13 = (undefined1)((uint)iVar15 >> 0x10);
        uVar14 = (undefined1)((uint)iVar15 >> 0x18);
        if (bVar2) {
          *puStack_64 = uVar14;
          puStack_64[1] = uVar13;
          puStack_64[2] = uVar12;
        }
        else {
          *puStack_64 = uVar12;
          puStack_64[1] = uVar13;
          puStack_64[2] = uVar14;
        }
        puStack_64 = puStack_64 + param_7 * 3;
        break;
      case 4:
        in_XMM0._0_8_ = (double)fVar17 * DOUBLE_00364890;
        *pfStack_70 = (float)(int)in_XMM0._0_8_;
        pfStack_70 = pfStack_70 + param_7;
        break;
      case 5:
        *pfStack_34 = fVar17;
        pfStack_34 = pfStack_34 + param_7;
        break;
      case 6:
        in_XMM0._0_4_ = (fVar17 + FLOAT_00365ce8) * FLOAT_00365dfc * FLOAT_00365cd0;
        bVar4 = (byte)(int)in_XMM0._0_4_;
code_r0x00161f06:
        *pbStack_7c = bVar4;
        pbStack_7c = pbStack_7c + param_7;
        goto joined_r0x00161f19;
      }
joined_r0x00161f19:
      iVar16 = iVar16 + 1;
    } while (param_9 != iVar16);
  }
  if (bVar2) {
    if (iStack_54 == 4) {
      param_5 = param_5 + param_8 * 4;
      if (0 < param_9) {
        iVar16 = 0;
        do {
          func_0x0000a838(param_5);
          param_5 = param_5 + param_7 * 4;
          iVar16 = iVar16 + 1;
        } while (param_9 != iVar16);
      }
    }
    else if (iStack_54 == 5) {
      param_5 = param_5 + param_8 * 4;
      if (0 < param_9) {
        iVar16 = 0;
        do {
          func_0x0000a85e(param_5);
          param_5 = param_5 + param_7 * 4;
          iVar16 = iVar16 + 1;
        } while (param_9 != iVar16);
      }
    }
    else if ((iStack_54 == 2) && (param_5 = param_5 + param_8 * 2, 0 < param_9)) {
      iVar16 = 0;
      do {
        func_0x0000a824(param_5);
        param_5 = param_5 + param_7 * 2;
        iVar16 = iVar16 + 1;
      } while (param_9 != iVar16);
    }
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.cx replaced with injection: get_pc_thunk_cx */

int FUN_00161584(uint param_1)

{
  if (param_1 - 0x10 < 0x11) {
    param_1 = param_1 - 0x10;
  }
  if ((int)param_1 < 3) {
    return param_1 + 2;
  }
  if (param_1 != 3) {
    if (param_1 == 4) {
      return 8;
    }
    if (0x3f < (int)param_1) {
      switch(param_1) {
      case 0x40:
        return 2;
      case 0x41:
        return 3;
      case 0x42:
      case 0x44:
        break;
      case 0x43:
      case 0x45:
        return 1;
      default:
        return 0;
      }
    }
  }
  return 4;
}


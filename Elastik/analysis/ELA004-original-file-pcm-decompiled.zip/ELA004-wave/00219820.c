
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00219820(int param_1,int param_2,int param_3,int param_4,undefined4 param_5,uint param_6,
                 int param_7,int *param_8)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  int iStack_3c;
  int iStack_34;
  int aiStack_20 [4];
  
  if (param_1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNSoundFileReader.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xa8,uVar4,"this != 0");
  }
  if (*(int *)(param_1 + 0x10) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNSoundFileReader.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xa8,uVar4,"_readBuffer");
  }
  iVar2 = func_0x00161584(param_5);
  if ((param_6 & 0x100) != 0) {
    param_6 = param_6 & 0xff;
  }
  if (0 < param_4) {
    iStack_34 = param_3;
    do {
      iVar6 = iVar2 * param_4 * param_6;
      iStack_3c = *(int *)(param_1 + 0xc);
      if (iVar6 - iStack_3c == 0 || iVar6 < iStack_3c) {
        iStack_3c = param_4;
        aiStack_20[0] = iVar6;
      }
      else {
        iStack_3c = iStack_3c / (int)(iVar2 * param_6);
        aiStack_20[0] = iStack_3c * param_6 * iVar2;
      }
      iVar3 = iStack_34 * iVar2 * param_6 + param_7;
      (**(code **)(*param_8 + 0x1c0))(param_8,iVar3);
      cVar1 = (**(code **)(*param_8 + 0x1ac))(param_8,*(undefined4 *)(param_1 + 0x10),aiStack_20);
      if (cVar1 == '\0') {
        FUN_0000ab14("Reading sound failed: We wanted to read %i bytes at %i, but only %i bytes have been read."
                     ,iVar6,iVar3,aiStack_20[0]);
      }
      if (0 < (int)param_6) {
        uVar7 = 0;
        do {
          iVar6 = *(int *)(param_2 + uVar7 * 4);
          if (iVar6 != 0) {
            func_0x001619b0(*(undefined4 *)(param_1 + 0x10),param_5,param_6,uVar7,
                            iVar6 + (iStack_34 - param_3) * 4,0x44,1,0,iStack_3c);
          }
          uVar7 = uVar7 + 1;
        } while (param_6 != uVar7);
      }
      param_4 = param_4 - iStack_3c;
      iStack_34 = iStack_34 + iStack_3c;
    } while (0 < param_4);
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_00289de8(int param_1,undefined4 param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined1 auStack_6c [92];
  
  if (param_1 == 2) {
    puVar3 = (undefined4 *)__Znwm(0x28);
    func_0x0002dc66(puVar3);
    *puVar3 = &UNK_003b3988;
    func_0x0028983c();
    puVar3[3] = 0;
    puVar3[4] = 0;
    puVar3[5] = 0;
    puVar3[6] = 0;
    puVar3[7] = 0;
    puVar3[8] = 0;
    puVar3[9] = 0;
    *puVar3 = &UNK_003b4248;
  }
  else {
    if (param_1 != 3) {
      return (int *)0x0;
    }
    puVar3 = (undefined4 *)__Znwm(0x28);
    func_0x0028971c(puVar3);
  }
  piVar1 = (int *)FUN_0002dfa6(puVar3);
  piVar1 = (int *)(**(code **)(*piVar1 + 0x48))(piVar1);
  FUN_0000bea2(auStack_6c);
  iVar2 = _setjmp(auStack_6c);
  if (iVar2 != 0) {
    return (int *)0x0;
  }
  (**(code **)(*piVar1 + 0x1a8))(piVar1,param_2);
  FUN_0000bec0(auStack_6c);
  return piVar1;
}


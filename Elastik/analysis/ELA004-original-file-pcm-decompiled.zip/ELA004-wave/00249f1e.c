
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00249f1e(int *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  
  FUN_00219a4c(param_1,param_2);
  if (param_1[8] != 0) {
    uVar1 = FUN_00033b90("Melodyne1WaveSampleCount");
    iVar2 = (**(code **)(*param_1 + 0x1bc))(param_1);
    uVar3 = FUN_000858da(iVar2 - param_1[0xc] / ((int)*(short *)((int)param_1 + 0x1a) * param_1[8]))
    ;
    FUN_00066284(param_2,uVar3,uVar1);
  }
  return;
}


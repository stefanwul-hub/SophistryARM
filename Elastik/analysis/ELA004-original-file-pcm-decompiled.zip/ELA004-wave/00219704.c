
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00219704(undefined4 param_1,undefined4 param_2,char *param_3,char *param_4)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  
  uVar5 = FUN_00033b90("GNNotImplementedException");
  param_4 = "/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNSoundFileReader.cpp";
  param_3 = "getSamplesForRange";
  uVar1 = __Znwm(0x20);
  func_0x000332e2(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  uVar1 = (**(code **)(*piVar2 + 0x48))(piVar2);
  uVar3 = func_0x00039354("Function %s not implemented yet in %s.");
  func_0x0003d480(uVar1,uVar3,&param_3);
  func_0x00034b8e(uVar1);
  puVar4 = (undefined4 *)__Znwm(0x18);
  func_0x0002dc66(puVar4);
  *puVar4 = &UNK_0036ce88;
  puVar4[3] = 0;
  puVar4[4] = 0;
  puVar4[5] = 0;
  piVar2 = (int *)FUN_0002dfa6(puVar4);
  piVar2 = (int *)(**(code **)(*piVar2 + 0x48))(piVar2);
  (**(code **)(*piVar2 + 0x1a4))(piVar2,uVar5,uVar1,0);
  (**(code **)(*piVar2 + 0x1a8))(piVar2);
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00219a4c(int *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  
  if ((param_2 != 0) && (iVar2 = (**(code **)(*param_1 + 0x1c0))(param_1), iVar2 != 0)) {
    if (iRam003d9084 == 0) {
      uVar3 = FUN_00033b90("privateChunks");
      uVar4 = FUN_00033b90("chunks");
      iRam003d9084 = FUN_0002c732(uVar4,uVar3,0);
    }
    iVar5 = 0;
    iVar2 = FUN_00029ddc(iRam003d9084);
    if (0 < iVar2) {
      do {
        uVar3 = FUN_0002a364(iRam003d9084,iVar5);
        uVar4 = (**(code **)(*param_1 + 0x1c0))(param_1);
        cVar1 = FUN_00064024(uVar4,uVar3);
        if (cVar1 != '\0') {
          uVar4 = (**(code **)(*param_1 + 0x1c0))(param_1);
          uVar4 = FUN_00064626(uVar4,uVar3);
          FUN_00066284(param_2,uVar4,uVar3);
        }
        iVar5 = iVar5 + 1;
        iVar2 = FUN_00029ddc(iRam003d9084);
      } while (iVar5 < iVar2);
    }
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001c4440(undefined4 *param_1)

{
  undefined4 uVar1;
  
  func_0x0001bfca(param_1);
  *param_1 = &UNK_00394b68;
  if (iRam003d8b44 == 0) {
    uVar1 = __Znwm(0x38);
    func_0x0006f04a(uVar1);
    iRam003d8b44 = FUN_0002dfa6(uVar1);
  }
  param_1[0x20] = 0;
  param_1[0x26] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001c47a8(int param_1,undefined4 param_2,int param_3,int param_4)

{
  double dVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  float *pfVar5;
  float fVar6;
  
  if ((*(float *)(param_1 + 0x94) == 0.0) && (!NAN(*(float *)(param_1 + 0x94)))) {
    iVar3 = func_0x001ab7c0(param_2);
    if (param_4 + -100 < iVar3 + param_3) {
      *(undefined4 *)(param_1 + 0x94) = 0x3f800000;
      iVar3 = func_0x001ab7c0(param_2);
      iVar3 = (param_4 - iVar3) + -99;
      goto LAB_001c47db;
    }
  }
  iVar3 = 0;
LAB_001c47db:
  if ((0.0 < *(float *)(param_1 + 0x94)) && (iVar3 < param_3)) {
    pfVar5 = (float *)(iVar3 * 4 + *(int *)(param_1 + 0x8c));
    *pfVar5 = *(float *)(param_1 + 0x94) * *pfVar5;
    pfVar5 = (float *)(iVar3 * 4 + *(int *)(param_1 + 0x90));
    *pfVar5 = *pfVar5 * *(float *)(param_1 + 0x94);
    dVar1 = DOUBLE_003648a0;
    fVar6 = (float)((double)*(float *)(param_1 + 0x94) - DOUBLE_003648a0);
    *(float *)(param_1 + 0x94) = fVar6;
    iVar3 = iVar3 + 1;
    if (0.0 < fVar6) {
      iVar4 = iVar3 * 4;
      do {
        if (param_3 <= iVar3) break;
        pfVar5 = (float *)(iVar4 + *(int *)(param_1 + 0x8c));
        *pfVar5 = fVar6 * *pfVar5;
        pfVar5 = (float *)(iVar4 + *(int *)(param_1 + 0x90));
        *pfVar5 = *(float *)(param_1 + 0x94) * *pfVar5;
        fVar6 = (float)((double)*(float *)(param_1 + 0x94) - dVar1);
        *(float *)(param_1 + 0x94) = fVar6;
        iVar3 = iVar3 + 1;
        iVar4 = iVar4 + 4;
      } while (0.0 < fVar6);
    }
  }
  piVar2 = (int *)func_0x00067f76();
  (**(code **)(*piVar2 + 0x1a4))(piVar2);
  func_0x001ad60a(param_2,param_1 + 0x8c,param_3);
  piVar2 = (int *)func_0x00067f76();
                    /* WARNING: Could not recover jumptable at 0x001c48f0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*piVar2 + 0x1ac))();
  return;
}


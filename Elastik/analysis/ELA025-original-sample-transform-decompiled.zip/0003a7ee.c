
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0003a7ee(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  char *pcVar8;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x30d,uVar3,"this != 0");
  }
  if (iRam003d4190 == 0) {
    iRam003d4190 = func_0x00039216("");
  }
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x10f,uVar3,"this != 0");
  }
  if (*(int *)(param_1 + 0x14) == -1) {
    if (*(char **)(param_1 + 0xc) == (char *)0x0) {
      return iRam003d4190;
    }
    uVar5 = 0xffffffff;
    pcVar8 = *(char **)(param_1 + 0xc);
    do {
      if (uVar5 == 0) break;
      uVar5 = uVar5 - 1;
      cVar1 = *pcVar8;
      pcVar8 = pcVar8 + 1;
    } while (cVar1 != '\0');
    iVar2 = ~uVar5 - 3;
  }
  else {
    iVar2 = *(int *)(param_1 + 0x14) + -2;
  }
  if (0 < iVar2) {
    iVar7 = 0;
    do {
      iVar6 = iVar2 - iVar7;
      cVar1 = FUN_00034a88(param_1,iVar6);
      if (cVar1 == '.') {
        iVar2 = *(int *)(param_1 + 0x14);
        if (iVar2 != -1) goto LAB_0003a899;
        if (*(char **)(param_1 + 0xc) == (char *)0x0) {
          iVar2 = 0;
          goto LAB_0003a899;
        }
        uVar5 = 0xffffffff;
        pcVar8 = *(char **)(param_1 + 0xc);
        goto code_r0x0003a987;
      }
    } while ((cVar1 != '/') && (iVar7 = iVar7 + 1, iVar2 != iVar7));
  }
  return iRam003d4190;
  while( true ) {
    uVar5 = uVar5 - 1;
    cVar1 = *pcVar8;
    pcVar8 = pcVar8 + 1;
    if (cVar1 == '\0') break;
code_r0x0003a987:
    if (uVar5 == 0) break;
  }
  iVar2 = ~uVar5 - 1;
LAB_0003a899:
  iVar2 = FUN_0003a042(param_1,iVar6 + 1,(iVar2 - iVar6) + -1);
  return iVar2;
}


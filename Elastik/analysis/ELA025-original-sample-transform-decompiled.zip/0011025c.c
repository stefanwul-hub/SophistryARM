
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0011025c(undefined4 *param_1)

{
  func_0x000acbb0(param_1);
  *param_1 = &UNK_00383968;
  param_1[3] = 0;
  param_1[4] = 0xff7fffff;
  param_1[5] = 0x7f7fffff;
  param_1[6] = 0;
  *(undefined1 *)(param_1 + 7) = 0;
  *(undefined1 *)((int)param_1 + 0x1d) = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  return;
}


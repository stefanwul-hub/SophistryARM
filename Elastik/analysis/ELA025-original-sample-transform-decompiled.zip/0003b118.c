
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Removing unreachable block (ram,0x0003b25a) */

void FUN_0003b118(int param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  char *pcVar6;
  char *pcVar7;
  int iStack_20;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x94f,uVar2,"this != 0");
  }
  if (param_2 != 0) {
    if (*(int *)(param_1 + 0x14) == -1) {
      iVar5 = *(int *)(param_2 + 0x14);
      if (iVar5 == -1) {
        pcVar7 = *(char **)(param_2 + 0xc);
        if (pcVar7 == (char *)0x0) {
          iStack_20 = 0;
        }
        else {
          uVar4 = 0xffffffff;
          pcVar6 = pcVar7;
          do {
            if (uVar4 == 0) break;
            uVar4 = uVar4 - 1;
            cVar1 = *pcVar6;
            pcVar6 = pcVar6 + 1;
          } while (cVar1 != '\0');
          iStack_20 = ~uVar4 - 1;
        }
        if (pcVar7 == (char *)0x0) {
          pcVar7 = "";
        }
        func_0x000384d4(param_1,pcVar7,iStack_20,0);
        return;
      }
    }
    else {
      iVar5 = *(int *)(param_2 + 0x14);
    }
    if (iVar5 == -1) {
      if (*(char **)(param_2 + 0xc) == (char *)0x0) {
        iVar5 = 0;
      }
      else {
        uVar4 = 0xffffffff;
        pcVar7 = *(char **)(param_2 + 0xc);
        do {
          if (uVar4 == 0) break;
          uVar4 = uVar4 - 1;
          cVar1 = *pcVar7;
          pcVar7 = pcVar7 + 1;
        } while (cVar1 != '\0');
        iVar5 = ~uVar4 - 1;
      }
    }
    uVar2 = FUN_00036896(param_2);
    FUN_0003788a(param_1,uVar2,iVar5);
  }
  return;
}


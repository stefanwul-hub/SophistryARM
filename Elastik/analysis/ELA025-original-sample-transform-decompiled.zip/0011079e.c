
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0011079e(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNNumberFormatter.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x74,uVar1,"this != 0");
  }
  if (-1 < param_2) {
    *(int *)(param_1 + 0xc) = param_2;
    return;
  }
  uVar1 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNNumberFormatter.cpp"
                         );
  uVar2 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x74,uVar1,"value >= 0");
  *(int *)(param_1 + 0xc) = param_2;
  return;
}


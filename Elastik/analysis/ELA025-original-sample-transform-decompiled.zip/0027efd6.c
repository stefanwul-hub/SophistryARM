
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0027efd6(undefined4 *param_1,undefined4 param_2,undefined4 param_3,float param_4,
                 int param_5)

{
  undefined *puVar1;
  undefined *puVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  longdouble lVar6;
  int iStack_30;
  undefined4 auStack_20 [4];
  
  *param_1 = &UNK_003b3908;
  auStack_20[0] = 0x3dcccccd;
  param_1[1] = param_4;
  param_1[7] = param_3;
  param_1[8] = param_2;
  param_1[2] = 0x44fa0000;
  param_1[3] = 0x3f800000;
  param_1[4] = 0x3f800000;
  param_1[0xe] = 0;
  param_1[0xd] = 0;
  param_1[0xf] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x14] = 0;
  if (FLOAT_00365ef4 <= param_4) {
    if (param_4 < FLOAT_00365ef8) {
      param_1[10] = 0x1000;
    }
    else {
      param_1[10] = (-(uint)(param_4 < FLOAT_00365efc) & 0xffffe000) + 0x4000;
    }
  }
  else {
    param_1[10] = 0x800;
  }
  param_1[0x10] = (int)param_1[10] >> 7;
  FUN_0027f65a(param_1 + 0xa9,(int)param_1[10] >> 7,param_1[7],param_1[1],-(param_5 == 0) & 2);
  (**(code **)(*(int *)param_1[0xa9] + 0x14))((int *)param_1[0xa9],auStack_20,0x3f800000);
  func_0x0028c30e(param_1 + 0xaa);
  (**(code **)(*(int *)param_1[0xaa] + 0x10))((int *)param_1[0xaa],0x800);
  func_0x0028c3d4(param_1 + 0xab,param_1[0xaa],param_1[1],0xffffffff,param_1[7],0,1);
  func_0x0028c366(param_1 + 0xac,param_1[0xaa],param_1[0x10],param_1[7]);
  if (param_5 == 1) {
    iVar3 = param_1[10];
    param_1[0x11] = iVar3 >> 5;
  }
  else {
    iVar3 = param_1[10];
    param_1[0x11] = iVar3 >> 3;
  }
  param_1[5] = (float)(int)-param_1[0x11];
  func_0x0028ec92(param_1 + 0xae,(int)(float)param_1[1],param_1[7],param_1[2],iVar3);
  iVar3 = func_0x0028c2fe();
  if ((iVar3 == 2) || (iVar3 = func_0x0028c2fe(), iVar3 == 3)) {
    uVar4 = 1;
  }
  else {
    uVar4 = 0;
  }
  func_0x0028c090(param_1 + 0xad,6,param_1[8] << 4,0x30,0,uVar4);
  param_1[0x12] = 7;
  iVar3 = func_0x0028c10e(param_1[0xad],param_1[8] - param_1[0xd],param_1[4],0x3f800000);
  param_1[0xc] = iVar3;
  iVar3 = (**(code **)(*(int *)param_1[0xa9] + 0xc))((int *)param_1[0xa9],iVar3 + param_1[0x11]);
  lVar6 = (longdouble)_floorf((float)iVar3 * FLOAT_00365f00);
  param_1[9] = (int)lVar6;
  auStack_20[0] = 0x3f800000;
  (**(code **)(*(int *)param_1[0xa9] + 0x1c))((int *)param_1[0xa9]);
  (**(code **)(*(int *)param_1[0xa9] + 0x2c))((int *)param_1[0xa9],param_1[2]);
  iVar3 = param_1[7];
  if (0 < iVar3) {
    iStack_30 = 0;
    puVar5 = param_1;
    do {
      puVar1 = PTR_DAT_003db156;
      uVar4 = (**(code **)PTR_DAT_003db156)(param_1[9]);
      puVar5[0x49] = uVar4;
      uVar4 = (**(code **)puVar1)(param_1[9]);
      puVar5[0x79] = uVar4;
      uVar4 = (**(code **)puVar1)(param_1[9]);
      puVar5[0x19] = uVar4;
      puVar1 = PTR_DAT_003db15a;
      (**(code **)PTR_DAT_003db15a)(puVar5[0x49],param_1[9]);
      (**(code **)puVar1)(puVar5[0x79],param_1[9]);
      (**(code **)puVar1)(puVar5[0x19],param_1[9]);
      iStack_30 = iStack_30 + 1;
      iVar3 = param_1[7];
      puVar5 = puVar5 + 1;
    } while (iStack_30 < iVar3);
  }
  puVar1 = PTR_DAT_003db156;
  uVar4 = (**(code **)PTR_DAT_003db156)(iVar3 * param_1[9]);
  param_1[0x17] = uVar4;
  puVar2 = PTR_DAT_003db15a;
  (**(code **)PTR_DAT_003db15a)(uVar4,param_1[7] * param_1[9]);
  uVar4 = (**(code **)puVar1)(param_1[7] * param_1[9]);
  param_1[0x18] = uVar4;
  (**(code **)puVar2)(uVar4,param_1[7] * param_1[9]);
  param_1[6] = 0x3f800000;
  param_1[0x13] = 0x80;
  return;
}


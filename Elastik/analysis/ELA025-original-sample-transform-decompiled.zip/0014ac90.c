
longdouble FUN_0014ac90(int param_1)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0x8c) != 0) {
    iVar1 = func_0x001f0b58(*(int *)(param_1 + 0x8c));
    if (iVar1 != 0) {
      return (longdouble)*(double *)(iVar1 + 0x18);
    }
  }
  return (longdouble)0;
}



void FUN_0007a71a(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  undefined4 uVar2;
  
  FUN_0007a5f0(param_1,param_2);
  (**(code **)(**(int **)(param_1 + 0x48) + 0x1a4))(*(int **)(param_1 + 0x48));
  piVar1 = (int *)FUN_00064626(*(undefined4 *)(param_1 + 0x44),param_3);
  if (piVar1 == (int *)0x0) {
    piVar1 = (int *)FUN_00064626(*(undefined4 *)(param_1 + 0x40),param_3);
    if (piVar1 == (int *)0x0) {
      uVar2 = FUN_00079ab8(param_1,param_3);
      uVar2 = FUN_001c5456(param_2,uVar2,param_3);
      FUN_00066284(*(undefined4 *)(param_1 + 0x40),uVar2,param_3);
      goto LAB_0007a76f;
    }
  }
  (**(code **)(*piVar1 + 0x1ec))(piVar1,param_2);
LAB_0007a76f:
                    /* WARNING: Could not recover jumptable at 0x0007a783. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x48) + 0x1ac))();
  return;
}


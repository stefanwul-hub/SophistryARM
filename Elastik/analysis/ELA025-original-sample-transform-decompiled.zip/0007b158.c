
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0007b158(int param_1,int *param_2)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  longdouble lVar8;
  double dVar9;
  double dStack_44;
  int iStack_2c;
  
  uVar5 = (**(code **)(*param_2 + 0x1bc))(param_2);
  uVar5 = func_0x00079cf2(param_1,uVar5);
  (**(code **)(**(int **)(param_1 + 0x14) + 0x1a4))(*(int **)(param_1 + 0x14));
  uVar6 = func_0x001c5c30(param_2);
  FUN_00066284(*(undefined4 *)(param_1 + 0x10),uVar6,uVar5);
  iVar7 = (**(code **)(*param_2 + 0x1d8))(param_2);
  *(double *)(param_1 + 0x24) =
       (double)iVar7 * DOUBLE_003647b0 * DOUBLE_003647b0 + *(double *)(param_1 + 0x24);
  (**(code **)(**(int **)(param_1 + 0x14) + 0x1ac))(*(int **)(param_1 + 0x14));
  dVar9 = (double)*(int *)(param_1 + 0x2c) - *(double *)(param_1 + 0x24);
  if ((DOUBLE_00364718 <= dVar9) || (NAN(dVar9) || NAN(DOUBLE_00364718))) {
    return;
  }
  uVar5 = __Znwm(0x20);
  FUN_00029d44(uVar5);
  piVar2 = (int *)FUN_0002dfa6(uVar5);
  uVar5 = (**(code **)(*piVar2 + 0x48))(piVar2);
  dStack_44 = *(double *)(param_1 + 0x24) - (double)*(int *)(param_1 + 0x2c);
  if ((dStack_44 <= DOUBLE_00364718) && (!NAN(dStack_44) && !NAN(DOUBLE_00364718))) {
    return;
  }
  (**(code **)(**(int **)(param_1 + 0x14) + 0x1a4))(*(int **)(param_1 + 0x14));
  uVar6 = func_0x00063ade(*(undefined4 *)(param_1 + 0x10));
  FUN_0002d256(uVar5,uVar6);
  func_0x0002b450(uVar5,PTR_DAT_003db046,0);
  iStack_2c = 0;
code_r0x0007a164:
  iVar7 = FUN_00029ddc(uVar5);
  if (iVar7 <= iStack_2c) {
code_r0x0007a1f0:
    (**(code **)(**(int **)(param_1 + 0x20) + 0x1ac))(*(int **)(param_1 + 0x20));
                    /* WARNING: Could not recover jumptable at 0x0007a219. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(param_1 + 0x14) + 0x1ac))();
    return;
  }
  do {
    if (dStack_44 <= DOUBLE_00364718) goto code_r0x0007a1f0;
    piVar2 = (int *)FUN_0002a364(uVar5,iStack_2c);
    uVar6 = (**(code **)(*piVar2 + 0x1a8))(piVar2);
    (**(code **)(**(int **)(param_1 + 0x20) + 0x1a4))(*(int **)(param_1 + 0x20));
    iVar7 = FUN_00064626(*(undefined4 *)(param_1 + 0x1c),uVar6);
    if (iVar7 == 0) {
      (**(code **)(**(int **)(param_1 + 0x20) + 0x1ac))(*(int **)(param_1 + 0x20));
      iVar7 = (**(code **)(*piVar2 + 0x1b8))(piVar2);
      if (iVar7 != 0) {
        uVar3 = (**(code **)(*piVar2 + 0x1b8))(piVar2);
        lVar8 = (longdouble)func_0x001a808c(uVar3);
        if ((double)lVar8 <= DOUBLE_003647b8) {
          piVar4 = (int *)func_0x0009af5e(uVar6);
          cVar1 = (**(code **)(*piVar4 + 0x1d0))(piVar4);
          if (cVar1 == '\0') {
            uVar6 = func_0x00079cf2(param_1,uVar6);
            FUN_00066606(*(undefined4 *)(param_1 + 0x10),uVar6);
            iVar7 = (**(code **)(*piVar2 + 0x1b0))(piVar2);
            dStack_44 = dStack_44 - (double)iVar7;
            dVar9 = *(double *)(param_1 + 0x24);
            iVar7 = (**(code **)(*piVar2 + 0x1b0))(piVar2);
            *(double *)(param_1 + 0x24) = dVar9 - (double)iVar7;
          }
          else {
            iVar7 = (**(code **)(*piVar4 + 0x1d8))(piVar4);
            dVar9 = DOUBLE_003647b0 * (double)iVar7 * DOUBLE_003647b0;
            cVar1 = (**(code **)(*piVar4 + 0x21c))(piVar4);
            if (cVar1 != '\0') break;
          }
        }
      }
    }
    else {
      (**(code **)(**(int **)(param_1 + 0x20) + 0x1ac))(*(int **)(param_1 + 0x20));
    }
    iStack_2c = iStack_2c + 1;
    iVar7 = FUN_00029ddc(uVar5);
    if (iVar7 <= iStack_2c) goto code_r0x0007a1f0;
  } while( true );
  uVar6 = func_0x00079cf2(param_1,uVar6);
  FUN_00066606(*(undefined4 *)(param_1 + 0x10),uVar6);
  dStack_44 = dStack_44 - dVar9;
  *(double *)(param_1 + 0x24) = *(double *)(param_1 + 0x24) - dVar9;
  iStack_2c = iStack_2c + 1;
  goto code_r0x0007a164;
}


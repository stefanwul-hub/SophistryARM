001ae48c  55  PUSH EBP
001ae48d  89e5  MOV EBP,ESP
001ae48f  83ec28  SUB ESP,0x28
001ae492  c744241c00000000  MOV dword ptr [ESP + 0x1c],0x0
001ae49a  c744241800000000  MOV dword ptr [ESP + 0x18],0x0
001ae4a2  8b451c  MOV EAX,dword ptr [EBP + 0x1c]
001ae4a5  89442414  MOV dword ptr [ESP + 0x14],EAX
001ae4a9  f20f104514  MOVSD XMM0,qword ptr [EBP + 0x14]
001ae4ae  f20f1144240c  MOVSD qword ptr [ESP + 0xc],XMM0
001ae4b4  8b4510  MOV EAX,dword ptr [EBP + 0x10]
001ae4b7  89442408  MOV dword ptr [ESP + 0x8],EAX
001ae4bb  8b450c  MOV EAX,dword ptr [EBP + 0xc]
001ae4be  89442404  MOV dword ptr [ESP + 0x4],EAX
001ae4c2  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001ae4c5  890424  MOV dword ptr [ESP],EAX
001ae4c8  e8cdfeffff  CALL 0x001ae39a
001ae4cd  c9  LEAVE
001ae4ce  c3  RET

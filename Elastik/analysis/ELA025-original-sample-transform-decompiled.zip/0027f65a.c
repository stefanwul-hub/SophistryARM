
undefined4
FUN_0027f65a(undefined4 *param_1,undefined4 param_2,int param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined4 uVar1;
  
  if (0x30 < param_3) {
    return 0x4c4b43;
  }
  uVar1 = __Znwm(0x2a8);
  func_0x002910a0(uVar1,param_2,param_3,param_4,param_5);
  *param_1 = uVar1;
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0027fb2a(undefined4 *param_1,int param_2,undefined4 param_3,float param_4,int param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  *param_1 = &UNK_003b3948;
  param_1[4] = param_2;
  param_1[10] = param_4;
  param_1[9] = param_3;
  if (FLOAT_00365ef4 <= param_4) {
    if (param_4 < FLOAT_00365ef8) {
      param_1[7] = 0x1000;
      iVar2 = param_1[7];
    }
    else {
      iVar2 = (-(uint)(param_4 < FLOAT_00365efc) & 0xffffe000) + 0x4000;
      param_1[7] = iVar2;
    }
  }
  else {
    param_1[7] = 0x800;
    iVar2 = param_1[7];
  }
  param_1[8] = iVar2 >> 7;
  iVar1 = iVar2 + (iVar2 >> 1);
  iVar3 = param_2 * 2;
  if (param_2 * 2 < iVar1) {
    iVar3 = iVar1;
  }
  iVar2 = (iVar2 >> 1) + iVar2 * 2;
  if (iVar2 <= iVar3) {
    iVar2 = iVar3;
  }
  param_1[6] = iVar2;
  func_0x0028c30e(param_1 + 1);
  (**(code **)(*(int *)param_1[1] + 0x10))((int *)param_1[1],0x800);
  func_0x0028c366(param_1 + 3,param_1[1],param_1[8],param_1[9]);
  if (param_5 != 5) {
    func_0x0028c3d4(param_1 + 2,param_1[1],param_1[10],0x400,param_1[9],1,1);
    (**(code **)(*(int *)param_1[3] + 0x24))((int *)param_1[3],1);
    return;
  }
  func_0x0028c3d4(param_1 + 2,param_1[1],param_1[10],0,param_1[9],0,1);
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_00079ab8(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  
  (**(code **)(**(int **)(param_1 + 0x18) + 0x1a4))(*(int **)(param_1 + 0x18));
  uVar2 = FUN_00033b90("/");
  cVar1 = func_0x000374b2(param_2,uVar2);
  if (cVar1 != '\0') {
    param_2 = func_0x0003b05e(param_2,1);
  }
  piVar3 = (int *)(**(code **)(**(int **)(param_1 + 0xc) + 0x20c))
                            (*(int **)(param_1 + 0xc),param_2,0);
  uVar2 = (**(code **)(*piVar3 + 0x1bc))(piVar3);
  uVar2 = FUN_0003a64e(uVar2);
  piVar4 = (int *)func_0x0009af5e(uVar2);
  cVar1 = (**(code **)(*piVar4 + 0x1d4))(piVar4);
  if (cVar1 == '\0') {
    cVar1 = (**(code **)(*piVar4 + 0x22c))(piVar4);
    if (cVar1 == '\0') {
      uVar2 = FUN_00033b90("GNInternalInconsistencyException");
      FUN_0000bfd6(uVar2,"ETRenderCacheCtrl::getFilePathWithName() failed on creating directory!");
      (**(code **)(**(int **)(param_1 + 0x18) + 0x1ac))(*(int **)(param_1 + 0x18));
      return piVar3;
    }
  }
  (**(code **)(**(int **)(param_1 + 0x18) + 0x1ac))(*(int **)(param_1 + 0x18));
  return piVar3;
}


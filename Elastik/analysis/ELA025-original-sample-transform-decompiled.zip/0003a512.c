
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0003a512(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  char *pcVar7;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x36d,uVar3,"this != 0");
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x10f,uVar3,"this != 0");
  }
  if (*(int *)(param_1 + 0x14) == -1) {
    if (*(char **)(param_1 + 0xc) == (char *)0x0) {
      return param_1;
    }
    uVar5 = 0xffffffff;
    pcVar7 = *(char **)(param_1 + 0xc);
    do {
      if (uVar5 == 0) break;
      uVar5 = uVar5 - 1;
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    iVar2 = ~uVar5 - 3;
  }
  else {
    iVar2 = *(int *)(param_1 + 0x14) + -2;
  }
  if (0 < iVar2) {
    iVar6 = 0;
    do {
      cVar1 = FUN_00034a88(param_1,iVar2 - iVar6);
      if (cVar1 == '.') {
        iVar2 = FUN_0003a042(param_1,0,iVar2 - iVar6);
        return iVar2;
      }
    } while ((cVar1 != '/') && (iVar6 = iVar6 + 1, iVar6 != iVar2));
  }
  return param_1;
}


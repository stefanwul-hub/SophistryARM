
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0003a64e(int param_1)

{
  char cVar1;
  int *piVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  char *pcVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  
  uVar9 = 0;
  uVar10 = 0;
  uVar8 = 0;
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x327,uVar3,"this != 0");
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x10f,uVar3,"this != 0");
  }
  if (*(int *)(param_1 + 0x14) == -1) {
    if (*(char **)(param_1 + 0xc) == (char *)0x0) {
      return param_1;
    }
    uVar5 = 0xffffffff;
    pcVar7 = *(char **)(param_1 + 0xc);
    do {
      if (uVar5 == 0) break;
      uVar5 = uVar5 - 1;
      cVar1 = *pcVar7;
      pcVar7 = pcVar7 + 1;
    } while (cVar1 != '\0');
    iVar6 = ~uVar5 - 2;
  }
  else {
    iVar6 = *(int *)(param_1 + 0x14) + -1;
  }
  if (-1 < iVar6) {
    do {
      cVar1 = FUN_00034a88(param_1,iVar6);
      if (cVar1 == '/') {
        if (0 < iVar6) goto LAB_0003a6ee;
        iVar6 = *(int *)(param_1 + 0x14);
        if (iVar6 != -1) goto LAB_0003a7a5;
        if (*(char **)(param_1 + 0xc) == (char *)0x0) goto LAB_0003a7aa;
        uVar5 = 0xffffffff;
        pcVar7 = *(char **)(param_1 + 0xc);
        goto code_r0x0003a7e4;
      }
      iVar6 = iVar6 + -1;
    } while (iVar6 != -1);
  }
  return param_1;
  while( true ) {
    uVar5 = uVar5 - 1;
    cVar1 = *pcVar7;
    pcVar7 = pcVar7 + 1;
    if (cVar1 == '\0') break;
code_r0x0003a7e4:
    if (uVar5 == 0) break;
  }
  iVar6 = ~uVar5 - 1;
LAB_0003a7a5:
  if (iVar6 == 1) {
    if (piRam003d4050 == (int *)0x0) {
      uVar8 = __Znwm(0x38,uVar8,uVar9,uVar10);
      func_0x0006f04a(uVar8);
      piRam003d4050 = (int *)FUN_0002dfa6(uVar8);
      (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
    }
    else {
      (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
    }
    if (iRam003d4054 == 0) {
      uVar8 = __Znwm(0x14);
      FUN_00084dba(uVar8);
      iRam003d4054 = FUN_0002dfa6(uVar8);
    }
    FUN_000854fe(iRam003d4054,"");
    if (iRam003d4058 == 0) {
      uVar8 = __Znwm(0x18);
      FUN_000630b6(uVar8);
      iRam003d4058 = FUN_0002dfa6(uVar8);
      func_0x00065c4a(iRam003d4058,1);
    }
    iVar6 = func_0x0006440e(iRam003d4058,iRam003d4054);
    if (iVar6 == -1) {
      uVar8 = __Znwm(0x14);
      FUN_00084dba(uVar8);
      piVar2 = (int *)FUN_0002dfa6(uVar8);
      FUN_000854fe(piVar2,"");
      iVar6 = func_0x00033aa6("");
      FUN_00066284(iRam003d4058,iVar6,piVar2);
      if (piVar2 != (int *)0x0) {
        (**(code **)(*piVar2 + 0x44))(piVar2);
      }
      (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
      return iVar6;
    }
    uVar8 = func_0x00063ade(iRam003d4058);
    iVar6 = FUN_0002a364(uVar8,iVar6);
    (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
    return iVar6;
  }
LAB_0003a7aa:
  iVar6 = 1;
LAB_0003a6ee:
  iVar6 = FUN_0003a042(param_1,0,iVar6);
  return iVar6;
}


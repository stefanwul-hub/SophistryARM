
longdouble FUN_0014ab7e(int param_1)

{
  longdouble lVar1;
  double dVar2;
  
  dVar2 = 0.0;
  if (*(int *)(param_1 + 0x78) != 0) {
    lVar1 = (longdouble)func_0x0015f258(*(int *)(param_1 + 0x78));
    dVar2 = (double)(*(float *)(param_1 + 0x88) * (float)lVar1);
  }
  lVar1 = (longdouble)FUN_0014a5d8(param_1);
  return (longdouble)(float)(dVar2 / (double)lVar1);
}


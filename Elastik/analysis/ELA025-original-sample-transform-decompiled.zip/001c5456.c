
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_001c5456(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  longdouble lVar7;
  
  puVar2 = (undefined4 *)__Znwm(0x34);
  func_0x0002dc66(puVar2);
  *puVar2 = &UNK_00394ee8;
  puVar2[3] = 0;
  puVar2[4] = 0;
  puVar2[5] = 0x3f800000;
  puVar2[6] = 0x3f800000;
  puVar2[7] = 0;
  puVar2[8] = 0;
  puVar2[9] = 0;
  puVar2[10] = 0;
  puVar2[0xb] = 0;
  puVar2[0xc] = 0;
  piVar3 = (int *)FUN_0002dfa6(puVar2);
  piVar3 = (int *)(**(code **)(*piVar3 + 0x48))(piVar3);
  pcVar1 = *(code **)(*piVar3 + 0x1d4);
  uVar4 = FUN_00149fae(param_1);
  (*pcVar1)(piVar3,uVar4);
  pcVar1 = *(code **)(*piVar3 + 0x1a4);
  lVar7 = (longdouble)FUN_0014ac90(param_1);
  (*pcVar1)(piVar3,(double)lVar7);
  pcVar1 = *(code **)(*piVar3 + 0x1ac);
  lVar7 = (longdouble)FUN_0014ab7e(param_1);
  (*pcVar1)(piVar3,FLOAT_00365ce8 / (float)lVar7);
  pcVar1 = *(code **)(*piVar3 + 0x1b4);
  iVar5 = func_0x0014a1ce(param_1);
  iVar6 = func_0x0014a1da(param_1);
  lVar7 = (longdouble)
          _pow(0,0x40000000,(double)((float)iVar5 / FLOAT_00365d3c + (float)iVar6 / FLOAT_00365d1c))
  ;
  (*pcVar1)(piVar3,(float)lVar7);
  pcVar1 = *(code **)(*piVar3 + 0x1bc);
  uVar4 = func_0x00149f26(param_1);
  (*pcVar1)(piVar3,uVar4);
  pcVar1 = *(code **)(*piVar3 + 0x1c4);
  uVar4 = func_0x00149f7c(param_1);
  uVar4 = func_0x0015f27e(uVar4);
  (*pcVar1)(piVar3,uVar4);
  (**(code **)(*piVar3 + 0x1dc))(piVar3,param_2);
  (**(code **)(*piVar3 + 0x1cc))(piVar3,param_3);
  (**(code **)(*piVar3 + 0x1ec))(piVar3,param_1);
  return piVar3;
}


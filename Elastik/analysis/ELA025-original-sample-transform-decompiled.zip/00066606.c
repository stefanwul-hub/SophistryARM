
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Possible PIC construction at 0x00066665: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x0006666a) */
/* WARNING: Removing unreachable block (ram,0x00066671) */
/* WARNING: Removing unreachable block (ram,0x00066679) */

void FUN_00066606(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  if (param_1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x153,uVar4,"this != 0");
  }
  if (*(int *)(param_1 + 0xc) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x153,uVar4,"_keys");
  }
  if (*(int *)(param_1 + 0x10) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x153,uVar4,"_objects");
  }
  if (param_2 == 0) {
    func_0x0000acae("GNDictionary: key is 0");
  }
  iVar6 = func_0x0002a9ba(*(undefined4 *)(param_1 + 0xc),param_2);
  if (iVar6 == -1) {
    return;
  }
  piVar2 = *(int **)(param_1 + 0xc);
  if (piVar2 == (int *)0x0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x1f1,uVar4,"this != 0");
  }
  if ((piVar2[4] <= iVar6) || (iVar6 < 0)) {
    uVar4 = (**(code **)(*piVar2 + 0xc))(piVar2);
    uVar4 = func_0x00034962(uVar4);
    func_0x0000acae("GNList::removeObjectAtIndex(): Index %i out of range of %s.",iVar6,uVar4);
  }
  iVar7 = iVar6 * 4;
  iVar8 = piVar2[3];
  piVar1 = *(int **)(iVar8 + iVar7);
  iVar3 = piVar2[4] + -1;
  if (iVar6 < iVar3) {
    while( true ) {
      *(undefined4 *)(iVar7 + iVar8) = ((undefined4 *)(iVar7 + iVar8))[1];
      iVar6 = iVar6 + 1;
      iVar3 = piVar2[4] + -1;
      iVar7 = iVar7 + 4;
      if (iVar3 <= iVar6) break;
      iVar8 = piVar2[3];
    }
  }
  piVar2[4] = iVar3;
  if (((char)piVar2[6] == '\0') && (piVar1 != (int *)0x0)) {
                    /* WARNING: Could not recover jumptable at 0x0002a6b4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar1 + 0x44))(piVar1);
    return;
  }
  return;
}


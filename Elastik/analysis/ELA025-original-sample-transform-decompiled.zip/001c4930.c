
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001c4930(int param_1)

{
  int iVar1;
  bool bVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  longdouble lVar13;
  longdouble lVar14;
  float fVar15;
  undefined8 uVar16;
  double dVar17;
  int iStack_44;
  int iStack_3c;
  float afStack_20 [4];
  
  iVar3 = (**(code **)(**(int **)(param_1 + 0x98) + 0x1d8))(*(int **)(param_1 + 0x98));
  if (iVar3 == 0) {
    return;
  }
  if (*(int *)(param_1 + 0x80) == 0) {
    (**(code **)(*piRam003d8b44 + 0x1a4))(piRam003d8b44);
    iVar11 = (**(code **)(**(int **)(param_1 + 0x98) + 0x1c8))(*(int **)(param_1 + 0x98));
    if (iVar11 == 0) {
      iVar11 = (**(code **)(**(int **)(param_1 + 0x98) + 0x1c0))(*(int **)(param_1 + 0x98));
      if (iVar11 == 1) {
        lVar13 = (longdouble)func_0x001ab7a0(iVar3);
        fVar15 = (float)lVar13;
      }
      else {
        lVar13 = (longdouble)func_0x001ab7a0(iVar3);
        fVar15 = (float)lVar13;
      }
    }
    else {
      iVar11 = (**(code **)(**(int **)(param_1 + 0x98) + 0x1c0))(*(int **)(param_1 + 0x98));
      if (iVar11 == 2) {
        lVar13 = (longdouble)func_0x001ab7a0(iVar3);
        fVar15 = (float)lVar13;
      }
      else if (iVar11 == 3) {
        lVar13 = (longdouble)func_0x001ab7a0(iVar3);
        fVar15 = (float)lVar13;
      }
      else if (iVar11 == 1) {
        lVar13 = (longdouble)func_0x001ab7a0(iVar3);
        fVar15 = (float)lVar13;
      }
      else {
        lVar13 = (longdouble)func_0x001ab7a0(iVar3);
        fVar15 = (float)lVar13;
      }
    }
    FUN_0022f910(param_1 + 0x80,0x200,2,fVar15);
    (**(code **)(*piRam003d8b44 + 0x1ac))(piRam003d8b44);
    if (*(int *)(param_1 + 0x80) == 0) {
      FUN_0000ab14("no _elastiqueHandle");
      return;
    }
  }
  lVar13 = (longdouble)(**(code **)(**(int **)(param_1 + 0x98) + 0x1b0))(*(int **)(param_1 + 0x98));
  lVar14 = (longdouble)(**(code **)(**(int **)(param_1 + 0x98) + 0x1b8))(*(int **)(param_1 + 0x98));
  afStack_20[0] = (float)lVar14;
  (**(code **)(**(int **)(param_1 + 0x80) + 0x18))
            (*(int **)(param_1 + 0x80),(float)lVar13,afStack_20);
  uVar4 = func_0x001ac91e(iVar3);
  lVar13 = (longdouble)func_0x001ab7a0(iVar3);
  dVar17 = (double)lVar13;
  uVar5 = func_0x001ac8f8(iVar3);
  uVar6 = func_0x001acd84(iVar3);
  uVar7 = (**(code **)(**(int **)(param_1 + 0x98) + 0x1e0))(*(int **)(param_1 + 0x98));
  uVar4 = FUN_001ae48c(uVar7,uVar6,uVar5,dVar17,uVar4);
  iVar8 = func_0x001ab7c0(iVar3);
  lVar13 = (longdouble)(**(code **)(**(int **)(param_1 + 0x98) + 0x1b0))(*(int **)(param_1 + 0x98));
  iVar12 = (int)((float)iVar8 * (float)lVar13);
  *(undefined4 *)(param_1 + 0x94) = 0;
  iStack_44 = 0;
  bVar2 = true;
  iVar11 = param_1 + 0x84;
  iVar1 = param_1 + 0x8c;
  iVar9 = (**(code **)(**(int **)(param_1 + 0x80) + 0x10))(*(int **)(param_1 + 0x80));
  iStack_3c = iVar12;
  if (iVar9 != 0) goto LAB_001c4bfe;
LAB_001c4ab4:
  uVar5 = (undefined4)((ulonglong)dVar17 >> 0x20);
  iVar10 = iVar8 - iStack_44;
  if (iVar10 <= iVar9) goto LAB_001c4c4e;
LAB_001c4ac2:
  uVar16 = CONCAT44((int)((ulonglong)dVar17 >> 0x20),iVar9);
  FUN_001afed2(iVar3,iVar11,iStack_44,iVar9);
  iStack_44 = iStack_44 + iVar9;
  do {
    uVar5 = (undefined4)((ulonglong)uVar16 >> 0x20);
    (**(code **)(**(int **)(param_1 + 0x80) + 8))(*(int **)(param_1 + 0x80),iVar11,iVar9,iVar1);
    iVar9 = iStack_3c + -0x200;
    if (iVar9 < 0) {
LAB_001c4c82:
      dVar17 = (double)CONCAT44(uVar5,iVar12);
      FUN_001c47a8(param_1,uVar4,iStack_3c,dVar17);
      iStack_3c = 0;
    }
    else {
      dVar17 = (double)CONCAT44(uVar5,iVar12);
      FUN_001c47a8(param_1,uVar4,0x200,iVar12);
      iStack_3c = iVar9;
      if (0 < iVar9) {
        iVar9 = (**(code **)(**(int **)(param_1 + 0x80) + 0x10))(*(int **)(param_1 + 0x80));
        while (iVar9 == 0) {
          uVar5 = (undefined4)((ulonglong)dVar17 >> 0x20);
          (**(code **)(**(int **)(param_1 + 0x80) + 8))(*(int **)(param_1 + 0x80),iVar11,0,iVar1);
          iVar9 = iStack_3c + -0x200;
          if (iVar9 < 0) goto LAB_001c4c82;
          dVar17 = (double)CONCAT44(uVar5,iVar12);
          FUN_001c47a8(param_1,uVar4,0x200,iVar12);
          iStack_3c = iVar9;
          if (iVar9 < 1) break;
          iVar9 = (**(code **)(**(int **)(param_1 + 0x80) + 0x10))(*(int **)(param_1 + 0x80));
        }
      }
    }
    if (!bVar2) break;
    iVar9 = (**(code **)(**(int **)(param_1 + 0x80) + 0x10))(*(int **)(param_1 + 0x80));
    if (iVar9 == 0) goto LAB_001c4ab4;
LAB_001c4bfe:
    _memset(*(undefined4 *)(param_1 + 0x84),0,&UNK_00015fe0);
    _memset(*(undefined4 *)(param_1 + 0x88),0,&UNK_00015fe0);
    uVar5 = (undefined4)((ulonglong)dVar17 >> 0x20);
    iVar10 = iVar8 - iStack_44;
    if (iVar9 < iVar10) goto LAB_001c4ac2;
LAB_001c4c4e:
    uVar16 = CONCAT44(uVar5,iVar10);
    FUN_001afed2(iVar3,iVar11,iStack_44,iVar10);
    bVar2 = false;
  } while( true );
joined_r0x001c4ca2:
  if (iStack_3c < 1) {
LAB_001c4d6d:
    FUN_001ac7dc(uVar4);
    uVar4 = *(undefined4 *)(param_1 + 0x98);
    uVar5 = func_0x00079a9c();
    FUN_0007b216(uVar5,uVar4);
    return;
  }
  iVar3 = (**(code **)(**(int **)(param_1 + 0x80) + 8))(*(int **)(param_1 + 0x80),0,0,iVar1);
  if (iVar3 == -1) {
    if ((0 < iStack_3c) &&
       (iVar3 = (**(code **)(**(int **)(param_1 + 0x80) + 0x20))(*(int **)(param_1 + 0x80),iVar1),
       0 < iVar3)) {
      if (iStack_3c < iVar3) {
LAB_001c4d50:
        FUN_001c47a8(param_1,uVar4,iStack_3c,iVar12);
      }
      else {
        FUN_001c47a8(param_1,uVar4,iVar3,iVar12);
      }
    }
    goto LAB_001c4d6d;
  }
  if (iStack_3c + -0x200 < 0) goto LAB_001c4d50;
  FUN_001c47a8(param_1,uVar4,0x200,iVar12);
  iStack_3c = iStack_3c + -0x200;
  goto joined_r0x001c4ca2;
}


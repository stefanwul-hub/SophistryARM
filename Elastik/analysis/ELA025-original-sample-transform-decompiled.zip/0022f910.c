
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined * FUN_0022f910(int *param_1,undefined4 param_2,int param_3,float param_4,uint param_5)

{
  int iVar1;
  undefined4 *puVar2;
  
  *param_1 = 0;
  if ((param_4 < FLOAT_00365edc) || (FLOAT_00365ee0 < param_4)) {
    return (undefined *)0x4c4b44;
  }
  if (0x2f < param_3 - 1U) {
    return (undefined *)0x4c4b45;
  }
  if (param_5 < 2) {
    iVar1 = __Znwm(700);
    FUN_0027efd6(iVar1,param_2,param_3,param_4,param_5);
  }
  else {
    if (param_5 - 2 < 2) {
      puVar2 = (undefined4 *)__Znwm(8);
      *puVar2 = PTR_DAT_003db132 + 8;
      *puVar2 = PTR_DAT_003db12e + 8;
      FUN_0027f65a(puVar2 + 1,param_2,param_3,param_4,param_5 - 2);
      *param_1 = (int)puVar2;
      goto LAB_0022f9c5;
    }
    if (1 < param_5 - 4) {
      return (undefined *)0x4c4b43;
    }
    iVar1 = __Znwm(0xec);
    FUN_0027fb2a(iVar1,param_2,param_3,param_4,param_5);
  }
  *param_1 = iVar1;
LAB_0022f9c5:
  if (*param_1 != 0) {
    return (undefined *)0x0;
  }
  return &UNK_000f4241;
}


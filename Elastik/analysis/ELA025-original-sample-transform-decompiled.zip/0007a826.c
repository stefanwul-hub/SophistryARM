
void FUN_0007a826(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  
  uVar1 = __Znwm(0x14);
  FUN_0001e688(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  uVar1 = __Znwm(0x9c);
  FUN_001c4440(uVar1);
  piVar3 = (int *)FUN_0002dfa6(uVar1);
  FUN_001c473c(piVar3,param_2);
  (**(code **)(*piVar3 + 0x23c))(piVar3);
  FUN_001c4930(piVar3);
  (**(code **)(*piVar3 + 0x240))(piVar3);
  piVar4 = (int *)FUN_0006d8fe();
  (**(code **)(*piVar4 + 0x1c0))(piVar4);
  (**(code **)(*piVar3 + 0x44))(piVar3);
                    /* WARNING: Could not recover jumptable at 0x0007a8c5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*piVar2 + 0x44))();
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0007b216(int param_1,int *param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iStack_20;
  
  uVar2 = __Znwm(0x20);
  FUN_00029d44(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  uVar2 = (**(code **)(*piVar3 + 0x48))(piVar3);
  uVar4 = (**(code **)(*param_2 + 0x1e0))(param_2);
  FUN_0007b158(param_1,uVar4);
  (**(code **)(**(int **)(param_1 + 0x48) + 0x1a4))(*(int **)(param_1 + 0x48));
  uVar4 = (**(code **)(*param_2 + 0x1d0))(param_2);
  FUN_00066606(*(undefined4 *)(param_1 + 0x44),uVar4);
  uVar4 = (**(code **)(*param_2 + 0x1e8))(param_2);
  FUN_0002d256(uVar2,uVar4);
  iStack_20 = 0;
  while( true ) {
    iVar6 = FUN_00029ddc(uVar2);
    if (iVar6 <= iStack_20) break;
    uVar4 = FUN_0002a364(uVar2,iStack_20);
    piVar3 = (int *)FUN_0006ee22();
    pcVar1 = *(code **)(*piVar3 + 0x1a4);
    uVar5 = FUN_00033b90("renderingReady");
    (*pcVar1)(piVar3,uVar5,uVar4);
    iStack_20 = iStack_20 + 1;
  }
                    /* WARNING: Could not recover jumptable at 0x0007b32f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x48) + 0x1ac))();
  return;
}


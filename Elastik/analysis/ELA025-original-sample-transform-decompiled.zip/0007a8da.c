
void FUN_0007a8da(int param_1)

{
  bool bVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uStack_10;
  
  bVar1 = true;
  do {
    (**(code **)(**(int **)(param_1 + 0x48) + 0x1a4))(*(int **)(param_1 + 0x48));
    uVar2 = FUN_00063426(*(undefined4 *)(param_1 + 0x40));
    iVar3 = FUN_0002cff4(uVar2);
    if (iVar3 == 0) {
      bVar1 = false;
      uStack_10 = 0;
    }
    else {
      uStack_10 = FUN_00064626(*(undefined4 *)(param_1 + 0x40),iVar3);
      FUN_00066284(*(undefined4 *)(param_1 + 0x44),uStack_10,iVar3);
      FUN_00066606(*(undefined4 *)(param_1 + 0x40),iVar3);
    }
    (**(code **)(**(int **)(param_1 + 0x48) + 0x1ac))(*(int **)(param_1 + 0x48));
    if (uStack_10 != 0) {
      FUN_0007a826(param_1,uStack_10);
    }
  } while (bVar1);
  return;
}


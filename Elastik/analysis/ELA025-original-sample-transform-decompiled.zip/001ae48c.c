
void FUN_001ae48c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
                 undefined4 param_5)

{
  func_0x001ae39a(param_1,param_2,param_3,param_4,param_5,0,0);
  return;
}


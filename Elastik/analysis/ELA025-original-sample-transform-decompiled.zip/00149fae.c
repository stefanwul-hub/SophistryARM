
undefined4 FUN_00149fae(int param_1)

{
  undefined4 uVar1;
  
  if (((*(int *)(param_1 + 0x78) != 0) && (*(int *)(param_1 + 0x28) != 0)) &&
     (*(int *)(param_1 + 0x24) != 0)) {
    uVar1 = FUN_0015f48c(*(int *)(param_1 + 0x78),*(int *)(param_1 + 0x28),*(int *)(param_1 + 0x24))
    ;
    return uVar1;
  }
  return 0;
}


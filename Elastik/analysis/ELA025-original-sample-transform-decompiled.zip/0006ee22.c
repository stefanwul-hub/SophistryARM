
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0006ee22(void)

{
  undefined4 *puVar1;
  
  if (iRam003d431c != 0) {
    return iRam003d431c;
  }
  puVar1 = (undefined4 *)__Znwm(0x1c);
  func_0x0002dc66(puVar1);
  puVar1[5] = 0;
  puVar1[3] = 0;
  *puVar1 = &UNK_003727a8;
  iRam003d431c = FUN_0002dfa6(puVar1);
  return iRam003d431c;
}


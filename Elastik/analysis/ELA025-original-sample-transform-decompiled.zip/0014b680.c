
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_0014b680(int param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int *piVar10;
  longdouble lVar11;
  float fVar12;
  double dVar13;
  
  piVar4 = *(int **)(param_1 + 0x9c);
  if (piVar4 == (int *)0x0) {
    if (*(int *)(param_1 + 0x78) == 0) {
      dVar13 = 0.0;
    }
    else {
      lVar11 = (longdouble)func_0x0015f258(*(int *)(param_1 + 0x78));
      dVar13 = (double)(*(float *)(param_1 + 0x88) * (float)lVar11);
    }
    lVar11 = (longdouble)FUN_0014a5d8(param_1);
    if (((((float)(dVar13 / (double)lVar11) != FLOAT_00365ce8) ||
         (NAN((float)(dVar13 / (double)lVar11)) || NAN(FLOAT_00365ce8))) ||
        (*(int *)(param_1 + 0x50) != 0)) || (*(int *)(param_1 + 0x54) != 0)) {
      piVar4 = (int *)FUN_0003dd2a("/");
      piVar4 = (int *)(**(code **)(*piVar4 + 0x1a4))(piVar4,*(undefined4 *)(param_1 + 0x28));
      pcVar1 = *(code **)(*piVar4 + 0x1a4);
      uVar5 = FUN_0003a64e(*(undefined4 *)(param_1 + 0x24));
      piVar4 = (int *)(*pcVar1)(piVar4,uVar5);
      if (*(int *)(param_1 + 0x78) != 0) {
        if (piRam003d47a0 == (int *)0x0) {
          uVar5 = __Znwm(0x30);
          FUN_0011025c(uVar5);
          piRam003d47a0 = (int *)FUN_0002dfa6(uVar5);
          FUN_0011079e(piRam003d47a0,2);
          (**(code **)(*piRam003d47a0 + 0x1dc))(piRam003d47a0,0x447a0000);
          (**(code **)(*piRam003d47a0 + 0x1d4))(piRam003d47a0,0);
        }
        uVar6 = FUN_0003a7ee(*(undefined4 *)(param_1 + 0x24));
        uVar5 = *(undefined4 *)(param_1 + 0x54);
        uVar2 = *(undefined4 *)(param_1 + 0x50);
        pcVar1 = *(code **)(*piRam003d47a0 + 0x1ac);
        if (*(int *)(param_1 + 0x78) == 0) {
          fVar12 = 0.0;
        }
        else {
          lVar11 = (longdouble)func_0x0015f258(*(int *)(param_1 + 0x78));
          fVar12 = *(float *)(param_1 + 0x88) * (float)lVar11;
        }
        uVar7 = (*pcVar1)(piRam003d47a0,fVar12);
        uVar3 = *(undefined4 *)(param_1 + 0x84);
        uVar8 = func_0x0015f27e(*(undefined4 *)(param_1 + 0x78));
        uVar9 = FUN_0003a99a(*(undefined4 *)(param_1 + 0x24));
        uVar9 = FUN_0003a512(uVar9);
        uVar5 = FUN_0003dd2a("%@_%d_%d_%@_%d_%d.%@",uVar9,uVar8,uVar3,uVar7,uVar2,uVar5,uVar6);
        piVar10 = (int *)(**(code **)(*piVar4 + 0x1a4))(piVar4,uVar5);
        piVar4 = *(int **)(param_1 + 0x9c);
        if (piVar10 != piVar4) {
          if (piVar4 != (int *)0x0) {
            (**(code **)(*piVar4 + 0x44))(piVar4);
          }
          *(int **)(param_1 + 0x9c) = piVar10;
          piVar4 = piVar10;
          if (piVar10 != (int *)0x0) {
            (**(code **)(*piVar10 + 0x40))(piVar10);
            piVar4 = *(int **)(param_1 + 0x9c);
          }
        }
        if (piVar4 != (int *)0x0) {
          return piVar4;
        }
      }
      piVar4 = (int *)0x0;
    }
    else {
      piVar4 = (int *)0x0;
    }
  }
  return piVar4;
}



undefined4 FUN_0018b0a6(int *param_1,uint param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  
  cVar1 = (**(code **)(*param_1 + 0x1b4))(param_1);
  if (cVar1 == '\0') {
    uVar2 = (**(code **)(*param_1 + 0x1a8))(param_1);
    iVar3 = FUN_000349f4(uVar2);
    iVar4 = (**(code **)(*param_1 + 0x1b0))(param_1);
    if (param_2 <= (uint)(iVar3 - iVar4)) {
      if (param_3 != (undefined4 *)0x0) {
        uVar2 = __Znwm(0x20);
        FUN_000332e2(uVar2);
        piVar5 = (int *)FUN_0002dfa6(uVar2);
        uVar2 = (**(code **)(*piVar5 + 0x48))(piVar5);
        *param_3 = uVar2;
        uVar2 = (**(code **)(*param_1 + 0x1b0))(param_1);
        uVar6 = (**(code **)(*param_1 + 0x1a8))(param_1);
        uVar2 = FUN_0003a042(uVar6,uVar2,param_2);
        FUN_0003b118(*param_3,uVar2);
      }
      param_1[5] = param_1[5] + param_2;
      return 1;
    }
  }
  return 0;
}


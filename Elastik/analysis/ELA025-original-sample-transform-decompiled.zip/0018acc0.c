
undefined4 FUN_0018acc0(int *param_1,undefined4 param_2,undefined4 *param_3)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  int *piVar4;
  uint uVar5;
  int iStack_20;
  undefined2 uStack_e;
  
  uStack_e = 0;
  cVar1 = (**(code **)(*param_1 + 0x1b4))(param_1);
  if (cVar1 == '\0') {
    iStack_20 = 0;
    uVar5 = param_1[5];
    while (uVar2 = (**(code **)(*param_1 + 0x1b8))(param_1), uVar5 < uVar2) {
      uStack_e = FUN_00035d80(param_1[3],param_1[5]);
      cVar1 = FUN_000376dc(param_2,uStack_e);
      if (cVar1 == '\0') break;
      if (iStack_20 == 0) {
        uVar3 = __Znwm(0x20);
        FUN_000332e2(uVar3);
        piVar4 = (int *)FUN_0002dfa6(uVar3);
        iStack_20 = (**(code **)(*piVar4 + 0x48))(piVar4);
      }
      FUN_0003788a(iStack_20,&uStack_e,1);
      uVar5 = param_1[5] + 1;
      param_1[5] = uVar5;
    }
    if (iStack_20 != 0) {
      if (param_3 != (undefined4 *)0x0) {
        uVar3 = __Znwm(0x20);
        FUN_000332e2(uVar3);
        piVar4 = (int *)FUN_0002dfa6(uVar3);
        uVar3 = (**(code **)(*piVar4 + 0x48))(piVar4);
        *param_3 = uVar3;
        FUN_0003b118(uVar3,iStack_20);
      }
      return 1;
    }
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0024c638(int param_1,byte *param_2,int param_3,int param_4,int *param_5,int param_6)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  bool bVar4;
  float fVar5;
  float fVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  short sVar10;
  uint uVar11;
  int iStack_78;
  int iStack_74;
  short sStack_5c;
  short sStack_4c;
  int iStack_38;
  byte abStack_2c [2];
  ushort uStack_2a;
  short sStack_28;
  short sStack_26;
  byte abStack_24 [8];
  byte *apbStack_1c [3];
  
  apbStack_1c[0] = abStack_2c;
  if (*(short *)(param_1 + 0x1a) == 2) {
    apbStack_1c[1] = abStack_24;
LAB_0024c66f:
    iVar8 = 0;
    do {
      *apbStack_1c[iVar8] = *param_2;
      param_2 = param_2 + 1;
      iVar8 = iVar8 + 1;
    } while (iVar8 < *(short *)(param_1 + 0x1a));
    if (0 < *(short *)(param_1 + 0x1a)) {
      iVar8 = 0;
      do {
        *(undefined2 *)(apbStack_1c[iVar8] + 2) = *(undefined2 *)param_2;
        param_2 = param_2 + 2;
        iVar8 = iVar8 + 1;
      } while (iVar8 < *(short *)(param_1 + 0x1a));
      goto LAB_0024c6bf;
    }
  }
  else {
    apbStack_1c[1] = abStack_2c;
    if (0 < *(short *)(param_1 + 0x1a)) goto LAB_0024c66f;
LAB_0024c6bf:
    if (*(short *)(param_1 + 0x1a) < 1) goto LAB_0024c727;
    iVar8 = 0;
    do {
      *(undefined2 *)(apbStack_1c[iVar8] + 4) = *(undefined2 *)param_2;
      param_2 = param_2 + 2;
      iVar8 = iVar8 + 1;
    } while (iVar8 < *(short *)(param_1 + 0x1a));
  }
  if (0 < *(short *)(param_1 + 0x1a)) {
    iVar8 = 0;
    do {
      *(undefined2 *)(apbStack_1c[iVar8] + 6) = *(undefined2 *)param_2;
      param_2 = param_2 + 2;
      iVar8 = iVar8 + 1;
    } while (iVar8 < *(short *)(param_1 + 0x1a));
  }
LAB_0024c727:
  fVar6 = FLOAT_00365ee8;
  fVar5 = FLOAT_00365df4;
  piVar1 = (int *)(param_1 + 0x48 + (uint)abStack_2c[0] * 8);
  piVar2 = (int *)(param_1 + 0x48 + (uint)*apbStack_1c[1] * 8);
  sVar10 = *(short *)(param_1 + 0x1a);
  iStack_78 = (int)sVar10;
  if (0 < sVar10) {
    iVar8 = (param_6 - param_3) * 4;
    if (param_4 < 1) {
      if (param_3 < 1) {
        iVar8 = 1;
        do {
          bVar4 = iVar8 < iStack_78;
          iVar8 = iVar8 + 1;
        } while (bVar4);
      }
      else {
        iVar8 = 1;
        do {
          bVar4 = iVar8 < iStack_78;
          iVar8 = iVar8 + 1;
        } while (bVar4);
      }
    }
    else if (param_3 < 1) {
      iVar7 = 1;
      do {
        sVar10 = *(short *)(apbStack_1c[iVar7 + -1] + 6);
        iVar3 = param_5[iVar7 + -1];
        if (iVar3 != 0) {
          if (sVar10 < 1) {
            *(float *)(iVar3 + iVar8) = (float)(int)sVar10 * fVar5;
          }
          else {
            *(float *)(iVar3 + iVar8) = (float)(int)sVar10 / fVar6;
          }
        }
        bVar4 = iVar7 < *(short *)(param_1 + 0x1a);
        iVar7 = iVar7 + 1;
      } while (bVar4);
      sVar10 = *(short *)(param_1 + 0x1a);
    }
    else {
      iVar8 = 1;
      do {
        bVar4 = iVar8 < iStack_78;
        iVar8 = iVar8 + 1;
      } while (bVar4);
    }
    fVar6 = FLOAT_00365ee8;
    fVar5 = FLOAT_00365df4;
    iStack_78 = (int)sVar10;
    if (0 < sVar10) {
      iVar8 = ((1 - param_3) + param_6) * 4;
      if (param_4 < 2) {
        if (param_3 < 2) {
          iVar8 = 1;
          do {
            bVar4 = iVar8 < iStack_78;
            iVar8 = iVar8 + 1;
          } while (bVar4);
        }
        else {
          iVar8 = 1;
          do {
            bVar4 = iVar8 < iStack_78;
            iVar8 = iVar8 + 1;
          } while (bVar4);
        }
      }
      else if (param_3 < 2) {
        iVar7 = 1;
        do {
          sVar10 = *(short *)(apbStack_1c[iVar7 + -1] + 4);
          iVar3 = param_5[iVar7 + -1];
          if (iVar3 != 0) {
            if (sVar10 < 1) {
              *(float *)(iVar3 + iVar8) = (float)(int)sVar10 * fVar5;
            }
            else {
              *(float *)(iVar3 + iVar8) = (float)(int)sVar10 / fVar6;
            }
          }
          iStack_78 = (int)*(short *)(param_1 + 0x1a);
          bVar4 = iVar7 < iStack_78;
          iVar7 = iVar7 + 1;
        } while (bVar4);
      }
      else {
        iVar8 = 1;
        do {
          bVar4 = iVar8 < iStack_78;
          iVar8 = iVar8 + 1;
        } while (bVar4);
      }
    }
  }
  fVar6 = FLOAT_00365ee8;
  fVar5 = FLOAT_00365df4;
  iStack_78 = iStack_78 * (*(short *)(param_1 + 0x38) + -2);
  if (iStack_78 < 1) {
    return;
  }
  iStack_38 = 1;
  do {
    iStack_74 = iStack_38 + 1;
    iVar8 = (int)sStack_26 * piVar1[1] + (int)sStack_28 * *piVar1;
    if (iVar8 < 0) {
      iVar8 = iVar8 + 0xff;
    }
    uVar9 = (uint)(*param_2 >> 4);
    if ((*param_2 >> 4 & 8) == 0) {
      iVar8 = (iVar8 >> 8) + uStack_2a * uVar9;
      if (iVar8 < -0x8000) goto LAB_0024c82f;
LAB_0024ca03:
      sStack_5c = 0x7fff;
      if (iVar8 < 0x8000) {
        sStack_5c = (short)iVar8;
      }
    }
    else {
      iVar8 = (iVar8 >> 8) + (uVar9 - 0x10) * (uint)uStack_2a;
      if (-0x8001 < iVar8) goto LAB_0024ca03;
LAB_0024c82f:
      sStack_5c = -0x8000;
    }
    iVar7 = (uint)uStack_2a * *(int *)(&UNK_00365980 + uVar9 * 4);
    iVar8 = iVar7 + 0xff;
    if (-1 < iVar7) {
      iVar8 = iVar7;
    }
    iVar7 = 0x10;
    if (0xf < iVar8 >> 8) {
      iVar7 = iVar8 >> 8;
    }
    uStack_2a = (ushort)iVar7;
    sStack_26 = sStack_28;
    sStack_28 = sStack_5c;
    iVar8 = (int)*(short *)(apbStack_1c[1] + 6) * piVar2[1] +
            (int)*(short *)(apbStack_1c[1] + 4) * *piVar2;
    if (iVar8 < 0) {
      iVar8 = iVar8 + 0xff;
    }
    uVar9 = (uint)(*param_2 & 0xf);
    if ((*param_2 & 8) == 0) {
      uVar11 = (uint)*(ushort *)(apbStack_1c[1] + 2);
      iVar7 = uVar11 * uVar9;
    }
    else {
      uVar11 = (uint)*(ushort *)(apbStack_1c[1] + 2);
      iVar7 = (uVar9 - 0x10) * uVar11;
    }
    iVar7 = (iVar8 >> 8) + iVar7;
    if (iVar7 < -0x8000) {
      sStack_4c = -0x8000;
    }
    else {
      sStack_4c = 0x7fff;
      if (iVar7 < 0x8000) {
        sStack_4c = (short)iVar7;
      }
    }
    iVar7 = uVar11 * *(int *)(&UNK_00365980 + uVar9 * 4);
    iVar8 = iVar7 + 0xff;
    if (-1 < iVar7) {
      iVar8 = iVar7;
    }
    iVar7 = 0x10;
    if (0xf < iVar8 >> 8) {
      iVar7 = iVar8 >> 8;
    }
    *(short *)(apbStack_1c[1] + 2) = (short)iVar7;
    *(undefined2 *)(apbStack_1c[1] + 6) = *(undefined2 *)(apbStack_1c[1] + 4);
    *(short *)(apbStack_1c[1] + 4) = sStack_4c;
    iVar8 = *param_5;
    if (((iVar8 != 0) && (param_3 <= iStack_74)) && (iStack_74 < param_4)) {
      iVar7 = param_6 + (iStack_74 - param_3);
      if (sStack_5c < 1) {
        *(float *)(iVar8 + iVar7 * 4) = (float)(int)sStack_5c * fVar5;
      }
      else {
        *(float *)(iVar8 + iVar7 * 4) = (float)(int)sStack_5c / fVar6;
      }
    }
    if (*(short *)(param_1 + 0x1a) == 1) {
      iStack_74 = iStack_38 + 2;
      iVar8 = *param_5;
      iStack_38 = iStack_74;
      if (((iVar8 != 0) && (param_3 <= iStack_74)) && (iStack_74 < param_4)) {
        iVar7 = param_6 + (iStack_74 - param_3);
        if (0 < sStack_4c) goto LAB_0024c982;
LAB_0024ca83:
        *(float *)(iVar8 + iVar7 * 4) = (float)(int)sStack_4c * fVar5;
        iStack_38 = iStack_74;
      }
    }
    else {
      iVar8 = param_5[1];
      iStack_38 = iStack_74;
      if (((iVar8 != 0) && (param_3 <= iStack_74)) && (iStack_74 < param_4)) {
        iVar7 = param_6 + (iStack_74 - param_3);
        if (sStack_4c < 1) goto LAB_0024ca83;
LAB_0024c982:
        *(float *)(iVar8 + iVar7 * 4) = (float)(int)sStack_4c / fVar6;
        iStack_38 = iStack_74;
      }
    }
    if (iStack_78 + -2 < 1) {
      return;
    }
    iStack_78 = iStack_78 + -2;
    param_2 = param_2 + 1;
  } while( true );
}



int FUN_0028916a(int param_1,byte param_2)

{
  undefined1 *puVar1;
  int iVar2;
  int iStack_10;
  
  if ((param_2 & 1) == 0) {
    iStack_10 = FUN_00028308(8);
  }
  else {
    iStack_10 = FUN_00028308(7);
  }
  if (iStack_10 != 0) {
    puVar1 = (undefined1 *)FUN_00027abc(iStack_10);
    *puVar1 = (char)*(undefined4 *)(param_1 + 0xc);
    puVar1[1] = (char)*(undefined4 *)(param_1 + 0x10);
    puVar1[2] = (char)*(undefined4 *)(param_1 + 0x24);
    puVar1[3] = (char)*(undefined4 *)(param_1 + 0x14);
    puVar1[4] = (char)*(undefined4 *)(param_1 + 0x18);
    puVar1[5] = (char)*(undefined4 *)(param_1 + 0x1c);
    puVar1[6] = (char)*(undefined4 *)(param_1 + 0x20);
    iVar2 = FUN_000278d6(iStack_10);
    if (iVar2 == 8) {
      puVar1[7] = 0;
      return iStack_10;
    }
  }
  return iStack_10;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0017fd74(int *param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 auStack_20 [4];
  
  auStack_20[0] = 4;
  if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x428,uVar2,"this != 0");
  }
  if (param_2 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFile.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x428,uVar2,"f != 0");
  }
  cVar1 = (**(code **)(*param_1 + 0x1ac))(param_1,param_2,auStack_20);
  if (cVar1 != '\0') {
    if (param_1[5] != 0) {
      func_0x0000a85e(param_2);
    }
    return 1;
  }
  return 0;
}


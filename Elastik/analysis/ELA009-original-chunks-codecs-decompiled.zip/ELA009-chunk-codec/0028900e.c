
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0028900e(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  char acStack_1d [13];
  
  if (param_2 == 0) {
    uVar2 = FUN_00033b90("GNSoundFileCannotReadFileException");
    FUN_0000bf34(uVar2);
  }
  iVar1 = FUN_000278d6(param_2);
  if (iVar1 < 7) {
    uVar2 = FUN_00033b90("GNSoundFileFormatNotSupportedException");
    FUN_0000bf34(uVar2);
  }
  uVar2 = __Znwm(0x24);
  FUN_0017e50c(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  uVar2 = (**(code **)(*piVar3 + 0x48))(piVar3);
  FUN_0017f8a0(uVar2,param_2);
  FUN_0017f560(uVar2,0);
  FUN_00180086(uVar2,acStack_1d);
  *(int *)(param_1 + 0xc) = (int)acStack_1d[0];
  FUN_00180086(uVar2,acStack_1d);
  *(int *)(param_1 + 0x10) = (int)acStack_1d[0];
  FUN_00180086(uVar2,acStack_1d);
  *(int *)(param_1 + 0x24) = (int)acStack_1d[0];
  FUN_00180086(uVar2,acStack_1d);
  *(int *)(param_1 + 0x14) = (int)acStack_1d[0];
  FUN_00180086(uVar2,acStack_1d);
  *(int *)(param_1 + 0x18) = (int)acStack_1d[0];
  FUN_00180086(uVar2,acStack_1d);
  *(int *)(param_1 + 0x1c) = (int)acStack_1d[0];
  FUN_00180086(uVar2,acStack_1d);
  *(int *)(param_1 + 0x20) = (int)acStack_1d[0];
  return;
}


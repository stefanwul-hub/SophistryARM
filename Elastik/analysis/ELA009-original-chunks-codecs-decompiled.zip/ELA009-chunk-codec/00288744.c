
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00288744(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  uint uStack_30;
  undefined1 auStack_2c [4];
  undefined1 auStack_28 [4];
  undefined1 auStack_24 [2];
  short sStack_22;
  short sStack_20;
  short asStack_1e [7];
  
  if (param_2 == 0) {
    uVar2 = FUN_00033b90("GNSoundFileCannotReadFileException");
    FUN_0000bf34(uVar2);
  }
  iVar1 = FUN_000278d6(param_2);
  if (iVar1 != 0x18) {
    uVar2 = FUN_00033b90("GNSoundFileFormatNotSupportedException");
    FUN_0000bf34(uVar2);
  }
  uVar2 = __Znwm(0x24);
  FUN_0017e50c(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  uVar2 = (**(code **)(*piVar3 + 0x48))(piVar3);
  FUN_0017f8a0(uVar2,param_2);
  FUN_0017f560(uVar2,0);
  FUN_0017fb68(uVar2,&uStack_30);
  FUN_0017fc6e(uVar2,&sStack_20);
  FUN_0017fc6e(uVar2,auStack_24);
  FUN_0017fd74(uVar2,auStack_2c);
  FUN_0017fb68(uVar2,param_1 + 0x18);
  FUN_0017fc6e(uVar2,asStack_1e);
  FUN_0017fc6e(uVar2,&sStack_22);
  FUN_0017fd74(uVar2,auStack_28);
  *(int *)(param_1 + 0x10) = (int)sStack_22;
  *(int *)(param_1 + 0x14) = (int)asStack_1e[0];
  if (((uStack_30 & 2) == 0) || (sStack_20 == 0)) {
    *(undefined4 *)(param_1 + 0x20) = 0;
  }
  else {
    *(undefined4 *)(param_1 + 0x20) = 3;
  }
  if ((uStack_30 & 1) == 0) {
    *(undefined1 *)(param_1 + 0xc) = 1;
  }
  else {
    *(undefined4 *)(param_1 + 0x18) = 0;
  }
  if ((*(int *)(param_1 + 0x20) != 0) && (sStack_20 != 0)) {
    *(int *)(param_1 + 0x1c) = sStack_20 + -0x30;
    return;
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  return;
}


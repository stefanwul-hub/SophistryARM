
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001aafc0(int *param_1,int *param_2,int param_3)

{
  code *pcVar1;
  char cVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  
  pcVar1 = *(code **)(*param_2 + 0x88);
  uVar4 = FUN_00033b90("licenseInfo");
  cVar2 = (*pcVar1)(param_2,uVar4);
  if ((cVar2 != '\0') && (param_3 == 0)) {
    piVar3 = (int *)(**(code **)(*param_1 + 0x1a4))(param_1);
    pcVar1 = *(code **)(*piVar3 + 0x88);
    uVar4 = FUN_000715c6("not licensed","Elastik");
    cVar2 = (*pcVar1)(piVar3,uVar4);
    if (cVar2 != '\0') goto code_r0x00033b90;
  }
  pcVar1 = *(code **)(*param_2 + 0x88);
  uVar4 = FUN_00033b90("sourceFilePosixPath");
  cVar2 = (*pcVar1)(param_2,uVar4);
  if (((cVar2 == '\0') || (param_3 != 0)) || (iVar5 = FUN_001aa9c6(param_1), iVar5 != 0)) {
    return 0;
  }
code_r0x00033b90:
  if (piRam003d4050 == (int *)0x0) {
    uVar4 = __Znwm(0x38);
    FUN_0006f04a(uVar4);
    piRam003d4050 = (int *)FUN_0002dfa6(uVar4);
    (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
  }
  else {
    (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
  }
  if (iRam003d4054 == 0) {
    uVar4 = __Znwm(0x14);
    func_0x00084dba(uVar4);
    iRam003d4054 = FUN_0002dfa6(uVar4);
  }
  func_0x000854fe(iRam003d4054,"invalidTextColor");
  if (iRam003d4058 == 0) {
    uVar4 = __Znwm(0x18);
    FUN_000630b6(uVar4);
    iRam003d4058 = FUN_0002dfa6(uVar4);
    func_0x00065c4a(iRam003d4058,1);
  }
  iVar5 = func_0x0006440e(iRam003d4058,iRam003d4054);
  if (iVar5 != -1) {
    uVar4 = FUN_00063ade(iRam003d4058);
    uVar4 = FUN_0002a364(uVar4,iVar5);
    (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
    return uVar4;
  }
  uVar4 = __Znwm(0x14);
  func_0x00084dba(uVar4);
  piVar3 = (int *)FUN_0002dfa6(uVar4);
  func_0x000854fe(piVar3,"invalidTextColor");
  uVar4 = func_0x00033aa6("invalidTextColor");
  FUN_00066284(iRam003d4058,uVar4,piVar3);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x44))(piVar3);
  }
  (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
  return uVar4;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001aa090(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  undefined4 uVar3;
  
  uVar1 = __Znwm(0x20);
  FUN_00029d44(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  uVar1 = (**(code **)(*piVar2 + 0x48))(piVar2);
  uVar3 = FUN_0002dd42(param_1);
  FUN_0002bb40(uVar1,uVar3);
  if (*(int *)(param_1 + 0x10) != 0) {
    FUN_0002bb40(uVar1,*(int *)(param_1 + 0x10));
  }
  uVar3 = FUN_00033b90(" ");
  FUN_0003b278(uVar1,uVar3);
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002dd42(int *param_1)

{
  int iVar1;
  undefined4 uVar2;
  char *pcVar3;
  
  iVar1 = (**(code **)(*param_1 + 8))(param_1);
  if (iVar1 != 0) {
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    iVar1 = func_0x0001f4dc(uVar2);
    if (iVar1 == 0) {
      pcVar3 = "";
    }
    else {
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
      uVar2 = func_0x0001f4dc(uVar2);
      pcVar3 = (char *)FUN_00034962(uVar2);
    }
    FUN_0003dd2a("%s (0X%X)",pcVar3,param_1);
    return;
  }
  FUN_0003dd2a("Object (0X%X)",param_1);
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001a9e08(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  undefined *puVar6;
  undefined *puVar7;
  
  uVar1 = func_0x00107314();
  if (*(int *)(param_1 + 0x14) != 0) {
    iVar2 = FUN_000349f4(*(int *)(param_1 + 0x14));
    if (iVar2 != 0) {
      iVar2 = FUN_00029ddc(uVar1);
      if (iVar2 == 0) {
        piVar3 = (int *)FUN_00033b90("1234567890");
      }
      else {
        uVar1 = FUN_0002a364(uVar1,0);
        piVar3 = (int *)func_0x001071e2(uVar1);
      }
      iVar2 = (**(code **)(*piVar3 + 0x90))(piVar3);
      piVar3 = *(int **)(param_1 + 0x14);
      if (piVar3 == (int *)0x0) {
        iVar4 = 1;
        uVar1 = 0;
      }
      else {
        iVar4 = (**(code **)(*piVar3 + 0x90))(piVar3);
        uVar1 = *(undefined4 *)(param_1 + 0x14);
      }
      uVar5 = (uint)(iVar2 * iVar4) % 0x50cefdf;
      puVar7 = (undefined *)(uVar5 / 10000);
      puVar6 = (undefined *)(uVar5 % 10000);
      if (&UNK_00002706 < puVar7) {
        puVar7 = &UNK_00002706;
      }
      if (&UNK_00002706 < puVar6) {
        puVar6 = &UNK_00002706;
      }
      FUN_0003dd2a("%@-%04i-%04i",uVar1,puVar7,puVar6);
      return;
    }
  }
  uVar1 = __Znwm(0x20);
  func_0x000332e2(uVar1);
  piVar3 = (int *)FUN_0002dfa6(uVar1);
                    /* WARNING: Could not recover jumptable at 0x001a9e60. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*piVar3 + 0x48))();
  return;
}


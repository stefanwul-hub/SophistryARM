
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0003b278(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  
  puVar1 = (undefined4 *)__Znwm(0x20);
  func_0x0002dc66(puVar1);
  *puVar1 = &UNK_0036ec68;
  *(undefined1 *)(puVar1 + 6) = 1;
  puVar1[3] = 0;
  puVar1[4] = 0;
  puVar1[5] = 0xffffffff;
  puVar1[7] = 0xffffffff;
  piVar2 = (int *)FUN_0002dfa6(puVar1);
  iVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
  iVar7 = 0;
  while( true ) {
    iVar5 = FUN_00029ddc(param_1);
    if (iVar5 <= iVar7) break;
    if (iVar7 != 0) {
      func_0x0003b118(iVar3,param_2);
    }
    uVar4 = FUN_0002a364(param_1,iVar7);
    func_0x0003b118(iVar3,uVar4);
    iVar7 = iVar7 + 1;
  }
  if (iVar3 != 0) {
    *(undefined1 *)(iVar3 + 0x18) = 0;
    return iVar3;
  }
  uVar4 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                         );
  uVar6 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0xd8,uVar4,"this != 0");
  mach_header_00000000.flags._0_1_ = 0;
  return 0;
}


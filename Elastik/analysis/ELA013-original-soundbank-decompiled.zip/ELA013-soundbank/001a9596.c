
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_001a9596(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  
  if (iRam003d4a3c != 0) {
    return iRam003d4a3c;
  }
  uVar1 = FUN_00033b90("GNObject");
  uVar2 = FUN_00033b90("ETSoundbank");
  iVar3 = FUN_0001fe74(uVar2,&UNK_001aa5d8,uVar1);
  uStack_28 = 0x10;
  uStack_24 = 4;
  iRam003d4a3c = iVar3;
  uStack_20 = FUN_00033b90("_identifier");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_001000ae(0x40);
  uVar2 = FUN_00033b90("_identifier");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000aa362(uVar2,uVar1);
  FUN_0002035a(iVar3,uVar1);
  uStack_28 = 0x1c;
  uStack_24 = 4;
  uStack_20 = FUN_00033b90("_sourceFilePosixPath");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_00033b90("GNString");
  uVar1 = FUN_00100532(uVar1);
  uVar2 = FUN_00033b90("_sourceFilePosixPath");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000aa362(uVar2,uVar1);
  FUN_0002035a(iVar3,uVar1);
  uStack_28 = 0x20;
  uStack_24 = 4;
  uStack_20 = FUN_00033b90("_rootFilePath");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_00033b90("GNFilePath");
  uVar2 = FUN_00033b90("_rootFilePath");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000fe3a4(uVar2,uVar1);
  FUN_000204a2(iVar3,uVar1);
  uStack_28 = 0x14;
  uStack_24 = 4;
  uStack_20 = FUN_00033b90("_serialNumber");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_00033b90("GNString");
  uVar1 = FUN_00100532(uVar1);
  uVar2 = FUN_00033b90("_serialNumber");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000aa362(uVar2,uVar1);
  FUN_0002035a(iVar3,uVar1);
  uStack_28 = 0x18;
  uStack_24 = 4;
  uStack_20 = FUN_00033b90("_responseCode");
  FUN_00020c18(iVar3,&uStack_28);
  uVar1 = FUN_00033b90("GNString");
  uVar1 = FUN_00100532(uVar1);
  uVar2 = FUN_00033b90("_responseCode");
  uVar2 = FUN_0003b05e(uVar2,1);
  uVar1 = FUN_000aa362(uVar2,uVar1);
  FUN_0002035a(iVar3,uVar1);
  return iRam003d4a3c;
}


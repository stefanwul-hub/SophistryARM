
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00031dac(char *param_1,undefined4 param_2,undefined4 param_3,char *param_4)

{
  undefined4 *puVar1;
  char *pcVar2;
  int iVar3;
  undefined4 uVar4;
  char *pcVar5;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  bool bVar9;
  
  pcVar2 = (char *)FUN_00041c54(param_3,param_2);
  if (*pcVar2 == '@') {
    iVar3 = _strchr(param_1,0x2a);
    bVar9 = iVar3 == 0;
    if (bVar9) {
      iVar3 = 5;
      pcVar5 = param_1;
      pcVar7 = "bool";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        puVar1 = *(undefined4 **)(pcVar2 + 8);
        uVar4 = func_0x00085800((int)*param_4);
        *puVar1 = uVar4;
        return;
      }
      iVar3 = 5;
      pcVar5 = param_1;
      pcVar7 = "char";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        puVar1 = *(undefined4 **)(pcVar2 + 8);
        uVar4 = func_0x00184080((int)*param_4);
        *puVar1 = uVar4;
        return;
      }
      iVar3 = 4;
      pcVar5 = param_1;
      pcVar7 = "int";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        puVar1 = *(undefined4 **)(pcVar2 + 8);
        uVar4 = FUN_000858da(*(undefined4 *)param_4);
        *puVar1 = uVar4;
        return;
      }
      iVar3 = 6;
      pcVar5 = param_1;
      pcVar7 = "float";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        puVar1 = *(undefined4 **)(pcVar2 + 8);
        uVar4 = func_0x00085a2c(*(undefined4 *)param_4);
        *puVar1 = uVar4;
        return;
      }
      iVar3 = 7;
      pcVar5 = param_1;
      pcVar7 = "double";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        puVar1 = *(undefined4 **)(pcVar2 + 8);
        uVar4 = func_0x00085b14(*(undefined8 *)param_4);
        *puVar1 = uVar4;
        return;
      }
      iVar3 = 8;
      pcVar5 = param_1;
      pcVar7 = "GNRange";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        puVar1 = *(undefined4 **)(pcVar2 + 8);
        uVar4 = func_0x00183f68(*(undefined4 *)param_4,*(undefined4 *)(param_4 + 4));
        *puVar1 = uVar4;
        return;
      }
      iVar3 = 7;
      pcVar5 = param_1;
      pcVar7 = "GNRect";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        puVar1 = *(undefined4 **)(pcVar2 + 8);
        uVar4 = func_0x00183e0c(*(undefined4 *)param_4,*(undefined4 *)(param_4 + 4),
                                *(undefined4 *)(param_4 + 8),*(undefined4 *)(param_4 + 0xc));
        *puVar1 = uVar4;
        return;
      }
      iVar3 = 8;
      pcVar5 = param_1;
      pcVar7 = "GNPoint";
      do {
        pcVar6 = pcVar5;
        pcVar8 = pcVar7;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar8 = pcVar7 + 1;
        pcVar6 = pcVar5 + 1;
        bVar9 = *pcVar5 == *pcVar7;
        pcVar5 = pcVar6;
        pcVar7 = pcVar8;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
      }
      bVar9 = iVar3 == 0;
      if (bVar9) {
        puVar1 = *(undefined4 **)(pcVar2 + 8);
        uVar4 = func_0x00183edc(*(undefined4 *)param_4,*(undefined4 *)(param_4 + 4));
        *puVar1 = uVar4;
        return;
      }
      iVar3 = 7;
      pcVar5 = "GNSize";
      do {
        pcVar7 = param_1;
        pcVar6 = pcVar5;
        if (iVar3 == 0) break;
        iVar3 = iVar3 + -1;
        pcVar6 = pcVar5 + 1;
        pcVar7 = param_1 + 1;
        bVar9 = *param_1 == *pcVar5;
        param_1 = pcVar7;
        pcVar5 = pcVar6;
      } while (bVar9);
      iVar3 = 0;
      if (!bVar9) {
        iVar3 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar6[-1];
      }
      if (iVar3 == 0) {
        puVar1 = *(undefined4 **)(pcVar2 + 8);
        uVar4 = func_0x00183ff4(*(undefined4 *)param_4,*(undefined4 *)(param_4 + 4));
        *puVar1 = uVar4;
        return;
      }
      FUN_0000ab14("GNSetTypedMethodInvocationArgumentPointerAtIndex() failed.");
    }
  }
  _memcpy(*(undefined4 *)(pcVar2 + 8),param_4,*(undefined4 *)(pcVar2 + 4));
  return;
}


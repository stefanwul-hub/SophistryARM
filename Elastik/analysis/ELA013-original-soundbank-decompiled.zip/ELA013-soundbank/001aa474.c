
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001aa474(int *param_1,char *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  char *pcVar5;
  char *pcVar6;
  char *pcVar7;
  char *pcVar8;
  bool bVar9;
  
  bVar9 = &stack0x00000000 == section_00000054.segname + 8;
  iVar4 = 0x11;
  pcVar5 = param_2;
  pcVar7 = "getChallangeCode";
  do {
    pcVar6 = pcVar5;
    pcVar8 = pcVar7;
    if (iVar4 == 0) break;
    iVar4 = iVar4 + -1;
    pcVar8 = pcVar7 + 1;
    pcVar6 = pcVar5 + 1;
    bVar9 = *pcVar5 == *pcVar7;
    pcVar5 = pcVar6;
    pcVar7 = pcVar8;
  } while (bVar9);
  iVar4 = 0;
  if (!bVar9) {
    iVar4 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
  }
  bVar9 = iVar4 == 0;
  if (bVar9) {
    FUN_001a9e08();
  }
  else {
    iVar4 = 0xf;
    pcVar5 = param_2;
    pcVar7 = "getLicenseInfo";
    do {
      pcVar6 = pcVar5;
      pcVar8 = pcVar7;
      if (iVar4 == 0) break;
      iVar4 = iVar4 + -1;
      pcVar8 = pcVar7 + 1;
      pcVar6 = pcVar5 + 1;
      bVar9 = *pcVar5 == *pcVar7;
      pcVar5 = pcVar6;
      pcVar7 = pcVar8;
    } while (bVar9);
    iVar4 = 0;
    if (!bVar9) {
      iVar4 = (uint)(byte)pcVar6[-1] - (uint)(byte)pcVar8[-1];
    }
    bVar9 = iVar4 == 0;
    if (!bVar9) {
      iVar4 = 0x10;
      pcVar5 = "setResponseCode";
      do {
        pcVar7 = param_2;
        pcVar6 = pcVar5;
        if (iVar4 == 0) break;
        iVar4 = iVar4 + -1;
        pcVar6 = pcVar5 + 1;
        pcVar7 = param_2 + 1;
        bVar9 = *param_2 == *pcVar5;
        param_2 = pcVar7;
        pcVar5 = pcVar6;
      } while (bVar9);
      iVar4 = 0;
      if (!bVar9) {
        iVar4 = (uint)(byte)pcVar7[-1] - (uint)(byte)pcVar6[-1];
      }
      if (iVar4 == 0) {
        piVar3 = (int *)FUN_00031a5c();
        piVar3 = (int *)*piVar3;
        piVar1 = (int *)param_1[6];
        if (piVar3 != piVar1) {
          if (piVar1 != (int *)0x0) {
            (**(code **)(*piVar1 + 0x44))();
          }
          param_1[6] = (int)piVar3;
          if (piVar3 != (int *)0x0) {
            (**(code **)(*piVar3 + 0x40))();
            return 0;
          }
        }
        return 0;
      }
      uVar2 = FUN_000320ba();
      return uVar2;
    }
    (**(code **)(*param_1 + 0x1a4))();
  }
  FUN_00031dac();
  iVar4 = FUN_00041c54();
  return **(undefined4 **)(iVar4 + 8);
}


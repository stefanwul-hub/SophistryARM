
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001a8162(int param_1,undefined **param_2)

{
  code *pcVar1;
  char cVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  int *piVar7;
  int iVar8;
  dword *pdVar9;
  int aiStack_178 [7];
  undefined8 uStack_15c;
  char *pcStack_154;
  int iStack_150;
  char *pcStack_14c;
  char *pcStack_130;
  char *pcStack_12c;
  char *pcStack_128;
  char *pcStack_124;
  undefined4 uStack_120;
  int *piStack_11c;
  dword *pdStack_118;
  int iStack_114;
  int iStack_110;
  undefined *puStack_10c;
  int iStack_108;
  uint uStack_104;
  uint uStack_100;
  uint uStack_fc;
  uint uStack_f8;
  int iStack_f4;
  undefined4 uStack_f0;
  undefined1 auStack_ec [6];
  char cStack_e6;
  undefined1 auStack_dc [5];
  char cStack_d7;
  undefined *apuStack_cc [4];
  undefined1 auStack_bc [8];
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined1 auStack_ac [7];
  char cStack_a5;
  undefined1 auStack_9c [4];
  char cStack_98;
  undefined4 uStack_2c;
  int *piStack_28;
  undefined4 uStack_24;
  dword *apdStack_20 [4];
  
  piVar7 = (int *)&uStack_15c;
  uStack_15c._0_4_ = "$\x03";
  aiStack_178[6] = 0x1a817f;
  uVar4 = __Znwm();
  aiStack_178[6] = 0x1a8189;
  uStack_15c._0_4_ = (char *)uVar4;
  FUN_00029d44();
  aiStack_178[6] = 0x1a8191;
  uStack_15c._0_4_ = (char *)uVar4;
  uStack_15c._0_4_ = (char *)FUN_0002dfa6();
  aiStack_178[6] = 0x1a8199;
  uStack_120 = (**(code **)(*(int *)(char *)uStack_15c + 0x48))();
  apdStack_20[0] = (dword *)0x0;
  uStack_24 = 0;
  piStack_28 = (int *)0x0;
  uStack_15c._0_4_ = (char *)0x0;
  uStack_15c._4_4_ = (char *)0x0;
  aiStack_178[6] = 0x1a81c8;
  iStack_f4 = func_0x001a7f58();
  if (param_1 == 0) {
    uStack_15c._0_4_ = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDate.cpp";
    aiStack_178[6] = 0x1a898c;
    iVar6 = func_0x0000a930();
    uStack_15c._0_4_ = "GNAssertionException";
    aiStack_178[6] = 0x1a899c;
    uStack_15c._0_4_ = (char *)FUN_00033b90();
    pcStack_14c = "dateString";
    pcStack_154 = section_00000230.segname + 0xc;
    uStack_15c._4_4_ = "Assertion failed in line %d of %s: %s.";
    aiStack_178[6] = 0x1a89c4;
    iStack_150 = iVar6;
    FUN_0000bfd6();
  }
  if (param_2 == (undefined **)0x0) {
    uStack_15c._0_4_ = "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDate.cpp";
    aiStack_178[6] = 0x1a8941;
    iVar6 = func_0x0000a930();
    uStack_15c._0_4_ = "GNAssertionException";
    aiStack_178[6] = 0x1a8951;
    uStack_15c._0_4_ = (char *)FUN_00033b90();
    pcStack_14c = "formatString";
    pcStack_154 = section_00000230.segname + 0xc;
    uStack_15c._4_4_ = "Assertion failed in line %d of %s: %s.";
    aiStack_178[6] = 0x1a8979;
    iStack_150 = iVar6;
    FUN_0000bfd6();
  }
  uStack_15c._0_4_ = (char *)param_2;
  aiStack_178[6] = 0x1a81ef;
  piVar5 = (int *)func_0x0018bc7c();
  pcStack_12c = "%";
  pcStack_130 = (char *)apdStack_20;
LAB_001a8206:
  aiStack_178[6] = 0x1a8211;
  uStack_15c._0_4_ = (char *)piVar5;
  cVar2 = (**(code **)(*piVar5 + 0x1b4))();
  if (cVar2 == '\0') {
    while( true ) {
      pcVar1 = *(code **)(*piVar5 + 0x1d4);
      uStack_15c._0_4_ = pcStack_12c;
      aiStack_178[6] = 0x1a822f;
      uStack_15c._4_4_ = (char *)FUN_00033b90();
      pcStack_154 = pcStack_130;
      aiStack_178[6] = 0x1a8242;
      uStack_15c._0_4_ = (char *)piVar5;
      (*pcVar1)();
      if (apdStack_20[0] != (dword *)0x0) {
        uStack_15c._0_4_ = (char *)apdStack_20[0];
        aiStack_178[6] = 0x1a8251;
        iVar6 = FUN_000349f4();
        if (iVar6 != 0) {
          uStack_15c._4_4_ = (char *)apdStack_20[0];
          uStack_15c._0_4_ = (char *)uStack_120;
          aiStack_178[6] = 0x1a8404;
          FUN_0002bb40();
        }
      }
      pcStack_154 = pcStack_130;
      uStack_15c._4_4_ = (char *)((int)&mach_header_00000000.magic + 2);
      aiStack_178[6] = 0x1a8276;
      uStack_15c._0_4_ = (char *)piVar5;
      cVar2 = (**(code **)(*piVar5 + 0x1d8))();
      if (cVar2 == '\0') goto LAB_001a8206;
      pcVar1 = *(code **)(*apdStack_20[0] + 0x88);
      uStack_15c._0_4_ = "%%";
      aiStack_178[6] = 0x1a8293;
      uStack_15c._4_4_ = (char *)FUN_00033b90();
      uStack_15c._0_4_ = (char *)apdStack_20[0];
      aiStack_178[6] = 0x1a829f;
      cVar2 = (*pcVar1)();
      if (cVar2 == '\0') break;
      uStack_15c._0_4_ = pcStack_12c;
      aiStack_178[6] = 0x1a82b5;
      uStack_15c._4_4_ = (char *)FUN_00033b90();
      uStack_15c._0_4_ = (char *)uStack_120;
      aiStack_178[6] = 0x1a82c7;
      FUN_0002bb40();
      aiStack_178[6] = 0x1a82d2;
      uStack_15c._0_4_ = (char *)piVar5;
      cVar2 = (**(code **)(*piVar5 + 0x1b4))();
      if (cVar2 != '\0') goto LAB_001a82da;
    }
    uStack_15c._4_4_ = (char *)apdStack_20[0];
    uStack_15c._0_4_ = (char *)uStack_120;
    aiStack_178[6] = 0x1a841e;
    FUN_0002bb40();
    goto LAB_001a8206;
  }
LAB_001a82da:
  uStack_15c._0_4_ = (char *)param_1;
  aiStack_178[6] = 0x1a82e5;
  piStack_11c = (int *)func_0x0018bc7c();
  iVar8 = 0;
  iStack_114 = 0x7fffffff;
  iStack_110 = 0x7fffffff;
  puStack_10c = (undefined *)0x7fffffff;
  iStack_108 = 0x7fffffff;
  uStack_104 = 0x7fffffff;
  uStack_100 = 0x7fffffff;
  uStack_fc = 0x7fffffff;
  uStack_f8 = 0x7fffffff;
  uStack_15c._0_4_ = (char *)uStack_120;
  aiStack_178[6] = 0x1a834b;
  iVar6 = FUN_00029ddc();
  if (0 < iVar6) {
LAB_001a834f:
    uStack_15c._0_4_ = (char *)uStack_120;
    aiStack_178[6] = 0x1a8361;
    uStack_15c._4_4_ = (char *)iVar8;
    apdStack_20[0] = (dword *)FUN_0002a364();
    uStack_15c._0_4_ = (char *)uStack_120;
    aiStack_178[6] = 0x1a8372;
    iVar6 = FUN_00029ddc();
    if (iVar8 < iVar6 + -1) {
      uStack_15c._4_4_ = (char *)(iVar8 + 1);
      uStack_15c._0_4_ = (char *)uStack_120;
      aiStack_178[6] = 0x1a8551;
      pdStack_118 = (dword *)FUN_0002a364();
    }
    else {
      pdStack_118 = (dword *)0x0;
    }
    iVar8 = iVar8 + 1;
    uStack_15c._0_4_ = "%";
    aiStack_178[6] = 0x1a8398;
    uStack_15c._4_4_ = (char *)FUN_00033b90();
    uStack_15c._0_4_ = (char *)apdStack_20[0];
    aiStack_178[6] = 0x1a83a7;
    cVar2 = func_0x000374b2();
    if (cVar2 == '\0') goto LAB_001a83ad;
    uStack_15c._0_4_ = (char *)apdStack_20[0];
    aiStack_178[6] = 0x1a842e;
    iVar6 = FUN_000349f4();
    if (iVar6 != 2) goto LAB_001a83ad;
    uStack_15c._4_4_ = (char *)((int)&mach_header_00000000.magic + 1);
    uStack_15c._0_4_ = (char *)apdStack_20[0];
    aiStack_178[6] = 0x1a844a;
    uVar3 = func_0x00035d80();
    switch(uVar3) {
    case 0x44:
      pcVar1 = *(code **)(*piStack_11c + 0x1d4);
      aiStack_178[6] = 0x1a8cc3;
      uStack_15c._4_4_ = (char *)func_0x0003401a();
      pcStack_154 = (char *)&uStack_24;
      uStack_15c._0_4_ = (char *)piStack_11c;
      aiStack_178[6] = 0x1a8cd9;
      cVar2 = (*pcVar1)();
      if (cVar2 != '\0') {
        uStack_15c._0_4_ = "+";
        aiStack_178[6] = 0x1a8cef;
        uStack_15c._4_4_ = (char *)FUN_00033b90();
        uStack_15c._0_4_ = (char *)uStack_24;
        aiStack_178[6] = 0x1a8cfe;
        cVar2 = func_0x000374b2();
        if (cVar2 == '\0') {
          uStack_15c._0_4_ = "-";
          aiStack_178[6] = 0x1a8d10;
          uStack_15c._4_4_ = (char *)FUN_00033b90();
          uStack_15c._0_4_ = (char *)uStack_24;
          aiStack_178[6] = 0x1a8d1f;
          cVar2 = func_0x000374b2();
          if (cVar2 == '\0') break;
        }
        uStack_15c._0_4_ = (char *)uStack_24;
        aiStack_178[6] = 0x1a8d32;
        iStack_108 = func_0x00034584();
        iStack_108 = iStack_108 * 0x15180;
      }
      break;
    case 0x48:
      uStack_2c = 0;
      if (piStack_11c == (int *)0x0) {
code_r0x001a8ff2:
        uStack_104 = 0x7fffffff;
        break;
      }
      if (pdStack_118 == (dword *)0x0) {
        pcStack_124 = (char *)&uStack_2c;
code_r0x001a8fbb:
        pdVar9 = (dword *)((int)&mach_header_00000000.magic + 2);
        do {
          pcStack_154 = pcStack_124;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8fe5;
          uStack_15c._4_4_ = (char *)pdVar9;
          cVar2 = (**(code **)(*piStack_11c + 0x1d8))();
          if (cVar2 != '\0') {
            uStack_15c._0_4_ = (char *)uStack_2c;
            aiStack_178[6] = 0x1a94bb;
            uStack_104 = func_0x00034584();
            goto LAB_001a85a6;
          }
          pdVar9 = (dword *)((int)pdVar9 + -1);
        } while (pdVar9 != (dword *)0x0);
        goto code_r0x001a8ff2;
      }
      pcStack_154 = (char *)&uStack_2c;
      uStack_15c._4_4_ = (char *)pdStack_118;
      uStack_15c._0_4_ = (char *)piStack_11c;
      aiStack_178[6] = 0x1a8fb3;
      pcStack_124 = pcStack_154;
      cVar2 = (**(code **)(*piStack_11c + 0x1c8))();
      if (cVar2 == '\0') goto code_r0x001a8fbb;
      uStack_15c._0_4_ = (char *)uStack_2c;
      aiStack_178[6] = 0x1a9088;
      uStack_104 = func_0x00034584();
      goto code_r0x001a85b4;
    case 0x49:
      uStack_2c = 0;
      if (piStack_11c != (int *)0x0) {
        if (pdStack_118 == (dword *)0x0) {
          pcStack_124 = (char *)&uStack_2c;
        }
        else {
          pcStack_154 = (char *)&uStack_2c;
          uStack_15c._4_4_ = (char *)pdStack_118;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8f18;
          pcStack_124 = pcStack_154;
          cVar2 = (**(code **)(*piStack_11c + 0x1c8))();
          if (cVar2 != '\0') {
            uStack_15c._0_4_ = (char *)uStack_2c;
            aiStack_178[6] = 0x1a9072;
            uStack_100 = func_0x00034584();
            goto code_r0x001a85b4;
          }
        }
        pdVar9 = (dword *)((int)&mach_header_00000000.magic + 2);
        do {
          pcStack_154 = pcStack_124;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8f4a;
          uStack_15c._4_4_ = (char *)pdVar9;
          cVar2 = (**(code **)(*piStack_11c + 0x1d8))();
          if (cVar2 != '\0') {
            uStack_15c._0_4_ = (char *)uStack_2c;
            aiStack_178[6] = 0x1a94a5;
            uStack_100 = func_0x00034584();
            goto LAB_001a85a6;
          }
          pdVar9 = (dword *)((int)pdVar9 + -1);
        } while (pdVar9 != (dword *)0x0);
      }
      uStack_100 = 0x7fffffff;
      break;
    case 0x4d:
      uStack_2c = 0;
      if (piStack_11c != (int *)0x0) {
        if (pdStack_118 == (dword *)0x0) {
          pcStack_124 = (char *)&uStack_2c;
        }
        else {
          pcStack_154 = (char *)&uStack_2c;
          uStack_15c._4_4_ = (char *)pdStack_118;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8c62;
          pcStack_124 = pcStack_154;
          cVar2 = (**(code **)(*piStack_11c + 0x1c8))();
          if (cVar2 != '\0') {
            uStack_15c._0_4_ = (char *)uStack_2c;
            aiStack_178[6] = 0x1a905c;
            uStack_fc = func_0x00034584();
            goto code_r0x001a85b4;
          }
        }
        pdVar9 = (dword *)((int)&mach_header_00000000.magic + 2);
        do {
          pcStack_154 = pcStack_124;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8c94;
          uStack_15c._4_4_ = (char *)pdVar9;
          cVar2 = (**(code **)(*piStack_11c + 0x1d8))();
          if (cVar2 != '\0') {
            uStack_15c._0_4_ = (char *)uStack_2c;
            aiStack_178[6] = 0x1a94d1;
            uStack_fc = func_0x00034584();
            goto LAB_001a85a6;
          }
          pdVar9 = (dword *)((int)pdVar9 + -1);
        } while (pdVar9 != (dword *)0x0);
      }
      uStack_fc = 0x7fffffff;
      break;
    case 0x53:
      uStack_2c = 0;
      if (piStack_11c != (int *)0x0) {
        if (pdStack_118 == (dword *)0x0) {
          pcStack_124 = (char *)&uStack_2c;
        }
        else {
          pcStack_154 = (char *)&uStack_2c;
          uStack_15c._4_4_ = (char *)pdStack_118;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8bf7;
          pcStack_124 = pcStack_154;
          cVar2 = (**(code **)(*piStack_11c + 0x1c8))();
          if (cVar2 != '\0') {
            uStack_15c._0_4_ = (char *)uStack_2c;
            aiStack_178[6] = 0x1a8c0a;
            uStack_f8 = func_0x00034584();
            goto code_r0x001a85b4;
          }
        }
        pdVar9 = (dword *)((int)&mach_header_00000000.magic + 2);
        do {
          pcStack_154 = pcStack_124;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a858f;
          uStack_15c._4_4_ = (char *)pdVar9;
          cVar2 = (**(code **)(*piStack_11c + 0x1d8))();
          if (cVar2 != '\0') {
            uStack_15c._0_4_ = (char *)uStack_2c;
            aiStack_178[6] = 0x1a946a;
            uStack_f8 = func_0x00034584();
            goto LAB_001a85a6;
          }
          pdVar9 = (dword *)((int)pdVar9 + -1);
        } while (pdVar9 != (dword *)0x0);
      }
      uStack_f8 = 0x7fffffff;
      break;
    case 0x59:
      if (pdStack_118 == (dword *)0x0) {
        pcStack_128 = (char *)&uStack_24;
code_r0x001a90b2:
        pcStack_154 = pcStack_128;
        uStack_15c._4_4_ = (char *)&mach_header_00000000.cputype;
        uStack_15c._0_4_ = (char *)piStack_11c;
        aiStack_178[6] = 0x1a90db;
        cVar2 = (**(code **)(*piStack_11c + 0x1d8))();
        if (cVar2 == '\0') break;
      }
      else {
        pcStack_154 = (char *)&uStack_24;
        uStack_15c._4_4_ = (char *)pdStack_118;
        uStack_15c._0_4_ = (char *)piStack_11c;
        aiStack_178[6] = 0x1a8b88;
        pcStack_128 = pcStack_154;
        cVar2 = (**(code **)(*piStack_11c + 0x1c8))();
        if (cVar2 == '\0') goto code_r0x001a90b2;
      }
      uStack_15c._0_4_ = (char *)uStack_24;
      aiStack_178[6] = 0x1a8b9b;
      puStack_10c = (undefined *)func_0x00034584();
      break;
    case 100:
      uStack_2c = 0;
      if (piStack_11c != (int *)0x0) {
        if (pdStack_118 == (dword *)0x0) {
          pcStack_124 = (char *)&uStack_2c;
        }
        else {
          pcStack_154 = (char *)&uStack_2c;
          uStack_15c._4_4_ = (char *)pdStack_118;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8afe;
          pcStack_124 = pcStack_154;
          cVar2 = (**(code **)(*piStack_11c + 0x1c8))();
          if (cVar2 != '\0') {
code_r0x001a9001:
            uStack_15c._0_4_ = (char *)uStack_2c;
            aiStack_178[6] = 0x1a900c;
            iStack_114 = func_0x00034584();
            goto code_r0x001a85b4;
          }
        }
        pdVar9 = (dword *)((int)&mach_header_00000000.magic + 2);
        do {
          pcStack_154 = pcStack_124;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8b30;
          uStack_15c._4_4_ = (char *)pdVar9;
          cVar2 = (**(code **)(*piStack_11c + 0x1d8))();
          if (cVar2 != '\0') goto code_r0x001a9449;
          pdVar9 = (dword *)((int)pdVar9 + -1);
        } while (pdVar9 != (dword *)0x0);
      }
      goto code_r0x001a8b3d;
    case 0x65:
      uStack_2c = 0;
      if (piStack_11c != (int *)0x0) {
        if (pdStack_118 == (dword *)0x0) {
          pcStack_124 = (char *)&uStack_2c;
        }
        else {
          pcStack_154 = (char *)&uStack_2c;
          uStack_15c._4_4_ = (char *)pdStack_118;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8a6c;
          pcStack_124 = pcStack_154;
          cVar2 = (**(code **)(*piStack_11c + 0x1c8))();
          if (cVar2 != '\0') goto code_r0x001a9001;
        }
        pdVar9 = (dword *)((int)&mach_header_00000000.magic + 2);
        do {
          pcStack_154 = pcStack_124;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8a9e;
          uStack_15c._4_4_ = (char *)pdVar9;
          cVar2 = (**(code **)(*piStack_11c + 0x1d8))();
          if (cVar2 != '\0') goto code_r0x001a9449;
          pdVar9 = (dword *)((int)pdVar9 + -1);
        } while (pdVar9 != (dword *)0x0);
      }
code_r0x001a8b3d:
      iStack_114 = 0x7fffffff;
      break;
    case 0x6d:
      uStack_2c = 0;
      if (piStack_11c != (int *)0x0) {
        if (pdStack_118 == (dword *)0x0) {
          pcStack_124 = (char *)&uStack_2c;
        }
        else {
          pcStack_154 = (char *)&uStack_2c;
          uStack_15c._4_4_ = (char *)pdStack_118;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8e7d;
          pcStack_124 = pcStack_154;
          cVar2 = (**(code **)(*piStack_11c + 0x1c8))();
          if (cVar2 != '\0') {
            uStack_15c._0_4_ = (char *)uStack_2c;
            aiStack_178[6] = 0x1a909e;
            iStack_110 = func_0x00034584();
            goto code_r0x001a85b4;
          }
        }
        pdVar9 = (dword *)((int)&mach_header_00000000.magic + 2);
        do {
          pcStack_154 = pcStack_124;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8eaf;
          uStack_15c._4_4_ = (char *)pdVar9;
          cVar2 = (**(code **)(*piStack_11c + 0x1d8))();
          if (cVar2 != '\0') {
            uStack_15c._0_4_ = (char *)uStack_2c;
            aiStack_178[6] = 0x1a9480;
            iStack_110 = func_0x00034584();
            goto LAB_001a85a6;
          }
          pdVar9 = (dword *)((int)pdVar9 + -1);
        } while (pdVar9 != (dword *)0x0);
      }
      iStack_110 = 0x7fffffff;
      break;
    case 0x70:
      pcStack_154 = (char *)&piStack_28;
      uStack_15c._4_4_ = (char *)((int)&mach_header_00000000.magic + 2);
      uStack_15c._0_4_ = (char *)piStack_11c;
      aiStack_178[6] = 0x1a8e12;
      (**(code **)(*piStack_11c + 0x1d8))();
      if (piStack_28 != (int *)0x0) {
        uStack_15c._0_4_ = (char *)piStack_28;
        aiStack_178[6] = 0x1a8e28;
        piStack_28 = (int *)(**(code **)(*piStack_28 + 0x1b8))();
      }
      break;
    case 0x79:
      uStack_2c = 0;
      if (piStack_11c != (int *)0x0) {
        if (pdStack_118 == (dword *)0x0) {
          pcStack_124 = (char *)&uStack_2c;
        }
        else {
          pcStack_154 = (char *)&uStack_2c;
          uStack_15c._4_4_ = (char *)pdStack_118;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8d9e;
          pcStack_124 = pcStack_154;
          cVar2 = (**(code **)(*piStack_11c + 0x1c8))();
          if (cVar2 != '\0') {
code_r0x001a9017:
            uStack_15c._0_4_ = (char *)uStack_2c;
            aiStack_178[6] = 0x1a9022;
            puStack_10c = (undefined *)func_0x00034584();
            if ((int)puStack_10c < 100) {
              if ((int)puStack_10c < 0x15) {
                puStack_10c = puStack_10c + 2000;
              }
              else {
                puStack_10c = puStack_10c + 0x76c;
              }
            }
            break;
          }
        }
        pdVar9 = (dword *)((int)&mach_header_00000000.magic + 2);
        do {
          pcStack_154 = pcStack_124;
          uStack_15c._0_4_ = (char *)piStack_11c;
          aiStack_178[6] = 0x1a8dd0;
          uStack_15c._4_4_ = (char *)pdVar9;
          cVar2 = (**(code **)(*piStack_11c + 0x1d8))();
          if (cVar2 != '\0') goto code_r0x001a9017;
          pdVar9 = (dword *)((int)pdVar9 + -1);
        } while (pdVar9 != (dword *)0x0);
      }
      puStack_10c = (undefined *)0x7fffffff;
    }
    goto LAB_001a85a6;
  }
LAB_001a83bf:
  if (iStack_108 != 0x7fffffff) {
    uStack_15c = (double)iStack_108;
    aiStack_178[6] = 0x1a83e1;
    uVar4 = func_0x001a7f58();
    return uVar4;
  }
  if (uStack_100 != 0x7fffffff) {
    if (0xc < uStack_100) {
      return 0;
    }
    if (piStack_28 != (int *)0x0) {
      pcVar1 = *(code **)(*piStack_28 + 0x88);
      uStack_15c._0_4_ = "AM";
      aiStack_178[6] = 0x1a88b4;
      uStack_15c._4_4_ = (char *)FUN_00033b90();
      uStack_15c._0_4_ = (char *)piStack_28;
      aiStack_178[6] = 0x1a88c0;
      cVar2 = (*pcVar1)();
      if (cVar2 == '\0') {
        if (piStack_28 == (int *)0x0) {
          return 0;
        }
        pcVar1 = *(code **)(*piStack_28 + 0x88);
        uStack_15c._0_4_ = "PM";
        aiStack_178[6] = 0x1a88e5;
        uStack_15c._4_4_ = (char *)FUN_00033b90();
        uStack_15c._0_4_ = (char *)piStack_28;
        aiStack_178[6] = 0x1a88f1;
        cVar2 = (*pcVar1)();
        if (cVar2 == '\0') {
          return 0;
        }
        uStack_104 = uStack_100 + 0xc;
        goto LAB_001a85f4;
      }
    }
    uStack_104 = uStack_100;
  }
LAB_001a85f4:
  if ((puStack_10c != (undefined *)0x7fffffff) && (&UNK_0000270f < puStack_10c)) {
    return 0;
  }
  if ((iStack_110 != 0x7fffffff) && (0xb < iStack_110 - 1U)) {
    return 0;
  }
  if ((iStack_114 != 0x7fffffff) && (0x1e < iStack_114 - 1U)) {
    return 0;
  }
  if ((uStack_104 != 0x7fffffff) && (0x18 < uStack_104)) {
    return 0;
  }
  if ((uStack_fc != 0x7fffffff) && (0x3c < uStack_fc)) {
    return 0;
  }
  if ((uStack_f8 != 0x7fffffff) && (0x3c < uStack_f8)) {
    return 0;
  }
  uStack_15c._0_4_ = (char *)param_2;
  aiStack_178[6] = 0x1a865f;
  cVar2 = func_0x00217a94();
  if (cVar2 == '\0') {
    iStack_114 = 1;
    iStack_110 = 1;
    puStack_10c = (undefined *)0x7b2;
    uStack_15c._0_4_ = (char *)param_2;
    aiStack_178[6] = 0x1a87d2;
    cVar2 = func_0x00217aea();
  }
  else {
    uStack_15c._0_4_ = (char *)param_2;
    aiStack_178[6] = 0x1a8672;
    cVar2 = func_0x00217aea();
  }
  if (cVar2 == '\0') {
    uStack_104 = 0;
    uStack_fc = 0;
    uStack_f8 = 0;
  }
  if (puStack_10c == (undefined *)0x7fffffff) {
    uStack_15c._0_4_ = "%y";
    aiStack_178[6] = 0x1a912e;
    uStack_15c._4_4_ = (char *)FUN_00033b90();
    uStack_15c._0_4_ = (char *)param_2;
    aiStack_178[6] = 0x1a913d;
    cVar2 = func_0x00037416();
    if (cVar2 != '\0') {
      return 0;
    }
    uStack_15c._0_4_ = "%Y";
    aiStack_178[6] = 0x1a9153;
    uStack_15c._4_4_ = (char *)FUN_00033b90();
    uStack_15c._0_4_ = (char *)param_2;
    aiStack_178[6] = 0x1a9162;
    cVar2 = func_0x00037416();
    if (cVar2 != '\0') {
      return 0;
    }
    uStack_15c._0_4_ = (char *)apuStack_cc;
    iStack_150 = iRam003d4a1c;
    uStack_15c._4_4_ = (char *)*(undefined8 *)(iStack_f4 + 0xc);
    pcStack_154 = (char *)((ulonglong)*(undefined8 *)(iStack_f4 + 0xc) >> 0x20);
    aiStack_178[6] = 0x1a9193;
    _CFAbsoluteTimeGetGregorianDate();
    piVar7 = aiStack_178 + 6;
    puStack_10c = apuStack_cc[0];
  }
  if (iStack_110 == 0x7fffffff) {
    *piVar7 = (int)"%m";
    piVar7[-1] = 0x1a91fd;
    iVar6 = FUN_00033b90();
    piVar7[1] = iVar6;
    *piVar7 = (int)param_2;
    piVar7[-1] = 0x1a920c;
    cVar2 = func_0x00037416();
    if (cVar2 != '\0') {
      return 0;
    }
    piVar7[3] = iRam003d4a1c;
    *(undefined8 *)(piVar7 + 1) = *(undefined8 *)(iStack_f4 + 0xc);
    *piVar7 = (int)auStack_9c;
    piVar7[-1] = 0x1a923d;
    _CFAbsoluteTimeGetGregorianDate();
    piVar7 = piVar7 + -1;
    iStack_110 = (int)cStack_98;
  }
  if (iStack_114 == 0x7fffffff) {
    *piVar7 = (int)"%d";
    piVar7[-1] = 0x1a9281;
    iVar6 = FUN_00033b90();
    piVar7[1] = iVar6;
    *piVar7 = (int)param_2;
    piVar7[-1] = 0x1a9290;
    cVar2 = func_0x00037416();
    if (cVar2 != '\0') {
      return 0;
    }
    *piVar7 = (int)"%e";
    piVar7[-1] = 0x1a92a6;
    iVar6 = FUN_00033b90();
    piVar7[1] = iVar6;
    *piVar7 = (int)param_2;
    piVar7[-1] = 0x1a92b5;
    cVar2 = func_0x00037416();
    if (cVar2 != '\0') {
      return 0;
    }
    piVar7[3] = iRam003d4a1c;
    *(undefined8 *)(piVar7 + 1) = *(undefined8 *)(iStack_f4 + 0xc);
    *piVar7 = (int)auStack_dc;
    piVar7[-1] = 0x1a92e6;
    _CFAbsoluteTimeGetGregorianDate();
    piVar7 = piVar7 + -1;
    iStack_114 = (int)cStack_d7;
  }
  if (uStack_104 == 0x7fffffff) {
    *piVar7 = (int)"%H";
    piVar7[-1] = 0x1a932a;
    iVar6 = FUN_00033b90();
    piVar7[1] = iVar6;
    *piVar7 = (int)param_2;
    piVar7[-1] = 0x1a9339;
    cVar2 = func_0x00037416();
    if (cVar2 != '\0') {
      return 0;
    }
    *piVar7 = (int)"%I";
    piVar7[-1] = 0x1a934f;
    iVar6 = FUN_00033b90();
    piVar7[1] = iVar6;
    *piVar7 = (int)param_2;
    piVar7[-1] = 0x1a935e;
    cVar2 = func_0x00037416();
    if (cVar2 != '\0') {
      return 0;
    }
    piVar7[3] = iRam003d4a1c;
    *(undefined8 *)(piVar7 + 1) = *(undefined8 *)(iStack_f4 + 0xc);
    *piVar7 = (int)auStack_ec;
    piVar7[-1] = 0x1a938f;
    _CFAbsoluteTimeGetGregorianDate();
    piVar7 = piVar7 + -1;
    uStack_104 = (uint)cStack_e6;
  }
  if (uStack_fc == 0x7fffffff) {
    *piVar7 = (int)"%M";
    piVar7[-1] = 0x1a93d3;
    iVar6 = FUN_00033b90();
    piVar7[1] = iVar6;
    *piVar7 = (int)param_2;
    piVar7[-1] = 0x1a93e2;
    cVar2 = func_0x00037416();
    if (cVar2 != '\0') {
      return 0;
    }
    piVar7[3] = iRam003d4a1c;
    *(undefined8 *)(piVar7 + 1) = *(undefined8 *)(iStack_f4 + 0xc);
    *piVar7 = (int)auStack_ac;
    piVar7[-1] = 0x1a9413;
    _CFAbsoluteTimeGetGregorianDate();
    piVar7 = piVar7 + -1;
    uStack_fc = (uint)cStack_a5;
  }
  if (uStack_f8 == 0x7fffffff) {
    *piVar7 = (int)"%S";
    piVar7[-1] = 0x1a880f;
    iVar6 = FUN_00033b90();
    piVar7[1] = iVar6;
    *piVar7 = (int)param_2;
    piVar7[-1] = 0x1a881e;
    cVar2 = func_0x00037416();
    if (cVar2 != '\0') {
      return 0;
    }
    piVar7[3] = iRam003d4a1c;
    *(undefined8 *)(piVar7 + 1) = *(undefined8 *)(iStack_f4 + 0xc);
    *piVar7 = (int)auStack_bc;
    piVar7[-1] = 0x1a884b;
    _CFAbsoluteTimeGetGregorianDate();
    piVar7 = piVar7 + -1;
    uStack_f8 = (uint)(double)CONCAT44(uStack_b0,uStack_b4);
  }
  piVar7[5] = uStack_f8;
  piVar7[4] = uStack_fc;
  piVar7[3] = uStack_104;
  piVar7[2] = iStack_114;
  piVar7[1] = iStack_110;
  *piVar7 = (int)puStack_10c;
  piVar7[-1] = 0x1a871a;
  uStack_f0 = func_0x001a7df0();
  piVar7[2] = 0;
  piVar7[1] = (int)param_2;
  *piVar7 = uStack_f0;
  piVar7[-1] = 0x1a873d;
  uStack_24 = func_0x001a6faa();
  piVar7[1] = (int)param_2;
  *piVar7 = uStack_24;
  piVar7[-1] = 0x1a874f;
  piVar5 = (int *)func_0x001a602c();
  pcVar1 = *(code **)(*piVar5 + 0x88);
  piVar7[1] = (int)param_2;
  *piVar7 = param_1;
  piVar7[-1] = 0x1a876b;
  iVar6 = func_0x001a602c();
  piVar7[1] = iVar6;
  *piVar7 = (int)piVar5;
  piVar7[-1] = 0x1a8774;
  cVar2 = (*pcVar1)();
  if (cVar2 == '\0') {
    return 0;
  }
  return uStack_f0;
code_r0x001a9449:
  uStack_15c._0_4_ = (char *)uStack_2c;
  aiStack_178[6] = 0x1a9454;
  iStack_114 = func_0x00034584();
LAB_001a85a6:
  if (pdStack_118 != (dword *)0x0) {
code_r0x001a85b4:
    pcStack_154 = (char *)0x0;
    uStack_15c._4_4_ = (char *)pdStack_118;
    uStack_15c._0_4_ = (char *)piStack_11c;
    aiStack_178[6] = 0x1a85dd;
    (**(code **)(*piStack_11c + 0x1e4))();
  }
LAB_001a83ad:
  uStack_15c._0_4_ = (char *)uStack_120;
  aiStack_178[6] = 0x1a83bb;
  iVar6 = FUN_00029ddc();
  if (iVar6 <= iVar8) goto LAB_001a83bf;
  goto LAB_001a834f;
}


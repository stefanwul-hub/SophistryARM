
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 * FUN_001aa5d8(void)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)__Znwm(0x3c);
  func_0x0002dc66(puVar1);
  *puVar1 = &UNK_00392d28;
  puVar1[4] = 0;
  puVar1[7] = 0;
  puVar1[8] = 0;
  puVar1[9] = 0;
  puVar1[3] = 0;
  puVar1[5] = 0;
  puVar1[6] = 0;
  puVar1[10] = 0;
  puVar1[0xd] = 0;
  puVar1[0xe] = 0;
  return puVar1;
}


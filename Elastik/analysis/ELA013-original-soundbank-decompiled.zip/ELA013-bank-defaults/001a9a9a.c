
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001a9a9a(void)

{
  if (piRam003d4a38 != (int *)0x0) {
    (**(code **)(*piRam003d4a38 + 0x44))(piRam003d4a38);
  }
  piRam003d4a38 = (int *)0x0;
  return;
}


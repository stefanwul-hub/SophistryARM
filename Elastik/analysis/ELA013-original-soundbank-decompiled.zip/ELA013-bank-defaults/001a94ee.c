
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001a94ee(int param_1,int *param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  
  FUN_000315e4(param_1,param_2);
  pcVar1 = *(code **)(*param_2 + 0x260);
  uVar2 = FUN_00033b90("dateAsString");
  iVar3 = (*pcVar1)(param_2,uVar2);
  if (iVar3 != 0) {
    uVar2 = FUN_00033b90("%d.%m.%Y %H:%M:%S");
    pcVar1 = *(code **)(*param_2 + 0x260);
    uVar4 = FUN_00033b90("dateAsString");
    uVar4 = (*pcVar1)(param_2,uVar4);
    iVar3 = FUN_001a8162(uVar4,uVar2,0);
    *(undefined8 *)(param_1 + 0xc) = *(undefined8 *)(iVar3 + 0xc);
  }
  return;
}


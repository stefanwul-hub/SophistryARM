
void FUN_001a9b52(int param_1)

{
  undefined4 uVar1;
  
  if (param_1 != 0) {
    uVar1 = FUN_001a9ac8();
    FUN_0002bb40(uVar1,param_1);
  }
  return;
}


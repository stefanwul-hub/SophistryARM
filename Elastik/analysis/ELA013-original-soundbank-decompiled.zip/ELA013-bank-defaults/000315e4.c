
void FUN_000315e4(int *param_1,int *param_2)

{
  code *pcVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  
  uVar3 = (**(code **)(*param_1 + 8))(param_1);
  uVar3 = FUN_00021866(uVar3);
  iVar7 = 0;
  while( true ) {
    iVar4 = FUN_00029ddc(uVar3);
    if (iVar4 <= iVar7) break;
    uVar5 = FUN_0002a364(uVar3,iVar7);
    cVar2 = (**(code **)(*param_2 + 0x26c))(param_2,uVar5);
    if (cVar2 != '\0') {
      pcVar1 = *(code **)(*param_1 + 0x168);
      uVar6 = (**(code **)(*param_2 + 0x260))(param_2,uVar5);
      (*pcVar1)(param_1,uVar6,uVar5,0);
    }
    iVar7 = iVar7 + 1;
  }
  return;
}


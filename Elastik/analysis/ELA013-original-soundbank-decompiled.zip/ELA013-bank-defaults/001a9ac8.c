
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_001a9ac8(void)

{
  undefined4 uVar1;
  
  if (iRam003d4a38 != 0) {
    return iRam003d4a38;
  }
  uVar1 = __Znwm(0x20);
  FUN_00029d44(uVar1);
  iRam003d4a38 = FUN_0002dfa6(uVar1);
  uVar1 = FUN_00084aa2();
  FUN_00083b04(uVar1,FUN_001a9a9a,0);
  return iRam003d4a38;
}


001a9dc4  55  PUSH EBP
001a9dc5  89e5  MOV EBP,ESP
001a9dc7  57  PUSH EDI
001a9dc8  56  PUSH ESI
001a9dc9  83ec10  SUB ESP,0x10
001a9dcc  8b7d08  MOV EDI,dword ptr [EBP + 0x8]
001a9dcf  8b750c  MOV ESI,dword ptr [EBP + 0xc]
001a9dd2  8b5718  MOV EDX,dword ptr [EDI + 0x18]
001a9dd5  39f2  CMP EDX,ESI
001a9dd7  741b  JZ 0x001a9df4
001a9dd9  85d2  TEST EDX,EDX
001a9ddb  7408  JZ 0x001a9de5
001a9ddd  8b02  MOV EAX,dword ptr [EDX]
001a9ddf  891424  MOV dword ptr [ESP],EDX
001a9de2  ff5044  CALL dword ptr [EAX + 0x44]
001a9de5  897718  MOV dword ptr [EDI + 0x18],ESI
001a9de8  85f6  TEST ESI,ESI
001a9dea  7408  JZ 0x001a9df4
001a9dec  8b06  MOV EAX,dword ptr [ESI]
001a9dee  893424  MOV dword ptr [ESP],ESI
001a9df1  ff5040  CALL dword ptr [EAX + 0x40]
001a9df4  83c410  ADD ESP,0x10
001a9df7  5e  POP ESI
001a9df8  5f  POP EDI
001a9df9  5d  POP EBP
001a9dfa  c3  RET


/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001aa80c(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  undefined4 uVar6;
  longdouble lVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    uVar2 = FUN_0003dd2a("%@.mounted",*(undefined4 *)(param_1 + 0x10));
    uVar3 = FUN_0006c39c();
    iVar4 = FUN_0006ca86(uVar3,uVar2);
    if (iVar4 == 0) {
      piVar5 = (int *)FUN_0006b262(0xffff8005,0x61737570,1);
      if (piVar5 != (int *)0x0) {
        iVar4 = FUN_001aa128(param_1);
        if (iVar4 != 0) {
          piVar5 = (int *)(**(code **)(*piVar5 + 0x20c))(piVar5,iVar4,0);
          if (piVar5 != (int *)0x0) {
            cVar1 = (**(code **)(*piVar5 + 0x1d0))(piVar5);
            if (cVar1 == '\0') {
              cVar1 = (**(code **)(*piVar5 + 0x1d4))(piVar5);
              if (cVar1 == '\0') {
                uVar2 = FUN_00033b90("");
                FUN_0003644c(uVar2,piVar5);
                cVar1 = (**(code **)(*piVar5 + 0x1d0))(piVar5);
                if (cVar1 == '\0') {
                  uVar2 = FUN_0003dd2a("%@.mounted",*(undefined4 *)(param_1 + 0x10));
                  uVar3 = FUN_00085800(1);
                  uVar6 = FUN_0006c39c();
                  FUN_0006cc88(uVar6,uVar3,uVar2);
                }
                else {
                  uVar2 = (**(code **)(*piVar5 + 0x1e0))(piVar5);
                  lVar7 = (longdouble)func_0x001a6284(uVar2);
                  *(double *)(param_1 + 0x2c) = (double)lVar7 - DOUBLE_00364908;
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}


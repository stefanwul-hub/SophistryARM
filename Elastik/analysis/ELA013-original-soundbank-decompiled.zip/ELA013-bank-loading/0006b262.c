
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0006b262(short param_1,undefined4 param_2,undefined1 param_3)

{
  short sVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 uVar4;
  undefined1 auStack_6c [92];
  
  sVar1 = _FSFindFolder((int)param_1,param_2,param_3,auStack_6c);
  if (sVar1 != 0) {
    return 0;
  }
  puVar2 = (undefined4 *)__Znwm(0x24);
  FUN_0009a1a2(puVar2);
  *puVar2 = &UNK_00371fa8;
  puVar2[5] = 0x20202020;
  puVar2[4] = 0x20202020;
  puVar2[8] = 0xffffffff;
  puVar2[6] = 0;
  puVar2[7] = 0;
  piVar3 = (int *)FUN_0002dfa6(puVar2);
  uVar4 = (**(code **)(*piVar3 + 0x48))(piVar3);
  uVar4 = func_0x0006aa48(uVar4,auStack_6c);
  return uVar4;
}


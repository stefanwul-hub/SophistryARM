
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001aa128(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  
  iVar1 = func_0x00107682();
  if ((iVar1 != 0) && (*(int *)(param_1 + 0x10) != 0)) {
    uVar2 = func_0x00107682();
    piVar3 = (int *)func_0x001071e2(uVar2);
    uVar2 = (**(code **)(**(int **)(param_1 + 0x10) + 0x90))(*(int **)(param_1 + 0x10));
    uVar4 = (**(code **)(*piVar3 + 0x90))(piVar3);
    uVar2 = FUN_0003dd2a(".%08X%08X.%s",uVar4,uVar2,"lib");
    return uVar2;
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0006c39c(void)

{
  int iVar1;
  undefined4 *puVar2;
  
  iVar1 = iRam003d430c;
  if (iRam003d430c == 0) {
    if ((iRam003d42f8 != 0) || (iRam003d42fc != 0)) {
      puVar2 = (undefined4 *)__Znwm(0x10);
      func_0x0002dc66(puVar2);
      *puVar2 = &UNK_00372228;
      puVar2[3] = 0;
      iRam003d430c = FUN_0002dfa6(puVar2);
      return iRam003d430c;
    }
    iVar1 = 0;
  }
  return iVar1;
}


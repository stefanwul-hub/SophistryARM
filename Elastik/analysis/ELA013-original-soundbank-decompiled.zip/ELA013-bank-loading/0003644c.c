
int FUN_0003644c(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  
  cVar1 = func_0x00036370(param_1,param_2,0);
  return (int)cVar1;
}


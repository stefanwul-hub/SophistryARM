
void FUN_001a9b78(int param_1,int *param_2)

{
  int *piVar1;
  char cVar2;
  
  if (param_2 != (int *)0x0) {
    cVar2 = (**(code **)(*param_2 + 0x80))(param_2);
    if (cVar2 != '\0') {
      param_2 = (int *)FUN_0003b448(param_2);
    }
  }
  piVar1 = *(int **)(param_1 + 0x10);
  if (param_2 != piVar1) {
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(int **)(param_1 + 0x10) = param_2;
    if (param_2 != (int *)0x0) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
  }
  return;
}


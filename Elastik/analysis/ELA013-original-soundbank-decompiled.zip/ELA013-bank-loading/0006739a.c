
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int * FUN_0006739a(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  char *pcVar6;
  undefined4 uVar7;
  int *piVar8;
  undefined4 *puVar9;
  int *piVar10;
  int iVar11;
  char *pcVar12;
  char *pcVar13;
  char *pcVar14;
  bool bVar15;
  undefined *apuStack_70 [13];
  char cStack_3c;
  undefined4 uStack_38;
  char *pcStack_34;
  undefined *puStack_30;
  int *piStack_2c;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  uStack_1c = param_1;
  uStack_20 = 0x673ac;
  cVar1 = func_0x001a4cb0();
  if (cVar1 != '\0') {
    piStack_2c = (int *)param_1;
    puStack_30 = &UNK_001a5ed1;
    piVar8 = (int *)func_0x00038f0c();
    piStack_2c = (int *)0x14;
    puStack_30 = &UNK_001a5edf;
    puVar9 = (undefined4 *)__Znwm();
    puStack_30 = &UNK_001a5ee9;
    piStack_2c = puVar9;
    func_0x0002dc66();
    *puVar9 = &UNK_003929a8;
    puVar9[3] = 0;
    puVar9[4] = 0;
    puStack_30 = &UNK_001a5f07;
    piStack_2c = puVar9;
    piVar10 = (int *)FUN_0002dfa6();
    piStack_2c = (int *)piVar10[3];
    if (piVar8 != piStack_2c) {
      if (piStack_2c != (int *)0x0) {
        puStack_30 = &UNK_001a5f1c;
        (**(code **)(*piStack_2c + 0x44))();
      }
      piVar10[3] = (int)piVar8;
      if (piVar8 != (int *)0x0) {
        puStack_30 = &UNK_001a5f2b;
        piStack_2c = piVar8;
        (**(code **)(*piVar8 + 0x40))();
      }
    }
    piVar10[4] = 0;
    puStack_30 = &UNK_001a5f3a;
    piStack_2c = piVar10;
    piVar8 = (int *)func_0x001a59d8();
    if (piVar8 != (int *)0x0) {
      puStack_30 = &UNK_001a5f48;
      piStack_2c = piVar8;
      (**(code **)(*piVar8 + 0x48))();
    }
    puStack_30 = &UNK_001a5f50;
    piStack_2c = piVar10;
    (**(code **)(*piVar10 + 0x44))();
    return piVar8;
  }
  uStack_1c = param_1;
  uStack_20 = 0x673c5;
  uVar7 = func_0x0002926c();
  cVar1 = func_0x001a4e18(uVar7);
  if (cVar1 != '\0') {
    piVar8 = (int *)func_0x001a5f6c(uVar7);
    return piVar8;
  }
  iVar2 = FUN_000278d6(uVar7);
  iVar2 = FUN_0000aecc(iVar2 + 1);
  if (iVar2 == 0) {
    FUN_0000ab14("XML Parser out of memory");
    piVar8 = (int *)0x0;
    goto code_r0x00067216;
  }
  func_0x001a32fa(apuStack_70);
  FUN_00027b4e(uVar7);
  uVar3 = FUN_000278d6(uVar7);
  uVar4 = FUN_00027abc(uVar7);
  _memcpy(iVar2,uVar4,uVar3);
  FUN_00027bec(uVar7);
  iVar5 = FUN_000278d6(uVar7);
  *(undefined1 *)(iVar2 + iVar5) = 0;
  func_0x0019cbaa(apuStack_70,iVar2,0,0);
  if (cStack_3c == '\0') {
    iVar5 = func_0x001a143a(apuStack_70,"plist");
    if ((iVar5 == 0) || (iVar5 = func_0x0019f0dc(iVar5), iVar5 == 0)) goto code_r0x000671d6;
    bVar15 = *(int *)(iVar5 + 0x24) == 0;
    if (bVar15) {
      pcVar6 = "";
    }
    else {
      pcVar6 = *(char **)(iVar5 + 0x20);
    }
    iVar11 = 5;
    pcVar13 = "dict";
    do {
      pcVar12 = pcVar6;
      pcVar14 = pcVar13;
      if (iVar11 == 0) break;
      iVar11 = iVar11 + -1;
      pcVar14 = pcVar13 + 1;
      pcVar12 = pcVar6 + 1;
      bVar15 = *pcVar6 == *pcVar13;
      pcVar6 = pcVar12;
      pcVar13 = pcVar14;
    } while (bVar15);
    iVar11 = 0;
    if (!bVar15) {
      iVar11 = (uint)(byte)pcVar12[-1] - (uint)(byte)pcVar14[-1];
    }
    if (iVar11 != 0) goto code_r0x000671d6;
    piVar8 = (int *)func_0x00066e46(iVar5);
  }
  else {
    pcVar6 = pcStack_34;
    if (puStack_30 == (undefined *)0x0) {
      pcVar6 = "";
    }
    FUN_0000ab14("XML Parser Error ID %d Row %d - %s",uStack_38,iStack_24 + 1,pcVar6);
code_r0x000671d6:
    piVar8 = (int *)0x0;
  }
  apuStack_70[0] = PTR_DAT_003db032 + 8;
  if (pcStack_34 != (char *)0x0) {
    FUN_0000b122(pcStack_34);
  }
  pcStack_34 = (char *)0x0;
  puStack_30 = (undefined *)0x0;
  piStack_2c = (int *)0x0;
  func_0x0019fd2c(apuStack_70);
code_r0x00067216:
  FUN_0000b122(iVar2);
  return piVar8;
}


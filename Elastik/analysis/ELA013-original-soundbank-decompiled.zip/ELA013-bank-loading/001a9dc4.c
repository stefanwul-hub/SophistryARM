
void FUN_001a9dc4(int param_1,int *param_2)

{
  int *piVar1;
  
  piVar1 = *(int **)(param_1 + 0x18);
  if (piVar1 != param_2) {
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(int **)(param_1 + 0x18) = param_2;
    if (param_2 != (int *)0x0) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
  }
  return;
}


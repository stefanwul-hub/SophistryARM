001a9cb4  55  PUSH EBP
001a9cb5  89e5  MOV EBP,ESP
001a9cb7  57  PUSH EDI
001a9cb8  56  PUSH ESI
001a9cb9  83ec10  SUB ESP,0x10
001a9cbc  8b7d08  MOV EDI,dword ptr [EBP + 0x8]
001a9cbf  8b750c  MOV ESI,dword ptr [EBP + 0xc]
001a9cc2  8b5720  MOV EDX,dword ptr [EDI + 0x20]
001a9cc5  39f2  CMP EDX,ESI
001a9cc7  741b  JZ 0x001a9ce4
001a9cc9  85d2  TEST EDX,EDX
001a9ccb  7408  JZ 0x001a9cd5
001a9ccd  8b02  MOV EAX,dword ptr [EDX]
001a9ccf  891424  MOV dword ptr [ESP],EDX
001a9cd2  ff5044  CALL dword ptr [EAX + 0x44]
001a9cd5  897720  MOV dword ptr [EDI + 0x20],ESI
001a9cd8  85f6  TEST ESI,ESI
001a9cda  7408  JZ 0x001a9ce4
001a9cdc  8b06  MOV EAX,dword ptr [ESI]
001a9cde  893424  MOV dword ptr [ESP],ESI
001a9ce1  ff5040  CALL dword ptr [EAX + 0x40]
001a9ce4  83c410  ADD ESP,0x10
001a9ce7  5e  POP ESI
001a9ce8  5f  POP EDI
001a9ce9  5d  POP EBP
001a9cea  c3  RET

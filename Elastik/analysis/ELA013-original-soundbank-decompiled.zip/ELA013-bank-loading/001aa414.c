
undefined4 FUN_001aa414(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  piVar1 = (int *)FUN_0006b262(0xffff8005,0x61737570,1);
  if (piVar1 != (int *)0x0) {
    iVar2 = FUN_001aa128(param_1);
    if (iVar2 != 0) {
      uVar3 = (**(code **)(*piVar1 + 0x20c))(piVar1,iVar2,0);
      return uVar3;
    }
  }
  return 0;
}


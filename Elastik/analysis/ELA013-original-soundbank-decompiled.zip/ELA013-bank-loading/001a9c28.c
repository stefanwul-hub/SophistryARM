
int * FUN_001a9c28(int param_1)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  
  if (((*(int *)(param_1 + 0x1c) != 0) &&
      (iVar3 = FUN_000349f4(*(int *)(param_1 + 0x1c)), iVar3 != 0)) &&
     (piVar4 = (int *)FUN_0009af5e(*(undefined4 *)(param_1 + 0x1c)), piVar4 != (int *)0x0)) {
    cVar2 = (**(code **)(*piVar4 + 0x1d0))(piVar4);
    if (cVar2 != '\0') {
      return piVar4;
    }
    piVar4 = (int *)func_0x0000cfca();
    piVar4 = (int *)(**(code **)(*piVar4 + 0x2c8))(piVar4);
    pcVar1 = *(code **)(*piVar4 + 0x210);
    uVar5 = FUN_0003a99a(*(undefined4 *)(param_1 + 0x1c));
    piVar4 = (int *)(*pcVar1)(piVar4,uVar5);
    return piVar4;
  }
  return (int *)0x0;
}


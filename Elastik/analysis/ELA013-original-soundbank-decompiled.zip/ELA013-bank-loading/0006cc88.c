
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0006cc88(int param_1,int param_2,int param_3)

{
  code *pcVar1;
  char cVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  if (param_1 == 0) {
    uVar5 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNPreferences.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x5f,uVar5,"this != 0");
  }
  if (param_3 == 0) {
    uVar5 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNPreferences.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x5f,uVar5,"key");
  }
  if ((*(int *)(param_1 + 0xc) == 0) && (func_0x0006c79a(param_1), *(int *)(param_1 + 0xc) == 0)) {
    uVar5 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNPreferences.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x65,uVar5,"_dict");
  }
  if (param_2 == 0) {
    cVar2 = func_0x00063f38(*(undefined4 *)(param_1 + 0xc),param_3);
    if (cVar2 != '\0') {
      func_0x00066606(*(undefined4 *)(param_1 + 0xc),param_3);
    }
  }
  else {
    FUN_00066284(*(undefined4 *)(param_1 + 0xc),param_2,param_3);
  }
  iVar3 = func_0x0006d8fe();
  if (iVar3 == 0) {
    uVar5 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNPreferences.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x70,uVar5,
                 "GNNotificationCenter::getDefaultCenter()");
  }
  piVar4 = (int *)func_0x0006d8fe();
  pcVar1 = *(code **)(*piVar4 + 0x1b0);
  uVar5 = FUN_00033b90("key");
  uVar5 = FUN_00066996(param_3,uVar5,0);
  if (piRam003d4304 == (int *)0x0) {
    piRam003d4304 = (int *)FUN_00033b90("GNPreferencesDidChangeNotification");
    (**(code **)(*piRam003d4304 + 0x40))(piRam003d4304);
  }
  (*pcVar1)(piVar4,piRam003d4304,param_1,uVar5,1,0);
  piVar4 = (int *)func_0x0006d8fe();
  pcVar1 = *(code **)(*piVar4 + 0x1b0);
  if (piRam003d4308 == (int *)0x0) {
    piRam003d4308 = (int *)FUN_00033b90("GNPreferencesNeedsToBeStoredNotification");
    (**(code **)(*piRam003d4308 + 0x40))(piRam003d4308);
  }
  (*pcVar1)(piVar4,piRam003d4308,param_1,0,1,1);
  return;
}


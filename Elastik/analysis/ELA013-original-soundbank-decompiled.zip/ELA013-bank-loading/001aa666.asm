001aa666  55  PUSH EBP
001aa667  89e5  MOV EBP,ESP
001aa669  57  PUSH EDI
001aa66a  56  PUSH ESI
001aa66b  53  PUSH EBX
001aa66c  83ec3c  SUB ESP,0x3c
001aa66f  e8a8a91300  CALL 0x002e501c
001aa674  8b7d08  MOV EDI,dword ptr [EBP + 0x8]
001aa677  8b4714  MOV EAX,dword ptr [EDI + 0x14]
001aa67a  85c0  TEST EAX,EAX
001aa67c  7516  JNZ 0x001aa694
001aa67e  c7472c00000000  MOV dword ptr [EDI + 0x2c],0x0
001aa685  c7473000000000  MOV dword ptr [EDI + 0x30],0x0
001aa68c  83c43c  ADD ESP,0x3c
001aa68f  5b  POP EBX
001aa690  5e  POP ESI
001aa691  5f  POP EDI
001aa692  5d  POP EBP
001aa693  c3  RET
001aa694  8b4710  MOV EAX,dword ptr [EDI + 0x10]
001aa697  89442404  MOV dword ptr [ESP + 0x4],EAX
001aa69b  8d83ccd71200  LEA EAX,[EBX + 0x12d7cc]
001aa6a1  8945d4  MOV dword ptr [EBP + -0x2c],EAX
001aa6a4  890424  MOV dword ptr [ESP],EAX
001aa6a7  e87e36e9ff  CALL 0x0003dd2a
001aa6ac  89c6  MOV ESI,EAX
001aa6ae  e8e91cecff  CALL 0x0006c39c
001aa6b3  89742404  MOV dword ptr [ESP + 0x4],ESI
001aa6b7  890424  MOV dword ptr [ESP],EAX
001aa6ba  e8c723ecff  CALL 0x0006ca86
001aa6bf  85c0  TEST EAX,EAX
001aa6c1  75bb  JNZ 0x001aa67e
001aa6c3  893c24  MOV dword ptr [ESP],EDI
001aa6c6  e8abfbffff  CALL 0x001aa276
001aa6cb  84c0  TEST AL,AL
001aa6cd  7440  JZ 0x001aa70f
001aa6cf  8b4710  MOV EAX,dword ptr [EDI + 0x10]
001aa6d2  89442404  MOV dword ptr [ESP + 0x4],EAX
001aa6d6  8b55d4  MOV EDX,dword ptr [EBP + -0x2c]
001aa6d9  891424  MOV dword ptr [ESP],EDX
001aa6dc  e84936e9ff  CALL 0x0003dd2a
001aa6e1  8945e0  MOV dword ptr [EBP + -0x20],EAX
001aa6e4  c7042401000000  MOV dword ptr [ESP],0x1
001aa6eb  e810b1edff  CALL 0x00085800
001aa6f0  89c6  MOV ESI,EAX
001aa6f2  e8a51cecff  CALL 0x0006c39c
001aa6f7  8b55e0  MOV EDX,dword ptr [EBP + -0x20]
001aa6fa  89542408  MOV dword ptr [ESP + 0x8],EDX
001aa6fe  89742404  MOV dword ptr [ESP + 0x4],ESI
001aa702  890424  MOV dword ptr [ESP],EAX
001aa705  e87e25ecff  CALL 0x0006cc88
001aa70a  e96fffffff  JMP 0x001aa67e
001aa70f  c744240801000000  MOV dword ptr [ESP + 0x8],0x1
001aa717  c744240470757361  MOV dword ptr [ESP + 0x4],0x61737570
001aa71f  c704240580ffff  MOV dword ptr [ESP],0xffff8005
001aa726  e8370becff  CALL 0x0006b262
001aa72b  89c6  MOV ESI,EAX
001aa72d  85c0  TEST EAX,EAX
001aa72f  743a  JZ 0x001aa76b
001aa731  893c24  MOV dword ptr [ESP],EDI
001aa734  e8eff9ffff  CALL 0x001aa128
001aa739  89c2  MOV EDX,EAX
001aa73b  85c0  TEST EAX,EAX
001aa73d  742c  JZ 0x001aa76b
001aa73f  8b06  MOV EAX,dword ptr [ESI]
001aa741  c744240800000000  MOV dword ptr [ESP + 0x8],0x0
001aa749  89542404  MOV dword ptr [ESP + 0x4],EDX
001aa74d  893424  MOV dword ptr [ESP],ESI
001aa750  ff900c020000  CALL dword ptr [EAX + 0x20c]
001aa756  89c6  MOV ESI,EAX
001aa758  85c0  TEST EAX,EAX
001aa75a  740f  JZ 0x001aa76b
001aa75c  8b00  MOV EAX,dword ptr [EAX]
001aa75e  893424  MOV dword ptr [ESP],ESI
001aa761  ff90d0010000  CALL dword ptr [EAX + 0x1d0]
001aa767  84c0  TEST AL,AL
001aa769  7572  JNZ 0x001aa7dd
001aa76b  c7472c00000000  MOV dword ptr [EDI + 0x2c],0x0
001aa772  c7473000000000  MOV dword ptr [EDI + 0x30],0x0
001aa779  893c24  MOV dword ptr [ESP],EDI
001aa77c  e851faffff  CALL 0x001aa1d2
001aa781  dd5dd8  FSTP qword ptr [EBP + -0x28]
001aa784  f20f1045d8  MOVSD XMM0,qword ptr [EBP + -0x28]
001aa789  660f2e83a4a01b00  UCOMISD XMM0,qword ptr [EBX + 0x1ba0a4]
001aa791  0f85f5feffff  JNZ 0x001aa68c
001aa797  0f8aeffeffff  JP 0x001aa68c
001aa79d  8b4710  MOV EAX,dword ptr [EDI + 0x10]
001aa7a0  89442404  MOV dword ptr [ESP + 0x4],EAX
001aa7a4  8b45d4  MOV EAX,dword ptr [EBP + -0x2c]
001aa7a7  890424  MOV dword ptr [ESP],EAX
001aa7aa  e87b35e9ff  CALL 0x0003dd2a
001aa7af  8945e4  MOV dword ptr [EBP + -0x1c],EAX
001aa7b2  c7042401000000  MOV dword ptr [ESP],0x1
001aa7b9  e842b0edff  CALL 0x00085800
001aa7be  89c6  MOV ESI,EAX
001aa7c0  e8d71becff  CALL 0x0006c39c
001aa7c5  8b55e4  MOV EDX,dword ptr [EBP + -0x1c]
001aa7c8  89542408  MOV dword ptr [ESP + 0x8],EDX
001aa7cc  89742404  MOV dword ptr [ESP + 0x4],ESI
001aa7d0  890424  MOV dword ptr [ESP],EAX
001aa7d3  e8b024ecff  CALL 0x0006cc88
001aa7d8  e9affeffff  JMP 0x001aa68c
001aa7dd  8b06  MOV EAX,dword ptr [ESI]
001aa7df  893424  MOV dword ptr [ESP],ESI
001aa7e2  ff90e0010000  CALL dword ptr [EAX + 0x1e0]
001aa7e8  85c0  TEST EAX,EAX
001aa7ea  0f847bffffff  JZ 0x001aa76b
001aa7f0  8b06  MOV EAX,dword ptr [ESI]
001aa7f2  893424  MOV dword ptr [ESP],ESI
001aa7f5  ff90e0010000  CALL dword ptr [EAX + 0x1e0]
001aa7fb  890424  MOV dword ptr [ESP],EAX
001aa7fe  e881baffff  CALL 0x001a6284
001aa803  dd5f2c  FSTP qword ptr [EDI + 0x2c]
001aa806  e96effffff  JMP 0x001aa779

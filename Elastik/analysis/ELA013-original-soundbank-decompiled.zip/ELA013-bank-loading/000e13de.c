
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000e13de(int param_1,int *param_2)

{
  short *psVar1;
  byte *pbVar2;
  int *piVar3;
  int iVar4;
  char cVar5;
  uint uVar6;
  uint *puVar7;
  undefined4 uVar8;
  int iVar9;
  uint uVar10;
  uint *puVar11;
  byte *pbVar12;
  byte *pbVar13;
  byte *pbVar14;
  byte *pbVar15;
  undefined1 uVar16;
  uint uStack_28c;
  uint uStack_288;
  uint uStack_280;
  int iStack_270;
  byte abStack_265 [5];
  byte abStack_260 [4];
  byte abStack_25c [4];
  byte abStack_258 [4];
  byte abStack_254 [8];
  byte abStack_24c [4];
  byte abStack_248 [4];
  byte abStack_244 [4];
  byte abStack_240 [496];
  undefined4 uStack_50;
  int *piStack_4c;
  char *pcStack_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  char *pcStack_3c;
  int iStack_24;
  int *apiStack_20 [4];
  
  apiStack_20[0] = param_2;
  if (*(int *)(param_1 + 0xc) != 0) {
    piStack_4c = (int *)0x2cebf4;
    uStack_50 = 0xe140a;
    uVar8 = func_0x0000a930();
    piStack_4c = (int *)0x2c3a30;
    uStack_50 = 0xe141a;
    piStack_4c = (int *)FUN_00033b90();
    pcStack_3c = "_file == 0";
    uStack_44 = 0x4f1;
    pcStack_48 = "Assertion failed in line %d of %s: %s.";
    uStack_50 = 0xe1442;
    uStack_40 = uVar8;
    FUN_0000bfd6();
  }
  *(undefined1 *)(*(int *)(param_1 + 0x14) + 0x2c) = 1;
  piStack_4c = apiStack_20[0];
  uStack_50 = 0xe1457;
  piStack_4c = (int *)(**(code **)(*apiStack_20[0] + 0x248))();
  *(int **)(param_1 + 0xc) = piStack_4c;
  if (piStack_4c != (int *)0x0) {
    uStack_50 = 0xe1468;
    (**(code **)(*piStack_4c + 0x40))();
  }
  if (*(int *)(param_1 + 0xc) == 0) {
    piStack_4c = (int *)0x2cee80;
    uStack_50 = 0xe14ad;
    piStack_4c = (int *)FUN_00033b90();
    uStack_50 = 0xe14b5;
    FUN_0000bf34();
  }
  iVar4 = *(int *)(param_1 + 0x14);
  piStack_4c = apiStack_20[0];
  uStack_50 = 0xe1480;
  iVar9 = (**(code **)(*apiStack_20[0] + 0x1d8))();
  *(int *)(iVar4 + 0x18) = iVar9;
  *(int *)(iVar4 + 0x1c) = iVar9 >> 0x1f;
  *(undefined4 *)(*(int *)(param_1 + 0x14) + 0x24) = *(undefined4 *)(param_1 + 0xc);
  iVar4 = *(int *)(param_1 + 0x14);
  piVar3 = *(int **)(iVar4 + 0x24);
  apiStack_20[0] = (int *)0x14;
  (**(code **)(*piVar3 + 0x1c0))(piVar3,0);
  pbVar2 = abStack_265 + 1;
  cVar5 = (**(code **)(*piVar3 + 0x1ac))(piVar3,pbVar2,apiStack_20);
  uVar16 = cVar5 == '\0';
  if (((bool)uVar16) || (uVar16 = apiStack_20[0] == (int *)0x14, !(bool)uVar16)) {
    uVar8 = FUN_00033b90("GNFileArchiveFormatNotSupportedException");
    FUN_0000bf34(uVar8);
  }
  iVar9 = 4;
  pbVar12 = (byte *)"GNFA";
  pbVar14 = pbVar2;
  do {
    pbVar13 = pbVar12;
    pbVar15 = pbVar14;
    if (iVar9 == 0) break;
    iVar9 = iVar9 + -1;
    pbVar15 = pbVar14 + 1;
    pbVar13 = pbVar12 + 1;
    uVar16 = *pbVar12 == *pbVar14;
    pbVar12 = pbVar13;
    pbVar14 = pbVar15;
  } while ((bool)uVar16);
  iVar9 = 0;
  if (!(bool)uVar16) {
    iVar9 = (uint)pbVar13[-1] - (uint)pbVar15[-1];
  }
  if (iVar9 != 0) {
    uVar8 = FUN_00033b90("GNFileArchiveFormatNotSupportedException");
    FUN_0000bf34(uVar8);
  }
  *(undefined4 *)(iVar4 + 4) = 0;
  iVar9 = 0;
  uVar6 = 0;
  do {
    uVar6 = uVar6 << 8 | (uint)abStack_260[iVar9];
    iVar9 = iVar9 + 1;
  } while (iVar9 != 4);
  *(uint *)(iVar4 + 4) = uVar6;
  *(undefined4 *)(iVar4 + 8) = 0;
  iVar9 = 0;
  uVar6 = 0;
  do {
    uVar6 = uVar6 << 8 | (uint)abStack_25c[iVar9];
    iVar9 = iVar9 + 1;
  } while (iVar9 != 4);
  *(uint *)(iVar4 + 8) = uVar6;
  if (*(uint *)(iVar4 + 4) < 0x14) {
    uVar8 = FUN_00033b90("GNFileArchiveFormatNotSupportedException");
    FUN_0000bf34(uVar8);
  }
  *(undefined4 *)(iVar4 + 0xc) = 0;
  iVar9 = 0;
  uVar6 = 0;
  do {
    uVar6 = uVar6 << 8 | (uint)abStack_258[iVar9];
    iVar9 = iVar9 + 1;
  } while (iVar9 != 4);
  *(uint *)(iVar4 + 0xc) = uVar6;
  *(undefined4 *)(iVar4 + 0x10) = 0;
  iVar9 = 0;
  uVar6 = 0;
  do {
    uVar6 = uVar6 << 8 | (uint)abStack_254[iVar9];
    iVar9 = iVar9 + 1;
  } while (iVar9 != 4);
  *(uint *)(iVar4 + 0x10) = uVar6;
  uStack_28c = *(uint *)(iVar4 + 4);
  uStack_288 = 0;
  if (*(int *)(iVar4 + 0x10) != 0) {
    apiStack_20[0] = (int *)(*(int *)(iVar4 + 0x10) * 0x240);
    uVar8 = FUN_0000aecc(apiStack_20[0]);
    *(undefined4 *)(iVar4 + 0x14) = uVar8;
    _memset(uVar8,0,apiStack_20[0]);
  }
  if (*(int *)(iVar4 + 0xc) != 0) {
    *(undefined1 *)(iVar4 + 0x2c) = 1;
  }
  if (*(int *)(iVar4 + 0x10) != 0) {
    uStack_280 = 0;
    iStack_270 = 0;
    do {
      (**(code **)(*piVar3 + 0x1c0))(piVar3,uStack_28c);
      puVar7 = (uint *)(iStack_270 + *(int *)(iVar4 + 0x14));
      if ((*(uint *)(iVar4 + 0x1c) <= uStack_288) &&
         ((*(uint *)(iVar4 + 0x1c) < uStack_288 || (*(uint *)(iVar4 + 0x18) < uStack_28c)))) {
        uVar8 = FUN_00033b90("GNFileArchiveFormatNotSupportedException");
        FUN_0000bf34(uVar8);
      }
      iStack_24 = 0x22c;
      cVar5 = (**(code **)(*piVar3 + 0x1ac))(piVar3,pbVar2,&iStack_24);
      if ((cVar5 == '\0') || (iStack_24 != 0x22c)) {
        uVar8 = FUN_00033b90("GNFileArchiveIsCorruptedException");
        FUN_0000bf34(uVar8);
      }
      puVar7[0x8b] = uStack_28c;
      puVar7[0x8c] = uStack_288;
      *puVar7 = 0;
      iVar9 = 1;
      do {
        *puVar7 = *puVar7 << 8 | (uint)pbVar2[iVar9 + -1];
        iVar9 = iVar9 + 1;
      } while (iVar9 != 5);
      puVar7[1] = 0;
      iVar9 = 0;
      uVar6 = 0;
      do {
        uVar6 = (uint)abStack_260[iVar9] | uVar6 << 8;
        puVar7[1] = uVar6;
        iVar9 = iVar9 + 1;
      } while (iVar9 != 4);
      puVar7[2] = 0;
      puVar7[3] = 0;
      iVar9 = 0;
      uVar6 = 0;
      uVar10 = 0;
      do {
        uVar10 = uVar10 << 8 | uVar6 >> 0x18;
        uVar6 = uVar6 << 8 | (uint)abStack_25c[iVar9];
        puVar7[2] = uVar6;
        puVar7[3] = uVar10;
        iVar9 = iVar9 + 1;
      } while (iVar9 != 8);
      puVar7[4] = 0;
      puVar7[5] = 0;
      iVar9 = 0;
      uVar6 = 0;
      uVar10 = 0;
      do {
        uVar10 = uVar10 << 8 | uVar6 >> 0x18;
        uVar6 = uVar6 << 8 | (uint)abStack_254[iVar9];
        puVar7[4] = uVar6;
        puVar7[5] = uVar10;
        iVar9 = iVar9 + 1;
      } while (iVar9 != 8);
      puVar7[6] = 0;
      iVar9 = 0;
      uVar6 = 0;
      do {
        uVar6 = (uint)abStack_24c[iVar9] | uVar6 << 8;
        puVar7[6] = uVar6;
        iVar9 = iVar9 + 1;
      } while (iVar9 != 4);
      puVar7[7] = 0;
      iVar9 = 0;
      uVar6 = 0;
      do {
        uVar6 = (uint)abStack_248[iVar9] | uVar6 << 8;
        puVar7[7] = uVar6;
        iVar9 = iVar9 + 1;
      } while (iVar9 != 4);
      puVar7[8] = 0;
      iVar9 = 0;
      uVar6 = 0;
      do {
        uVar6 = (uint)abStack_244[iVar9] | uVar6 << 8;
        puVar7[8] = uVar6;
        iVar9 = iVar9 + 1;
      } while (iVar9 != 4);
      iVar9 = 0;
      do {
        *(ushort *)(iVar9 + (int)(puVar7 + 9)) = CONCAT11(pbVar2[iVar9 + 0x24],pbVar2[iVar9 + 0x25])
        ;
        iVar9 = iVar9 + 2;
      } while (iVar9 != 0x200);
      iStack_24 = 0;
      if ((short)puVar7[9] != 0) {
        iStack_24 = 0;
        puVar11 = puVar7;
        do {
          iStack_24 = iStack_24 + 1;
          psVar1 = (short *)((int)puVar11 + 0x26);
          puVar11 = (uint *)((int)puVar11 + 2);
        } while (*psVar1 != 0);
        if (0 < iStack_24) {
          uVar8 = __Znwm(0x20);
          func_0x000332e2(uVar8);
          uVar6 = FUN_0002dfa6(uVar8);
          puVar7[0x8f] = uVar6;
          func_0x0003788a(uVar6,puVar7 + 9,iStack_24);
        }
      }
      puVar7[0x89] = 0;
      puVar7[0x8a] = 0;
      iVar9 = 0;
      uVar6 = 0;
      uVar10 = 0;
      do {
        uVar10 = uVar10 << 8 | uVar6 >> 0x18;
        uVar6 = uVar6 << 8 | (uint)*(byte *)((int)&uStack_40 + iVar9);
        puVar7[0x89] = uVar6;
        puVar7[0x8a] = uVar10;
        iVar9 = iVar9 + 1;
      } while (iVar9 != 8);
      if (*(int *)(iVar4 + 0xc) == 0) {
        uVar10 = *puVar7;
        puVar7[0x8d] = uStack_28c + uVar10;
        puVar7[0x8e] = uStack_288 + CARRY4(uStack_28c,uVar10);
        uVar6 = uVar10 + puVar7[4];
        uStack_288 = uStack_288 + puVar7[5] + (uint)CARRY4(uVar10,puVar7[4]) +
                     (uint)CARRY4(uStack_28c,uVar6);
      }
      else {
        puVar7[0x8d] = puVar7[4];
        puVar7[0x8e] = puVar7[5];
        uVar6 = *puVar7;
        uStack_288 = uStack_288 + CARRY4(uStack_28c,uVar6);
      }
      uStack_28c = uStack_28c + uVar6;
      uStack_280 = uStack_280 + 1;
      iStack_270 = iStack_270 + 0x240;
    } while (uStack_280 < *(uint *)(iVar4 + 0x10));
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0006ca86(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNPreferences.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x7b,uVar3,"this != 0");
  }
  if (param_2 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNPreferences.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x7b,uVar3,"key");
  }
  if (*(int *)(param_1 + 0xc) == 0) {
    func_0x0006c79a(param_1);
    if (*(int *)(param_1 + 0xc) == 0) {
      uVar3 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNPreferences.cpp"
                             );
      uVar4 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x7e,uVar3,"_dict");
    }
  }
  iVar2 = *(int *)(param_1 + 0xc);
  if (iVar2 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x16d,uVar3,"this != 0");
  }
  if (*(int *)(iVar2 + 0xc) == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x16d,uVar3,"_keys");
  }
  if (*(int *)(iVar2 + 0x10) == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNDictionary.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x16d,uVar3,"_objects");
  }
  if (param_2 == 0) {
    func_0x0000acae("GNDictionary: key is 0");
  }
  if (*(int *)(iVar2 + 0x14) != 0) {
    iVar5 = func_0x0006440e(iVar2,param_2);
    if (iVar5 != -1) goto LAB_0006467d;
  }
  iVar5 = func_0x0002a9ba(*(undefined4 *)(iVar2 + 0xc),param_2);
  if (iVar5 == -1) {
    return 0;
  }
LAB_0006467d:
  piVar1 = *(int **)(iVar2 + 0x10);
  if (piVar1 == (int *)0x0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x15b,uVar3,"this != 0");
  }
  if ((iVar5 < 0) || (piVar1[4] <= iVar5)) {
    uVar3 = (**(code **)(*piVar1 + 0xc))(piVar1);
    uVar3 = FUN_00034962(uVar3);
    func_0x0000acae("GNList::getObjectAtIndex(): Index %i out of range of %s.",iVar5,uVar3);
  }
  return *(undefined4 *)(piVar1[3] + iVar5 * 4);
}


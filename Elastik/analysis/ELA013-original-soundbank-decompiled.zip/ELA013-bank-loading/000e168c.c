
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_000e168c(int param_1,int *param_2)

{
  short sVar1;
  undefined4 *puVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  puVar2 = (undefined4 *)__Znwm(0x1c);
  FUN_0009a1a2(puVar2);
  *puVar2 = &UNK_0037b668;
  puVar2[4] = 0;
  puVar2[5] = 0;
  puVar2[6] = 0;
  piVar3 = (int *)FUN_0002dfa6(puVar2);
  iVar4 = (**(code **)(*piVar3 + 0x48))(piVar3);
  iVar5 = FUN_000349f4(param_2);
  if (iVar5 < 1) {
    uVar6 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                           );
    uVar7 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar7,"Assertion failed in line %d of %s: %s.",0x69d,uVar6,
                 "posixPath->getLength() > 0");
  }
  sVar1 = FUN_00035d80(param_2,0);
  if (sVar1 != 0x2f) {
    uVar6 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNFileArchive.cpp"
                           );
    uVar7 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar7,"Assertion failed in line %d of %s: %s.",0x69e,uVar6,
                 "posixPath->getCharacterAtIndex(0) == \'/\'");
  }
  *(int *)(iVar4 + 0x10) = param_1;
  *(undefined4 *)(iVar4 + 0x14) = 0;
  uVar6 = (**(code **)(*param_2 + 0x40))(param_2);
  *(undefined4 *)(iVar4 + 0x18) = uVar6;
  (**(code **)(**(int **)(param_1 + 0x20) + 0x1a4))(*(int **)(param_1 + 0x20));
  if (*(int *)(param_1 + 0x24) != 0) {
    FUN_000df8d2(iVar4);
    (**(code **)(**(int **)(param_1 + 0x20) + 0x1ac))(*(int **)(param_1 + 0x20));
    (**(code **)(**(int **)(param_1 + 0x28) + 0x40))(*(int **)(param_1 + 0x28));
    return iVar4;
  }
  (**(code **)(**(int **)(param_1 + 0x20) + 0x1ac))(*(int **)(param_1 + 0x20));
  (**(code **)(**(int **)(param_1 + 0x28) + 0x40))(*(int **)(param_1 + 0x28));
  return iVar4;
}


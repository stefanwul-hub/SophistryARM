
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0009a1a2(undefined4 *param_1)

{
  func_0x0002dc66(param_1);
  *param_1 = &UNK_00375948;
  param_1[3] = 0;
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001aa666(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  longdouble lVar7;
  
  if (*(int *)(param_1 + 0x14) != 0) {
    uVar2 = FUN_0003dd2a("%@.mounted",*(undefined4 *)(param_1 + 0x10));
    uVar3 = FUN_0006c39c();
    iVar4 = FUN_0006ca86(uVar3,uVar2);
    if (iVar4 == 0) {
      cVar1 = FUN_001aa276(param_1);
      if (cVar1 == '\0') {
        piVar6 = (int *)FUN_0006b262(0xffff8005,0x61737570,1);
        if ((((piVar6 == (int *)0x0) || (iVar4 = FUN_001aa128(param_1), iVar4 == 0)) ||
            (piVar6 = (int *)(**(code **)(*piVar6 + 0x20c))(piVar6,iVar4,0), piVar6 == (int *)0x0))
           || ((cVar1 = (**(code **)(*piVar6 + 0x1d0))(piVar6), cVar1 == '\0' ||
               (iVar4 = (**(code **)(*piVar6 + 0x1e0))(piVar6), iVar4 == 0)))) {
          *(undefined4 *)(param_1 + 0x2c) = 0;
          *(undefined4 *)(param_1 + 0x30) = 0;
        }
        else {
          uVar2 = (**(code **)(*piVar6 + 0x1e0))(piVar6);
          lVar7 = (longdouble)func_0x001a6284(uVar2);
          *(double *)(param_1 + 0x2c) = (double)lVar7;
        }
        lVar7 = (longdouble)FUN_001aa1d2(param_1);
        if ((double)lVar7 != DOUBLE_00364718) {
          return;
        }
        if (NAN((double)lVar7) || NAN(DOUBLE_00364718)) {
          return;
        }
        uVar2 = FUN_0003dd2a("%@.mounted",*(undefined4 *)(param_1 + 0x10));
        uVar3 = FUN_00085800(1);
        uVar5 = FUN_0006c39c();
        FUN_0006cc88(uVar5,uVar3,uVar2);
        return;
      }
      uVar2 = FUN_0003dd2a("%@.mounted",*(undefined4 *)(param_1 + 0x10));
      uVar3 = FUN_00085800(1);
      uVar5 = FUN_0006c39c();
      FUN_0006cc88(uVar5,uVar3,uVar2);
    }
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  return;
}


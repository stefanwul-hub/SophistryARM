
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00039354(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  if (param_1 != 0) {
    puVar1 = (undefined4 *)__Znwm(0x20);
    func_0x0002dc66(puVar1);
    *puVar1 = &UNK_0036ec68;
    *(undefined1 *)(puVar1 + 6) = 1;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0xffffffff;
    puVar1[7] = 0xffffffff;
    piVar2 = (int *)FUN_0002dfa6(puVar1);
    iVar3 = (**(code **)(*piVar2 + 0x48))(piVar2);
    func_0x000390f6(iVar3,param_1);
    if (iVar3 == 0) {
      uVar4 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                             );
      uVar5 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xd8,uVar4,"this != 0");
    }
    *(undefined1 *)(iVar3 + 0x18) = 0;
    return iVar3;
  }
  if (piRam003d4050 == (int *)0x0) {
    uVar4 = __Znwm(0x38);
    FUN_0006f04a(uVar4);
    piRam003d4050 = (int *)FUN_0002dfa6(uVar4);
    (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
  }
  else {
    (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
  }
  if (iRam003d4054 == 0) {
    uVar4 = __Znwm(0x14);
    FUN_00084dba(uVar4);
    iRam003d4054 = FUN_0002dfa6(uVar4);
  }
  FUN_000854fe(iRam003d4054,"");
  if (iRam003d4058 == 0) {
    uVar4 = __Znwm(0x18);
    FUN_000630b6(uVar4);
    iRam003d4058 = FUN_0002dfa6(uVar4);
    FUN_00065c4a(iRam003d4058,1);
  }
  iVar3 = FUN_0006440e(iRam003d4058,iRam003d4054);
  if (iVar3 != -1) {
    uVar4 = FUN_00063ade(iRam003d4058);
    iVar3 = FUN_0002a364(uVar4,iVar3);
    (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
    return iVar3;
  }
  uVar4 = __Znwm(0x14);
  FUN_00084dba(uVar4);
  piVar2 = (int *)FUN_0002dfa6(uVar4);
  FUN_000854fe(piVar2,"");
  iVar3 = FUN_00033aa6("");
  FUN_00066284(iRam003d4058,iVar3,piVar2);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x44))(piVar2);
  }
  (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
  return iVar3;
}


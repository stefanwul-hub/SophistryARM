
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001b6fa0(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x1a3,uVar1,"this != 0");
  }
  if (*(int *)(param_1 + 0x24) == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x1a3,uVar1,"_rootObject");
  }
  *(undefined4 *)(param_1 + 0x20) = 1;
  piVar3 = *(int **)(param_1 + 0x18);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x44))(piVar3);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  piVar3 = *(int **)(param_1 + 0x1c);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x44))(piVar3);
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  uVar1 = __Znwm(0x20);
  FUN_00029d44(uVar1);
  uVar1 = FUN_0002dfa6(uVar1);
  *(undefined4 *)(param_1 + 0x18) = uVar1;
  uVar1 = __Znwm(0x20);
  FUN_00029d44(uVar1);
  uVar1 = FUN_0002dfa6(uVar1);
  *(undefined4 *)(param_1 + 0x1c) = uVar1;
  uVar1 = __Znwm(0x14);
  FUN_00170a4c(uVar1);
  uVar1 = FUN_0002dfa6(uVar1);
  *(undefined4 *)(param_1 + 0x30) = uVar1;
  FUN_00170700(uVar1,0x3fd,1);
  func_0x001706e8(*(undefined4 *)(param_1 + 0x30));
  FUN_0002bb40(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x24));
  if (*(int *)(param_1 + 0x30) != 0) {
    FUN_001707e8(*(int *)(param_1 + 0x30),*(undefined4 *)(param_1 + 0x24));
  }
  (**(code **)(**(int **)(param_1 + 0x24) + 0x70))(*(int **)(param_1 + 0x24),param_1);
  iVar5 = 0;
  iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x18));
  if (0 < iVar2) {
    do {
      piVar3 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0x18),iVar5);
      iVar2 = (**(code **)(*piVar3 + 0x74))(piVar3);
      if (iVar2 == 0) {
        FUN_0000ab14("Some archived object does not have a class description");
      }
      else {
        FUN_0002c44c(*(undefined4 *)(param_1 + 0x1c),iVar2);
      }
      iVar5 = iVar5 + 1;
      iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x18));
    } while (iVar5 < iVar2);
  }
  piVar3 = *(int **)(param_1 + 0x30);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x44))(piVar3);
  }
  *(undefined4 *)(param_1 + 0x30) = 0;
  return;
}


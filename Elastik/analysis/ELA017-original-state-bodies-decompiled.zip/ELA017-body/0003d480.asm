0003d480  55  PUSH EBP
0003d481  89e5  MOV EBP,ESP
0003d483  57  PUSH EDI
0003d484  56  PUSH ESI
0003d485  53  PUSH EBX
0003d486  81ecac100000  SUB ESP,0x10ac
0003d48c  e88b7b2a00  CALL 0x002e501c
0003d491  c785d0efffff00000000  MOV dword ptr [EBP + 0xffffefd0],0x0
0003d49b  c785d4efffff00000000  MOV dword ptr [EBP + 0xffffefd4],0x0
0003d4a5  c785c0efffff00000000  MOV dword ptr [EBP + 0xffffefc0],0x0
0003d4af  c785c4efffff00000000  MOV dword ptr [EBP + 0xffffefc4],0x0
0003d4b9  c785b0efffff00000000  MOV dword ptr [EBP + 0xffffefb0],0x0
0003d4c3  c785b4efffff00000000  MOV dword ptr [EBP + 0xffffefb4],0x0
0003d4cd  c785a0efffff00000000  MOV dword ptr [EBP + 0xffffefa0],0x0
0003d4d7  c785a4efffff00000000  MOV dword ptr [EBP + 0xffffefa4],0x0
0003d4e1  c78590efffff00000000  MOV dword ptr [EBP + 0xffffef90],0x0
0003d4eb  c78594efffff00000000  MOV dword ptr [EBP + 0xffffef94],0x0
0003d4f5  c78588efffff00000000  MOV dword ptr [EBP + 0xffffef88],0x0
0003d4ff  c7858cefffff00000000  MOV dword ptr [EBP + 0xffffef8c],0x0
0003d509  8bb30f6d3900  MOV ESI,dword ptr [EBX + 0x396d0f]
0003d50f  85f6  TEST ESI,ESI
0003d511  0f84e2060000  JZ 0x0003dbf9
0003d517  8b4d0c  MOV ECX,dword ptr [EBP + 0xc]
0003d51a  85c9  TEST ECX,ECX
0003d51c  0f842c070000  JZ 0x0003dc4e
0003d522  8b450c  MOV EAX,dword ptr [EBP + 0xc]
0003d525  8b4014  MOV EAX,dword ptr [EAX + 0x14]
0003d528  8985d8efffff  MOV dword ptr [EBP + 0xffffefd8],EAX
0003d52e  83c001  ADD EAX,0x1
0003d531  0f84f2040000  JZ 0x0003da29
0003d537  31f6  XOR ESI,ESI
0003d539  31ff  XOR EDI,EDI
0003d53b  8d0437  LEA EAX,[EDI + ESI*0x1]
0003d53e  8985e0efffff  MOV dword ptr [EBP + 0xffffefe0],EAX
0003d544  3985d8efffff  CMP dword ptr [EBP + 0xffffefd8],EAX
0003d54a  7e29  JLE 0x0003d575
0003d54c  89442404  MOV dword ptr [ESP + 0x4],EAX
0003d550  8b450c  MOV EAX,dword ptr [EBP + 0xc]
0003d553  890424  MOV dword ptr [ESP],EAX
0003d556  e82588ffff  CALL 0x00035d80
0003d55b  6683f825  CMP AX,0x25
0003d55f  745d  JZ 0x0003d5be
0003d561  83c601  ADD ESI,0x1
0003d564  8d0437  LEA EAX,[EDI + ESI*0x1]
0003d567  8985e0efffff  MOV dword ptr [EBP + 0xffffefe0],EAX
0003d56d  3985d8efffff  CMP dword ptr [EBP + 0xffffefd8],EAX
0003d573  7fd7  JG 0x0003d54c
0003d575  85f6  TEST ESI,ESI
0003d577  743a  JZ 0x0003d5b3
0003d579  89b58cefffff  MOV dword ptr [EBP + 0xffffef8c],ESI
0003d57f  89bd88efffff  MOV dword ptr [EBP + 0xffffef88],EDI
0003d585  8b8588efffff  MOV EAX,dword ptr [EBP + 0xffffef88]
0003d58b  8b958cefffff  MOV EDX,dword ptr [EBP + 0xffffef8c]
0003d591  89442404  MOV dword ptr [ESP + 0x4],EAX
0003d595  89542408  MOV dword ptr [ESP + 0x8],EDX
0003d599  8b550c  MOV EDX,dword ptr [EBP + 0xc]
0003d59c  891424  MOV dword ptr [ESP],EDX
0003d59f  e89ecaffff  CALL 0x0003a042
0003d5a4  89442404  MOV dword ptr [ESP + 0x4],EAX
0003d5a8  8b4508  MOV EAX,dword ptr [EBP + 0x8]
0003d5ab  890424  MOV dword ptr [ESP],EAX
0003d5ae  e865dbffff  CALL 0x0003b118
0003d5b3  81c4ac100000  ADD ESP,0x10ac
0003d5b9  5b  POP EBX
0003d5ba  5e  POP ESI
0003d5bb  5f  POP EDI
0003d5bc  5d  POP EBP
0003d5bd  c3  RET
0003d5be  85f6  TEST ESI,ESI
0003d5c0  0f8524040000  JNZ 0x0003d9ea
0003d5c6  c685e8efffff00  MOV byte ptr [EBP + 0xffffefe8],0x0
0003d5cd  8b95e0efffff  MOV EDX,dword ptr [EBP + 0xffffefe0]
0003d5d3  83c201  ADD EDX,0x1
0003d5d6  8995e4efffff  MOV dword ptr [EBP + 0xffffefe4],EDX
0003d5dc  c785dcefffff01000000  MOV dword ptr [EBP + 0xffffefdc],0x1
0003d5e6  8d8373992800  LEA EAX,[EBX + 0x289973]
0003d5ec  898584efffff  MOV dword ptr [EBP + 0xffffef84],EAX
0003d5f2  8d939f652800  LEA EDX,[EBX + 0x28659f]
0003d5f8  899580efffff  MOV dword ptr [EBP + 0xffffef80],EDX
0003d5fe  8d83fb662800  LEA EAX,[EBX + 0x2866fb]
0003d604  89857cefffff  MOV dword ptr [EBP + 0xffffef7c],EAX
0003d60a  8d93d3652800  LEA EDX,[EBX + 0x2865d3]
0003d610  899578efffff  MOV dword ptr [EBP + 0xffffef78],EDX
0003d616  8d85e8efffff  LEA EAX,[EBP + 0xffffefe8]
0003d61c  898574efffff  MOV dword ptr [EBP + 0xffffef74],EAX
0003d622  e9c5000000  JMP 0x0003d6ec
0003d627  8b450c  MOV EAX,dword ptr [EBP + 0xc]
0003d62a  8b500c  MOV EDX,dword ptr [EAX + 0xc]
0003d62d  85d2  TEST EDX,EDX
0003d62f  0f843b030000  JZ 0x0003d970
0003d635  89c2  MOV EDX,EAX
0003d637  8b420c  MOV EAX,dword ptr [EDX + 0xc]
0003d63a  85c0  TEST EAX,EAX
0003d63c  0f8423030000  JZ 0x0003d965
0003d642  89442404  MOV dword ptr [ESP + 0x4],EAX
0003d646  8d83f39d2800  LEA EAX,[EBX + 0x289df3]
0003d64c  890424  MOV dword ptr [ESP],EAX
0003d64f  e85ad6fcff  CALL 0x0000acae
0003d654  8b85e4efffff  MOV EAX,dword ptr [EBP + 0xffffefe4]
0003d65a  89442404  MOV dword ptr [ESP + 0x4],EAX
0003d65e  8b550c  MOV EDX,dword ptr [EBP + 0xc]
0003d661  891424  MOV dword ptr [ESP],EDX
0003d664  e81787ffff  CALL 0x00035d80
0003d669  8385dcefffff01  ADD dword ptr [EBP + 0xffffefdc],0x1
0003d670  6683f825  CMP AX,0x25
0003d674  0f84a6000000  JZ 0x0003d720
0003d67a  6683f840  CMP AX,0x40
0003d67e  0f85ac000000  JNZ 0x0003d730
0003d684  8b4510  MOV EAX,dword ptr [EBP + 0x10]
0003d687  83451004  ADD dword ptr [EBP + 0x10],0x4
0003d68b  8b38  MOV EDI,dword ptr [EAX]
0003d68d  85ff  TEST EDI,EDI
0003d68f  0f84f1020000  JZ 0x0003d986
0003d695  8b07  MOV EAX,dword ptr [EDI]
0003d697  893c24  MOV dword ptr [ESP],EDI
0003d69a  ff5008  CALL dword ptr [EAX + 0x8]
0003d69d  89c6  MOV ESI,EAX
0003d69f  8b5508  MOV EDX,dword ptr [EBP + 0x8]
0003d6a2  8b02  MOV EAX,dword ptr [EDX]
0003d6a4  891424  MOV dword ptr [ESP],EDX
0003d6a7  ff5008  CALL dword ptr [EAX + 0x8]
0003d6aa  39c6  CMP ESI,EAX
0003d6ac  0f8415020000  JZ 0x0003d8c7
0003d6b2  8b07  MOV EAX,dword ptr [EDI]
0003d6b4  893c24  MOV dword ptr [ESP],EDI
0003d6b7  ff500c  CALL dword ptr [EAX + 0xc]
0003d6ba  89442404  MOV dword ptr [ESP + 0x4],EAX
0003d6be  8b4508  MOV EAX,dword ptr [EBP + 0x8]
0003d6c1  890424  MOV dword ptr [ESP],EAX
0003d6c4  e84fdaffff  CALL 0x0003b118
0003d6c9  be01000000  MOV ESI,0x1
0003d6ce  80bde8efffff00  CMP byte ptr [EBP + 0xffffefe8],0x0
0003d6d5  0f8507010000  JNZ 0x0003d7e2
0003d6db  8385e4efffff01  ADD dword ptr [EBP + 0xffffefe4],0x1
0003d6e2  89f2  MOV EDX,ESI
0003d6e4  84d2  TEST DL,DL
0003d6e6  0f853d010000  JNZ 0x0003d829
0003d6ec  8b95e4efffff  MOV EDX,dword ptr [EBP + 0xffffefe4]
0003d6f2  3995d8efffff  CMP dword ptr [EBP + 0xffffefd8],EDX
0003d6f8  0f8e29ffffff  JLE 0x0003d627
0003d6fe  89d0  MOV EAX,EDX
0003d700  89442404  MOV dword ptr [ESP + 0x4],EAX
0003d704  8b550c  MOV EDX,dword ptr [EBP + 0xc]
0003d707  891424  MOV dword ptr [ESP],EDX
0003d70a  e87186ffff  CALL 0x00035d80
0003d70f  8385dcefffff01  ADD dword ptr [EBP + 0xffffefdc],0x1
0003d716  6683f825  CMP AX,0x25
0003d71a  0f855affffff  JNZ 0x0003d67a
0003d720  8d830b9e2800  LEA EAX,[EBX + 0x289e0b]
0003d726  890424  MOV dword ptr [ESP],EAX
0003d729  e86264ffff  CALL 0x00033b90
0003d72e  eb8a  JMP 0x0003d6ba
0003d730  0fbef0  MOVSX ESI,AL
0003d733  89742404  MOV dword ptr [ESP + 0x4],ESI
0003d737  8b830f6d3900  MOV EAX,dword ptr [EBX + 0x396d0f]
0003d73d  890424  MOV dword ptr [ESP],EAX
0003d740  e8816bffff  CALL 0x000342c6
0003d745  84c0  TEST AL,AL
0003d747  0f84ef000000  JZ 0x0003d83c
0003d74d  8b4510  MOV EAX,dword ptr [EBP + 0x10]
0003d750  83451004  ADD dword ptr [EBP + 0x10],0x4
0003d754  0fbe00  MOVSX EAX,byte ptr [EAX]
0003d757  89859cefffff  MOV dword ptr [EBP + 0xffffef9c],EAX
0003d75d  8b95dcefffff  MOV EDX,dword ptr [EBP + 0xffffefdc]
0003d763  8995a4efffff  MOV dword ptr [EBP + 0xffffefa4],EDX
0003d769  8b85e0efffff  MOV EAX,dword ptr [EBP + 0xffffefe0]
0003d76f  8985a0efffff  MOV dword ptr [EBP + 0xffffefa0],EAX
0003d775  8b85a0efffff  MOV EAX,dword ptr [EBP + 0xffffefa0]
0003d77b  8b95a4efffff  MOV EDX,dword ptr [EBP + 0xffffefa4]
0003d781  89442404  MOV dword ptr [ESP + 0x4],EAX
0003d785  89542408  MOV dword ptr [ESP + 0x8],EDX
0003d789  8b550c  MOV EDX,dword ptr [EBP + 0xc]
0003d78c  891424  MOV dword ptr [ESP],EDX
0003d78f  e8aec8ffff  CALL 0x0003a042
0003d794  89c7  MOV EDI,EAX
0003d796  85c0  TEST EAX,EAX
0003d798  0f84d8020000  JZ 0x0003da76
0003d79e  8b470c  MOV EAX,dword ptr [EDI + 0xc]
0003d7a1  85c0  TEST EAX,EAX
0003d7a3  0f8419020000  JZ 0x0003d9c2
0003d7a9  8b470c  MOV EAX,dword ptr [EDI + 0xc]
0003d7ac  85c0  TEST EAX,EAX
0003d7ae  0f842b020000  JZ 0x0003d9df
0003d7b4  8b959cefffff  MOV EDX,dword ptr [EBP + 0xffffef9c]
0003d7ba  89542408  MOV dword ptr [ESP + 0x8],EDX
0003d7be  89442404  MOV dword ptr [ESP + 0x4],EAX
0003d7c2  8b8574efffff  MOV EAX,dword ptr [EBP + 0xffffef74]
0003d7c8  890424  MOV dword ptr [ESP],EAX
0003d7cb  e8ffcb3900  CALL 0x003da3cf
0003d7d0  be01000000  MOV ESI,0x1
0003d7d5  80bde8efffff00  CMP byte ptr [EBP + 0xffffefe8],0x0
0003d7dc  0f84f9feffff  JZ 0x0003d6db
0003d7e2  c744240c00000000  MOV dword ptr [ESP + 0xc],0x0
0003d7ea  fc  CLD
0003d7eb  b9ffffffff  MOV ECX,0xffffffff
0003d7f0  31c0  XOR EAX,EAX
0003d7f2  8bbd74efffff  MOV EDI,dword ptr [EBP + 0xffffef74]
0003d7f8  f2ae  SCASB.REPNE ES:EDI
0003d7fa  f7d1  NOT ECX
0003d7fc  83e901  SUB ECX,0x1
0003d7ff  894c2408  MOV dword ptr [ESP + 0x8],ECX
0003d803  8b9574efffff  MOV EDX,dword ptr [EBP + 0xffffef74]
0003d809  89542404  MOV dword ptr [ESP + 0x4],EDX
0003d80d  8b4508  MOV EAX,dword ptr [EBP + 0x8]
0003d810  890424  MOV dword ptr [ESP],EAX
0003d813  e8bcacffff  CALL 0x000384d4
0003d818  8385e4efffff01  ADD dword ptr [EBP + 0xffffefe4],0x1
0003d81f  89f2  MOV EDX,ESI
0003d821  84d2  TEST DL,DL
0003d823  0f84c3feffff  JZ 0x0003d6ec
0003d829  8bbde0efffff  MOV EDI,dword ptr [EBP + 0xffffefe0]
0003d82f  03bddcefffff  ADD EDI,dword ptr [EBP + 0xffffefdc]
0003d835  31f6  XOR ESI,ESI
0003d837  e9fffcffff  JMP 0x0003d53b
0003d83c  89742404  MOV dword ptr [ESP + 0x4],ESI
0003d840  8b830b6d3900  MOV EAX,dword ptr [EBX + 0x396d0b]
0003d846  890424  MOV dword ptr [ESP],EAX
0003d849  e8786affff  CALL 0x000342c6
0003d84e  84c0  TEST AL,AL
0003d850  747c  JZ 0x0003d8ce
0003d852  8b4510  MOV EAX,dword ptr [EBP + 0x10]
0003d855  83451004  ADD dword ptr [EBP + 0x10],0x4
0003d859  8b00  MOV EAX,dword ptr [EAX]
0003d85b  8985acefffff  MOV dword ptr [EBP + 0xffffefac],EAX
0003d861  8b95dcefffff  MOV EDX,dword ptr [EBP + 0xffffefdc]
0003d867  8995b4efffff  MOV dword ptr [EBP + 0xffffefb4],EDX
0003d86d  8b85e0efffff  MOV EAX,dword ptr [EBP + 0xffffefe0]
0003d873  8985b0efffff  MOV dword ptr [EBP + 0xffffefb0],EAX
0003d879  8b85b0efffff  MOV EAX,dword ptr [EBP + 0xffffefb0]
0003d87f  8b95b4efffff  MOV EDX,dword ptr [EBP + 0xffffefb4]
0003d885  89442404  MOV dword ptr [ESP + 0x4],EAX
0003d889  89542408  MOV dword ptr [ESP + 0x8],EDX
0003d88d  8b550c  MOV EDX,dword ptr [EBP + 0xc]
0003d890  891424  MOV dword ptr [ESP],EDX
0003d893  e8aac7ffff  CALL 0x0003a042
0003d898  89c7  MOV EDI,EAX
0003d89a  85c0  TEST EAX,EAX
0003d89c  0f84b2020000  JZ 0x0003db54
0003d8a2  8b470c  MOV EAX,dword ptr [EDI + 0xc]
0003d8a5  85c0  TEST EAX,EAX
0003d8a7  0f84b2010000  JZ 0x0003da5f
0003d8ad  8b470c  MOV EAX,dword ptr [EDI + 0xc]
0003d8b0  85c0  TEST EAX,EAX
0003d8b2  0f849c010000  JZ 0x0003da54
0003d8b8  8b95acefffff  MOV EDX,dword ptr [EBP + 0xffffefac]
0003d8be  89542408  MOV dword ptr [ESP + 0x8],EDX
0003d8c2  e9f7feffff  JMP 0x0003d7be
0003d8c7  89f8  MOV EAX,EDI
0003d8c9  e9ecfdffff  JMP 0x0003d6ba
0003d8ce  89742404  MOV dword ptr [ESP + 0x4],ESI
0003d8d2  8b83036d3900  MOV EAX,dword ptr [EBX + 0x396d03]
0003d8d8  890424  MOV dword ptr [ESP],EAX
0003d8db  e8e669ffff  CALL 0x000342c6
0003d8e0  84c0  TEST AL,AL
0003d8e2  0f84b1000000  JZ 0x0003d999
0003d8e8  8b4510  MOV EAX,dword ptr [EBP + 0x10]
0003d8eb  83451008  ADD dword ptr [EBP + 0x10],0x8
0003d8ef  f20f1000  MOVSD XMM0,qword ptr [EAX]
0003d8f3  f20f1185b8efffff  MOVSD qword ptr [EBP + 0xffffefb8],XMM0
0003d8fb  8b85dcefffff  MOV EAX,dword ptr [EBP + 0xffffefdc]
0003d901  8985c4efffff  MOV dword ptr [EBP + 0xffffefc4],EAX
0003d907  8b95e0efffff  MOV EDX,dword ptr [EBP + 0xffffefe0]
0003d90d  8995c0efffff  MOV dword ptr [EBP + 0xffffefc0],EDX
0003d913  8b85c0efffff  MOV EAX,dword ptr [EBP + 0xffffefc0]
0003d919  8b95c4efffff  MOV EDX,dword ptr [EBP + 0xffffefc4]
0003d91f  89442404  MOV dword ptr [ESP + 0x4],EAX
0003d923  89542408  MOV dword ptr [ESP + 0x8],EDX
0003d927  8b550c  MOV EDX,dword ptr [EBP + 0xc]
0003d92a  891424  MOV dword ptr [ESP],EDX
0003d92d  e810c7ffff  CALL 0x0003a042
0003d932  89c7  MOV EDI,EAX
0003d934  85c0  TEST EAX,EAX
0003d936  0f8472020000  JZ 0x0003dbae
0003d93c  8b470c  MOV EAX,dword ptr [EDI + 0xc]
0003d93f  85c0  TEST EAX,EAX
0003d941  0f84f6010000  JZ 0x0003db3d
0003d947  8b470c  MOV EAX,dword ptr [EDI + 0xc]
0003d94a  85c0  TEST EAX,EAX
0003d94c  0f84e0010000  JZ 0x0003db32
0003d952  f20f1085b8efffff  MOVSD XMM0,qword ptr [EBP + 0xffffefb8]
0003d95a  f20f11442408  MOVSD qword ptr [ESP + 0x8],XMM0
0003d960  e959feffff  JMP 0x0003d7be
0003d965  8d833b652800  LEA EAX,[EBX + 0x28653b]
0003d96b  e9d2fcffff  JMP 0x0003d642
0003d970  837814ff  CMP dword ptr [EAX + 0x14],-0x1
0003d974  7444  JZ 0x0003d9ba
0003d976  890424  MOV dword ptr [ESP],EAX
0003d979  e83c67ffff  CALL 0x000340ba
0003d97e  8b550c  MOV EDX,dword ptr [EBP + 0xc]
0003d981  e9b1fcffff  JMP 0x0003d637
0003d986  8d833b652800  LEA EAX,[EBX + 0x28653b]
0003d98c  890424  MOV dword ptr [ESP],EAX
0003d98f  e8fc61ffff  CALL 0x00033b90
0003d994  e921fdffff  JMP 0x0003d6ba
0003d999  89742404  MOV dword ptr [ESP + 0x4],ESI
0003d99d  8b83076d3900  MOV EAX,dword ptr [EBX + 0x396d07]
0003d9a3  890424  MOV dword ptr [ESP],EAX
0003d9a6  e81b69ffff  CALL 0x000342c6
0003d9ab  84c0  TEST AL,AL
0003d9ad  0f850e010000  JNZ 0x0003dac1
0003d9b3  31f6  XOR ESI,ESI
0003d9b5  e914fdffff  JMP 0x0003d6ce
0003d9ba  8b550c  MOV EDX,dword ptr [EBP + 0xc]
0003d9bd  e975fcffff  JMP 0x0003d637
0003d9c2  837f14ff  CMP dword ptr [EDI + 0x14],-0x1
0003d9c6  0f84ddfdffff  JZ 0x0003d7a9
0003d9cc  893c24  MOV dword ptr [ESP],EDI
0003d9cf  e8e666ffff  CALL 0x000340ba
0003d9d4  8b470c  MOV EAX,dword ptr [EDI + 0xc]
0003d9d7  85c0  TEST EAX,EAX
0003d9d9  0f85d5fdffff  JNZ 0x0003d7b4
0003d9df  8d833b652800  LEA EAX,[EBX + 0x28653b]
0003d9e5  e9cafdffff  JMP 0x0003d7b4
0003d9ea  89b594efffff  MOV dword ptr [EBP + 0xffffef94],ESI
0003d9f0  89bd90efffff  MOV dword ptr [EBP + 0xffffef90],EDI
0003d9f6  8b8590efffff  MOV EAX,dword ptr [EBP + 0xffffef90]
0003d9fc  8b9594efffff  MOV EDX,dword ptr [EBP + 0xffffef94]
0003da02  89442404  MOV dword ptr [ESP + 0x4],EAX
0003da06  89542408  MOV dword ptr [ESP + 0x8],EDX
0003da0a  8b550c  MOV EDX,dword ptr [EBP + 0xc]
0003da0d  891424  MOV dword ptr [ESP],EDX
0003da10  e82dc6ffff  CALL 0x0003a042
0003da15  89442404  MOV dword ptr [ESP + 0x4],EAX
0003da19  8b4508  MOV EAX,dword ptr [EBP + 0x8]
0003da1c  890424  MOV dword ptr [ESP],EAX
0003da1f  e8f4d6ffff  CALL 0x0003b118
0003da24  e99dfbffff  JMP 0x0003d5c6
0003da29  8b450c  MOV EAX,dword ptr [EBP + 0xc]
0003da2c  8b500c  MOV EDX,dword ptr [EAX + 0xc]
0003da2f  85d2  TEST EDX,EDX
0003da31  0f8468010000  JZ 0x0003db9f
0003da37  fc  CLD
0003da38  31c0  XOR EAX,EAX
0003da3a  8b8dd8efffff  MOV ECX,dword ptr [EBP + 0xffffefd8]
0003da40  89d7  MOV EDI,EDX
0003da42  f2ae  SCASB.REPNE ES:EDI
0003da44  f7d1  NOT ECX
0003da46  83e901  SUB ECX,0x1
0003da49  898dd8efffff  MOV dword ptr [EBP + 0xffffefd8],ECX
0003da4f  e9e3faffff  JMP 0x0003d537
0003da54  8d833b652800  LEA EAX,[EBX + 0x28653b]
0003da5a  e959feffff  JMP 0x0003d8b8
0003da5f  837f14ff  CMP dword ptr [EDI + 0x14],-0x1
0003da63  0f8444feffff  JZ 0x0003d8ad
0003da69  893c24  MOV dword ptr [ESP],EDI
0003da6c  e84966ffff  CALL 0x000340ba
0003da71  e937feffff  JMP 0x0003d8ad
0003da76  8b8584efffff  MOV EAX,dword ptr [EBP + 0xffffef84]
0003da7c  890424  MOV dword ptr [ESP],EAX
0003da7f  e8accefcff  CALL 0x0000a930
0003da84  89c6  MOV ESI,EAX
0003da86  8b9580efffff  MOV EDX,dword ptr [EBP + 0xffffef80]
0003da8c  891424  MOV dword ptr [ESP],EDX
0003da8f  e8fc60ffff  CALL 0x00033b90
0003da94  8b957cefffff  MOV EDX,dword ptr [EBP + 0xffffef7c]
0003da9a  89542410  MOV dword ptr [ESP + 0x10],EDX
0003da9e  8974240c  MOV dword ptr [ESP + 0xc],ESI
0003daa2  c744240819010000  MOV dword ptr [ESP + 0x8],0x119
0003daaa  8b9578efffff  MOV EDX,dword ptr [EBP + 0xffffef78]
0003dab0  89542404  MOV dword ptr [ESP + 0x4],EDX
0003dab4  890424  MOV dword ptr [ESP],EAX
0003dab7  e81ae5fcff  CALL 0x0000bfd6
0003dabc  e9ddfcffff  JMP 0x0003d79e
0003dac1  8b4510  MOV EAX,dword ptr [EBP + 0x10]
0003dac4  83451004  ADD dword ptr [EBP + 0x10],0x4
0003dac8  8b00  MOV EAX,dword ptr [EAX]
0003daca  8985ccefffff  MOV dword ptr [EBP + 0xffffefcc],EAX
0003dad0  8b95dcefffff  MOV EDX,dword ptr [EBP + 0xffffefdc]
0003dad6  8995d4efffff  MOV dword ptr [EBP + 0xffffefd4],EDX
0003dadc  8b85e0efffff  MOV EAX,dword ptr [EBP + 0xffffefe0]
0003dae2  8985d0efffff  MOV dword ptr [EBP + 0xffffefd0],EAX
0003dae8  8b85d0efffff  MOV EAX,dword ptr [EBP + 0xffffefd0]
0003daee  8b95d4efffff  MOV EDX,dword ptr [EBP + 0xffffefd4]
0003daf4  89442404  MOV dword ptr [ESP + 0x4],EAX
0003daf8  89542408  MOV dword ptr [ESP + 0x8],EDX
0003dafc  8b550c  MOV EDX,dword ptr [EBP + 0xc]
0003daff  891424  MOV dword ptr [ESP],EDX
0003db02  e83bc5ffff  CALL 0x0003a042
0003db07  89c7  MOV EDI,EAX
0003db09  85c0  TEST EAX,EAX
0003db0b  0f84aa010000  JZ 0x0003dcbb
0003db11  8b470c  MOV EAX,dword ptr [EDI + 0xc]
0003db14  85c0  TEST EAX,EAX
0003db16  0f8488010000  JZ 0x0003dca4
0003db1c  8b470c  MOV EAX,dword ptr [EDI + 0xc]
0003db1f  85c0  TEST EAX,EAX
0003db21  0f8472010000  JZ 0x0003dc99
0003db27  8b95ccefffff  MOV EDX,dword ptr [EBP + 0xffffefcc]
0003db2d  e988fcffff  JMP 0x0003d7ba
0003db32  8d833b652800  LEA EAX,[EBX + 0x28653b]
0003db38  e915feffff  JMP 0x0003d952
0003db3d  837f14ff  CMP dword ptr [EDI + 0x14],-0x1
0003db41  0f8400feffff  JZ 0x0003d947
0003db47  893c24  MOV dword ptr [ESP],EDI
0003db4a  e86b65ffff  CALL 0x000340ba
0003db4f  e9f3fdffff  JMP 0x0003d947
0003db54  8b8584efffff  MOV EAX,dword ptr [EBP + 0xffffef84]
0003db5a  890424  MOV dword ptr [ESP],EAX
0003db5d  e8cecdfcff  CALL 0x0000a930
0003db62  89c6  MOV ESI,EAX
0003db64  8b9580efffff  MOV EDX,dword ptr [EBP + 0xffffef80]
0003db6a  891424  MOV dword ptr [ESP],EDX
0003db6d  e81e60ffff  CALL 0x00033b90
0003db72  8b957cefffff  MOV EDX,dword ptr [EBP + 0xffffef7c]
0003db78  89542410  MOV dword ptr [ESP + 0x10],EDX
0003db7c  8974240c  MOV dword ptr [ESP + 0xc],ESI
0003db80  c744240819010000  MOV dword ptr [ESP + 0x8],0x119
0003db88  8b9578efffff  MOV EDX,dword ptr [EBP + 0xffffef78]
0003db8e  89542404  MOV dword ptr [ESP + 0x4],EDX
0003db92  890424  MOV dword ptr [ESP],EAX
0003db95  e83ce4fcff  CALL 0x0000bfd6
0003db9a  e903fdffff  JMP 0x0003d8a2
0003db9f  c785d8efffff00000000  MOV dword ptr [EBP + 0xffffefd8],0x0
0003dba9  e989f9ffff  JMP 0x0003d537
0003dbae  8b8584efffff  MOV EAX,dword ptr [EBP + 0xffffef84]
0003dbb4  890424  MOV dword ptr [ESP],EAX
0003dbb7  e874cdfcff  CALL 0x0000a930
0003dbbc  89c6  MOV ESI,EAX
0003dbbe  8b9580efffff  MOV EDX,dword ptr [EBP + 0xffffef80]
0003dbc4  891424  MOV dword ptr [ESP],EDX
0003dbc7  e8c45fffff  CALL 0x00033b90
0003dbcc  8b957cefffff  MOV EDX,dword ptr [EBP + 0xffffef7c]
0003dbd2  89542410  MOV dword ptr [ESP + 0x10],EDX
0003dbd6  8974240c  MOV dword ptr [ESP + 0xc],ESI
0003dbda  c744240819010000  MOV dword ptr [ESP + 0x8],0x119
0003dbe2  8b9578efffff  MOV EDX,dword ptr [EBP + 0xffffef78]
0003dbe8  89542404  MOV dword ptr [ESP + 0x4],EDX
0003dbec  890424  MOV dword ptr [ESP],EAX
0003dbef  e8e2e3fcff  CALL 0x0000bfd6
0003dbf4  e943fdffff  JMP 0x0003d93c
0003dbf9  8d83539c2800  LEA EAX,[EBX + 0x289c53]
0003dbff  890424  MOV dword ptr [ESP],EAX
0003dc02  e80fb6ffff  CALL 0x00039216
0003dc07  89830f6d3900  MOV dword ptr [EBX + 0x396d0f],EAX
0003dc0d  8d83df9d2800  LEA EAX,[EBX + 0x289ddf]
0003dc13  890424  MOV dword ptr [ESP],EAX
0003dc16  e8fbb5ffff  CALL 0x00039216
0003dc1b  89830b6d3900  MOV dword ptr [EBX + 0x396d0b],EAX
0003dc21  8d83e79d2800  LEA EAX,[EBX + 0x289de7]
0003dc27  890424  MOV dword ptr [ESP],EAX
0003dc2a  e8e7b5ffff  CALL 0x00039216
0003dc2f  8983036d3900  MOV dword ptr [EBX + 0x396d03],EAX
0003dc35  8d83ef9d2800  LEA EAX,[EBX + 0x289def]
0003dc3b  890424  MOV dword ptr [ESP],EAX
0003dc3e  e8d3b5ffff  CALL 0x00039216
0003dc43  8983076d3900  MOV dword ptr [EBX + 0x396d07],EAX
0003dc49  e9c9f8ffff  JMP 0x0003d517
0003dc4e  8d8373992800  LEA EAX,[EBX + 0x289973]
0003dc54  890424  MOV dword ptr [ESP],EAX
0003dc57  e8d4ccfcff  CALL 0x0000a930
0003dc5c  89c6  MOV ESI,EAX
0003dc5e  8d839f652800  LEA EAX,[EBX + 0x28659f]
0003dc64  890424  MOV dword ptr [ESP],EAX
0003dc67  e8245fffff  CALL 0x00033b90
0003dc6c  8d93fb662800  LEA EDX,[EBX + 0x2866fb]
0003dc72  89542410  MOV dword ptr [ESP + 0x10],EDX
0003dc76  8974240c  MOV dword ptr [ESP + 0xc],ESI
0003dc7a  c74424080f010000  MOV dword ptr [ESP + 0x8],0x10f
0003dc82  8d93d3652800  LEA EDX,[EBX + 0x2865d3]
0003dc88  89542404  MOV dword ptr [ESP + 0x4],EDX
0003dc8c  890424  MOV dword ptr [ESP],EAX
0003dc8f  e842e3fcff  CALL 0x0000bfd6
0003dc94  e989f8ffff  JMP 0x0003d522
0003dc99  8d833b652800  LEA EAX,[EBX + 0x28653b]
0003dc9f  e983feffff  JMP 0x0003db27
0003dca4  837f14ff  CMP dword ptr [EDI + 0x14],-0x1
0003dca8  0f846efeffff  JZ 0x0003db1c
0003dcae  893c24  MOV dword ptr [ESP],EDI
0003dcb1  e80464ffff  CALL 0x000340ba
0003dcb6  e961feffff  JMP 0x0003db1c
0003dcbb  8b8584efffff  MOV EAX,dword ptr [EBP + 0xffffef84]
0003dcc1  890424  MOV dword ptr [ESP],EAX
0003dcc4  e867ccfcff  CALL 0x0000a930
0003dcc9  89c6  MOV ESI,EAX
0003dccb  8b9580efffff  MOV EDX,dword ptr [EBP + 0xffffef80]
0003dcd1  891424  MOV dword ptr [ESP],EDX
0003dcd4  e8b75effff  CALL 0x00033b90
0003dcd9  8b957cefffff  MOV EDX,dword ptr [EBP + 0xffffef7c]
0003dcdf  89542410  MOV dword ptr [ESP + 0x10],EDX
0003dce3  8974240c  MOV dword ptr [ESP + 0xc],ESI
0003dce7  c744240819010000  MOV dword ptr [ESP + 0x8],0x119
0003dcef  8b9578efffff  MOV EDX,dword ptr [EBP + 0xffffef78]
0003dcf5  89542404  MOV dword ptr [ESP + 0x4],EDX
0003dcf9  890424  MOV dword ptr [ESP],EAX
0003dcfc  e8d5e2fcff  CALL 0x0000bfd6
0003dd01  e90bfeffff  JMP 0x0003db11

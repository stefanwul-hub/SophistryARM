
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0000ae5a(int param_1,undefined4 param_2)

{
  undefined1 auStack_410 [1024];
  undefined1 *puStack_10;
  
  if (param_1 != 0) {
    if (param_1 < 1) {
      puStack_10 = &stack0x0000000c;
      _vsprintf(auStack_410,param_2,puStack_10);
      FUN_0000acae("%s (Code %i)",auStack_410,param_1);
      return;
    }
    FUN_0000ab14("Error Code > 0 ?");
  }
  return;
}


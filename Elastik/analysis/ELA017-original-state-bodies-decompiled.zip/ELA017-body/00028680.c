
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00028680(int param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  code *pcStack_34;
  undefined4 uStack_30;
  undefined4 uStack_28;
  code *pcStack_24;
  
  (**(code **)(*param_2 + 0x1bc))(param_2,*(undefined4 *)(param_1 + 0x10));
  FUN_00027b4e(param_1);
  if (*(int *)(param_1 + 0x10) == 0) {
    pcStack_24 = *(code **)(*param_2 + 0x1bc);
    if (*(int *)(param_1 + 0x18) != 0) goto LAB_000286cf;
LAB_000287d0:
    iVar3 = *(int *)(param_1 + 0xc);
    if (iVar3 == 0) goto LAB_000286d2;
    uVar2 = FUN_0000ae24(iVar3);
    (*pcStack_24)(param_2,uVar2);
    pcStack_34 = *(code **)(*param_2 + 0x1e0);
    if (*(int *)(param_1 + 0x18) != 0) goto LAB_000286f2;
LAB_00028803:
    if (*(int *)(param_1 + 0xc) != 0) {
      uStack_30 = FUN_0000ae24(*(int *)(param_1 + 0xc));
      iVar3 = *(int *)(param_1 + 0x18);
      goto joined_r0x0002881a;
    }
    uStack_30 = 0;
  }
  else {
    (**(code **)(*param_2 + 0x1bc))(param_2,1);
    uVar2 = *(undefined4 *)(param_1 + 0x10);
    if (*(int *)(param_1 + 0x18) == 0) {
      if (*(int *)(param_1 + 0xc) == 0) {
        uStack_28 = 0;
      }
      else {
        uStack_28 = FUN_0000ae24(*(int *)(param_1 + 0xc));
      }
    }
    else {
      uStack_28 = *(undefined4 *)(param_1 + 0x1c);
    }
    iVar3 = *(int *)(param_1 + 0x18);
    if (iVar3 == 0) {
      if (*(int *)(param_1 + 0xc) == 0) {
        FUN_0000ab14("GNData::bytes(). Data object doesn\'t have alloced memory yet.");
        iVar3 = 0;
      }
      else {
        iVar3 = **(int **)(*(int *)(param_1 + 0xc) + 0xc);
      }
    }
    func_0x0000a978(iVar3,uStack_28,uVar2);
    pcStack_24 = *(code **)(*param_2 + 0x1bc);
    if (*(int *)(param_1 + 0x18) == 0) goto LAB_000287d0;
LAB_000286cf:
    iVar3 = *(int *)(param_1 + 0x1c);
LAB_000286d2:
    (*pcStack_24)(param_2,iVar3);
    pcStack_34 = *(code **)(*param_2 + 0x1e0);
    if (*(int *)(param_1 + 0x18) == 0) goto LAB_00028803;
LAB_000286f2:
    uStack_30 = *(undefined4 *)(param_1 + 0x1c);
  }
  iVar3 = *(int *)(param_1 + 0x18);
joined_r0x0002881a:
  if (iVar3 == 0) {
    if (*(int *)(param_1 + 0xc) == 0) {
      FUN_0000ab14("GNData::bytes(). Data object doesn\'t have alloced memory yet.");
      iVar3 = 0;
    }
    else {
      iVar3 = **(int **)(*(int *)(param_1 + 0xc) + 0xc);
    }
  }
  (*pcStack_34)(param_2,iVar3,uStack_30);
  iVar3 = *(int *)(param_1 + 0x10);
  if (iVar3 != 0) {
    if (*(int *)(param_1 + 0x18) == 0) {
      if (*(int *)(param_1 + 0xc) == 0) {
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_0000ae24(*(int *)(param_1 + 0xc));
      }
    }
    else {
      uVar2 = *(undefined4 *)(param_1 + 0x1c);
    }
    iVar1 = *(int *)(param_1 + 0x18);
    if (iVar1 == 0) {
      if (*(int *)(param_1 + 0xc) == 0) {
        FUN_0000ab14("GNData::bytes(). Data object doesn\'t have alloced memory yet.");
        iVar1 = 0;
      }
      else {
        iVar1 = **(int **)(*(int *)(param_1 + 0xc) + 0xc);
      }
    }
    func_0x0000a978(iVar1,uVar2,iVar3);
  }
  if ((*(int *)(param_1 + 0x18) == 0) && (iVar3 = *(int *)(param_1 + 0xc), iVar3 != 0)) {
    if (iVar3 == 0) {
      FUN_0000acae("GNMemoryHandle is nil.");
    }
    iVar1 = *(int *)(iVar3 + 8) + -1;
    *(int *)(iVar3 + 8) = iVar1;
    if (iVar1 == 0) {
      if (iRam003d3ef0 == 0) {
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      func_0x0004313e(iRam003d3ef0,iVar3);
      iRam003d3ef4 = iRam003d3ef4 + 1;
    }
    return;
  }
  return;
}


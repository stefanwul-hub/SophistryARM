
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00170700(int param_1,undefined *param_2,char param_3)

{
  undefined4 uVar1;
  
  uVar1 = FUN_0018147a(param_2);
  *(undefined4 *)(param_1 + 0xc) = uVar1;
  *(char *)(param_1 + 0x10) = param_3;
  if (param_3 == '\0') {
    func_0x001811de(uVar1,&UNK_0017068e);
    param_2 = &UNK_001706a0;
    param_1 = *(int *)(param_1 + 0xc);
  }
  else {
    func_0x001811de(uVar1,&UNK_00170686);
    param_2 = &UNK_001706d6;
    param_1 = *(int *)(param_1 + 0xc);
  }
  *(undefined **)(param_1 + 8) = param_2;
  return;
}


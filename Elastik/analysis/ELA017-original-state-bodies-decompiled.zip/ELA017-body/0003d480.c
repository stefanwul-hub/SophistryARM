
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0003d480(int *param_1,int param_2,int *param_3)

{
  int iVar1;
  int *piVar2;
  bool bVar3;
  char cVar4;
  short sVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  char *pcVar10;
  undefined4 uVar11;
  uint uVar12;
  int iVar13;
  undefined8 in_stack_ffffef4c;
  int iStack_102c;
  int iStack_1028;
  int iStack_1020;
  char acStack_101c [4108];
  
  if (iRam003d41a0 == 0) {
    iRam003d41a0 = func_0x00039216("c");
    uRam003d419c = func_0x00039216("diuoxX");
    uRam003d4194 = func_0x00039216("eEfgG");
    uRam003d4198 = func_0x00039216("sp");
  }
  if (param_2 == 0) {
    uVar6 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                           );
    uVar11 = FUN_00033b90("GNAssertionException");
    in_stack_ffffef4c = CONCAT44(uVar6,0x10f);
    FUN_0000bfd6(uVar11,"Assertion failed in line %d of %s: %s.",0x10f,uVar6,"this != 0");
  }
  iStack_102c = *(int *)(param_2 + 0x14);
  if (iStack_102c == -1) {
    if (*(char **)(param_2 + 0xc) == (char *)0x0) {
      iStack_102c = 0;
    }
    else {
      uVar12 = 0xffffffff;
      pcVar10 = *(char **)(param_2 + 0xc);
      do {
        if (uVar12 == 0) break;
        uVar12 = uVar12 - 1;
        cVar4 = *pcVar10;
        pcVar10 = pcVar10 + 1;
      } while (cVar4 != '\0');
      iStack_102c = ~uVar12 - 1;
    }
  }
  iStack_1028 = 0;
  do {
    iVar13 = 0;
    iVar1 = iStack_1028;
    while( true ) {
      if (iStack_102c <= iVar1) {
        if (iVar13 != 0) {
          uVar6 = func_0x0003a042(param_2,iStack_1028,iVar13);
          func_0x0003b118(param_1,uVar6);
        }
        return;
      }
      sVar5 = FUN_00035d80(param_2,iVar1);
      if (sVar5 == 0x25) break;
      iVar13 = iVar13 + 1;
      iVar1 = iStack_1028 + iVar13;
    }
    if (iVar13 != 0) {
      in_stack_ffffef4c = CONCAT44((int)((ulonglong)in_stack_ffffef4c >> 0x20),iVar13);
      uVar6 = func_0x0003a042(param_2,iStack_1028,iVar13);
      func_0x0003b118(param_1,uVar6);
    }
    acStack_101c[0] = '\0';
    iStack_1020 = iVar1 + 1;
    iStack_1028 = 1;
    do {
      while (iVar13 = iStack_1028, iStack_1020 < iStack_102c) {
        sVar5 = FUN_00035d80(param_2,iStack_1020);
        if (sVar5 == 0x25) goto LAB_0003d720;
LAB_0003d67a:
        iStack_1028 = iStack_1028 + 1;
        if (sVar5 == 0x40) {
          piVar2 = param_3 + 1;
          piVar9 = (int *)*param_3;
          param_3 = piVar2;
          if (piVar9 == (int *)0x0) {
            piVar9 = (int *)FUN_00033b90("");
          }
          else {
            iVar7 = (**(code **)(*piVar9 + 8))(piVar9);
            iVar8 = (**(code **)(*param_1 + 8))(param_1);
            if (iVar7 != iVar8) {
              piVar9 = (int *)(**(code **)(*piVar9 + 0xc))(piVar9);
            }
          }
          goto LAB_0003d6ba;
        }
        iVar7 = (int)(char)sVar5;
        cVar4 = FUN_000342c6(iRam003d41a0,iVar7);
        if (cVar4 == '\0') {
          cVar4 = FUN_000342c6(uRam003d419c,iVar7);
          if (cVar4 != '\0') {
            iVar7 = *param_3;
            uVar6 = (undefined4)((ulonglong)in_stack_ffffef4c >> 0x20);
            iVar8 = func_0x0003a042(param_2,iVar1,iStack_1028);
            if (iVar8 == 0) {
              uVar6 = func_0x0000a930(
                                     "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                                     );
              uVar11 = FUN_00033b90("GNAssertionException");
              FUN_0000bfd6(uVar11,"Assertion failed in line %d of %s: %s.",0x119,uVar6,"this != 0");
            }
            if ((*(int *)(iVar8 + 0xc) == 0) && (*(int *)(iVar8 + 0x14) != -1)) {
              FUN_000340ba(iVar8);
            }
            pcVar10 = *(char **)(iVar8 + 0xc);
            if (pcVar10 == (char *)0x0) {
              pcVar10 = "";
            }
            in_stack_ffffef4c = CONCAT44(uVar6,iVar7);
            param_3 = param_3 + 1;
            goto LAB_0003d7be;
          }
          cVar4 = FUN_000342c6(uRam003d4194,iVar7);
          if (cVar4 != '\0') {
            piVar2 = param_3 + 2;
            in_stack_ffffef4c = *(undefined8 *)param_3;
            iVar7 = func_0x0003a042(param_2,iVar1,iStack_1028);
            if (iVar7 == 0) {
              uVar6 = func_0x0000a930(
                                     "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                                     );
              uVar11 = FUN_00033b90("GNAssertionException");
              FUN_0000bfd6(uVar11,"Assertion failed in line %d of %s: %s.",0x119,uVar6,"this != 0");
            }
            if ((*(int *)(iVar7 + 0xc) == 0) && (*(int *)(iVar7 + 0x14) != -1)) {
              FUN_000340ba(iVar7);
            }
            pcVar10 = *(char **)(iVar7 + 0xc);
            param_3 = piVar2;
            if (pcVar10 == (char *)0x0) {
              pcVar10 = "";
            }
            goto LAB_0003d7be;
          }
          cVar4 = FUN_000342c6(uRam003d4198,iVar7);
          if (cVar4 != '\0') {
            iVar7 = *param_3;
            uVar6 = (undefined4)((ulonglong)in_stack_ffffef4c >> 0x20);
            iVar8 = func_0x0003a042(param_2,iVar1,iStack_1028);
            if (iVar8 == 0) {
              uVar6 = func_0x0000a930(
                                     "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                                     );
              uVar11 = FUN_00033b90("GNAssertionException");
              FUN_0000bfd6(uVar11,"Assertion failed in line %d of %s: %s.",0x119,uVar6,"this != 0");
            }
            if ((*(int *)(iVar8 + 0xc) == 0) && (*(int *)(iVar8 + 0x14) != -1)) {
              FUN_000340ba(iVar8);
            }
            pcVar10 = *(char **)(iVar8 + 0xc);
            if (pcVar10 == (char *)0x0) {
              pcVar10 = "";
            }
            goto LAB_0003d7ba;
          }
          bVar3 = false;
          goto LAB_0003d6ce;
        }
        iVar7 = (int)(char)*param_3;
        uVar6 = (undefined4)((ulonglong)in_stack_ffffef4c >> 0x20);
        iVar8 = func_0x0003a042(param_2,iVar1,iStack_1028);
        if (iVar8 == 0) {
          uVar6 = func_0x0000a930(
                                 "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNString.cpp"
                                 );
          uVar11 = FUN_00033b90("GNAssertionException");
          FUN_0000bfd6(uVar11,"Assertion failed in line %d of %s: %s.",0x119,uVar6,"this != 0");
        }
        if ((*(int *)(iVar8 + 0xc) == 0) && (*(int *)(iVar8 + 0x14) != -1)) {
          FUN_000340ba(iVar8);
          pcVar10 = *(char **)(iVar8 + 0xc);
        }
        else {
          pcVar10 = *(char **)(iVar8 + 0xc);
        }
        if (pcVar10 == (char *)0x0) {
          pcVar10 = "";
        }
LAB_0003d7ba:
        param_3 = param_3 + 1;
        in_stack_ffffef4c = CONCAT44(uVar6,iVar7);
LAB_0003d7be:
        _sprintf(acStack_101c,pcVar10,in_stack_ffffef4c);
        bVar3 = true;
        if (acStack_101c[0] != '\0') goto LAB_0003d7e2;
LAB_0003d6db:
        iStack_1028 = iVar13 + 1;
        iStack_1020 = iStack_1020 + 1;
        if (bVar3) goto LAB_0003d829;
      }
      if ((*(int *)(param_2 + 0xc) == 0) && (*(int *)(param_2 + 0x14) != -1)) {
        FUN_000340ba(param_2);
      }
      pcVar10 = *(char **)(param_2 + 0xc);
      if (pcVar10 == (char *)0x0) {
        pcVar10 = "";
      }
      FUN_0000acae("Error while parsing %s.",pcVar10);
      sVar5 = FUN_00035d80(param_2,iStack_1020);
      if (sVar5 != 0x25) goto LAB_0003d67a;
LAB_0003d720:
      piVar9 = (int *)FUN_00033b90("%");
LAB_0003d6ba:
      func_0x0003b118(param_1,piVar9);
      bVar3 = true;
LAB_0003d6ce:
      if (acStack_101c[0] == '\0') goto LAB_0003d6db;
LAB_0003d7e2:
      iStack_1028 = iVar13 + 1;
      uVar12 = 0xffffffff;
      pcVar10 = acStack_101c;
      do {
        if (uVar12 == 0) break;
        uVar12 = uVar12 - 1;
        cVar4 = *pcVar10;
        pcVar10 = pcVar10 + 1;
      } while (cVar4 != '\0');
      in_stack_ffffef4c = 0;
      func_0x000384d4(param_1,acStack_101c,~uVar12 - 1);
      iStack_1020 = iStack_1020 + 1;
    } while (!bVar3);
LAB_0003d829:
    iStack_1028 = iVar13 + 1;
    iStack_1028 = iVar1 + iStack_1028;
  } while( true );
}


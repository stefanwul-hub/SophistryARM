
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_000424ac(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x11e,uVar3,"this != 0");
  }
  if (param_2 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x11e,uVar3,"anElement");
  }
  iVar5 = func_0x0004226a(param_1,param_2);
  if (iVar5 == -1) {
    return;
  }
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0xe8,uVar3,"this != 0");
  }
  if (iVar5 < 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0xe8,uVar3,"index >= 0");
  }
  if (*(int *)(param_1 + 0x10) < iVar5) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0xe8,uVar3,"index <= _numElements");
  }
  iVar2 = *(int *)(param_1 + 0x10) + -1;
  if (iVar5 < iVar2) {
    do {
      iVar2 = *(int *)(param_1 + 0x18);
      iVar1 = iVar5 + 1;
      _memcpy(*(int *)(param_1 + 0xc) + iVar5 * iVar2,*(int *)(param_1 + 0xc) + iVar2 * iVar1,iVar2)
      ;
      iVar2 = *(int *)(param_1 + 0x10) + -1;
      iVar5 = iVar1;
    } while (iVar1 < iVar2);
  }
  *(int *)(param_1 + 0x10) = iVar2;
  return;
}


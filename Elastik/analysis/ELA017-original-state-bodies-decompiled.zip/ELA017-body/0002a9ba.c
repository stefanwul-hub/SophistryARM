
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0002a9ba(int param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iStack_20;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x243,uVar3,"this != 0");
  }
  if ((param_2 != (int *)0x0) || (*(char *)(param_1 + 0x19) != '\0')) {
    iVar2 = func_0x0002a8c2(param_1,param_2);
    if (iVar2 != -1) {
      return iVar2;
    }
    if (param_2 == (int *)0x0) {
      return -1;
    }
    if (0 < *(int *)(param_1 + 0x10)) {
      iVar2 = 0;
      iStack_20 = 0;
      while (cVar1 = (**(code **)(*param_2 + 0x88))
                               (param_2,*(undefined4 *)(iStack_20 + *(int *)(param_1 + 0xc))),
            cVar1 == '\0') {
        iVar2 = iVar2 + 1;
        iStack_20 = iStack_20 + 4;
        if (*(int *)(param_1 + 0x10) <= iVar2) {
          return -1;
        }
      }
      if (*(int *)(iStack_20 + *(int *)(param_1 + 0xc)) != 0) {
        return iVar2;
      }
    }
  }
  return -1;
}


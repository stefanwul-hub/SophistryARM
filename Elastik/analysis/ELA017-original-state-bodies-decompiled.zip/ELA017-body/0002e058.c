
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0002e058(int param_1)

{
  if (param_1 != 0) {
    if (*(int *)(param_1 + 8) == -0x10) {
      FUN_0000ab14("On address %x: Released object detected.",param_1);
      return 0;
    }
    if (2 < *(int *)(param_1 + 8) + 0x100U) {
      FUN_0000ab14("On address %x: Refering to some memory which is not representing an object.",
                   param_1);
      return 0;
    }
  }
  return 1;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00033b90(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  
  if (piRam003d4050 == (int *)0x0) {
    uVar2 = __Znwm(0x38);
    FUN_0006f04a(uVar2);
    piRam003d4050 = (int *)FUN_0002dfa6(uVar2);
    (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
  }
  else {
    (**(code **)(*piRam003d4050 + 0x1a4))(piRam003d4050);
  }
  if (iRam003d4054 == 0) {
    uVar2 = __Znwm(0x14);
    FUN_00084dba(uVar2);
    iRam003d4054 = FUN_0002dfa6(uVar2);
  }
  FUN_000854fe(iRam003d4054,param_1);
  if (iRam003d4058 == 0) {
    uVar2 = __Znwm(0x18);
    FUN_000630b6(uVar2);
    iRam003d4058 = FUN_0002dfa6(uVar2);
    FUN_00065c4a(iRam003d4058,1);
  }
  iVar1 = FUN_0006440e(iRam003d4058,iRam003d4054);
  if (iVar1 != -1) {
    uVar2 = FUN_00063ade(iRam003d4058);
    uVar2 = FUN_0002a364(uVar2,iVar1);
    (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
    return uVar2;
  }
  uVar2 = __Znwm(0x14);
  FUN_00084dba(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  FUN_000854fe(piVar3,param_1);
  uVar2 = FUN_00033aa6(param_1);
  FUN_00066284(iRam003d4058,uVar2,piVar3);
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x44))(piVar3);
  }
  (**(code **)(*piRam003d4050 + 0x1ac))(piRam003d4050);
  return uVar2;
}


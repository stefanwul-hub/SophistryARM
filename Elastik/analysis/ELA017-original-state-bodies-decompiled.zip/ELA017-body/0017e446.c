
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0017e446(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  func_0x0017e2fa(param_1,param_2);
  uVar2 = FUN_000278d6(param_2);
  FUN_0000ab14("SwapIn:  Read:       %i (%i bytes).",1,uVar2);
  iVar1 = *(int *)(param_1 + 0x30);
  iVar3 = FUN_000278d6(param_2);
  *(int *)(param_1 + 0x30) = iVar1 - iVar3;
  return;
}


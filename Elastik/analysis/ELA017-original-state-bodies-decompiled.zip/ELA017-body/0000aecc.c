
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0000aecc(int param_1)

{
  short sVar1;
  int iVar2;
  
  iVar2 = _malloc(param_1 + iRam003d3ed8);
  if (iVar2 == 0) {
    sVar1 = _MemError();
    FUN_0000ae5a((int)sVar1,"Out of memory. Cannot allocate %i bytes",param_1);
  }
  if (cRam003d3f0a == '\0') {
    cRam003d3f0a = 1;
    if (iRam003d3ee8 != 0) {
      FUN_00042ffe(iRam003d3ee8,iVar2);
      if (iRam003d3ed8 != 0) {
        _memset(iVar2 + param_1,0xfe,iRam003d3ed8);
      }
      iRam003d3edc = iRam003d3edc + 1;
    }
    cRam003d3f0a = '\0';
  }
  return iVar2;
}


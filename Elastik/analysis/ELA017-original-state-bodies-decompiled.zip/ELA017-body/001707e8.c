
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001707e8(int param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  char *pcVar6;
  undefined4 uVar7;
  uint uVar8;
  int iVar9;
  char *pcVar10;
  int in_stack_ffffffe8;
  int aiStack_14 [2];
  
  if ((*(char *)(param_1 + 0x11) == '\0') && (param_2 != (int *)0x0)) {
    (**(code **)(*param_2 + 0x40))(param_2);
  }
  iVar2 = *(int *)(*(int *)(param_1 + 0xc) + 0x14);
  if ((iVar2 != 1) && (iVar2 != 2)) {
    if (iVar2 != 0) {
      return;
    }
    aiStack_14[0] = 1;
    func_0x001817d4(*(int *)(param_1 + 0xc),param_2);
    return;
  }
  _exit(1);
  iVar2 = *(int *)(in_stack_ffffffe8 + 0x18);
  if (iVar2 == aiStack_14[0]) {
    return;
  }
  iVar3 = *(int *)(in_stack_ffffffe8 + 0x20);
  *(int *)(in_stack_ffffffe8 + 0x18) = aiStack_14[0];
  *(undefined4 *)(in_stack_ffffffe8 + 0x1c) = 0;
  uVar7 = FUN_0000aecc(aiStack_14[0] * 4);
  *(undefined4 *)(in_stack_ffffffe8 + 0x20) = uVar7;
  _memset(uVar7,0,aiStack_14[0] * 4);
  if (iVar2 != 0) {
    iVar9 = 0;
    do {
      iVar4 = *(int *)(iVar3 + iVar9 * 4);
      if (iVar4 != 0) {
        iVar5 = *(int *)(in_stack_ffffffe8 + 0x14);
        if ((iVar5 == 1) || (iVar5 == 2)) {
          _exit(1);
          return;
        }
        if (iVar5 == 0) {
          func_0x001817d4(in_stack_ffffffe8,iVar4,0);
        }
      }
      iVar9 = iVar9 + 1;
    } while (iVar2 != iVar9);
  }
  if (iVar3 != 0) {
    if ((cRam003d3f09 == '\0') && (cRam003d3f09 = 1, iRam003d3ee8 != 0)) {
      FUN_000424ac(iRam003d3ee8,iVar3);
    }
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  pcVar6 = "GNFree(0)";
  if (cRam003d3ef8 == '\0') {
    uVar8 = 0xffffffff;
    pcVar10 = pcVar6;
    do {
      if (uVar8 == 0) break;
      uVar8 = uVar8 - 1;
      cVar1 = *pcVar10;
      pcVar10 = pcVar10 + 1;
    } while (cVar1 != '\0');
    uVar8 = ~uVar8 - 1;
    if (uVar8 < 0x2000) {
      pcVar10 = pcVar6;
      pcVar6 = (char *)FUN_0000aecc(uVar8 * 3 + 0x400);
      _vsprintf(pcVar6,pcVar10,aiStack_14);
    }
    if (piRam003d3f0c == (int *)0x0) {
      uVar7 = __Znwm(0x38);
      FUN_0006f04a(uVar7);
      piRam003d3f0c = (int *)FUN_0002dfa6(uVar7);
    }
    (**(code **)(*piRam003d3f0c + 0x1a4))(piRam003d3f0c);
    _puts(pcVar6);
    (**(code **)(*piRam003d3f0c + 0x1ac))(piRam003d3f0c);
    if (uVar8 < 0x2000) {
      if (pcVar6 != (char *)0x0) {
        if (cRam003d3f09 == '\0') {
          cRam003d3f09 = 1;
          if (iRam003d3ee8 != 0) {
            FUN_000424ac(iRam003d3ee8,pcVar6);
          }
          cRam003d3f09 = '\0';
        }
        _free(pcVar6);
        return;
      }
      FUN_0000ab14("GNFree(0)");
    }
  }
  return;
}


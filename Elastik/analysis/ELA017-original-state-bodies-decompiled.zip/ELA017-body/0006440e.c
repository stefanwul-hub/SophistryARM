
int FUN_0006440e(int param_1,int *param_2)

{
  int iVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  undefined4 uVar7;
  int *piVar8;
  int iStack_40;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int iStack_1c;
  int *piStack_18;
  int *piStack_14;
  int *piStack_10;
  
  iVar4 = (**(code **)(*param_2 + 0x90))(param_2);
  iVar5 = FUN_00029ddc(*(undefined4 *)(param_1 + 0xc));
  piVar6 = (int *)func_0x000427b6(*(undefined4 *)(param_1 + 0x14));
  iVar1 = iVar5 + -1;
  if (iVar5 == 0) {
    return -1;
  }
  if (iVar4 < *piVar6) {
    return -1;
  }
  if (piVar6[iVar1 * 2] < iVar4) {
    return -1;
  }
  if (iVar1 < 0) {
    return -1;
  }
  iStack_1c = iVar1 / 2;
  if (iStack_1c < 0) {
    return -1;
  }
  if (iVar5 <= iStack_1c) {
    return -1;
  }
  iStack_2c = 0;
  iStack_28 = iVar1;
  while( true ) {
    piStack_18 = piVar6 + iStack_1c * 2;
    if (iVar4 == *piStack_18) break;
    if (iVar4 < *piStack_18) {
      iStack_28 = iStack_1c + -1;
    }
    else {
      iStack_2c = iStack_1c + 1;
    }
    if (iStack_28 < iStack_2c) {
      return -1;
    }
    iStack_1c = (iStack_2c + iStack_28) / 2;
    if (iStack_1c < 0) {
      return -1;
    }
    if (iVar5 <= iStack_1c) {
      return -1;
    }
  }
  iStack_40 = iStack_1c;
  if ((0 < iStack_1c) && (iVar4 == piVar6[iStack_1c * 2 + -2])) {
    piStack_10 = piStack_18 + -4;
    do {
      iStack_40 = iStack_40 + -1;
      if (iStack_40 == 0) break;
      iVar5 = *piStack_10;
      piStack_10 = piStack_10 + -2;
    } while (iVar4 == iVar5);
  }
  if ((iStack_1c < iVar1) && (iVar4 == piVar6[iStack_1c * 2 + 2])) {
    piStack_14 = piVar6 + iStack_1c * 2 + 4;
    do {
      iStack_1c = iStack_1c + 1;
      if (iStack_1c == iVar1) break;
      iVar5 = *piStack_14;
      piStack_14 = piStack_14 + 2;
    } while (iVar4 == iVar5);
  }
  if (iStack_1c != iStack_40) {
    if (iStack_1c < iStack_40) {
      piStack_18 = piVar6 + iStack_40 * 2;
    }
    else {
      piVar8 = piVar6 + iStack_40 * 2;
      iStack_24 = iStack_40;
      do {
        pcVar2 = *(code **)(*param_2 + 0x88);
        uVar7 = FUN_0002a364(*(undefined4 *)(param_1 + 0xc),piVar8[1]);
        cVar3 = (*pcVar2)(param_2,uVar7);
        if (cVar3 != '\0') {
          return piVar8[1];
        }
        iStack_24 = iStack_24 + 1;
        piVar8 = piVar8 + 2;
      } while (iStack_24 <= iStack_1c);
      piStack_18 = piVar6 + iStack_24 * 2;
    }
  }
  pcVar2 = *(code **)(*param_2 + 0x88);
  uVar7 = FUN_0002a364(*(undefined4 *)(param_1 + 0xc),piStack_18[1]);
  cVar3 = (*pcVar2)(param_2,uVar7);
  if (cVar3 == '\0') {
    return -1;
  }
  return piStack_18[1];
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

dword FUN_0000ae24(int param_1)

{
  if (param_1 != 0) {
    return *(dword *)(param_1 + 4);
  }
  FUN_0000acae("GNMemoryHandle is nil.");
  return mach_header_00000000.cputype;
}


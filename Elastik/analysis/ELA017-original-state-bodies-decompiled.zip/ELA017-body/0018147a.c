
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 * FUN_0018147a(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int iStack_20;
  
  puVar1 = (undefined4 *)FUN_0000aecc(0x24);
  if (param_1 == 0) {
    param_1 = iRam00366280;
    if (iRam00366280 == 0) {
      iStack_20 = 0;
    }
    else {
      iStack_20 = iRam00366280 * 4;
    }
  }
  else {
    iStack_20 = param_1 * 4;
  }
  *puVar1 = &UNK_001810d0;
  puVar1[1] = 0;
  puVar1[2] = &UNK_001810d8;
  puVar1[3] = 0;
  puVar1[4] = 0;
  puVar1[6] = param_1;
  puVar1[7] = 0;
  puVar1[5] = 0;
  uVar2 = FUN_0000aecc(iStack_20);
  puVar1[8] = uVar2;
  _memset(uVar2,0,iStack_20);
  return puVar1;
}


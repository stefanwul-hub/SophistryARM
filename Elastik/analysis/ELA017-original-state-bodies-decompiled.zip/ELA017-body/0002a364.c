
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0002a364(int *param_1,int param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == (int *)0x0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x15b,uVar1,"this != 0");
  }
  if ((param_2 < 0) || (param_1[4] <= param_2)) {
    uVar1 = (**(code **)(*param_1 + 0xc))(param_1);
    uVar1 = FUN_00034962(uVar1);
    FUN_0000acae("GNList::getObjectAtIndex(): Index %i out of range of %s.",param_2,uVar1);
  }
  return *(undefined4 *)(param_1[3] + param_2 * 4);
}


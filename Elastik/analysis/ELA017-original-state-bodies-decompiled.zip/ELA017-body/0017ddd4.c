
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0017ddd4(void)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 *puVar5;
  int *piVar6;
  
  if (iRam003d494c != 0) {
    return iRam003d494c;
  }
  uVar2 = FUN_00033b90("GNDefaultSwapFilePath");
  uVar3 = func_0x0006c39c();
  iVar4 = func_0x0006ca86(uVar3,uVar2);
  if (iVar4 == 0) {
    piVar6 = (int *)func_0x0009b8fa();
    if (piVar6 != (int *)0x0) {
      pcVar1 = *(code **)(*piVar6 + 0x20c);
      uVar2 = FUN_00033b90("APVM");
      uVar3 = FUN_0003dd2a("Appwork VM");
      iVar4 = (*pcVar1)(piVar6,uVar3,uVar2);
      if (iVar4 != 0) goto LAB_0017de21;
    }
    FUN_0000acae("Cannot create swap file.");
    iVar4 = 0;
  }
LAB_0017de21:
  puVar5 = (undefined4 *)__Znwm(0x34);
  func_0x0017e5fa(puVar5);
  *puVar5 = &UNK_0038fac8;
  puVar5[9] = 0;
  puVar5[10] = 0;
  puVar5[0xc] = 0;
  iRam003d494c = FUN_0002dfa6(puVar5);
  func_0x0017e9be(iRam003d494c,iVar4);
  return iRam003d494c;
}


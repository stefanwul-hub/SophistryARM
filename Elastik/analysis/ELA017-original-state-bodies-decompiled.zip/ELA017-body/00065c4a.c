
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00065c4a(int param_1,char param_2)

{
  int iVar1;
  undefined4 *puVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  
  if (param_2 == '\0') {
    piVar3 = *(int **)(param_1 + 0x14);
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x44))(piVar3);
      *(undefined4 *)(param_1 + 0x14) = 0;
      return;
    }
  }
  else if (*(int *)(param_1 + 0x14) == 0) {
    uVar4 = __Znwm(0x24);
    func_0x00041414(uVar4);
    uVar4 = FUN_0002dfa6(uVar4);
    *(undefined4 *)(param_1 + 0x14) = uVar4;
    func_0x000416b2(uVar4,0);
    func_0x00041774(*(undefined4 *)(param_1 + 0x14),8);
    func_0x0004258e(*(undefined4 *)(param_1 + 0x14));
    iVar1 = FUN_00029ddc(*(undefined4 *)(param_1 + 0xc));
    func_0x00041ab8(*(undefined4 *)(param_1 + 0x14),iVar1);
    func_0x00042828(*(undefined4 *)(param_1 + 0x14));
    puVar2 = (undefined4 *)func_0x000427b6(*(undefined4 *)(param_1 + 0x14));
    if (iVar1 < 1) {
      func_0x00042668(*(undefined4 *)(param_1 + 0x14),&UNK_000643fe,0);
      return;
    }
    iVar5 = 0;
    do {
      piVar3 = (int *)FUN_0002a364(*(undefined4 *)(param_1 + 0xc),iVar5);
      uVar4 = (**(code **)(*piVar3 + 0x90))(piVar3);
      *puVar2 = uVar4;
      puVar2[1] = iVar5;
      puVar2 = puVar2 + 2;
      iVar5 = iVar5 + 1;
    } while (iVar1 != iVar5);
    func_0x00042668(*(undefined4 *)(param_1 + 0x14),&UNK_000643fe,0);
    return;
  }
  return;
}


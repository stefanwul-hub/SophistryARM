
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0002bff8(int *param_1,int *param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x18c,uVar2,"this != 0");
  }
  if ((param_2 == (int *)0x0) && (*(char *)((int)param_1 + 0x19) == '\0')) {
    uVar2 = (**(code **)(*param_1 + 0xc))(param_1);
    uVar2 = FUN_00034962(uVar2);
    FUN_0000acae("GNList::insertObjectAtIndex(): Cannot insert nil object into %s.",uVar2);
  }
  if ((param_1[4] < param_3) || (param_3 < 0)) {
    uVar2 = (**(code **)(*param_1 + 0xc))(param_1);
    uVar2 = FUN_00034962(uVar2);
    FUN_0000acae("GNList::insertObjectAtIndex(): Index %i out of range of %s.",param_3,uVar2);
    iVar1 = param_1[4] + 1;
    param_1[4] = iVar1;
  }
  else {
    iVar1 = param_1[4] + 1;
    param_1[4] = iVar1;
  }
  iVar4 = iVar1 * 0x10 + 1;
  if (iVar4 < 0) {
    iVar4 = iVar1 * 0x10 + 0x10;
  }
  func_0x0002a14a(param_1,iVar4 >> 4);
  iVar1 = param_1[4] + -1;
  if (param_3 < iVar1) {
    iVar4 = iVar1 * 4;
    do {
      *(undefined4 *)(iVar4 + param_1[3]) = ((undefined4 *)(iVar4 + param_1[3]))[-1];
      iVar1 = iVar1 + -1;
      iVar4 = iVar4 + -4;
    } while (param_3 < iVar1);
  }
  *(int **)(param_1[3] + param_3 * 4) = param_2;
  if (((char)param_1[6] == '\0') && (param_2 != (int *)0x0)) {
    (**(code **)(*param_2 + 0x40))(param_2);
  }
  return;
}


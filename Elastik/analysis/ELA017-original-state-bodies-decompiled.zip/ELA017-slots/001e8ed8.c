
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001e8ed8(char *param_1,char *param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  char *pcVar5;
  
  uVar2 = (**(code **)(*(int *)param_1 + 8))(param_1);
  iVar3 = func_0x0001f4dc(uVar2);
  if (iVar3 == 0) {
    param_2 = "";
  }
  else {
    uVar2 = (**(code **)(*(int *)param_1 + 8))(param_1);
    uVar2 = func_0x0001f4dc(uVar2);
    param_2 = (char *)FUN_00034962(uVar2);
  }
  param_1 = "encodeInt64() not implemented by %s";
  if (cRam003d3ef8 == '\0') {
    uVar4 = 0xffffffff;
    pcVar5 = param_1;
    do {
      if (uVar4 == 0) break;
      uVar4 = uVar4 - 1;
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    uVar4 = ~uVar4 - 1;
    if (uVar4 < 0x2000) {
      param_1 = (char *)FUN_0000aecc(uVar4 * 3 + 0x400);
      _vsprintf(param_1,"encodeInt64() not implemented by %s",&param_2);
    }
    if (piRam003d3f0c == (int *)0x0) {
      uVar2 = __Znwm(0x38);
      func_0x0006f04a(uVar2);
      piRam003d3f0c = (int *)FUN_0002dfa6(uVar2);
    }
    (**(code **)(*piRam003d3f0c + 0x1a4))(piRam003d3f0c);
    _puts(param_1);
    (**(code **)(*piRam003d3f0c + 0x1ac))(piRam003d3f0c);
    if (uVar4 < 0x2000) {
      if (param_1 != (char *)0x0) {
        if (cRam003d3f09 == '\0') {
          cRam003d3f09 = 1;
          if (iRam003d3ee8 != 0) {
            func_0x000424ac(iRam003d3ee8,param_1);
          }
          cRam003d3f09 = '\0';
        }
        _free(param_1);
        return;
      }
      FUN_0000ab14("GNFree(0)");
    }
  }
  return;
}


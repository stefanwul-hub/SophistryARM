
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_001b6af0(int param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  char *pcVar3;
  undefined4 uVar4;
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x1cd,uVar2,"this != 0");
  }
  if (param_2 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x1cd,uVar2,"d != 0");
  }
  if (*(int *)(param_1 + 0x1c) == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x1cd,uVar2,
                 "_classDescriptions != 0");
  }
  iVar1 = FUN_0002a9ba(*(undefined4 *)(param_1 + 0x1c),param_2);
  if (iVar1 != -1) {
    return iVar1 + 1;
  }
  iVar1 = (**(code **)(*param_2 + 0xc))(param_2);
  if (iVar1 == 0) {
    pcVar3 = "";
  }
  else {
    uVar2 = (**(code **)(*param_2 + 0xc))(param_2);
    pcVar3 = (char *)FUN_00034962(uVar2);
  }
  FUN_0000acae("GNArchiver: Cannot create classnumber for unregistered class %s",pcVar3);
  return 0;
}


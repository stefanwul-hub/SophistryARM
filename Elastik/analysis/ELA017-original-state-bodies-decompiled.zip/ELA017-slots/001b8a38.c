
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001b8a38(int param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int aiStack_20 [4];
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x1e6,uVar3,"this != 0");
  }
  if (*(int *)(param_1 + 0x24) == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x1e6,uVar3,"_stream");
  }
  if (*(char *)(param_1 + 0x28) != '\0') {
    cVar1 = FUN_00163006(*(undefined4 *)(param_1 + 0x24),aiStack_20);
    *(char *)(param_1 + 0x28) = cVar1;
    if ((cVar1 != '\0') && (aiStack_20[0] != 0)) {
      uVar3 = FUN_001b894a(param_1,aiStack_20[0]);
      return uVar3;
    }
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001b8cc8(int param_1,int *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int aiStack_20 [4];
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x200,uVar1,"this != 0");
  }
  if (*(int *)(param_1 + 0x24) == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x200,uVar1,"_stream");
  }
  if (*(char *)(param_1 + 0x28) != '\0') {
    uVar1 = FUN_00163c82(*(undefined4 *)(param_1 + 0x24),aiStack_20);
    if (aiStack_20[0] != -1) {
      if (param_2 == (int *)0x0) {
        return uVar1;
      }
      *param_2 = aiStack_20[0];
      return uVar1;
    }
    *(undefined1 *)(param_1 + 0x28) = 0;
  }
  return 0;
}


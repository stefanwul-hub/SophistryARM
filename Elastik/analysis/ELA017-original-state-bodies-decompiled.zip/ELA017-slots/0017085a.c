
undefined4 FUN_0017085a(int param_1,int param_2)

{
  int iVar1;
  
  if (*(char *)(param_1 + 0x10) == '\0') {
    iVar1 = func_0x0018175c(*(undefined4 *)(param_1 + 0xc),param_2);
    if (iVar1 != 0) {
      return 1;
    }
  }
  else {
    iVar1 = func_0x0018175c(*(undefined4 *)(param_1 + 0xc),param_2);
    if (param_2 == iVar1) {
      return 1;
    }
  }
  return 0;
}


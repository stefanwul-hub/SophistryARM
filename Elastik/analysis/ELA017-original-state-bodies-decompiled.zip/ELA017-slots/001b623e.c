
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001b623e(int param_1,char param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (*(int *)(param_1 + 0x20) != 2) {
    return;
  }
  if (*(int *)(param_1 + 0x28) == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x127,uVar1,"_stream");
  }
  FUN_001645bc(*(undefined4 *)(param_1 + 0x28),(-(uint)(param_2 == '\0') & 0xfffffff5) + 0x59);
  return;
}


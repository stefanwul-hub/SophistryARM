
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_00163c82(int param_1,int *param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iStack_24;
  char acStack_1d [13];
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x1ee,uVar3,"this != 0");
  }
  if ((*(int *)(param_1 + 0x14) == 0) && (*(int *)(param_1 + 0x18) == 0)) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x1ee,uVar3,"_data || _file");
  }
  if (param_2 == (int *)0x0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x1ee,uVar3,"length");
  }
  if (*(int *)(param_1 + 0x18) == 0) {
    iVar5 = *(int *)(param_1 + 0x10);
    iVar2 = FUN_000278d6(*(undefined4 *)(param_1 + 0x14));
    if (iVar5 < iVar2) {
      *param_2 = -1;
      iVar5 = FUN_00027abc(*(undefined4 *)(param_1 + 0x14));
      *(undefined1 *)(iVar5 + *(int *)(param_1 + 0x10)) = 0x62;
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
      cVar1 = FUN_00163006(param_1,&iStack_24);
      if (cVar1 != '\0') {
        *param_2 = iStack_24;
        if (iStack_24 != 0) {
          uVar3 = FUN_0000aecc(iStack_24);
          _memcpy(uVar3,iVar5 + *(int *)(param_1 + 0x10),iStack_24);
          *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + iStack_24;
          return uVar3;
        }
        uVar3 = FUN_0000aecc(0);
        return uVar3;
      }
    }
  }
  else {
    cVar1 = FUN_00180086(*(int *)(param_1 + 0x18),acStack_1d);
    if (cVar1 != '\0') {
      if (acStack_1d[0] != 'b') {
        FUN_0000ab14("GNTypedStream inconsistency: String expected.");
        return 0;
      }
      cVar1 = FUN_00163006(param_1,param_2);
      if (cVar1 != '\0') {
        uVar3 = FUN_0000aecc(*param_2);
        cVar1 = (**(code **)(**(int **)(param_1 + 0x18) + 0x1ac))
                          (*(int **)(param_1 + 0x18),uVar3,param_2);
        if (cVar1 != '\0') {
          return uVar3;
        }
      }
    }
  }
  return 0;
}


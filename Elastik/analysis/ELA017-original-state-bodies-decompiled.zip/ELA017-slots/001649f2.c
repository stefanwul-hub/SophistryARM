
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001649f2(int param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  if (param_1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xe2,uVar4,"this != 0");
  }
  if ((*(int *)(param_1 + 0x14) == 0) && (*(int *)(param_1 + 0x18) == 0)) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xe2,uVar4,"_data || _file");
  }
  if (param_3 < 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xe2,uVar4,"length >= 0");
  }
  else if ((0 < param_3) && (param_2 == 0)) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0xe4,uVar4,"bytes");
  }
  if (*(int *)(param_1 + 0x18) == 0) {
    iVar2 = param_3 + *(int *)(param_1 + 0x10);
    iVar3 = *(int *)(param_1 + 0x14);
    if (iVar3 != 0) {
      iVar3 = FUN_000278d6(iVar3);
      if (iVar2 + 0x10 < iVar3) {
        iVar3 = *(int *)(param_1 + 0x14);
      }
      else {
        FUN_00027bec(*(undefined4 *)(param_1 + 0x14));
        (**(code **)(**(int **)(param_1 + 0x14) + 0x1a4))(*(int **)(param_1 + 0x14),iVar2 + 0x410);
        FUN_00027b4e(*(undefined4 *)(param_1 + 0x14));
        iVar3 = *(int *)(param_1 + 0x14);
      }
    }
    iVar3 = FUN_00027abc(iVar3);
    *(undefined1 *)(iVar3 + *(int *)(param_1 + 0x10)) = 0x62;
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
    FUN_001640f2(param_1,param_3);
    if (param_3 != 0) {
      _memcpy(iVar3 + *(int *)(param_1 + 0x10),param_2,param_3);
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + param_3;
    }
  }
  else {
    cVar1 = func_0x00180772(*(int *)(param_1 + 0x18),0x62);
    if (((cVar1 == '\0') || (cVar1 = FUN_001640f2(param_1,param_3), cVar1 == '\0')) ||
       (cVar1 = (**(code **)(**(int **)(param_1 + 0x18) + 0x1b0))
                          (*(int **)(param_1 + 0x18),param_2,param_3), cVar1 == '\0')) {
      return 0;
    }
  }
  return 1;
}


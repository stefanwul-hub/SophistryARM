
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

dword FUN_001b8dca(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int iVar7;
  
  if (param_1 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x213,uVar4,"this != 0");
  }
  if (*(int *)(param_1 + 0x1c) == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x213,uVar4,"_classDescriptions");
  }
  if (param_2 == 0) {
    uVar4 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar5 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x213,uVar4,"classname");
  }
  iVar7 = 0;
  while( true ) {
    iVar2 = FUN_00029ddc(*(undefined4 *)(param_1 + 0x1c));
    if (iVar2 <= iVar7) {
      return 0;
    }
    iVar2 = FUN_0002a364(*(undefined4 *)(param_1 + 0x1c),iVar7);
    iVar3 = func_0x0001f4dc(iVar2);
    if (iVar3 == 0) {
      uVar4 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                             );
      uVar5 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x217,uVar4,"d->getClassname()");
      piVar6 = (int *)func_0x0001f4dc(iVar2);
      cVar1 = (**(code **)(*piVar6 + 0x88))(piVar6,param_2);
    }
    else {
      piVar6 = (int *)func_0x0001f4dc(iVar2);
      cVar1 = (**(code **)(*piVar6 + 0x88))(piVar6,param_2);
    }
    if (cVar1 != '\0') break;
    iVar7 = iVar7 + 1;
  }
  if (iVar2 != 0) {
    return *(dword *)(iVar2 + 0x18);
  }
  uVar4 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNClassDescription.cpp"
                         );
  uVar5 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar5,"Assertion failed in line %d of %s: %s.",0x12e,uVar4,"this != 0");
  return mach_header_00000000.flags;
}


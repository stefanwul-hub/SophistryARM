
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001b6980(int *param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  
  if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x197,uVar2,"this != 0");
  }
  if (param_2 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x197,uVar2,"classname");
  }
  piVar5 = (int *)FUN_0001fcfc(param_2);
  if (piVar5 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x199,uVar2,"desc");
    FUN_0001f9fa(0,param_3);
    param_1 = *(int **)((int)param_1 + 0x1c);
  }
  else {
    FUN_0001f9fa(piVar5,param_3);
    param_1 = *(int **)((int)param_1 + 0x1c);
  }
  if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x294,uVar2,"this != 0");
  }
  if (piVar5 == (int *)0x0) {
    if (*(char *)((int)param_1 + 0x19) == '\0') {
      uVar2 = (**(code **)(*param_1 + 0xc))(param_1);
      uVar2 = FUN_00034962(uVar2);
      FUN_0000acae("GNList::addObjectIfAbsent(): Cannot add nil object into %s.",uVar2);
    }
  }
  else if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x2df,uVar2,"this != 0");
  }
  iVar4 = FUN_0002a9ba(param_1,piVar5);
  if (iVar4 != -1) {
    return;
  }
  if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNList.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x174,uVar2,"this != 0");
  }
  if ((piVar5 == (int *)0x0) && (*(char *)((int)param_1 + 0x19) == '\0')) {
    uVar2 = (**(code **)(*param_1 + 0xc))(param_1);
    uVar2 = FUN_00034962(uVar2);
    FUN_0000acae("GNList::addObject(): Cannot add nil object to %s.",uVar2);
  }
  iVar1 = (param_1[4] + 1) * 0x10;
  iVar4 = iVar1 + 1;
  if (iVar4 < 0) {
    iVar4 = iVar1 + 0x10;
  }
  func_0x0002a14a(param_1,iVar4 >> 4);
  *(int **)(param_1[3] + param_1[4] * 4) = piVar5;
  param_1[4] = param_1[4] + 1;
  if (((char)param_1[6] == '\0') && (piVar5 != (int *)0x0)) {
    (**(code **)(*piVar5 + 0x40))(piVar5);
  }
  return;
}


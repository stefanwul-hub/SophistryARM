
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001b66c4(int *param_1,int *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  if ((param_1[8] == 1) && (param_2 != (int *)0x0)) {
    if (param_1[0xc] == 0) {
      cVar1 = FUN_0002ae60(param_1[6],param_2);
    }
    else {
      cVar1 = FUN_0017085a(param_1[0xc],param_2);
    }
    if (cVar1 == '\0') {
      cVar1 = (**(code **)(*param_2 + 0x80))(param_2);
      if (cVar1 == '\0') {
        FUN_0002bff8(param_1[6],param_2,1);
      }
      else {
        FUN_0002bb40(param_1[6],param_2);
      }
      if (param_1[0xc] != 0) {
        FUN_001707e8(param_1[0xc],param_2);
      }
      (**(code **)(*param_2 + 0x70))(param_2,param_1);
    }
  }
  if (param_1[8] == 2) {
    if (param_1[10] == 0) {
      uVar2 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNArchiver.cpp"
                             );
      uVar3 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x178,uVar2,"_stream");
    }
    if (param_2 != (int *)0x0) {
      uVar2 = (**(code **)(*param_1 + 0x2c8))(param_1,param_2);
      FUN_001640f2(param_1[10],uVar2);
      return;
    }
    FUN_001640f2(param_1[10],0);
  }
  return;
}


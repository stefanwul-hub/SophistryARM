
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined8 FUN_001e9440(int *param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = (**(code **)(*param_1 + 8))(param_1);
  iVar2 = func_0x0001f4dc(uVar1);
  if (iVar2 != 0) {
    uVar1 = (**(code **)(*param_1 + 8))(param_1);
    uVar1 = func_0x0001f4dc(uVar1);
    uVar1 = FUN_00034962(uVar1);
    FUN_0000ab14("decodeInt64() not implemented by %s",uVar1);
    return 0;
  }
  FUN_0000ab14("decodeInt64() not implemented by %s","");
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001b816a(int param_1)

{
  undefined1 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char acStack_1d [13];
  
  if (param_1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x18e,uVar2,"this != 0");
  }
  if (*(int *)(param_1 + 0x24) == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNUnarchiver.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x18e,uVar2,"_stream");
  }
  if (*(char *)(param_1 + 0x28) != '\0') {
    uVar1 = FUN_00163580(*(undefined4 *)(param_1 + 0x24),acStack_1d);
    *(undefined1 *)(param_1 + 0x28) = uVar1;
    if (acStack_1d[0] == 'Y') {
      return 1;
    }
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00163580(int param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  char acStack_1d [13];
  
  if (param_1 == 0) {
    uVar5 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x168,uVar5,"this != 0");
  }
  if ((*(int *)(param_1 + 0x14) == 0) && (*(int *)(param_1 + 0x18) == 0)) {
    uVar5 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x168,uVar5,"_data || _file");
  }
  if (param_2 == (char *)0x0) {
    uVar5 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNTypedStream.cpp"
                           );
    uVar6 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar6,"Assertion failed in line %d of %s: %s.",0x168,uVar5,"c");
  }
  if (*(int *)(param_1 + 0x18) == 0) {
    iVar2 = *(int *)(param_1 + 0x10);
    iVar3 = FUN_000278d6(*(undefined4 *)(param_1 + 0x14));
    if (iVar3 < iVar2 + 1) {
      return 0;
    }
    iVar2 = FUN_00027abc(*(undefined4 *)(param_1 + 0x14));
    pcVar4 = (char *)(iVar2 + *(int *)(param_1 + 0x10));
    if (*pcVar4 == 'c') {
      *param_2 = pcVar4[1];
      *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 2;
      iVar2 = 1;
    }
    else {
      FUN_0000ab14("GNTypedStream inconsistency: Char expected, %c read.",(int)*pcVar4);
      iVar2 = 0;
    }
  }
  else {
    cVar1 = FUN_00180086(*(int *)(param_1 + 0x18),acStack_1d);
    if (cVar1 == '\0') {
      return 0;
    }
    if (acStack_1d[0] == 'c') {
      cVar1 = FUN_00180086(*(undefined4 *)(param_1 + 0x18),param_2);
      return (int)cVar1;
    }
    FUN_0000ab14("GNTypedStream inconsistency: Char expected.");
    iVar2 = 0;
  }
  return iVar2;
}


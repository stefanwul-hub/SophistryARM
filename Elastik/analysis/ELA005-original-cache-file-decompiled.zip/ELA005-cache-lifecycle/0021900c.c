
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_0021900c(int param_1,int param_2,int param_3,int param_4,int param_5)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iStack_20;
  
  iVar3 = *(int *)(param_1 + 0x4c);
  if (param_4 < iVar3) {
    iVar4 = iVar3 - param_4;
    if (param_4 + param_5 <= iVar3) {
      iVar4 = param_5;
    }
    if (-1 < iVar4) {
      if (0 < iVar4) {
        iStack_20 = param_2;
        param_5 = iVar4;
        do {
          iVar3 = *(int *)(param_1 + 0x50);
          iVar2 = param_4 - iVar3 * (param_4 / iVar3);
          iVar4 = iVar3 - iVar2;
          if (param_5 < iVar4) {
            iVar4 = param_5;
          }
          iVar3 = FUN_00218102(param_1,param_4 / iVar3);
          if (iVar3 == -1) {
            *(undefined1 *)(param_1 + 0x30) = 1;
            pcVar1 = *(char **)(param_1 + 0x40);
            if (*(int *)(param_1 + 0x44) < 1) {
              return 0;
            }
            iVar3 = 0;
            do {
              if ((*pcVar1 != '\0') && (*(int *)(pcVar1 + 4) != -1)) {
                FUN_0000ab14("GNSoundFileCache: buffer unnderrun at sample index %i (%i samples) with pending request from %i to %i"
                             ,param_4,param_5,*(int *)(pcVar1 + 4) * *(int *)(param_1 + 0x50),
                             *(int *)(param_1 + 0x50) * *(int *)(pcVar1 + 8));
              }
              iVar3 = iVar3 + 1;
            } while (iVar3 < *(int *)(param_1 + 0x44));
            return 0;
          }
          _memcpy(iStack_20,
                  *(int *)(*(int *)(param_1 + 0x10) + 4 + iVar3 * 8) +
                  (param_3 * *(int *)(param_1 + 0x50) + iVar2) * 4,iVar4 * 4);
          param_5 = param_5 - iVar4;
          param_4 = param_4 + iVar4;
          iStack_20 = iStack_20 + iVar4 * 4;
        } while (0 < param_5);
      }
      return 1;
    }
  }
  return 0;
}



undefined4 FUN_00218cf6(int param_1,int param_2,undefined4 param_3,int param_4,int param_5)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 0x4c);
  if (param_4 < iVar2) {
    if (param_5 + param_4 <= iVar2) {
      iVar2 = param_5 + param_4;
    }
    iVar1 = *(int *)(param_1 + 0x50);
    *(int *)(param_2 + 4) = param_4 / iVar1;
    *(int *)(param_2 + 8) = iVar2 / iVar1;
    return 1;
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4
FUN_001af4e2(int param_1,undefined4 param_2,int param_3,int param_4,int param_5,char param_6)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 auStack_468 [255];
  undefined1 auStack_6c [92];
  
  cVar2 = param_6;
  piVar1 = *(int **)(param_1 + 0x54);
  if (piVar1 == (int *)0x0) {
    FUN_0000ab14("GNSoundFile::getSamplesOfChannelForRange(): File already closed.");
  }
  else {
    uVar6 = *(uint *)(param_1 + 0x14);
    if ((uVar6 & 0x100) != 0) {
      uVar6 = uVar6 & 0xff;
    }
    iVar4 = *(int *)(param_1 + 0x24);
    if (iVar4 == 0) {
      iVar4 = (**(code **)(*piVar1 + 0x1bc))(piVar1);
    }
    if (uVar6 == 0) {
      return 0;
    }
    iVar3 = uVar6 - 1;
    if (param_3 < (int)uVar6) {
      iVar3 = param_3;
    }
    param_3 = iVar3;
    if ((param_4 < 0) || (iVar4 < param_4 + param_5)) {
      iVar3 = param_4 + param_5;
      _memset(param_2,0,param_5 << 2);
      if (param_4 < 0) {
        if (iVar3 < 1) {
          return 1;
        }
        param_4 = 0;
        param_5 = iVar3;
      }
      if (iVar4 < iVar3) {
        if (iVar4 <= param_4) {
          return 1;
        }
        param_5 = iVar4 - param_4;
      }
    }
    if (cVar2 == '\0') {
      cVar2 = FUN_0021900c(*(undefined4 *)(param_1 + 0xc),param_2,param_3,param_4,param_5);
      if (cVar2 != '\0') {
        return 1;
      }
      _memset(param_2,0,param_5 << 2);
    }
    else {
      _memset(auStack_468,0,0x3fc);
      auStack_468[param_3] = param_2;
      FUN_0000bea2(auStack_6c);
      iVar4 = _setjmp(auStack_6c);
      if (iVar4 == 0) {
        if (piRam003d4a90 == (int *)0x0) {
          uVar5 = __Znwm(0x38);
          FUN_0006f04a(uVar5);
          piRam003d4a90 = (int *)FUN_0002dfa6(uVar5);
        }
        (**(code **)(*piRam003d4a90 + 0x1a4))(piRam003d4a90);
        if (*(int *)(param_1 + 0x4c) == 1) {
          piVar1 = *(int **)(param_1 + 0x5c + param_3 * 4);
          (**(code **)(*piVar1 + 0x1c8))(piVar1,&param_2,param_4,param_5);
        }
        else {
          (**(code **)(**(int **)(param_1 + 0x54) + 0x1c8))
                    (*(int **)(param_1 + 0x54),auStack_468,param_4,param_5);
        }
        if (piRam003d4a90 == (int *)0x0) {
          uVar5 = __Znwm(0x38);
          FUN_0006f04a(uVar5);
          piRam003d4a90 = (int *)FUN_0002dfa6(uVar5);
        }
        (**(code **)(*piRam003d4a90 + 0x1ac))(piRam003d4a90);
        FUN_0000bec0(auStack_6c);
        return 1;
      }
      if (piRam003d4a90 == (int *)0x0) {
        uVar5 = __Znwm(0x38);
        FUN_0006f04a(uVar5);
        piRam003d4a90 = (int *)FUN_0002dfa6(uVar5);
      }
      (**(code **)(*piRam003d4a90 + 0x1ac))(piRam003d4a90);
    }
  }
  return 0;
}



void FUN_001aecf0(int param_1,undefined4 param_2,int param_3,int param_4,double param_5,
                 double param_6)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  
  param_4 = param_3 + param_4;
  if (0.0 < param_5) {
    param_3 = param_3 - (int)(param_5 * *(double *)(param_1 + 0x18));
  }
  if (0.0 < param_6) {
    param_4 = param_4 + (int)(param_6 * *(double *)(param_1 + 0x18));
  }
  if (param_3 < 0) {
    param_3 = 0;
  }
  iVar2 = *(int *)(param_1 + 0x24);
  if ((iVar2 == 0) && (piVar1 = *(int **)(param_1 + 0x54), piVar1 != (int *)0x0)) {
    iVar2 = (**(code **)(*piVar1 + 0x1bc))(piVar1);
  }
  if (iVar2 <= param_4) {
    param_4 = *(int *)(param_1 + 0x24);
    if (param_4 == 0) {
      piVar1 = *(int **)(param_1 + 0x54);
      if (piVar1 == (int *)0x0) {
        param_4 = -1;
        goto LAB_001aed8d;
      }
      param_4 = (**(code **)(*piVar1 + 0x1bc))(piVar1);
    }
    param_4 = param_4 + -1;
  }
LAB_001aed8d:
  if (param_4 <= param_3) {
    return;
  }
  param_4 = param_4 - param_3;
  if (*(int *)(param_1 + 0xc) == 0) {
    return;
  }
  iVar2 = *(int *)(param_1 + 0x24);
  if ((iVar2 == 0) && (piVar1 = *(int **)(param_1 + 0x54), piVar1 != (int *)0x0)) {
    iVar2 = (**(code **)(*piVar1 + 0x1bc))(piVar1);
    if (param_3 < 0) goto LAB_001aee15;
LAB_001aeda8:
    if (param_3 + param_4 <= iVar2) goto LAB_001aedb7;
  }
  else {
    if (-1 < param_3) goto LAB_001aeda8;
LAB_001aee15:
    param_4 = param_4 + param_3;
    if (param_4 < 1) {
      return;
    }
    if (param_4 <= iVar2) {
      param_3 = 0;
      goto LAB_001aedb7;
    }
    param_3 = 0;
  }
  if (iVar2 <= param_3) {
    return;
  }
  param_4 = iVar2 - param_3;
LAB_001aedb7:
  uVar3 = func_0x001f0b72(param_2);
  FUN_00218cf6(*(undefined4 *)(param_1 + 0xc),uVar3,0,param_3,param_4);
  return;
}


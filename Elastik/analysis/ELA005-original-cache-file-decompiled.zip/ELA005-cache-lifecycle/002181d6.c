
int FUN_002181d6(int param_1)

{
  int iVar1;
  char *pcVar2;
  int iVar3;
  int iStack_18;
  int *piStack_14;
  
  if (*(int *)(param_1 + 0x1c) < 1) {
    return -1;
  }
  piStack_14 = *(int **)(param_1 + 0x10);
  iVar3 = *piStack_14;
  if (iVar3 != -1) {
    if (0 < *(int *)(param_1 + 0x44)) {
      iStack_18 = 0;
      while( true ) {
        piStack_14 = piStack_14 + 2;
        iVar1 = 0;
        pcVar2 = *(char **)(param_1 + 0x40);
        while ((((*pcVar2 == '\0' || (*(int *)(pcVar2 + 4) == -1)) || (iVar3 < *(int *)(pcVar2 + 4))
                ) || (*(int *)(pcVar2 + 8) < iVar3))) {
          pcVar2 = pcVar2 + 0xc;
          iVar1 = iVar1 + 1;
          if (iVar1 == *(int *)(param_1 + 0x44)) {
            return iStack_18;
          }
        }
        iStack_18 = iStack_18 + 1;
        if (*(int *)(param_1 + 0x1c) == iStack_18) break;
        iVar3 = *piStack_14;
        if (iVar3 == -1) {
          return iStack_18;
        }
      }
      return -1;
    }
  }
  return 0;
}


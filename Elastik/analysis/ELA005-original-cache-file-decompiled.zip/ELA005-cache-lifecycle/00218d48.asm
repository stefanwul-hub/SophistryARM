00218d48  55  PUSH EBP
00218d49  89e5  MOV EBP,ESP
00218d4b  8b450c  MOV EAX,dword ptr [EBP + 0xc]
00218d4e  c74004ffffffff  MOV dword ptr [EAX + 0x4],0xffffffff
00218d55  c74008ffffffff  MOV dword ptr [EAX + 0x8],0xffffffff
00218d5c  5d  POP EBP
00218d5d  c3  RET

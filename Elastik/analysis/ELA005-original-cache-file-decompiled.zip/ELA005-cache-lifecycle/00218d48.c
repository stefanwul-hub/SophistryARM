
void FUN_00218d48(undefined4 param_1,int param_2)

{
  *(undefined4 *)(param_2 + 4) = 0xffffffff;
  *(undefined4 *)(param_2 + 8) = 0xffffffff;
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4 FUN_001ac468(int *param_1,int *param_2,char param_3)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int iStack_28;
  
  iVar2 = (**(code **)(*param_1 + 0x1bc))(param_1);
  if (iVar2 == 0) {
    return 0;
  }
  iStack_28 = func_0x0003a99a(iVar2);
  if (iStack_28 == 0) {
    return 0;
  }
  piVar3 = (int *)(**(code **)(*param_1 + 0x204))(param_1);
  if (piVar3 == (int *)0x0) {
    return 0;
  }
  uVar4 = func_0x001abcb8();
  uVar4 = func_0x0009cd48(uVar4);
  for (iVar2 = 0; iVar5 = FUN_00029ddc(uVar4), iVar2 < iVar5; iVar2 = iVar2 + 1) {
    uVar7 = FUN_0002a364(uVar4,iVar2);
    iVar5 = FUN_0003dd2a(".%@",uVar7);
    cVar1 = func_0x0003ac96(iStack_28,iVar5);
    if (cVar1 != '\0') {
      iVar2 = FUN_000349f4(iStack_28);
      iVar6 = FUN_000349f4(iVar5);
      iStack_28 = func_0x0003a32e(iStack_28,iVar2 - iVar6);
      if (iStack_28 == 0) {
        return 0;
      }
      goto LAB_001ac522;
    }
  }
  iVar5 = 0;
LAB_001ac522:
  uVar4 = FUN_00033b90(".L");
  cVar1 = func_0x0003ac96(iStack_28,uVar4);
  if (cVar1 == '\0') {
    uVar4 = FUN_00033b90("-L");
    cVar1 = func_0x0003ac96(iStack_28,uVar4);
    if (cVar1 != '\0') goto LAB_001ac65c;
    iVar2 = 0;
  }
  else {
LAB_001ac65c:
    iVar2 = FUN_000349f4(iStack_28);
    uVar4 = func_0x0003a32e(iStack_28,iVar2 + -1);
    iVar2 = FUN_0003dd2a("%@R",uVar4);
    if (param_2 != (int *)0x0) {
      *param_2 = 0;
    }
  }
  uVar4 = FUN_00033b90(".R");
  cVar1 = func_0x0003ac96(iStack_28,uVar4);
  if (cVar1 == '\0') {
    uVar4 = FUN_00033b90("-R");
    cVar1 = func_0x0003ac96(iStack_28,uVar4);
    if (cVar1 == '\0') goto LAB_001ac5f1;
  }
  iVar2 = FUN_000349f4(iStack_28);
  uVar4 = func_0x0003a32e(iStack_28,iVar2 + -1);
  iVar2 = FUN_0003dd2a("%@L",uVar4);
  if (param_2 != (int *)0x0) {
    *param_2 = 1;
  }
LAB_001ac5f1:
  if (param_3 == '\0') {
    if (iVar2 == 0) {
      return 0;
    }
    if (iVar5 != 0) {
      FUN_0003dd2a("%@%@",iVar2,iVar5);
    }
    iVar2 = *piVar3;
  }
  else {
    if (param_2 == (int *)0x0) {
      uVar4 = func_0x0000a930("/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNSoundFile.cpp"
                             );
      uVar7 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar7,"Assertion failed in line %d of %s: %s.",0x261,uVar4,"channelIndex");
    }
    if (*param_2 == 0) {
      iStack_28 = FUN_0003dd2a("%@.L",iStack_28);
    }
    else if (*param_2 == 1) {
      iStack_28 = FUN_0003dd2a("%@.R",iStack_28);
    }
    if (iVar5 != 0) {
      FUN_0003dd2a("%@%@",iStack_28,iVar5);
    }
    iVar2 = *piVar3;
  }
                    /* WARNING: Could not recover jumptable at 0x001ac65a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar4 = (**(code **)(iVar2 + 0x210))();
  return uVar4;
}


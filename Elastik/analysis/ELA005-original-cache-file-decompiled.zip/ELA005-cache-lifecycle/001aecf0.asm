001aecf0  55  PUSH EBP
001aecf1  89e5  MOV EBP,ESP
001aecf3  57  PUSH EDI
001aecf4  56  PUSH ESI
001aecf5  53  PUSH EBX
001aecf6  83ec2c  SUB ESP,0x2c
001aecf9  8b5510  MOV EDX,dword ptr [EBP + 0x10]
001aecfc  f20f104518  MOVSD XMM0,qword ptr [EBP + 0x18]
001aed01  f20f104d20  MOVSD XMM1,qword ptr [EBP + 0x20]
001aed06  89d6  MOV ESI,EDX
001aed08  037514  ADD ESI,dword ptr [EBP + 0x14]
001aed0b  660fefd2  PXOR XMM2,XMM2
001aed0f  660f2ec2  UCOMISD XMM0,XMM2
001aed13  0f86f5000000  JBE 0x001aee0e
001aed19  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001aed1c  f20f594018  MULSD XMM0,qword ptr [EAX + 0x18]
001aed21  f20f2cc0  CVTTSD2SI EAX,XMM0
001aed25  89d7  MOV EDI,EDX
001aed27  29c7  SUB EDI,EAX
001aed29  660f2eca  UCOMISD XMM1,XMM2
001aed2d  0f86d3000000  JBE 0x001aee06
001aed33  8b5508  MOV EDX,dword ptr [EBP + 0x8]
001aed36  f20f594a18  MULSD XMM1,qword ptr [EDX + 0x18]
001aed3b  f20f2cc1  CVTTSD2SI EAX,XMM1
001aed3f  01c6  ADD ESI,EAX
001aed41  89d1  MOV ECX,EDX
001aed43  85ff  TEST EDI,EDI
001aed45  b800000000  MOV EAX,0x0
001aed4a  0f48f8  CMOVS EDI,EAX
001aed4d  8b4124  MOV EAX,dword ptr [ECX + 0x24]
001aed50  85c0  TEST EAX,EAX
001aed52  7512  JNZ 0x001aed66
001aed54  8b5154  MOV EDX,dword ptr [ECX + 0x54]
001aed57  85d2  TEST EDX,EDX
001aed59  740b  JZ 0x001aed66
001aed5b  8b02  MOV EAX,dword ptr [EDX]
001aed5d  891424  MOV dword ptr [ESP],EDX
001aed60  ff90bc010000  CALL dword ptr [EAX + 0x1bc]
001aed66  39c6  CMP ESI,EAX
001aed68  7c23  JL 0x001aed8d
001aed6a  8b5508  MOV EDX,dword ptr [EBP + 0x8]
001aed6d  8b4224  MOV EAX,dword ptr [EDX + 0x24]
001aed70  85c0  TEST EAX,EAX
001aed72  7516  JNZ 0x001aed8a
001aed74  8b5254  MOV EDX,dword ptr [EDX + 0x54]
001aed77  85d2  TEST EDX,EDX
001aed79  0f84a4000000  JZ 0x001aee23
001aed7f  8b02  MOV EAX,dword ptr [EDX]
001aed81  891424  MOV dword ptr [ESP],EDX
001aed84  ff90bc010000  CALL dword ptr [EAX + 0x1bc]
001aed8a  8d70ff  LEA ESI,[EAX + -0x1]
001aed8d  39f7  CMP EDI,ESI
001aed8f  7d53  JGE 0x001aede4
001aed91  29fe  SUB ESI,EDI
001aed93  8b4508  MOV EAX,dword ptr [EBP + 0x8]
001aed96  8b500c  MOV EDX,dword ptr [EAX + 0xc]
001aed99  85d2  TEST EDX,EDX
001aed9b  7447  JZ 0x001aede4
001aed9d  8b4824  MOV ECX,dword ptr [EAX + 0x24]
001aeda0  85c9  TEST ECX,ECX
001aeda2  7448  JZ 0x001aedec
001aeda4  85ff  TEST EDI,EDI
001aeda6  786d  JS 0x001aee15
001aeda8  8d0437  LEA EAX,[EDI + ESI*0x1]
001aedab  39c1  CMP ECX,EAX
001aedad  7d08  JGE 0x001aedb7
001aedaf  39f9  CMP ECX,EDI
001aedb1  7e31  JLE 0x001aede4
001aedb3  89ce  MOV ESI,ECX
001aedb5  29fe  SUB ESI,EDI
001aedb7  8b550c  MOV EDX,dword ptr [EBP + 0xc]
001aedba  891424  MOV dword ptr [ESP],EDX
001aedbd  e8b01d0400  CALL 0x001f0b72
001aedc2  89742410  MOV dword ptr [ESP + 0x10],ESI
001aedc6  897c240c  MOV dword ptr [ESP + 0xc],EDI
001aedca  c744240800000000  MOV dword ptr [ESP + 0x8],0x0
001aedd2  89442404  MOV dword ptr [ESP + 0x4],EAX
001aedd6  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
001aedd9  8b410c  MOV EAX,dword ptr [ECX + 0xc]
001aeddc  890424  MOV dword ptr [ESP],EAX
001aeddf  e8129f0600  CALL 0x00218cf6
001aede4  83c42c  ADD ESP,0x2c
001aede7  5b  POP EBX
001aede8  5e  POP ESI
001aede9  5f  POP EDI
001aedea  5d  POP EBP
001aedeb  c3  RET
001aedec  8b5054  MOV EDX,dword ptr [EAX + 0x54]
001aedef  85d2  TEST EDX,EDX
001aedf1  74b1  JZ 0x001aeda4
001aedf3  8b02  MOV EAX,dword ptr [EDX]
001aedf5  891424  MOV dword ptr [ESP],EDX
001aedf8  ff90bc010000  CALL dword ptr [EAX + 0x1bc]
001aedfe  89c1  MOV ECX,EAX
001aee00  85ff  TEST EDI,EDI
001aee02  79a4  JNS 0x001aeda8
001aee04  eb0f  JMP 0x001aee15
001aee06  8b4d08  MOV ECX,dword ptr [EBP + 0x8]
001aee09  e935ffffff  JMP 0x001aed43
001aee0e  89d7  MOV EDI,EDX
001aee10  e914ffffff  JMP 0x001aed29
001aee15  01fe  ADD ESI,EDI
001aee17  85f6  TEST ESI,ESI
001aee19  7ec9  JLE 0x001aede4
001aee1b  39f1  CMP ECX,ESI
001aee1d  7c0e  JL 0x001aee2d
001aee1f  31ff  XOR EDI,EDI
001aee21  eb94  JMP 0x001aedb7
001aee23  beffffffff  MOV ESI,0xffffffff
001aee28  e960ffffff  JMP 0x001aed8d
001aee2d  31ff  XOR EDI,EDI
001aee2f  e97bffffff  JMP 0x001aedaf

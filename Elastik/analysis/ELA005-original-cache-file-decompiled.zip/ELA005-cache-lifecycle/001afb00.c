
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_001afb00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5,undefined4 param_6,undefined8 param_7,undefined8 param_8)

{
  char cVar1;
  
  cVar1 = FUN_001af4e2(param_1,param_3,param_4,param_5,param_6,(int)cRam003d4a48);
  if (cRam003d4a48 == '\0') {
    FUN_001aecf0(param_1,param_2,param_5,param_6,param_7,param_8);
  }
  return (int)cVar1;
}


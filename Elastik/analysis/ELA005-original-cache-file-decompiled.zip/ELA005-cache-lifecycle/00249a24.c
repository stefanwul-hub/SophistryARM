
longdouble FUN_00249a24(int param_1)

{
  return (longdouble)*(int *)(param_1 + 0x24);
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0021827e(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  iVar3 = *(int *)(param_1 + 0x1c);
  if (*(int *)(param_1 + 0x20) <= iVar3) {
    func_0x0000acae("GNFileCache: Buffer block count to low.");
    iVar3 = *(int *)(param_1 + 0x1c);
  }
  iVar1 = *(int *)(param_1 + 0x10);
  uVar2 = FUN_0000aecc(*(undefined4 *)(param_1 + 0x18));
  *(undefined4 *)(iVar1 + iVar3 * 8 + 4) = uVar2;
  *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + 1;
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0014ad4e(int param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  char *pcVar9;
  longdouble lVar10;
  double dVar11;
  
  iVar3 = param_3;
  iVar2 = param_2;
  if ((*(int *)(param_1 + 0x8c) != 0) &&
     (iVar6 = func_0x001f0b58(*(int *)(param_1 + 0x8c)), iVar6 != 0)) {
    lVar10 = (longdouble)func_0x001ab7a0(iVar6);
    iVar7 = (int)lVar10;
    if (iVar2 < iVar3) {
      if (*(int *)(param_1 + 0x8c) != 0) {
        dVar11 = DOUBLE_00364740;
        FUN_001f0c06(*(int *)(param_1 + 0x8c),iVar2,iVar7,DOUBLE_00364740,DOUBLE_00364740);
        FUN_001f0b98(*(undefined4 *)(param_1 + 0x8c),iVar2,(iVar3 - iVar2) + 1,dVar11,dVar11);
        return;
      }
    }
    else {
      if (iVar2 <= iVar3) {
        pcVar4 = 
        "ETKeyMapping::adjustSoundFileClients failed startSampleIndex:%d stopSampleIndex:%d";
        if (cRam003d3ef8 == '\0') {
          uVar8 = 0xffffffff;
          pcVar9 = pcVar4;
          do {
            if (uVar8 == 0) break;
            uVar8 = uVar8 - 1;
            cVar1 = *pcVar9;
            pcVar9 = pcVar9 + 1;
          } while (cVar1 != '\0');
          uVar8 = ~uVar8 - 1;
          param_2 = iVar2;
          param_3 = iVar3;
          if (uVar8 < 0x2000) {
            pcVar4 = (char *)FUN_0000aecc(uVar8 * 3 + 0x400);
            _vsprintf(pcVar4,
                      "ETKeyMapping::adjustSoundFileClients failed startSampleIndex:%d stopSampleIndex:%d"
                      ,&param_2);
          }
          if (piRam003d3f0c == (int *)0x0) {
            uVar5 = __Znwm(0x38);
            func_0x0006f04a(uVar5);
            piRam003d3f0c = (int *)FUN_0002dfa6(uVar5);
          }
          (**(code **)(*piRam003d3f0c + 0x1a4))(piRam003d3f0c);
          _puts(pcVar4);
          (**(code **)(*piRam003d3f0c + 0x1ac))(piRam003d3f0c);
          if (uVar8 < 0x2000) {
            if (pcVar4 != (char *)0x0) {
              if (cRam003d3f09 == '\0') {
                cRam003d3f09 = 1;
                if (iRam003d3ee8 != 0) {
                  func_0x000424ac(iRam003d3ee8,pcVar4);
                }
                cRam003d3f09 = '\0';
              }
              _free(pcVar4);
              return;
            }
            FUN_0000ab14("GNFree(0)");
          }
        }
        return;
      }
      if (*(int *)(param_1 + 0x8c) != 0) {
        FUN_001f0c06(*(int *)(param_1 + 0x8c),iVar2,iVar7,0,0x40590000,0,0x40590000);
        iVar6 = func_0x001ab7c0(iVar6);
        FUN_001f0b98(*(undefined4 *)(param_1 + 0x8c),iVar2,(iVar6 - iVar2) + 1,0,0x40590000,0,
                     0x40590000);
      }
      if (*(int *)(param_1 + 0x90) != 0) {
        dVar11 = DOUBLE_00364740;
        FUN_001f0c06(*(int *)(param_1 + 0x90),0,iVar7,DOUBLE_00364740,DOUBLE_00364740);
        FUN_001f0b98(*(undefined4 *)(param_1 + 0x90),0,iVar3 + 1,dVar11,dVar11);
      }
    }
  }
  return;
}


001f0b98  55  PUSH EBP
001f0b99  89e5  MOV EBP,ESP
001f0b9b  56  PUSH ESI
001f0b9c  83ec24  SUB ESP,0x24
001f0b9f  8b7508  MOV ESI,dword ptr [EBP + 0x8]
001f0ba2  8b4510  MOV EAX,dword ptr [EBP + 0x10]
001f0ba5  f20f104d14  MOVSD XMM1,qword ptr [EBP + 0x14]
001f0baa  f20f10451c  MOVSD XMM0,qword ptr [EBP + 0x1c]
001f0baf  85c0  TEST EAX,EAX
001f0bb1  ba00000000  MOV EDX,0x0
001f0bb6  0f48c2  CMOVS EAX,EDX
001f0bb9  8b550c  MOV EDX,dword ptr [EBP + 0xc]
001f0bbc  895618  MOV dword ptr [ESI + 0x18],EDX
001f0bbf  89461c  MOV dword ptr [ESI + 0x1c],EAX
001f0bc2  85c0  TEST EAX,EAX
001f0bc4  7506  JNZ 0x001f0bcc
001f0bc6  83c424  ADD ESP,0x24
001f0bc9  5e  POP ESI
001f0bca  5d  POP EBP
001f0bcb  c3  RET
001f0bcc  f20f11442410  MOVSD qword ptr [ESP + 0x10],XMM0
001f0bd2  f20f114c2408  MOVSD qword ptr [ESP + 0x8],XMM1
001f0bd8  89742404  MOV dword ptr [ESP + 0x4],ESI
001f0bdc  8b460c  MOV EAX,dword ptr [ESI + 0xc]
001f0bdf  890424  MOV dword ptr [ESP],EAX
001f0be2  e84de2fbff  CALL 0x001aee34
001f0be7  8b460c  MOV EAX,dword ptr [ESI + 0xc]
001f0bea  894508  MOV dword ptr [EBP + 0x8],EAX
001f0bed  83c424  ADD ESP,0x24
001f0bf0  5e  POP ESI
001f0bf1  5d  POP EBP
001f0bf2  e923bffbff  JMP 0x001acb1a

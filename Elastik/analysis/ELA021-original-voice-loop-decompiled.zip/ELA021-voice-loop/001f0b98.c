
void FUN_001f0b98(int param_1,undefined4 param_2,int param_3,undefined8 param_4,undefined8 param_5)

{
  int *piVar1;
  
  if (param_3 < 0) {
    param_3 = 0;
  }
  *(undefined4 *)(param_1 + 0x18) = param_2;
  *(int *)(param_1 + 0x1c) = param_3;
  if (param_3 == 0) {
    return;
  }
  func_0x001aee34(*(undefined4 *)(param_1 + 0xc),param_1,param_4,param_5);
  piVar1 = *(int **)(*(int *)(param_1 + 0xc) + 0xc);
  if (piVar1 != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x002182dd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar1 + 0x1a8))();
    return;
  }
  return;
}



/* WARNING: Possible PIC construction at 0x001f0c4b: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x001f0c50) */

void FUN_001f0c06(int param_1,undefined4 param_2,undefined4 param_3)

{
  int *piVar1;
  
  func_0x001aef64(*(undefined4 *)(param_1 + 0xc),param_1,param_2,param_3);
  piVar1 = *(int **)(*(int *)(param_1 + 0xc) + 0xc);
  if (piVar1 != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x002182dd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar1 + 0x1a8))();
    return;
  }
  return;
}


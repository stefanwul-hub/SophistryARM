
undefined4 FUN_00149f34(int param_1)

{
  return *(undefined4 *)(param_1 + 0x5c);
}


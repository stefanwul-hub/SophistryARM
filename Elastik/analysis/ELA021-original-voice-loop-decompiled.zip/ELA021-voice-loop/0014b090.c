
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0014b090(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  double dVar4;
  double dVar5;
  double dVar6;
  float fVar7;
  undefined1 auStack_10 [4];
  
  dVar6 = (double)CONCAT44(param_3,param_2) * DOUBLE_00364840;
  dVar5 = (double)*(float *)(param_1 + 0x6c);
  dVar4 = (double)*(float *)(param_1 + 0x70);
  if (dVar4 <= dVar5) {
    if (((dVar5 == dVar4) && (!NAN(dVar5) && !NAN(dVar4))) || (dVar5 <= dVar4)) {
      dVar4 = 0.0;
    }
    else {
      dVar4 = (DOUBLE_00364840 - dVar5) + dVar4;
    }
  }
  else {
    dVar4 = dVar4 - dVar5;
  }
  switch(*(undefined4 *)(param_1 + 0x60)) {
  default:
    goto LAB_0014b12c;
  case 1:
    dVar5 = DOUBLE_00364840;
    fVar7 = FLOAT_00365dd8;
    break;
  case 2:
    dVar5 = DOUBLE_00364858;
    fVar7 = FLOAT_00365ddc;
    break;
  case 3:
    dVar5 = DOUBLE_00364860;
    fVar7 = FLOAT_00365de0;
    break;
  case 4:
    dVar5 = DOUBLE_00364868;
    fVar7 = FLOAT_00365d60;
    break;
  case 5:
    dVar5 = DOUBLE_00364848;
    fVar7 = FLOAT_00365de4;
    break;
  case 6:
    dVar5 = DOUBLE_00364850;
    fVar7 = FLOAT_00365dd4;
  }
  dVar6 = (double)(fVar7 * (float)(int)(dVar6 / dVar5 + DOUBLE_00364790));
LAB_0014b12c:
  *(float *)(param_1 + 0x6c) = (float)dVar6;
  FUN_0014af3e(param_1);
  dVar4 = dVar4 + dVar6;
  if ((DOUBLE_00364840 <= dVar4) || (NAN(dVar4) || NAN(DOUBLE_00364840))) {
    *(float *)(param_1 + 0x70) = (float)(dVar4 - DOUBLE_00364840);
    FUN_0014af3e(param_1);
    iVar1 = *(int *)(param_1 + 0x78);
  }
  else {
    *(float *)(param_1 + 0x70) = (float)dVar4;
    FUN_0014af3e(param_1);
    iVar1 = *(int *)(param_1 + 0x78);
  }
  if (iVar1 != 0) {
    iVar1 = *(int *)(iVar1 + 0x28);
    if (iVar1 == 0) {
      return;
    }
    auStack_10[0] = 1;
    if (*(int *)(iVar1 + 0x78) != 0) {
      *(undefined1 *)(iVar1 + 0x7f) = 1;
      iVar2 = func_0x00029ddc(*(undefined4 *)(iVar1 + 0x78));
      iVar2 = iVar2 + -1;
      if (-1 < iVar2) {
        do {
          iVar3 = func_0x0002ba14(*(undefined4 *)(iVar1 + 0x78),iVar2);
          if (iVar3 != 0) {
            func_0x00041e1c(iVar3,auStack_10,10);
          }
          iVar2 = iVar2 + -1;
        } while (iVar2 != -1);
      }
      *(undefined1 *)(iVar1 + 0x7f) = 0;
    }
    return;
  }
  return;
}


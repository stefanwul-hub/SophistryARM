
void FUN_001ae634(int param_1,undefined4 param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = func_0x001f0b72(param_2);
  func_0x002183d2(*(undefined4 *)(param_1 + 0xc),uVar2);
  func_0x001f0b64(param_2,0);
  func_0x001f0b7e(param_2,0);
  func_0x001f0b20(param_2,0);
  func_0x0002aaae(*(undefined4 *)(param_1 + 0x28),param_2);
  iVar3 = func_0x00029ddc(*(undefined4 *)(param_1 + 0x28));
  if ((iVar3 == 0) && (*(int *)(param_1 + 0xc) != 0)) {
    func_0x0021803c(*(int *)(param_1 + 0xc));
    piVar1 = *(int **)(param_1 + 0xc);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(undefined4 *)(param_1 + 0xc) = 0;
  }
  return;
}


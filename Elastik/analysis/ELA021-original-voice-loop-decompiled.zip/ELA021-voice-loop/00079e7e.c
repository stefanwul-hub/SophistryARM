
int FUN_00079e7e(int param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  
  uVar2 = (**(code **)(**(int **)(param_1 + 0xc) + 0x1bc))(*(int **)(param_1 + 0xc));
  piVar3 = (int *)func_0x001ab794(param_2);
  uVar4 = (**(code **)(*piVar3 + 0x1bc))(piVar3);
  cVar1 = func_0x000374b2(uVar4,uVar2);
  return (int)cVar1;
}


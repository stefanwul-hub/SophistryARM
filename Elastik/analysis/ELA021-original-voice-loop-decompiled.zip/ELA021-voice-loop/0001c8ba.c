
uint FUN_0001c8ba(int param_1)

{
  uint uVar1;
  
  uVar1 = *(uint *)(param_1 + 0x58);
  if ((uVar1 & 0x100) != 0) {
    uVar1 = uVar1 & 0xff;
  }
  return uVar1;
}


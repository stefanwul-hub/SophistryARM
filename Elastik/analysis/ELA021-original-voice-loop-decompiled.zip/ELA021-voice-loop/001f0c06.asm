001f0c06  55  PUSH EBP
001f0c07  89e5  MOV EBP,ESP
001f0c09  57  PUSH EDI
001f0c0a  56  PUSH ESI
001f0c0b  83ec40  SUB ESP,0x40
001f0c0e  8b7508  MOV ESI,dword ptr [EBP + 0x8]
001f0c11  8b450c  MOV EAX,dword ptr [EBP + 0xc]
001f0c14  8945f4  MOV dword ptr [EBP + -0xc],EAX
001f0c17  8b7d10  MOV EDI,dword ptr [EBP + 0x10]
001f0c1a  f20f104514  MOVSD XMM0,qword ptr [EBP + 0x14]
001f0c1f  f20f1145e8  MOVSD qword ptr [EBP + -0x18],XMM0
001f0c24  f20f10451c  MOVSD XMM0,qword ptr [EBP + 0x1c]
001f0c29  f20f1145e0  MOVSD qword ptr [EBP + -0x20],XMM0
001f0c2e  897c240c  MOV dword ptr [ESP + 0xc],EDI
001f0c32  89442408  MOV dword ptr [ESP + 0x8],EAX
001f0c36  89742404  MOV dword ptr [ESP + 0x4],ESI
001f0c3a  8b460c  MOV EAX,dword ptr [ESI + 0xc]
001f0c3d  890424  MOV dword ptr [ESP],EAX
001f0c40  e81fe3fbff  CALL 0x001aef64
001f0c45  8b460c  MOV EAX,dword ptr [ESI + 0xc]
001f0c48  890424  MOV dword ptr [ESP],EAX
001f0c4b  e8cabefbff  CALL 0x001acb1a
001f0c50  f20f1045e0  MOVSD XMM0,qword ptr [EBP + -0x20]
001f0c55  f20f11442418  MOVSD qword ptr [ESP + 0x18],XMM0
001f0c5b  f20f1045e8  MOVSD XMM0,qword ptr [EBP + -0x18]
001f0c60  f20f11442410  MOVSD qword ptr [ESP + 0x10],XMM0
001f0c66  897c240c  MOV dword ptr [ESP + 0xc],EDI
001f0c6a  8b45f4  MOV EAX,dword ptr [EBP + -0xc]
001f0c6d  89442408  MOV dword ptr [ESP + 0x8],EAX
001f0c71  89742404  MOV dword ptr [ESP + 0x4],ESI
001f0c75  8b460c  MOV EAX,dword ptr [ESI + 0xc]
001f0c78  890424  MOV dword ptr [ESP],EAX
001f0c7b  e870e0fbff  CALL 0x001aecf0
001f0c80  8b460c  MOV EAX,dword ptr [ESI + 0xc]
001f0c83  894508  MOV dword ptr [EBP + 0x8],EAX
001f0c86  83c440  ADD ESP,0x40
001f0c89  5e  POP ESI
001f0c8a  5f  POP EDI
001f0c8b  5d  POP EBP
001f0c8c  e989befbff  JMP 0x001acb1a

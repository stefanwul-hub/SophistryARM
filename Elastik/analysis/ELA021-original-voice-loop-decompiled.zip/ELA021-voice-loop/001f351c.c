
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001f351c(undefined4 *param_1)

{
  func_0x0001bfca(param_1);
  *param_1 = &UNK_0039c388;
  _memset(param_1 + 0x20,0,0x68);
  return;
}


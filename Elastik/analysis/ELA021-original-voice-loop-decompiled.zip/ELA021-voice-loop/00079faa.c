
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00079faa(int param_1,int param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  
  if (param_2 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/Elastik/Projects/XCode/../../Source/ETRenderCacheCtrl.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x199,uVar2,"soundFile");
  }
  piVar1 = (int *)func_0x001ab794(param_2);
  uVar2 = (**(code **)(*piVar1 + 0x1bc))(piVar1);
  (**(code **)(**(int **)(param_1 + 0x20) + 0x1a4))(*(int **)(param_1 + 0x20));
  iVar3 = func_0x00064626(*(undefined4 *)(param_1 + 0x1c),uVar2);
  if (iVar3 != 0) {
    iVar3 = func_0x00085f34(iVar3);
    if (iVar3 + -1 < 1) {
      func_0x00066606(*(undefined4 *)(param_1 + 0x1c),uVar2);
                    /* WARNING: Could not recover jumptable at 0x0007a064. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(**(int **)(param_1 + 0x20) + 0x1ac))();
      return;
    }
    uVar4 = func_0x000858da(iVar3 + -1);
    FUN_00066284(*(undefined4 *)(param_1 + 0x1c),uVar4,uVar2);
  }
                    /* WARNING: Could not recover jumptable at 0x0007a03e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 0x20) + 0x1ac))();
  return;
}


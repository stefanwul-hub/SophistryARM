
int * FUN_001aca46(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  
  if (*(int *)(param_1 + 0xc) == 0) {
    func_0x001ac9dc(param_1);
  }
  uVar1 = __Znwm(0x20);
  func_0x001f0a04(uVar1);
  piVar2 = (int *)FUN_0002dfa6(uVar1);
  func_0x001f0b20(piVar2,param_1);
  uVar1 = func_0x002182e0(*(undefined4 *)(param_1 + 0xc));
  func_0x001f0b64(piVar2,uVar1);
  uVar1 = func_0x002182e0(*(undefined4 *)(param_1 + 0xc));
  func_0x001f0b7e(piVar2,uVar1);
  FUN_0002bb40(*(undefined4 *)(param_1 + 0x28),piVar2);
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x44))(piVar2);
  }
  return piVar2;
}


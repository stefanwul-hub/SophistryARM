
void FUN_0014a576(int param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0xa8) = param_2;
  return;
}


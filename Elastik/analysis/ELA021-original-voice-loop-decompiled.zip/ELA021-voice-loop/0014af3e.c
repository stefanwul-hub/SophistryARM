
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0014af3e(int param_1)

{
  int iVar1;
  int iVar2;
  double dVar3;
  int iStack_20;
  
  if (*(int *)(param_1 + 0x8c) == 0) {
    return;
  }
  iVar1 = func_0x001f0b58(*(int *)(param_1 + 0x8c));
  if (iVar1 == 0) {
    return;
  }
  dVar3 = (double)*(float *)(param_1 + 0x6c);
  if (dVar3 == 0.0) {
LAB_0014af79:
    iStack_20 = 0;
  }
  else {
    if ((dVar3 == DOUBLE_00364840) && (!NAN(dVar3) && !NAN(DOUBLE_00364840))) goto LAB_0014af79;
    iVar2 = func_0x001ab7c0(iVar1);
    iStack_20 = (int)(((double)iVar2 * (double)*(float *)(param_1 + 0x6c)) / DOUBLE_00364840);
  }
  dVar3 = (double)*(float *)(param_1 + 0x70);
  if (dVar3 != 0.0) {
    if ((dVar3 != DOUBLE_00364840) || (NAN(dVar3) || NAN(DOUBLE_00364840))) {
      iVar2 = func_0x001ab7c0(iVar1);
      iVar2 = (int)(((double)iVar2 * (double)*(float *)(param_1 + 0x70)) / DOUBLE_00364840);
      goto LAB_0014afaf;
    }
  }
  iVar2 = func_0x001ab7c0(iVar1);
  iVar2 = iVar2 + -1;
LAB_0014afaf:
  if (iStack_20 == iVar2) {
    if (iVar2 == 0) {
      iVar2 = func_0x001ab7c0(iVar1);
      iVar2 = iVar2 + -1;
    }
    else {
      iVar2 = iVar2 + -1;
    }
  }
  FUN_0014ad4e(param_1,iStack_20,iVar2);
  *(int *)(param_1 + 0x94) = iStack_20;
  *(int *)(param_1 + 0x98) = iVar2;
  return;
}


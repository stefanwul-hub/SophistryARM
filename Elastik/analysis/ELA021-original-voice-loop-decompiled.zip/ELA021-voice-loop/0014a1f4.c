
undefined4 FUN_0014a1f4(int param_1)

{
  return *(undefined4 *)(param_1 + 0x58);
}


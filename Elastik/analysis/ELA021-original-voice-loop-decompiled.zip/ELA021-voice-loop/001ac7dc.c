
void FUN_001ac7dc(int param_1)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 0x4c) == 1) {
    piVar1 = *(int **)(param_1 + 0x5c);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x1a8))(piVar1);
      piVar1 = *(int **)(param_1 + 0x5c);
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x44))(piVar1);
      }
      *(undefined4 *)(param_1 + 0x5c) = 0;
    }
    piVar1 = *(int **)(param_1 + 0x60);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x1a8))(piVar1);
      piVar1 = *(int **)(param_1 + 0x60);
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x44))(piVar1);
      }
      *(undefined4 *)(param_1 + 0x60) = 0;
    }
LAB_001ac802:
    piVar1 = *(int **)(param_1 + 0x54);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(undefined4 *)(param_1 + 0x54) = 0;
    if (*(int *)(param_1 + 0x4c) == 1) {
      piVar1 = *(int **)(param_1 + 100);
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x1a8))(piVar1);
        piVar1 = *(int **)(param_1 + 100);
        if (piVar1 != (int *)0x0) {
          (**(code **)(*piVar1 + 0x44))(piVar1);
        }
        *(undefined4 *)(param_1 + 100) = 0;
      }
      piVar1 = *(int **)(param_1 + 0x68);
      if (piVar1 != (int *)0x0) {
        (**(code **)(*piVar1 + 0x1a8))(piVar1);
        piVar1 = *(int **)(param_1 + 0x68);
        if (piVar1 != (int *)0x0) {
          (**(code **)(*piVar1 + 0x44))(piVar1);
        }
        *(undefined4 *)(param_1 + 0x68) = 0;
      }
      goto LAB_001ac882;
    }
  }
  else {
    piVar1 = *(int **)(param_1 + 0x54);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x1a8))(piVar1);
      goto LAB_001ac802;
    }
  }
  piVar1 = *(int **)(param_1 + 0x58);
  if (piVar1 == (int *)0x0) {
    return;
  }
  (**(code **)(*piVar1 + 0x1a8))(piVar1);
LAB_001ac882:
  piVar1 = *(int **)(param_1 + 0x58);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x44))(piVar1);
  }
  *(undefined4 *)(param_1 + 0x58) = 0;
  return;
}



undefined4 _GNAudioUnitWrapperEntry(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int *piVar2;
  
  if (*(short *)(param_1 + 2) != -1) {
    uVar1 = FUN_00006bce(param_1,param_2);
    return uVar1;
  }
  uVar1 = *(undefined4 *)(param_1 + 4);
  piVar2 = (int *)__Znwm(0x174);
  FUN_000038ac(piVar2,uVar1);
  (**(code **)(*piVar2 + 0xc))(piVar2);
  _SetComponentInstanceStorage(uVar1,piVar2);
  return 0;
}


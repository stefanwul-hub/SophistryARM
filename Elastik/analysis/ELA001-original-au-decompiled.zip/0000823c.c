
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 _GNAudioUnitWrapperViewEntry(int param_1,int param_2)

{
  short sVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  
  sVar1 = *(short *)(param_1 + 2);
  if (sVar1 == -1) {
    uVar3 = *(undefined4 *)(param_1 + 4);
    puVar2 = (undefined4 *)__Znwm(0x34);
    *puVar2 = PTR_DAT_003db002 + 8;
    puVar2[1] = uVar3;
    func_0x000020e8(puVar2 + 2);
    *puVar2 = &UNK_0036c5a8;
    puVar2[2] = &UNK_0036c5c8;
    puVar2[4] = 0;
    puVar2[5] = 0;
    puVar2[7] = 0;
    puVar2[8] = 0;
    puVar2[9] = 0;
    puVar2[10] = 0;
    puVar2[0xb] = 0;
    puVar2[0xc] = 0;
    (*_UNK_0036c5b4)(puVar2);
    _SetComponentInstanceStorage(uVar3,puVar2);
LAB_000082e0:
    uVar3 = 0;
  }
  else {
    if (param_2 != 0) {
      if (sVar1 != 0x301) {
        if (sVar1 != 0x302) {
          uVar3 = FUN_000075da(param_1,param_2);
          return uVar3;
        }
        uVar3 = *(undefined4 *)(param_1 + 4);
        *(undefined4 *)(param_2 + 0x14) = *(undefined4 *)(param_1 + 8);
        *(undefined4 *)(param_2 + 0x18) = uVar3;
        goto LAB_000082e0;
      }
      if ((((*(int *)(param_1 + 0x18) != 0) && (*(int *)(param_1 + 0x14) != 0)) &&
          (*(int *)(param_1 + 0x10) != 0)) &&
         (((*(int *)(param_1 + 8) != 0 && (*(int *)(param_1 + 0xc) != 0)) &&
          (*(int *)(param_1 + 4) != 0)))) {
        uVar3 = func_0x00007b68(param_2,*(int *)(param_1 + 0x18),*(int *)(param_1 + 0x14),
                                *(int *)(param_1 + 0x10),*(int *)(param_1 + 0xc),
                                *(int *)(param_1 + 8),*(int *)(param_1 + 4));
        return uVar3;
      }
    }
    uVar3 = 0xffffffce;
  }
  return uVar3;
}


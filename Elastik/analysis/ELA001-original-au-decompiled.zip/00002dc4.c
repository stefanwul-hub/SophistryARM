
undefined4 FUN_00002dc4(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  
  if (*(int *)(param_1 + 0x18) == 0) {
    uVar1 = __Znwm(0x24);
    func_0x00041414(uVar1);
    iVar2 = FUN_0002dfa6(uVar1);
    *(int *)(param_1 + 0x18) = iVar2;
    if (iVar2 == 0) {
      return 0xffffff94;
    }
    func_0x000416b2(iVar2,0);
    func_0x00041774(*(undefined4 *)(param_1 + 0x18),0xc);
  }
  uStack_18 = param_2;
  uStack_14 = param_3;
  uStack_10 = param_4;
  func_0x00042ffe(*(undefined4 *)(param_1 + 0x18),&uStack_18);
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_00004210(int param_1,undefined *param_2,int param_3,int param_4,double *param_5)

{
  char cVar1;
  short sVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uVar9;
  undefined *puVar10;
  longdouble lVar11;
  int iStack_44;
  int iStack_40;
  int *piStack_3c;
  undefined4 uStack_38;
  int *piStack_34;
  int iStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  int aiStack_20 [4];
  
  iStack_30 = param_4 + -0xfa02;
  if (param_2 == (undefined *)0x12) {
    *(undefined4 *)param_5 = 0x61757677;
    *(undefined4 *)((int)param_5 + 4) = 0x454c534b;
    *(undefined4 *)(param_5 + 1) = 0x55424552;
    *(undefined4 *)((int)param_5 + 0xc) = 0;
    *(undefined4 *)(param_5 + 2) = 0;
    return 0;
  }
  if (param_2 < (undefined *)0x13) {
    if (param_2 == (undefined *)0x8) {
      if ((param_3 != 0) && (param_3 != 2)) {
        if (param_3 == 1) {
          return -0x2a7f;
        }
        return -0x2a72;
      }
      *(undefined4 *)param_5 = *(undefined4 *)(param_1 + 0x54);
      *(undefined4 *)((int)param_5 + 4) = *(undefined4 *)(param_1 + 0x58);
      *(undefined4 *)(param_5 + 1) = *(undefined4 *)(param_1 + 0x5c);
      *(undefined4 *)((int)param_5 + 0xc) = *(undefined4 *)(param_1 + 0x60);
      *(undefined4 *)(param_5 + 2) = *(undefined4 *)(param_1 + 100);
      *(undefined4 *)((int)param_5 + 0x14) = *(undefined4 *)(param_1 + 0x68);
      *(undefined4 *)(param_5 + 3) = *(undefined4 *)(param_1 + 0x6c);
      *(undefined4 *)((int)param_5 + 0x1c) = *(undefined4 *)(param_1 + 0x70);
      *(undefined4 *)(param_5 + 4) = *(undefined4 *)(param_1 + 0x74);
      *(undefined4 *)((int)param_5 + 0x24) = *(undefined4 *)(param_1 + 0x78);
      return 0;
    }
    if ((undefined *)0x8 < param_2) {
      if (param_2 == (undefined *)0xd) {
        _memcpy(param_5,0x3d3920,iRam00366008 << 2);
        return 0;
      }
      if ((undefined *)0xd < param_2) {
        if (param_2 == (undefined *)0xe) {
          uVar9 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x260))(*(int **)(param_1 + 0x13c));
          *(undefined4 *)param_5 = uVar9;
          return 0;
        }
        if (param_2 == (undefined *)0x10) {
          if (((-1 < iStack_30) &&
              (iVar8 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2a0))
                                 (*(int **)(param_1 + 0x13c)), iStack_30 < iVar8)) &&
             ((iVar8 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2c8))
                                 (*(int **)(param_1 + 0x13c),iStack_30), iVar8 == 2 &&
              ((iStack_2c = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2cc))
                                      (*(int **)(param_1 + 0x13c),iStack_30), iStack_2c != 0 &&
               (iStack_28 = func_0x00029ddc(iStack_2c), 0 < iStack_28)))))) {
            iStack_24 = __Znam(iStack_28 << 2);
            iVar8 = 0;
            do {
              uVar9 = func_0x0002a364(iStack_2c,iVar8);
              uVar9 = func_0x0000c426(uVar9);
              *(undefined4 *)(iStack_24 + iVar8 * 4) = uVar9;
              iVar8 = iVar8 + 1;
            } while (iVar8 != iStack_28);
            uVar9 = _CFArrayCreate(0,iStack_24,iStack_28,0);
            *(undefined4 *)param_5 = uVar9;
            __ZdlPv(iStack_24);
            return 0;
          }
          return -0x2a63;
        }
        return -0x2a7f;
      }
      if (param_2 != (undefined *)0xb) {
        if (param_2 != (undefined *)0xc) {
          return -0x2a7f;
        }
        lVar11 = (longdouble)
                 (**(code **)(**(int **)(param_1 + 0x13c) + 0x270))(*(int **)(param_1 + 0x13c));
        *param_5 = (double)lVar11;
        return 0;
      }
      if (((param_3 != 0) && (param_3 != 2)) && (param_3 == 1)) {
        *(undefined4 *)param_5 = 0;
        return 0;
      }
LAB_000046de:
      *(undefined4 *)param_5 = 1;
      return 0;
    }
    if (param_2 == (undefined *)0x3) {
      if (param_3 != 0) {
        return -0x2a72;
      }
      iVar8 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2a0))(*(int **)(param_1 + 0x13c));
      if (param_5 == (double *)0x0) {
        return 0;
      }
      if (iVar8 < 1) {
        return 0;
      }
      puVar10 = &UNK_0000fa02;
      do {
        *(undefined **)((int)param_5 + (int)puVar10 * 4 + -0x3e808) = puVar10;
        puVar10 = puVar10 + 1;
      } while (&UNK_0000fa02 + iVar8 != puVar10);
      return 0;
    }
    if (param_2 < (undefined *)0x4) {
      if (param_2 == (undefined *)0x0) {
        *(undefined4 *)param_5 = 0;
        FUN_00004210(param_1,0x1c,0,0,&iStack_30);
        sVar2 = _GetComponentInfo(*(undefined4 *)(param_1 + 4),&iStack_44,0,0,0);
        if (sVar2 == 0) {
          uVar9 = _CFDictionaryCreateMutable(0,0,PTR_003daff2,PTR_003daff6);
          aiStack_20[0] = 0;
          iStack_28 = 0;
          uVar3 = _CFNumberCreate(0,3,&iStack_28);
          _CFDictionarySetValue(uVar9,_UNK_0036c570,uVar3);
          _CFRelease(uVar3);
          aiStack_20[0] = iStack_44;
          iStack_28 = iStack_44;
          uVar3 = _CFNumberCreate(0,3,&iStack_28);
          _CFDictionarySetValue(uVar9,_UNK_0036c56c,uVar3);
          _CFRelease(uVar3);
          aiStack_20[0] = iStack_40;
          iStack_28 = iStack_40;
          uVar3 = _CFNumberCreate(0,3,&iStack_28);
          _CFDictionarySetValue(uVar9,_UNK_0036c568,uVar3);
          _CFRelease(uVar3);
          aiStack_20[0] = (int)piStack_3c;
          iStack_28 = (int)piStack_3c;
          uVar3 = _CFNumberCreate(0,3,&iStack_28);
          _CFDictionarySetValue(uVar9,_UNK_0036c564,uVar3);
          _CFRelease(uVar3);
          uVar3 = _CFDataCreateMutable(0,0);
          uVar4 = __Znwm(0x14);
          FUN_0001e688(uVar4);
          piVar5 = (int *)FUN_0002dfa6(uVar4);
          uVar4 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2dc))(*(int **)(param_1 + 0x13c));
          func_0x00027b4e(uVar4);
          uVar6 = func_0x000278d6(uVar4);
          uVar7 = func_0x00027abc(uVar4);
          _CFDataAppendBytes(uVar3,uVar7,uVar6);
          func_0x00027bec(uVar4);
          if (piVar5 != (int *)0x0) {
            (**(code **)(*piVar5 + 0x44))(piVar5);
          }
          _CFDictionarySetValue(uVar9,_UNK_0036c560,uVar3);
          _CFRelease(uVar3);
          _CFDictionarySetValue(uVar9,_UNK_0036c55c,iStack_2c);
          aiStack_20[0] = 0;
          iVar8 = FUN_00004210(param_1,0x1a,0,0,aiStack_20);
          if (iVar8 == 0) {
            iStack_28 = aiStack_20[0];
            uVar3 = _CFNumberCreate(0,3,&iStack_28);
            _CFDictionarySetValue(uVar9,_UNK_0036c558,uVar3);
            _CFRelease(uVar3);
          }
          iVar8 = FUN_00004210(param_1,6,0,0,&iStack_24);
          if (iVar8 == 0) {
            uVar3 = _CFNumberCreate(0,0xc,&iStack_24);
            _CFDictionarySetValue(uVar9,_UNK_0036c554,uVar3);
            _CFRelease(uVar3);
          }
          *(undefined4 *)param_5 = uVar9;
          return 0;
        }
        return (int)sVar2;
      }
      if (param_2 != (undefined *)0x2) {
        return -0x2a7f;
      }
      lVar11 = (longdouble)
               (**(code **)(**(int **)(param_1 + 0x13c) + 600))(*(int **)(param_1 + 0x13c));
      *param_5 = (double)lVar11;
      return 0;
    }
    if (param_2 != (undefined *)0x4) {
      if (param_2 != (undefined *)0x5) {
        return -0x2a7f;
      }
      if (param_4 == 7) {
        *(undefined **)param_5 = &UNK_00003224;
        return 0;
      }
      if (param_4 == 0xe) {
        *(undefined **)param_5 = &UNK_000059ee;
        return 0;
      }
      if (param_4 == 6) {
        *(undefined **)param_5 = &UNK_00003290;
        return 0;
      }
      return -0x2a7d;
    }
    if (param_3 != 0) {
      return -0x2a72;
    }
    if (iStack_30 < 0) {
      return -0x2a63;
    }
    iVar8 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2a0))(*(int **)(param_1 + 0x13c));
    if (iVar8 <= iStack_30) {
      return -0x2a63;
    }
    uStack_38 = __Znwm(0x14);
    FUN_0001e688(uStack_38);
    piStack_34 = (int *)FUN_0002dfa6(uStack_38);
    iVar8 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2c8))(*(int **)(param_1 + 0x13c),iStack_30)
    ;
    if (iVar8 == 2) {
      *(undefined4 *)(param_5 + 8) = 1;
    }
    else if (iVar8 == 3) {
      *(undefined4 *)(param_5 + 8) = 0xe;
    }
    else if (iVar8 == 1) {
      *(undefined4 *)(param_5 + 8) = 2;
    }
    else {
      *(undefined4 *)(param_5 + 8) = 0;
    }
    lVar11 = (longdouble)
             (**(code **)(**(int **)(param_1 + 0x13c) + 0x2ac))
                       (*(int **)(param_1 + 0x13c),iStack_30);
    *(float *)((int)param_5 + 0x44) = (float)lVar11;
    lVar11 = (longdouble)
             (**(code **)(**(int **)(param_1 + 0x13c) + 0x2b0))
                       (*(int **)(param_1 + 0x13c),iStack_30);
    *(float *)(param_5 + 9) = (float)lVar11;
    lVar11 = (longdouble)
             (**(code **)(**(int **)(param_1 + 0x13c) + 0x2a8))
                       (*(int **)(param_1 + 0x13c),iStack_30);
    *(float *)((int)param_5 + 0x4c) = (float)lVar11;
    *(undefined4 *)((int)param_5 + 0x3c) = *(undefined4 *)(iStack_30 * 4 + iRam00366004);
    *(undefined4 *)(param_5 + 10) = 0xc8000000;
    if ((*(int *)(param_5 + 8) == 0xe) || (*(int *)(param_5 + 8) == 0)) {
      *(undefined4 *)(param_5 + 10) = 0xc8200000;
    }
    _CFStringGetCString(*(undefined4 *)(iStack_30 * 4 + iRam00366004),param_5,0x38,0x8000100);
    cVar1 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2c4))(*(int **)(param_1 + 0x13c),iStack_30)
    ;
    if (cVar1 == '\0') {
      *(uint *)(param_5 + 10) = *(uint *)(param_5 + 10) | 0x1000000;
    }
    if (piStack_34 != (int *)0x0) {
      (**(code **)(*piStack_34 + 0x44))(piStack_34);
      return 0;
    }
  }
  else {
    if (param_2 != (undefined *)0x1c) {
      if (param_2 < (undefined *)0x1d) {
        if (param_2 == (undefined *)0x16) {
          *(undefined4 *)param_5 = *(undefined4 *)(param_1 + 0x80);
          *(undefined4 *)(param_1 + 0x80) = 0;
          return 0;
        }
        if ((undefined *)0x16 < param_2) {
          if (param_2 != (undefined *)0x18) {
            if (param_2 != (undefined *)0x1b) {
              return -0x2a7f;
            }
            *(undefined4 *)param_5 = *(undefined4 *)(param_1 + 0x1c);
            *(undefined4 *)((int)param_5 + 4) = *(undefined4 *)(param_1 + 0x20);
            *(undefined4 *)(param_5 + 1) = *(undefined4 *)(param_1 + 0x24);
            *(undefined4 *)((int)param_5 + 0xc) = *(undefined4 *)(param_1 + 0x28);
            return 0;
          }
          if (*(int *)(param_1 + 0xc) == 0) {
            return -0x2a63;
          }
          _CFRetain(*(int *)(param_1 + 0xc));
          *(undefined4 *)param_5 = *(undefined4 *)(param_1 + 0xc);
          return 0;
        }
        if (param_2 == (undefined *)0x14) {
          lVar11 = (longdouble)
                   (**(code **)(**(int **)(param_1 + 0x13c) + 0x26c))(*(int **)(param_1 + 0x13c));
          *param_5 = (double)lVar11;
          return 0;
        }
        if (param_2 == (undefined *)0x15) {
          if (param_3 != 0) {
            return -0x2a72;
          }
          *(undefined4 *)param_5 = *(undefined4 *)(param_1 + 0x134);
          return 0;
        }
        return -0x2a7f;
      }
      if (param_2 != (undefined *)0x24) {
        if (param_2 < (undefined *)0x25) {
          if (param_2 == (undefined *)0x1e) {
            return -0x2a63;
          }
          if (param_2 != (undefined *)0x21) {
            return -0x2a7f;
          }
          if (param_3 != 0) {
            return -0x2a72;
          }
          aiStack_20[0] = *(int *)param_5 + -0xfa02;
          if (-1 < aiStack_20[0]) {
            iVar8 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2a0))(*(int **)(param_1 + 0x13c));
            if (iVar8 <= aiStack_20[0]) {
              return -0x2a7f;
            }
            iStack_40 = __Znwm(0x14);
            FUN_0001e688(iStack_40);
            piStack_3c = (int *)FUN_0002dfa6(iStack_40);
            if (*(undefined4 **)((int)param_5 + 4) == (undefined4 *)0x0) {
              uVar9 = (**(code **)(**(int **)(param_1 + 0x13c) + 700))
                                (*(int **)(param_1 + 0x13c),aiStack_20[0]);
              uVar9 = func_0x0000c426(uVar9);
              *(undefined4 *)(param_5 + 1) = uVar9;
            }
            else {
              uVar9 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2b8))
                                (*(int **)(param_1 + 0x13c),aiStack_20[0],
                                 **(undefined4 **)((int)param_5 + 4));
              uVar9 = func_0x0000c426(uVar9);
              *(undefined4 *)(param_5 + 1) = uVar9;
            }
            if (piStack_3c == (int *)0x0) {
              return 0;
            }
            (**(code **)(*piStack_3c + 0x44))(piStack_3c);
            return 0;
          }
          return -0x2a7f;
        }
        if (param_2 != (undefined *)0x3e8) {
          if (param_2 == &UNK_0000fa01) {
            *(int *)param_5 = param_1;
            return 0;
          }
          if (param_2 == (undefined *)0x25) {
            if (param_3 != 0) {
              return -0x2a72;
            }
            *(undefined4 *)param_5 = *(undefined4 *)(param_1 + 0x138);
            return 0;
          }
          return -0x2a7f;
        }
        if (param_3 != 0) {
          return -0x2a72;
        }
        goto LAB_000046de;
      }
      if (*(int *)(param_1 + 0x14) != 0) {
        _CFRetain(*(int *)(param_1 + 0x14));
      }
    }
    uVar9 = *(undefined4 *)(param_1 + 0x14);
    *(undefined4 *)param_5 = *(undefined4 *)(param_1 + 0x10);
    *(undefined4 *)((int)param_5 + 4) = uVar9;
  }
  return 0;
}



int FUN_00006bce(int param_1,int param_2)

{
  undefined4 uVar1;
  short sVar2;
  undefined4 uVar3;
  float *pfVar4;
  undefined1 *puVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  uint *puVar10;
  char *pcVar11;
  char *pcVar12;
  char *pcVar13;
  char *pcVar14;
  bool bVar15;
  longdouble lVar16;
  uint uStack_5c;
  int iStack_58;
  int iStack_34;
  char acStack_28 [16];
  uint uStack_18;
  uint uStack_14;
  undefined1 uStack_d;
  
  if (param_2 == 0) {
    return -0x32;
  }
  sVar2 = *(short *)(param_1 + 2);
  if (sVar2 == 9) {
    func_0x000093f0(param_2 + 0x140);
    func_0x000093f0(param_2 + 0x158);
    (**(code **)(**(int **)(param_2 + 0x13c) + 0x24c))(*(int **)(param_2 + 0x13c));
    return 0;
  }
  if (9 < sVar2) {
    if (sVar2 == 0xe) {
      puVar10 = *(uint **)(param_1 + 0x14);
      if (*(int *)(param_1 + 0x10) == 0) {
        return -0x32;
      }
      if (*(int *)(param_1 + 4) == 0) {
        return -0x32;
      }
      if (puVar10 == (uint *)0x0) {
        uStack_18 = 0;
        puVar10 = &uStack_18;
      }
      iVar6 = FUN_00005490(param_2,puVar10,*(int *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0xc),
                           *(undefined4 *)(param_1 + 8),*(int *)(param_1 + 4));
      return iVar6;
    }
    if (sVar2 < 0xf) {
      if (sVar2 != 0xb) {
        if (0xb < sVar2) {
          return -0x7fff7ffe;
        }
        iVar6 = FUN_00002dc4(param_2,*(undefined4 *)(param_1 + 0xc),*(undefined4 *)(param_1 + 8),
                             *(undefined4 *)(param_1 + 4));
        return iVar6;
      }
      iVar6 = *(int *)(param_1 + 8);
      iVar8 = *(int *)(param_1 + 4);
      if (*(int *)(param_2 + 0x18) != 0) {
        iVar7 = FUN_00041be2(*(int *)(param_2 + 0x18));
        iVar7 = iVar7 + -1;
        if (-1 < iVar7) {
          do {
            piVar9 = (int *)FUN_00041c54(*(undefined4 *)(param_2 + 0x18),iVar7);
            if ((iVar6 == *piVar9) && (iVar8 == piVar9[1])) {
              FUN_00041fc6(*(undefined4 *)(param_2 + 0x18),iVar7);
            }
            iVar7 = iVar7 + -1;
          } while (iVar7 != -1);
        }
      }
    }
    else {
      if (sVar2 != 0x11) {
        if (sVar2 < 0x12) {
          if (sVar2 == 0xf) {
            iVar6 = FUN_00002e66(param_2,*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 4));
            return iVar6;
          }
          if (sVar2 == 0x10) {
            iVar6 = *(int *)(param_1 + 8);
            iVar8 = *(int *)(param_1 + 4);
            if (iVar6 == 0) {
              return -0x32;
            }
            if (*(int *)(param_2 + 0x7c) != 0) {
              iVar7 = FUN_00041be2(*(int *)(param_2 + 0x7c));
              iVar7 = iVar7 + -1;
              if (iVar7 < 0) {
                return 0;
              }
              do {
                piVar9 = (int *)FUN_00041c54(*(undefined4 *)(param_2 + 0x7c),iVar7);
                if ((iVar6 == *piVar9) && (iVar8 == piVar9[1])) {
                  FUN_00041fc6(*(undefined4 *)(param_2 + 0x7c),iVar7);
                }
                iVar7 = iVar7 + -1;
              } while (iVar7 != -1);
              return 0;
            }
            return -0x32;
          }
        }
        else {
          if (sVar2 == 0x101) {
            if (*(int *)(param_2 + 8) < 1) {
              return -0x2a73;
            }
            FUN_000092b0(param_2 + 0x158,*(undefined4 *)(param_1 + 4),
                         *(byte *)(param_1 + 0x10) & 0xf0,*(byte *)(param_1 + 0x10) & 0xf,
                         *(undefined1 *)(param_1 + 0xc),*(undefined1 *)(param_1 + 8));
            return 0;
          }
          if (sVar2 == 0x102) {
            return 0;
          }
        }
        goto LAB_00006c38;
      }
      iVar6 = *(int *)(param_1 + 8);
      iVar8 = *(int *)(param_1 + 4);
      if (*(int *)(param_2 + 8) < 1) {
        return -0x2a73;
      }
      if (iVar8 != 0) {
        iStack_34 = 0;
        do {
          if (*(int *)(iVar6 + 0xc) == 1) {
            FUN_00009348(param_2 + 0x140,*(undefined4 *)(iVar6 + 0x10),*(int *)(iVar6 + 8) + -0xfa02
                         ,*(undefined4 *)(iVar6 + 0x14));
          }
          iStack_34 = iStack_34 + 1;
          iVar6 = iVar6 + 0x20;
        } while (iVar8 != iStack_34);
      }
    }
    return 0;
  }
  if (sVar2 != 4) {
    if (4 < sVar2) {
      if (sVar2 == 6) {
        pfVar4 = *(float **)(param_1 + 4);
        if (pfVar4 != (float *)0x0) {
          iVar6 = *(int *)(param_1 + 0x10) + -0xfa02;
          if (iVar6 < 0) {
            return -0x2a7e;
          }
          iVar8 = (**(code **)(**(int **)(param_2 + 0x13c) + 0x2a0))(*(int **)(param_2 + 0x13c));
          if (iVar8 <= iVar6) {
            return -0x2a7e;
          }
          lVar16 = (longdouble)
                   (**(code **)(**(int **)(param_2 + 0x13c) + 0x2a8))
                             (*(int **)(param_2 + 0x13c),iVar6);
          *pfVar4 = (float)lVar16;
          return 0;
        }
      }
      else {
        if (5 < sVar2) {
          if (sVar2 == 7) {
            uVar1 = *(undefined4 *)(param_1 + 8);
            iVar6 = *(int *)(param_1 + 0x14) + -0xfa02;
            if ((-1 < iVar6) &&
               (iVar8 = (**(code **)(**(int **)(param_2 + 0x13c) + 0x2a0))
                                  (*(int **)(param_2 + 0x13c)), iVar6 < iVar8)) {
              (**(code **)(**(int **)(param_2 + 0x13c) + 0x2a4))
                        (*(int **)(param_2 + 0x13c),uVar1,iVar6);
              return 0;
            }
            return -0x2a7e;
          }
          if (sVar2 == 8) {
            return -0x7fff7ffe;
          }
          goto LAB_00006c38;
        }
        iVar6 = *(int *)(param_1 + 0x14);
        uVar1 = *(undefined4 *)(param_1 + 0xc);
        iVar8 = *(int *)(param_1 + 4);
        if (*(int *)(param_1 + 8) == 0) {
          if (iVar8 == 0) {
            if (iVar6 == 0x13) {
              return 0;
            }
            if (iVar6 != 0x1b) {
              return -0x2a63;
            }
            if (*(int *)(param_1 + 0x10) != 0) {
              return -0x2a72;
            }
            acStack_28[0] = '\0';
            acStack_28[1] = '\0';
            acStack_28[2] = '\0';
            acStack_28[3] = '\0';
            acStack_28[4] = '\0';
            acStack_28[5] = '\0';
            acStack_28[6] = '\0';
            acStack_28[7] = '\0';
            acStack_28[8] = '\0';
            acStack_28[9] = '\0';
            acStack_28[10] = '\0';
            acStack_28[0xb] = '\0';
            acStack_28[0xc] = '\0';
            acStack_28[0xd] = '\0';
            acStack_28[0xe] = '\0';
            acStack_28[0xf] = '\0';
            bVar15 = (char *)(param_2 + 0x1c) == (char *)0x0;
            iVar6 = 0x10;
            pcVar11 = acStack_28;
            pcVar13 = (char *)(param_2 + 0x1c);
            do {
              pcVar12 = pcVar11;
              pcVar14 = pcVar13;
              if (iVar6 == 0) break;
              iVar6 = iVar6 + -1;
              pcVar14 = pcVar13 + 1;
              pcVar12 = pcVar11 + 1;
              bVar15 = *pcVar11 == *pcVar13;
              pcVar11 = pcVar12;
              pcVar13 = pcVar14;
            } while (bVar15);
            iVar6 = 0;
            if (!bVar15) {
              iVar6 = (uint)(byte)pcVar12[-1] - (uint)(byte)pcVar14[-1];
            }
            if (iVar6 == 0) {
              return 0;
            }
            *(undefined4 *)(param_2 + 0x1c) = 0;
            *(undefined4 *)(param_2 + 0x20) = 0;
            *(undefined4 *)(param_2 + 0x24) = 0;
            *(undefined4 *)(param_2 + 0x28) = 0;
            if (*(int *)(param_2 + 0x18) == 0) {
              return 0;
            }
            iVar6 = FUN_00041be2(*(int *)(param_2 + 0x18));
            iVar6 = iVar6 + -1;
            if (iVar6 < 0) {
              return 0;
            }
            do {
              piVar9 = (int *)FUN_00041c54(*(undefined4 *)(param_2 + 0x18),iVar6);
              if (*piVar9 == 0x1b) {
                (*(code *)piVar9[1])(piVar9[2],*(undefined4 *)(param_2 + 4),0x1b,0,uVar1);
              }
              iVar6 = iVar6 + -1;
            } while (iVar6 != -1);
            return 0;
          }
        }
        else if (iVar8 != 0) {
          iVar6 = FUN_00005f2c(param_2,iVar6,*(int *)(param_1 + 0x10),uVar1,*(int *)(param_1 + 8),
                               iVar8);
          return iVar6;
        }
      }
      return -0x32;
    }
    if (sVar2 == 1) {
      iVar6 = FUN_0000529a(param_2);
      return iVar6;
    }
    if (sVar2 < 2) {
      if (sVar2 == -3) {
        iVar6 = *(int *)(param_1 + 4);
        if (iVar6 < 0xe) {
          if (0xb < iVar6) {
            return 0;
          }
          if (iVar6 == 8) {
            return 0;
          }
          if ((iVar6 < 9) && (iVar6 < 1)) {
LAB_00007376:
            iVar6 = FUN_000075da(param_1,param_2);
            return iVar6;
          }
        }
        else if ((0x11 < iVar6) && (1 < iVar6 - 0x101U)) goto LAB_00007376;
        return 1;
      }
    }
    else {
      if (sVar2 == 2) {
        if (*(int *)(param_2 + 8) < 1) {
          return 0;
        }
        func_0x000093f0(param_2 + 0x140);
        func_0x000093f0(param_2 + 0x158);
        (**(code **)(**(int **)(param_2 + 0x13c) + 0x240))(*(int **)(param_2 + 0x13c));
        *(undefined4 *)(param_2 + 8) = 0;
        return 0;
      }
      if (sVar2 == 3) {
        puVar10 = *(uint **)(param_1 + 8);
        puVar5 = *(undefined1 **)(param_1 + 4);
        iVar6 = FUN_0000287c(param_2,*(undefined4 *)(param_1 + 0x14),*(undefined4 *)(param_1 + 0x10)
                             ,*(undefined4 *)(param_1 + 0xc),&uStack_14,&uStack_d);
        if (puVar10 != (uint *)0x0) {
          *puVar10 = uStack_14;
        }
        if (puVar5 != (undefined1 *)0x0) {
          *puVar5 = uStack_d;
          return iVar6;
        }
        return iVar6;
      }
    }
LAB_00006c38:
    iVar6 = FUN_000075da(param_1,param_2);
    return iVar6;
  }
  iVar6 = *(int *)(param_1 + 0x14);
  uVar1 = *(undefined4 *)(param_1 + 0x10);
  uVar3 = *(undefined4 *)(param_1 + 0xc);
  iVar8 = *(int *)(param_1 + 8);
  puVar10 = *(uint **)(param_1 + 4);
  if (puVar10 == (uint *)0x0) {
    return -0x32;
  }
  if (iVar8 == 0) {
    iVar6 = FUN_0000287c(param_2,iVar6,uVar1,uVar3,&uStack_18,&uStack_d);
    *puVar10 = uStack_18;
    return iVar6;
  }
  uStack_5c = *puVar10;
  if (uStack_5c == 0) {
    if (iVar6 != 0) {
      iVar7 = -0x32;
      goto LAB_00006ee3;
    }
    uStack_5c = 4;
  }
  iVar7 = FUN_0000287c(param_2,iVar6,uVar1,uVar3,&uStack_14,&uStack_d);
  if (iVar7 == 0) {
    if (uStack_5c < uStack_14) {
      iVar7 = __Znam(uStack_14);
      iStack_58 = iVar7;
    }
    else {
      iStack_58 = 0;
      iVar7 = iVar8;
    }
    iVar7 = FUN_00004210(param_2,iVar6,uVar1,uVar3,iVar7);
    if (iVar7 == 0) {
      if (uStack_14 <= uStack_5c) {
        *puVar10 = uStack_14;
        return 0;
      }
      _memcpy(iVar8,iStack_58,uStack_5c);
      if (iStack_58 != 0) {
        __ZdaPv(iStack_58);
        return 0;
      }
      return 0;
    }
  }
LAB_00006ee3:
  *puVar10 = 0;
  return iVar7;
}


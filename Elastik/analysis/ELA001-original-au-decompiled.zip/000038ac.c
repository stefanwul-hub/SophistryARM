
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_000038ac(undefined4 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  undefined4 uVar5;
  int iVar6;
  short sVar7;
  undefined4 *puVar8;
  longdouble lVar9;
  uint uStack_20;
  
  param_1[1] = param_2;
  *param_1 = &UNK_0036c540;
  param_1[2] = 0xffffffff;
  param_1[3] = 0;
  param_1[6] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x49] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  func_0x00008f28(param_1 + 0x50);
  func_0x00008f28(param_1 + 0x56);
  param_1[0x5c] = 0;
  cVar1 = func_0x00040a5e();
  if (cVar1 == '\0') {
    FUN_00040a70();
  }
  func_0x0000a4f2();
  func_0x0000a4ce();
  uVar2 = __Znwm(0x14);
  FUN_0001e688(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  uVar2 = __Znwm(0x48);
  FUN_00008482(uVar2);
  uVar2 = FUN_0002dfa6(uVar2);
  param_1[0x4b] = uVar2;
  FUN_00008d7e(uVar2,param_1 + 7);
  uVar2 = __Znwm(0x168);
  FUN_0001ad16(uVar2);
  uVar2 = FUN_0002dfa6(uVar2);
  param_1[0x4f] = uVar2;
  uVar2 = __Znwm(0x38);
  FUN_00023d8c(uVar2);
  piVar4 = (int *)FUN_0002dfa6(uVar2);
  uVar2 = (**(code **)(*piVar4 + 0x48))(piVar4);
  FUN_0001d8c0(param_1[0x4f],uVar2);
  uVar2 = func_0x0001c3b2(param_1[0x4f]);
  func_0x00024b2a(uVar2,1);
  uVar2 = __Znwm(0x20);
  FUN_00029d44(uVar2);
  uVar2 = FUN_0002dfa6(uVar2);
  param_1[0x5c] = uVar2;
  FUN_0002a14a(uVar2,0x600);
  uVar2 = FUN_0000aecc(0xd0);
  param_1[0x4a] = uVar2;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  puVar8 = param_1 + 0xb;
  for (iVar6 = 10; iVar6 != 0; iVar6 = iVar6 + -1) {
    *puVar8 = 0;
    puVar8 = puVar8 + 1;
  }
  puVar8 = param_1 + 0x15;
  for (iVar6 = 10; iVar6 != 0; iVar6 = iVar6 + -1) {
    *puVar8 = 0;
    puVar8 = puVar8 + 1;
  }
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  puVar8 = param_1 + 0x29;
  for (iVar6 = 0x10; iVar6 != 0; iVar6 = iVar6 + -1) {
    *puVar8 = 0;
    puVar8 = puVar8 + 1;
  }
  puVar8 = param_1 + 0x39;
  for (iVar6 = 0x10; iVar6 != 0; iVar6 = iVar6 + -1) {
    *puVar8 = 0;
    puVar8 = puVar8 + 1;
  }
  param_1[4] = 0xffffffff;
  param_1[5] = _UNK_0036c574;
  iVar6 = func_0x0000cfca();
  if (iVar6 == 0) {
    func_0x0000d582();
    uVar2 = __Znwm(0x180);
    func_0x00009678(uVar2);
    uVar2 = FUN_0002dfa6(uVar2);
    uVar5 = func_0x00033b90("com.ueberschall.elastik.au");
    func_0x0000980e(uVar2,uVar5);
    func_0x0000946c(uVar2);
    func_0x00008e8a();
  }
  func_0x00008e78(param_1[0x4f]);
  iRam0036600c = iRam0036600c + 1;
  if (iRam0036600c == 1) {
    uVar2 = func_0x0000cfca();
    func_0x0000f688(uVar2);
    piVar4 = (int *)param_1[0x4f];
    cVar1 = (**(code **)(*piVar4 + 0x268))(piVar4,0,2);
    if (cVar1 != '\0') {
      sRam003d3920 = 0;
      sRam003d3922 = 2;
    }
    uStack_20 = (uint)(cVar1 != '\0');
    sVar7 = 0;
    while( true ) {
      cVar1 = (**(code **)(*piVar4 + 0x268))(piVar4,0,(int)sVar7);
      if (cVar1 != '\0') {
        *(undefined2 *)(uStack_20 * 4 + 0x3d3920) = 0;
        *(short *)(uStack_20 * 4 + 0x3d3922) = sVar7;
        uStack_20 = uStack_20 + 1;
      }
      sVar7 = sVar7 + 1;
      if (0x10 < sVar7) break;
      while (sVar7 == 2) {
        sVar7 = 3;
      }
    }
    uRam00366008 = uStack_20;
    uRam00366004 = func_0x00002500(param_1[0x4f]);
  }
  uVar2 = FUN_00002446(param_1[0x4f]);
  param_1[3] = uVar2;
  func_0x0001cd38(param_1[0x4f],(int)sRam003d3920);
  func_0x0001ce42(param_1[0x4f],(int)sRam003d3922);
  cVar1 = (**(code **)(*(int *)param_1[0x4f] + 0x350))((int *)param_1[0x4f]);
  param_1[0x4d] = (uint)(cVar1 != '\0');
  lVar9 = (longdouble)(**(code **)(*(int *)param_1[0x4f] + 600))((int *)param_1[0x4f]);
  if (((double)lVar9 == DOUBLE_00364718) && (!NAN((double)lVar9) && !NAN(DOUBLE_00364718))) {
    (**(code **)(*(int *)param_1[0x4f] + 0x254))((int *)param_1[0x4f],0,0x40e58880);
  }
  iVar6 = (**(code **)(*(int *)param_1[0x4f] + 0x260))((int *)param_1[0x4f]);
  if (iVar6 == 0) {
    (**(code **)(*(int *)param_1[0x4f] + 0x25c))((int *)param_1[0x4f],0x484);
  }
  lVar9 = (longdouble)(**(code **)(*(int *)param_1[0x4f] + 600))((int *)param_1[0x4f]);
  *(double *)(param_1 + 0xb) = (double)lVar9;
  param_1[0xd] = 0x6c70636d;
  param_1[0xe] = 0x29;
  param_1[0x13] = 0x20;
  uVar2 = func_0x0001c8ce(param_1[0x4f]);
  param_1[0x12] = uVar2;
  param_1[0x11] = 4;
  param_1[0x10] = 1;
  param_1[0xf] = 4;
  param_1[0x15] = param_1[0xb];
  param_1[0x16] = param_1[0xc];
  param_1[0x17] = param_1[0xd];
  param_1[0x18] = param_1[0xe];
  param_1[0x19] = 4;
  param_1[0x1a] = 1;
  param_1[0x1b] = 4;
  param_1[0x1c] = uVar2;
  param_1[0x1d] = param_1[0x13];
  param_1[0x1e] = param_1[0x14];
  uVar2 = func_0x0001c8ba(param_1[0x4f]);
  param_1[0x1c] = uVar2;
  if (piVar3 != (int *)0x0) {
    (**(code **)(*piVar3 + 0x44))(piVar3);
  }
  return;
}


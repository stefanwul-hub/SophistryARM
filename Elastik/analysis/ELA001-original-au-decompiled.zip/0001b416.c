
undefined4 FUN_0001b416(int *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  
  uVar2 = __Znwm(0x38);
  func_0x00153fb6(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  piVar3 = (int *)(**(code **)(*piVar3 + 0x48))(piVar3);
  func_0x001551ce(piVar3,2);
  iVar4 = (**(code **)(*param_1 + 0x3b8))(param_1);
  if (iVar4 != 0) {
    pcVar1 = *(code **)(*piVar3 + 0x298);
    uVar2 = (**(code **)(*param_1 + 0x3b8))(param_1);
    uVar2 = (*pcVar1)(piVar3,uVar2);
    return uVar2;
  }
  return 0;
}


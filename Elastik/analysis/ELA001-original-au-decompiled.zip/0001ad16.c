
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0001ad16(undefined4 *param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  
  func_0x00155ba0(param_1);
  *param_1 = &UNK_0036d648;
  *(undefined1 *)(param_1 + 0x2e) = 1;
  if (cRam003d3f9c == '\0') {
    piVar2 = (int *)__Znwm(0x94);
    func_0x001576bc(piVar2);
    (**(code **)(*piVar2 + 8))(piVar2);
    iVar3 = func_0x000410a8();
    *(int *)(iVar3 + 0x20) = *(int *)(iVar3 + 0x20) + 1;
    (**(code **)(*piVar2 + 4))(piVar2);
    iVar3 = func_0x000410a8();
    *(int *)(iVar3 + 0x20) = *(int *)(iVar3 + 0x20) + -1;
    cRam003d3f9c = '\x01';
  }
  param_1[0x2f] = 0;
  iVar3 = 0;
  puVar1 = param_1;
  do {
    *(undefined1 *)(puVar1 + 0x30) = 0;
    iVar3 = iVar3 + 1;
    puVar1 = (undefined4 *)((int)puVar1 + 1);
  } while (iVar3 != 0x7f);
  *(undefined1 *)(param_1 + 0x50) = 0x80;
  param_1[0x53] = 0;
  param_1[0x54] = 0;
  param_1[0x55] = 0;
  param_1[0x56] = 0;
  *(undefined1 *)(param_1 + 0x57) = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0x40e58880;
  return;
}


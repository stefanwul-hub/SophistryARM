
undefined4 FUN_00002e66(int param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  int iStack_14;
  int iStack_10;
  
  if (*(int *)(param_1 + 0x7c) == 0) {
    uVar1 = __Znwm(0x24);
    func_0x00041414(uVar1);
    iVar2 = FUN_0002dfa6(uVar1);
    *(int *)(param_1 + 0x7c) = iVar2;
    if (iVar2 == 0) {
      return 0xffffff94;
    }
    func_0x000416b2(iVar2,0);
    func_0x00041774(*(undefined4 *)(param_1 + 0x7c),8);
  }
  if (param_2 != 0) {
    iVar2 = FUN_00041be2(*(undefined4 *)(param_1 + 0x7c));
    iVar2 = iVar2 + -1;
    if (-1 < iVar2) {
      do {
        piVar3 = (int *)FUN_00041c54(*(undefined4 *)(param_1 + 0x7c),iVar2);
        if ((param_2 == *piVar3) && (param_3 == piVar3[1])) {
          return 0;
        }
        iVar2 = iVar2 + -1;
      } while (iVar2 != -1);
    }
    iStack_14 = param_2;
    iStack_10 = param_3;
    func_0x00042ffe(*(undefined4 *)(param_1 + 0x7c),&iStack_14);
    return 0;
  }
  return 0xffffffce;
}


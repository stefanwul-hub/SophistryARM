
undefined4 FUN_00002446(int *param_1)

{
  char cVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  int iStack_10;
  
  iVar2 = (**(code **)(*param_1 + 0x2e8))(param_1);
  cVar1 = (**(code **)(*param_1 + 0x2e4))(param_1);
  if ((cVar1 == '\0') || (iVar2 < 1)) {
    uVar6 = 0;
  }
  else {
    piVar3 = (int *)__Znam(iVar2 << 3);
    uVar6 = _CFArrayCreateMutable(0,iVar2,0);
    iStack_10 = 0;
    do {
      *piVar3 = iStack_10;
      uVar4 = (**(code **)(*param_1 + 0x2ec))(param_1,iStack_10);
      iVar5 = func_0x0000c426(uVar4);
      piVar3[1] = iVar5;
      _CFArrayAppendValue(uVar6,piVar3);
      iStack_10 = iStack_10 + 1;
      piVar3 = piVar3 + 2;
    } while (iVar2 != iStack_10);
  }
  return uVar6;
}


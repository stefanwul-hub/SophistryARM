
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

bool FUN_00040a70(void)

{
  int iVar1;
  
  iVar1 = _pthread_key_create(0x3d41a8,0);
  uRam003d41ac = iVar1 == 0;
  return iVar1 == 0;
}


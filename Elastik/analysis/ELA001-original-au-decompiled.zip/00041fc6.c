
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00041fc6(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  if (param_1 == 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar4 = func_0x00033b90("GNAssertionException");
    func_0x0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0xe8,uVar3,"this != 0");
  }
  if (param_2 < 0) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar4 = func_0x00033b90("GNAssertionException");
    func_0x0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0xe8,uVar3,"index >= 0");
  }
  if (*(int *)(param_1 + 0x10) < param_2) {
    uVar3 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNFoundation/../../GNFoundation/GNStorage.cpp"
                           );
    uVar4 = func_0x00033b90("GNAssertionException");
    func_0x0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0xe8,uVar3,
                    "index <= _numElements");
  }
  iVar2 = *(int *)(param_1 + 0x10) + -1;
  if (param_2 < iVar2) {
    do {
      iVar2 = *(int *)(param_1 + 0x18);
      iVar1 = param_2 + 1;
      _memcpy(*(int *)(param_1 + 0xc) + param_2 * iVar2,*(int *)(param_1 + 0xc) + iVar2 * iVar1,
              iVar2);
      iVar2 = *(int *)(param_1 + 0x10) + -1;
      param_2 = iVar1;
    } while (iVar1 < iVar2);
  }
  *(int *)(param_1 + 0x10) = iVar2;
  return;
}


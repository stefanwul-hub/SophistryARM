
void FUN_00009348(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  if (-1 < *(int *)(param_1 + 0x10)) {
    return;
  }
  func_0x0006210c(*(undefined4 *)
                   (*(int *)(param_1 + 0x14) + (*(uint *)(param_1 + 8) % *(uint *)(param_1 + 4)) * 4
                   ),param_3,param_4,param_2);
  *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  return;
}


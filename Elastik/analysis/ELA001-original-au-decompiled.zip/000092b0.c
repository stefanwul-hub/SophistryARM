
void FUN_000092b0(int param_1,undefined4 param_2,undefined1 param_3,undefined1 param_4,
                 undefined1 param_5,undefined1 param_6)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (0 < *(int *)(param_1 + 0x10)) {
    uVar1 = *(undefined4 *)
             (*(int *)(param_1 + 0x14) + (*(uint *)(param_1 + 8) % *(uint *)(param_1 + 4)) * 4);
    uVar2 = func_0x000622e0(uVar1);
    func_0x000607d6(uVar2,param_3,param_4,param_5,param_6);
    func_0x00061ffc(uVar1,uVar2,param_2);
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
  }
  return;
}


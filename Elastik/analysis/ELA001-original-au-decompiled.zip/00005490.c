
uint FUN_00005490(int param_1,uint *param_2,undefined4 param_3,undefined4 param_4,int param_5,
                 uint *param_6)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint uVar5;
  int iVar6;
  uint *puVar7;
  int iVar8;
  uint *puStack_10c;
  uint uStack_fc;
  int iStack_f0;
  undefined1 auStack_e0 [80];
  uint auStack_90 [16];
  undefined4 auStack_50 [16];
  uint uStack_10;
  
  func_0x0000bea2(auStack_e0);
  iVar2 = _setjmp(auStack_e0);
  if (iVar2 != 0) {
    return 0;
  }
  iVar2 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x260))(*(int **)(param_1 + 0x13c));
  if (iVar2 < param_5) {
    uStack_fc = 0xffffd586;
    goto LAB_00005521;
  }
  uStack_fc = -(uint)(*(uint *)(param_1 + 0x70) < *param_6) & 0xffffffce;
  uVar1 = *param_6;
  if (uStack_fc != 0) goto LAB_00005521;
  puVar4 = auStack_50;
  for (iVar2 = 0x10; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar4 = 0;
    puVar4 = puVar4 + 1;
  }
  puVar7 = auStack_90;
  for (iVar2 = 0x10; iVar2 != 0; iVar2 = iVar2 + -1) {
    *puVar7 = 0;
    puVar7 = puVar7 + 1;
  }
  if (*(int *)(param_1 + 0x7c) != 0) {
    uStack_10 = *param_2 | 4;
    iVar2 = FUN_00041be2(*(undefined4 *)(param_1 + 0x7c));
    iVar2 = iVar2 + -1;
    if (-1 < iVar2) {
      do {
        puVar4 = (undefined4 *)FUN_00041c54(*(undefined4 *)(param_1 + 0x7c),iVar2);
        (*(code *)*puVar4)(puVar4[1],&uStack_10,param_3,param_4,param_5,param_6);
        iVar2 = iVar2 + -1;
      } while (iVar2 != -1);
    }
  }
  if (*(int *)(param_1 + 0x48) == 0) {
LAB_00005737:
    if (*(int *)(param_1 + 0x138) == 0) {
      (**(code **)(**(int **)(param_1 + 0x13c) + 0x288))(*(int **)(param_1 + 0x13c),0);
    }
    else {
      (**(code **)(**(int **)(param_1 + 0x13c) + 0x288))(*(int **)(param_1 + 0x13c),1);
    }
    if (0 < *(int *)(param_1 + 0x70)) {
      iStack_f0 = 0;
      puStack_10c = auStack_90;
      iVar2 = param_1;
      puVar7 = param_6;
      do {
        if (iStack_f0 < (int)uVar1) {
          if (puVar7[3] == 0) {
            puVar7[3] = *(uint *)(iVar2 + 0xa4);
            goto LAB_000057cc;
          }
          *puStack_10c = puVar7[3];
        }
        else {
LAB_000057cc:
          _memset(*(undefined4 *)(iVar2 + 0xa4),0,param_5 << 2);
          *puStack_10c = *(uint *)(iVar2 + 0xa4);
        }
        iStack_f0 = iStack_f0 + 1;
        puStack_10c = puStack_10c + 1;
        iVar2 = iVar2 + 4;
        puVar7 = puVar7 + 3;
      } while (iStack_f0 < *(int *)(param_1 + 0x70));
    }
    uStack_fc = func_0x00002f6c(param_1,param_3,param_5,auStack_50,auStack_90);
    if (0 < (int)uVar1) {
      uVar5 = 0;
      puVar7 = param_6;
      do {
        puVar7[3] = auStack_90[uVar5];
        uVar5 = uVar5 + 1;
        puVar7 = puVar7 + 3;
      } while (uVar1 != uVar5);
    }
  }
  else {
    **(int **)(param_1 + 0x128) = *(int *)(param_1 + 0x48);
    if (0 < *(int *)(param_1 + 0x48)) {
      iVar8 = 0;
      iVar6 = 0;
      iVar2 = param_1;
      do {
        if (*(int *)(param_1 + 0xa0) < 0) {
          *(undefined4 *)(iVar6 + *(int *)(param_1 + 0x128) + 0xc) = *(undefined4 *)(iVar2 + 0xe4);
        }
        else {
          *(undefined4 *)(iVar6 + *(int *)(param_1 + 0x128) + 0xc) = 0;
        }
        *(undefined4 *)(iVar6 + *(int *)(param_1 + 0x128) + 4) = 1;
        *(int *)(iVar6 + *(int *)(param_1 + 0x128) + 8) = param_5 << 2;
        iVar8 = iVar8 + 1;
        iVar6 = iVar6 + 0xc;
        iVar2 = iVar2 + 4;
      } while (iVar8 < *(int *)(param_1 + 0x48));
    }
    if (-1 < *(int *)(param_1 + 0xa0)) {
      if (0 < *(int *)(param_1 + 0xa0)) {
        uStack_fc = (**(code **)(param_1 + 0x98))
                              (*(undefined4 *)(param_1 + 0x9c),param_2,param_3,param_4,param_5,
                               *(undefined4 *)(param_1 + 0x128));
        goto LAB_00005719;
      }
LAB_00005727:
      if (0 < *(int *)(param_1 + 0x48)) {
        iVar2 = 0;
        do {
          auStack_50[iVar2] = *(undefined4 *)(iVar2 * 0xc + *(int *)(param_1 + 0x128) + 0xc);
          iVar2 = iVar2 + 1;
        } while (iVar2 < *(int *)(param_1 + 0x48));
      }
      goto LAB_00005737;
    }
    uStack_fc = (**(code **)(param_1 + 0x84))
                          (*(undefined4 *)(param_1 + 0x88),param_2,param_3,param_4,param_5,
                           *(undefined4 *)(param_1 + 0x128));
LAB_00005719:
    if (uStack_fc == 0) goto LAB_00005727;
  }
  if (*(int *)(param_1 + 0x7c) != 0) {
    uStack_10 = *param_2 | 8;
    iVar2 = FUN_00041be2(*(undefined4 *)(param_1 + 0x7c));
    iVar2 = iVar2 + -1;
    if (-1 < iVar2) {
      do {
        puVar4 = (undefined4 *)FUN_00041c54(*(undefined4 *)(param_1 + 0x7c),iVar2);
        (*(code *)*puVar4)(puVar4[1],&uStack_10,param_3,param_4,param_5,param_6);
        iVar2 = iVar2 + -1;
      } while (iVar2 != -1);
    }
  }
LAB_00005521:
  func_0x0000bec0(auStack_e0);
  if (uStack_fc != 0) {
    if (uStack_fc == *(uint *)(param_1 + 0x80)) {
      return uStack_fc;
    }
    *(uint *)(param_1 + 0x80) = uStack_fc;
    if (*(int *)(param_1 + 0x18) != 0) {
      iVar2 = FUN_00041be2(*(int *)(param_1 + 0x18));
      iVar2 = iVar2 + -1;
      if (-1 < iVar2) {
        do {
          while (piVar3 = (int *)FUN_00041c54(*(undefined4 *)(param_1 + 0x18),iVar2),
                *piVar3 != 0x16) {
            iVar2 = iVar2 + -1;
            if (iVar2 == -1) {
              return uStack_fc;
            }
          }
          (*(code *)piVar3[1])(piVar3[2],*(undefined4 *)(param_1 + 4),0x16,0,0);
          iVar2 = iVar2 + -1;
        } while (iVar2 != -1);
      }
    }
  }
  return uStack_fc;
}


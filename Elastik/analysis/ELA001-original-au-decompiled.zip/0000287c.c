
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

undefined4
FUN_0000287c(int param_1,undefined *param_2,uint param_3,int param_4,int *param_5,
            undefined1 *param_6)

{
  int iVar1;
  
  param_4 = param_4 + -0xfa02;
  if (param_2 == (undefined *)0x12) {
    if (param_3 != 0) {
      return 0xffffd58e;
    }
    *param_5 = 0x14;
    *param_6 = 0;
    return 0;
  }
  if (param_2 < (undefined *)0x13) {
    if (param_2 == (undefined *)0x5) {
      if (param_3 != 0) {
        return 0xffffd58e;
      }
      goto LAB_00002a39;
    }
    if (param_2 < (undefined *)0x6) {
      if (param_2 != (undefined *)0x2) {
        if (param_2 < (undefined *)0x3) {
          if (param_2 == (undefined *)0x0) {
            if (param_3 != 0) {
              return 0xffffd58e;
            }
            *param_5 = 4;
            *param_6 = 1;
            return 0;
          }
          if (param_2 == (undefined *)0x1) {
            if (1 < param_3) {
              return 0xffffd58e;
            }
            *param_5 = 0xc;
            *param_6 = 1;
            return 0;
          }
          return 0xffffd581;
        }
        if (param_2 != (undefined *)0x3) {
          if (param_2 != (undefined *)0x4) {
            return 0xffffd581;
          }
          if (param_3 != 0) {
            return 0xffffd58e;
          }
          *param_5 = 0x54;
          *param_6 = 0;
          return 0;
        }
        if (param_3 != 0) {
          return 0xffffd58e;
        }
        iVar1 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2a0))(*(int **)(param_1 + 0x13c));
LAB_00002ba9:
        *param_5 = iVar1 << 2;
        *param_6 = 0;
        return 0;
      }
      *param_5 = 8;
    }
    else {
      if (param_2 == (undefined *)0xc) goto LAB_00002add;
      if ((undefined *)0xc < param_2) {
        if (param_2 == (undefined *)0xe) {
          if (param_3 != 0) {
            return 0xffffd58e;
          }
          *param_5 = 4;
          *param_6 = *(int *)(param_1 + 8) < 1;
          return 0;
        }
        if (param_2 <= (undefined *)((int)&mach_header_00000000.filetype + 1)) {
          if (param_3 != 0) {
            return 0xffffd58e;
          }
          iVar1 = iRam00366008;
          if (iRam00366008 == 0) {
            return 0xffffd581;
          }
          goto LAB_00002ba9;
        }
        if (param_2 != (undefined *)0x10) {
          return 0xffffd581;
        }
        if (param_4 < 0) {
          return 0xffffd581;
        }
        iVar1 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2a0))(*(int **)(param_1 + 0x13c));
        if (iVar1 <= param_4) {
          return 0xffffd581;
        }
        iVar1 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2c8))
                          (*(int **)(param_1 + 0x13c),param_4);
        if (iVar1 != 2) {
          return 0xffffd581;
        }
LAB_00002a39:
        *param_5 = 4;
        *param_6 = 0;
        return 0;
      }
      if (param_2 != (undefined *)0x8) {
        if (param_2 != (undefined *)0xb) {
          return 0xffffd581;
        }
        goto LAB_00002a39;
      }
      *param_5 = 0x28;
    }
    if ((param_3 == 0) || (param_3 == 2)) {
      *param_6 = *(int *)(param_1 + 8) < 1;
      return 0;
    }
    if (param_3 != 1) {
      return 0xffffd58e;
    }
LAB_00002c1f:
    *param_6 = 0;
    return 0;
  }
  if (param_2 == (undefined *)0x1b) {
    if (param_3 == 0) {
      *param_5 = 0x10;
      *param_6 = 1;
      return 0;
    }
    return 0xffffd581;
  }
  if (param_2 < (undefined *)0x1c) {
    if (param_2 != (undefined *)0x16) {
      if (param_2 < (undefined *)0x17) {
        if (param_2 != (undefined *)0x14) {
          if (param_2 != (undefined *)0x15) {
            return 0xffffd581;
          }
LAB_00002aa6:
          *param_6 = 1;
          *param_5 = 4;
          return 0;
        }
LAB_00002add:
        if (param_3 != 0) {
          return 0xffffd58e;
        }
        *param_5 = 8;
        *param_6 = 0;
        return 0;
      }
      if (param_2 != (undefined *)0x17) {
        if (param_2 != (undefined *)0x18) {
          return 0xffffd581;
        }
        if (param_3 != 0) {
          return 0xffffd58e;
        }
        if (*(int *)(param_1 + 0xc) == 0) {
          return 0xffffd581;
        }
        goto LAB_00002a39;
      }
      if (1 < param_3) {
        return 0xffffd58e;
      }
      goto LAB_00002b09;
    }
LAB_00002b1f:
    if (param_3 == 0) {
      *param_5 = 4;
      *param_6 = 0;
      return 0;
    }
  }
  else {
    if (param_2 != (undefined *)0x24) {
      if ((undefined *)0x24 < param_2) {
        if (param_2 != (undefined *)0x3e8) {
          if (param_2 != &UNK_0000fa01) {
            if (param_2 != (undefined *)0x25) {
              return 0xffffd581;
            }
            goto LAB_00002aa6;
          }
          *param_5 = 4;
          goto LAB_00002c1f;
        }
        goto LAB_00002b1f;
      }
      if (param_2 != (undefined *)0x1c) {
        if (param_2 != (undefined *)0x21) {
          return 0xffffd581;
        }
        if (param_3 != 0) {
          return 0xffffd58e;
        }
        *param_5 = 0xc;
        *param_6 = 0;
        return 0;
      }
    }
    if (param_3 == 0) {
LAB_00002b09:
      *param_5 = 8;
      *param_6 = 1;
      return 0;
    }
  }
  return 0xffffd58e;
}


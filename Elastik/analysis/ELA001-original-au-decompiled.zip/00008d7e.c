
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00008d7e(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  iVar1 = func_0x00008af0();
  if (iVar1 == 0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/Elastik/Projects/XCode/../../../AppWork/GNAudio/Carbon/GNAUHostTimeInfo.cpp"
                           );
    uVar3 = func_0x00033b90("GNAssertionException");
    func_0x0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0x13,uVar2,
                    "host != GNAUHostUndefined");
  }
  *(undefined4 *)(param_1 + 0xc) = param_2;
  return;
}


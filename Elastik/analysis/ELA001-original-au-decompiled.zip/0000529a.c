
undefined4 FUN_0000529a(int param_1)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int iStack_14;
  int iStack_10;
  
  uVar5 = *(undefined4 *)(param_1 + 0x48);
  uVar1 = *(undefined4 *)(param_1 + 0x70);
  iVar3 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x260))(*(int **)(param_1 + 0x13c));
  iVar3 = iVar3 << 2;
  if (0 < *(int *)(param_1 + 8)) {
    func_0x000093f0(param_1 + 0x140);
    func_0x000093f0(param_1 + 0x158);
    (**(code **)(**(int **)(param_1 + 0x13c) + 0x240))(*(int **)(param_1 + 0x13c));
    *(undefined4 *)(param_1 + 8) = 0;
  }
  iVar4 = func_0x000093e4(param_1 + 0x140);
  if ((iVar4 == 0) || (iVar4 = func_0x000093e4(param_1 + 0x158), iVar4 == 0)) {
LAB_0000530f:
    uVar5 = 0xffffd585;
  }
  else {
    cVar2 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x268))
                      (*(int **)(param_1 + 0x13c),uVar5,uVar1);
    if (cVar2 == '\0') {
      uVar5 = 0xffffd58c;
    }
    else {
      if (*(int *)(param_1 + 0x124) < iVar3) {
        iStack_10 = 0x10;
        iVar4 = param_1;
        do {
          if (*(int *)(iVar4 + 0xa4) != 0) {
            func_0x0000b122(*(int *)(iVar4 + 0xa4));
            *(undefined4 *)(iVar4 + 0xa4) = 0;
          }
          if (*(int *)(iVar4 + 0xe4) != 0) {
            func_0x0000b122(*(int *)(iVar4 + 0xe4));
            *(undefined4 *)(iVar4 + 0xe4) = 0;
          }
          iVar4 = iVar4 + 4;
          iStack_10 = iStack_10 + -1;
        } while (iStack_10 != 0);
      }
      if (0 < *(int *)(param_1 + 0x70)) {
        iStack_14 = 0;
        iVar4 = param_1;
        do {
          if (*(int *)(iVar4 + 0xa4) == 0) {
            iVar6 = FUN_0000aecc(iVar3);
            *(int *)(iVar4 + 0xa4) = iVar6;
            if (iVar6 == 0) goto LAB_0000530f;
          }
          iStack_14 = iStack_14 + 1;
          iVar4 = iVar4 + 4;
        } while (iStack_14 < *(int *)(param_1 + 0x70));
      }
      *(int *)(param_1 + 0x124) = iVar3;
      func_0x0000868a(*(undefined4 *)(param_1 + 300));
      func_0x0001cd38(*(undefined4 *)(param_1 + 0x13c),uVar5);
      func_0x0001ce42(*(undefined4 *)(param_1 + 0x13c),uVar1);
      (**(code **)(**(int **)(param_1 + 0x13c) + 0x24c))(*(int **)(param_1 + 0x13c));
      func_0x0001c9fa(*(undefined4 *)(param_1 + 0x13c),0);
      (**(code **)(**(int **)(param_1 + 0x13c) + 0x23c))(*(int **)(param_1 + 0x13c));
      *(undefined4 *)(param_1 + 8) = 1;
      uVar5 = 0;
    }
  }
  return uVar5;
}


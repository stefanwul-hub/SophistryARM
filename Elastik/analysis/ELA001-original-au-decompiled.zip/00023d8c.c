
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00023d8c(undefined4 *param_1)

{
  int iVar1;
  undefined4 *puVar2;
  
  func_0x0002dc66(param_1);
  *param_1 = &UNK_0036e2e8;
  puVar2 = param_1 + 3;
  for (iVar1 = 0xb; iVar1 != 0; iVar1 = iVar1 + -1) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  return;
}


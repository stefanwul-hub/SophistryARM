
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_00005b64(int param_1,undefined4 param_2)

{
  char cVar1;
  short sVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int *piVar6;
  undefined4 uVar7;
  int iStack_44;
  int iStack_40;
  int iStack_3c;
  undefined4 uStack_30;
  int iStack_2c;
  undefined1 auStack_28 [4];
  int iStack_24;
  undefined4 auStack_20 [4];
  
  FUN_00004210(param_1,0x1c,0,0,&uStack_30);
  iVar3 = _CFGetTypeID(param_2);
  iVar4 = _CFDictionaryGetTypeID();
  if (iVar3 == iVar4) {
    sVar2 = _GetComponentInfo(*(undefined4 *)(param_1 + 4),&iStack_44,0,0,0);
    if (sVar2 != 0) {
      return (int)sVar2;
    }
    auStack_20[0] = _CFDictionaryGetValue(param_2,_UNK_0036c570);
    _CFNumberGetValue(auStack_20[0],3,&iStack_24);
    if (iStack_24 == 0) {
      auStack_20[0] = _CFDictionaryGetValue(param_2,_UNK_0036c56c);
      _CFNumberGetValue(auStack_20[0],3,&iStack_24);
      if (iStack_24 == iStack_44) {
        auStack_20[0] = _CFDictionaryGetValue(param_2,_UNK_0036c568);
        _CFNumberGetValue(auStack_20[0],3,&iStack_24);
        if (iStack_24 == iStack_40) {
          auStack_20[0] = _CFDictionaryGetValue(param_2,_UNK_0036c564);
          _CFNumberGetValue(auStack_20[0],3,&iStack_24);
          if ((iStack_24 == iStack_3c) &&
             (iVar3 = _CFDictionaryGetValue(param_2,_UNK_0036c560), iVar3 != 0)) {
            uVar5 = __Znwm(0x14);
            FUN_0001e688(uVar5);
            piVar6 = (int *)FUN_0002dfa6(uVar5);
            uVar5 = _CFDataGetLength(iVar3);
            uVar7 = _CFDataGetBytePtr(iVar3);
            uVar5 = func_0x0002803a(uVar7,uVar5);
            (**(code **)(**(int **)(param_1 + 0x13c) + 0x2e0))(*(int **)(param_1 + 0x13c),uVar5);
            cVar1 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x350))(*(int **)(param_1 + 0x13c));
            *(uint *)(param_1 + 0x134) = (uint)(cVar1 != '\0');
            if (piVar6 != (int *)0x0) {
              (**(code **)(*piVar6 + 0x44))(piVar6);
            }
            iStack_2c = _CFDictionaryGetValue(param_2,_UNK_0036c55c);
            if (iStack_2c == 0) {
              iStack_2c = _UNK_0036c574;
            }
            uStack_30 = 0xffffffff;
            FUN_00005f2c(param_1,0x1c,0,0,&uStack_30,8);
            if (*(int *)(param_1 + 0x18) != 0) {
              iVar3 = FUN_00041be2(*(int *)(param_1 + 0x18));
              iVar3 = iVar3 + -1;
              if (-1 < iVar3) {
                do {
                  piVar6 = (int *)FUN_00041c54(*(undefined4 *)(param_1 + 0x18),iVar3);
                  if (*piVar6 == 0x1c) {
                    (*(code *)piVar6[1])(piVar6[2],*(undefined4 *)(param_1 + 4),0x1c,0,0);
                  }
                  iVar3 = iVar3 + -1;
                } while (iVar3 != -1);
              }
            }
            cVar1 = _CFDictionaryGetValueIfPresent(param_2,_UNK_0036c558,auStack_20);
            if (cVar1 != '\0') {
              _CFNumberGetValue(auStack_20[0],3,&iStack_24);
              FUN_00005f2c(param_1,0x1a,0,0,&iStack_24,4);
            }
            cVar1 = _CFDictionaryGetValueIfPresent(param_2,_UNK_0036c554,auStack_20);
            if (cVar1 != '\0') {
              _CFNumberGetValue(auStack_20[0],0xc,auStack_28);
              FUN_00005f2c(param_1,6,0,0,auStack_28,4);
            }
            return 0;
          }
        }
      }
    }
  }
  return -0x2a63;
}


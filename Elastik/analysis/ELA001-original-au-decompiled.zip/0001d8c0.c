
void FUN_0001d8c0(int param_1,int *param_2)

{
  int *piVar1;
  
  piVar1 = *(int **)(param_1 + 0x5c);
  if (piVar1 != param_2) {
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    *(int **)(param_1 + 0x5c) = param_2;
    if (param_2 != (int *)0x0) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
  }
  return;
}


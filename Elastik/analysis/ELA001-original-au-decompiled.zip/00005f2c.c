
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_00005f2c(int param_1,int param_2,int param_3,undefined4 param_4,double *param_5,uint param_6
                )

{
  double dVar1;
  char cVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 *puVar9;
  char *pcVar10;
  char *pcVar11;
  int iVar12;
  double *pdVar13;
  double *pdVar14;
  undefined4 *puVar15;
  bool bVar16;
  longdouble lVar17;
  int iStack_64;
  undefined1 auStack_54 [40];
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  uint auStack_20 [4];
  
  switch(param_2) {
  case 0:
    if (param_6 != 4) {
      return -0x2a63;
    }
    if (param_3 != 0) {
      return -0x2a72;
    }
    iVar5 = FUN_00005b64(param_1,*(undefined4 *)param_5);
    return iVar5;
  case 1:
    if (param_6 < 0xc) {
      return -0x2a63;
    }
    auStack_20[0] = 0xc;
    if (param_6 < 0xd) {
      auStack_20[0] = param_6;
    }
    iStack_2c = 0;
    uStack_28 = 0;
    uStack_24 = 0;
    _memcpy(&iStack_2c,param_5,auStack_20[0]);
    if (iStack_2c == 0) {
      *(undefined4 *)(param_1 + 0xa0) = 0;
      return 0;
    }
    bVar16 = 0 < *(int *)(param_1 + 8);
    if (bVar16) {
      func_0x000093f0(param_1 + 0x140);
      func_0x000093f0(param_1 + 0x158);
      (**(code **)(**(int **)(param_1 + 0x13c) + 0x240))(*(int **)(param_1 + 0x13c));
      *(undefined4 *)(param_1 + 8) = 0;
    }
    auStack_20[0] = 0x28;
    iVar5 = _AudioUnitGetProperty(iStack_2c,8,2,uStack_28,auStack_54,auStack_20);
    if (iVar5 != 0) {
      return iVar5;
    }
    iVar5 = FUN_00005f2c(param_1,8,1,uStack_24,auStack_54,0x28);
    if (iVar5 != 0) {
      return iVar5;
    }
    auStack_20[0] = 4;
    iVar5 = _AudioUnitGetProperty(iStack_2c,5,0,0xe,param_1 + 0x98,auStack_20);
    if (iVar5 != 0) {
      return iVar5;
    }
    *(int *)(param_1 + 0x8c) = iStack_2c;
    *(undefined4 *)(param_1 + 0x90) = uStack_28;
    *(undefined4 *)(param_1 + 0x94) = uStack_24;
    uVar3 = _GetComponentInstanceStorage(iStack_2c);
    *(undefined4 *)(param_1 + 0x9c) = uVar3;
    *(undefined4 *)(param_1 + 0xa0) = 1;
    if (bVar16) {
      iVar5 = FUN_0000529a(param_1);
      return iVar5;
    }
    break;
  case 2:
    if (param_6 != 8) {
      return -0x2a63;
    }
    dVar1 = *param_5;
    if (0 < *(int *)(param_1 + 8)) {
      return -0x2a61;
    }
    lVar17 = (longdouble)
             (**(code **)(**(int **)(param_1 + 0x13c) + 600))(*(int **)(param_1 + 0x13c));
    if (dVar1 != (double)lVar17) {
      uVar3 = __Znwm(0x14);
      FUN_0001e688(uVar3);
      piVar4 = (int *)FUN_0002dfa6(uVar3);
      (**(code **)(**(int **)(param_1 + 0x13c) + 0x254))(*(int **)(param_1 + 0x13c),dVar1);
      if (piVar4 != (int *)0x0) {
        (**(code **)(*piVar4 + 0x44))(piVar4);
      }
      if (*(int *)(param_1 + 0x18) != 0) {
        iVar5 = FUN_00041be2(*(int *)(param_1 + 0x18));
        iVar5 = iVar5 + -1;
        if (-1 < iVar5) {
          do {
            piVar4 = (int *)FUN_00041c54(*(undefined4 *)(param_1 + 0x18),iVar5);
            if (*piVar4 == 2) {
              (*(code *)piVar4[1])(piVar4[2],*(undefined4 *)(param_1 + 4),2,param_3,param_4);
            }
            iVar5 = iVar5 + -1;
          } while (iVar5 != -1);
        }
      }
      *(double *)(param_1 + 0x2c) = dVar1;
      *(double *)(param_1 + 0x54) = dVar1;
      return 0;
    }
    break;
  default:
    return -0x2a7f;
  case 8:
    if (0 < *(int *)(param_1 + 8)) {
      return -0x2a61;
    }
    if (*(int *)(param_5 + 1) != 0x6c70636d) {
      return -0x2a74;
    }
    uVar8 = 0x28;
    if (param_6 < 0x29) {
      uVar8 = param_6;
    }
    if (param_3 == 0) {
      cVar2 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x268))
                        (*(int **)(param_1 + 0x13c),*(undefined4 *)((int)param_5 + 0x1c),
                         *(undefined4 *)((int)param_5 + 0x1c));
      if (cVar2 == '\0') {
        return -0x2a74;
      }
      puVar9 = (undefined4 *)(param_1 + 0x54);
    }
    else if (param_3 == 1) {
      puVar9 = (undefined4 *)(param_1 + 0x2c);
    }
    else {
      if (param_3 != 2) {
        return -0x2a72;
      }
      puVar9 = (undefined4 *)(param_1 + 0x54);
    }
    puVar15 = puVar9;
    for (iVar5 = 10; iVar5 != 0; iVar5 = iVar5 + -1) {
      *puVar15 = 0;
      puVar15 = puVar15 + 1;
    }
    _memcpy(puVar9,param_5,uVar8);
    if (param_3 == 0) {
      *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(param_1 + 0x54);
      *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_1 + 0x58);
      *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(param_1 + 0x5c);
      *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_1 + 0x60);
      *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 100);
      *(undefined4 *)(param_1 + 0x40) = *(undefined4 *)(param_1 + 0x68);
      *(undefined4 *)(param_1 + 0x44) = *(undefined4 *)(param_1 + 0x6c);
      *(undefined4 *)(param_1 + 0x48) = *(undefined4 *)(param_1 + 0x70);
      *(undefined4 *)(param_1 + 0x4c) = *(undefined4 *)(param_1 + 0x74);
      *(undefined4 *)(param_1 + 0x50) = *(undefined4 *)(param_1 + 0x78);
    }
    dVar1 = *param_5;
    if (((dVar1 != DOUBLE_00364718) &&
        (lVar17 = (longdouble)
                  (**(code **)(**(int **)(param_1 + 0x13c) + 600))(*(int **)(param_1 + 0x13c)),
        dVar1 != (double)lVar17)) && (piVar4 = *(int **)(param_1 + 0x13c), piVar4 != (int *)0x0)) {
      cVar2 = (**(code **)(*piVar4 + 0x250))(piVar4);
      if (cVar2 == '\0') {
        uVar3 = __Znwm(0x14);
        FUN_0001e688(uVar3);
        piVar4 = (int *)FUN_0002dfa6(uVar3);
        (**(code **)(**(int **)(param_1 + 0x13c) + 0x254))(*(int **)(param_1 + 0x13c),*param_5);
        if (piVar4 != (int *)0x0) {
          (**(code **)(*piVar4 + 0x44))(piVar4);
        }
      }
      else {
        (**(code **)(**(int **)(param_1 + 0x13c) + 0x240))(*(int **)(param_1 + 0x13c));
        uVar3 = __Znwm(0x14);
        FUN_0001e688(uVar3);
        piVar4 = (int *)FUN_0002dfa6(uVar3);
        (**(code **)(**(int **)(param_1 + 0x13c) + 0x254))(*(int **)(param_1 + 0x13c),*param_5);
        if (piVar4 != (int *)0x0) {
          (**(code **)(*piVar4 + 0x44))(piVar4);
        }
        (**(code **)(**(int **)(param_1 + 0x13c) + 0x23c))(*(int **)(param_1 + 0x13c));
      }
    }
    if (*(int *)(param_1 + 0x18) != 0) {
      iVar5 = FUN_00041be2(*(int *)(param_1 + 0x18));
      iVar5 = iVar5 + -1;
      if (-1 < iVar5) {
        do {
          piVar4 = (int *)FUN_00041c54(*(undefined4 *)(param_1 + 0x18),iVar5);
          if (*piVar4 == 8) {
            (*(code *)piVar4[1])(piVar4[2],*(undefined4 *)(param_1 + 4),8,param_3,param_4);
          }
          iVar5 = iVar5 + -1;
        } while (iVar5 != -1);
      }
    }
    break;
  case 0xb:
    return -0x2a71;
  case 0xe:
    if (param_6 != 4) {
      return -0x2a63;
    }
    if (0 < *(int *)(param_1 + 8)) {
      return -0x2a61;
    }
    iVar5 = *(int *)param_5;
    iVar12 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x260))(*(int **)(param_1 + 0x13c));
    if (iVar5 != iVar12) {
      uVar3 = __Znwm(0x14);
      FUN_0001e688(uVar3);
      piVar4 = (int *)FUN_0002dfa6(uVar3);
      (**(code **)(**(int **)(param_1 + 0x13c) + 0x25c))
                (*(int **)(param_1 + 0x13c),*(undefined4 *)param_5);
      if (piVar4 != (int *)0x0) {
        (**(code **)(*piVar4 + 0x44))(piVar4);
      }
      if (*(int *)(param_1 + 0x18) != 0) {
        iVar5 = FUN_00041be2(*(int *)(param_1 + 0x18));
        iVar5 = iVar5 + -1;
        if (-1 < iVar5) {
          do {
            piVar4 = (int *)FUN_00041c54(*(undefined4 *)(param_1 + 0x18),iVar5);
            if (*piVar4 == 0xe) {
              (*(code *)piVar4[1])(piVar4[2],*(undefined4 *)(param_1 + 4),0xe,param_3,param_4);
            }
            iVar5 = iVar5 + -1;
          } while (iVar5 != -1);
          return 0;
        }
      }
    }
    break;
  case 0x15:
    if (param_3 != 0) {
      return -0x2a72;
    }
    if (param_6 != 4) {
      return -0x2a63;
    }
    uVar8 = (uint)(*(int *)param_5 != 0);
    if (uVar8 != *(uint *)(param_1 + 0x134)) {
      (**(code **)(**(int **)(param_1 + 0x13c) + 0x34c))(*(int **)(param_1 + 0x13c),uVar8);
      *(uint *)(param_1 + 0x134) = uVar8;
      if (*(int *)(param_1 + 0x18) != 0) {
        iVar5 = FUN_00041be2(*(int *)(param_1 + 0x18));
        iVar5 = iVar5 + -1;
        if (-1 < iVar5) {
          do {
            piVar4 = (int *)FUN_00041c54(*(undefined4 *)(param_1 + 0x18),iVar5);
            if (*piVar4 == 0x15) {
              (*(code *)piVar4[1])(piVar4[2],*(undefined4 *)(param_1 + 4),0x15,0,param_4);
            }
            iVar5 = iVar5 + -1;
          } while (iVar5 != -1);
        }
      }
    }
    break;
  case 0x17:
    if (param_6 < 8) {
      return -0x2a63;
    }
    *(undefined4 *)(param_1 + 0x84) = *(undefined4 *)param_5;
    *(undefined4 *)(param_1 + 0x88) = *(undefined4 *)((int)param_5 + 4);
    *(undefined4 *)(param_1 + 0xa0) = 0xffffffff;
    if (*(int *)(param_1 + 0x18) != 0) {
      iVar5 = FUN_00041be2(*(int *)(param_1 + 0x18));
      iVar5 = iVar5 + -1;
      if (-1 < iVar5) {
        do {
          piVar4 = (int *)FUN_00041c54(*(undefined4 *)(param_1 + 0x18),iVar5);
          if (*piVar4 == 0x17) {
            (*(code *)piVar4[1])(piVar4[2],*(undefined4 *)(param_1 + 4),0x17,param_3,param_4);
          }
          iVar5 = iVar5 + -1;
        } while (iVar5 != -1);
      }
    }
    break;
  case 0x1b:
    if (param_3 != 0) {
      return -0x2a72;
    }
    uVar8 = 0x10;
    if (param_6 < 0x11) {
      uVar8 = param_6;
    }
    bVar16 = true;
    uVar7 = uVar8;
    pcVar10 = (char *)(param_1 + 0x1c);
    pdVar13 = param_5;
    do {
      pcVar11 = pcVar10;
      pdVar14 = pdVar13;
      if (uVar7 == 0) break;
      uVar7 = uVar7 - 1;
      pdVar14 = (double *)((int)pdVar13 + 1);
      pcVar11 = pcVar10 + 1;
      bVar16 = *pcVar10 == *(char *)pdVar13;
      pcVar10 = pcVar11;
      pdVar13 = pdVar14;
    } while (bVar16);
    iVar5 = 0;
    if (!bVar16) {
      iVar5 = (uint)(byte)pcVar11[-1] - (uint)*(byte *)((int)pdVar14 + -1);
    }
    if (iVar5 != 0) {
      *(undefined4 *)(param_1 + 0x1c) = 0;
      *(undefined4 *)(param_1 + 0x20) = 0;
      *(undefined4 *)(param_1 + 0x24) = 0;
      *(undefined4 *)(param_1 + 0x28) = 0;
      _memcpy((char *)(param_1 + 0x1c),param_5,uVar8);
      if (*(int *)(param_1 + 0x18) != 0) {
        iVar5 = FUN_00041be2(*(int *)(param_1 + 0x18));
        iVar5 = iVar5 + -1;
        if (-1 < iVar5) {
          do {
            piVar4 = (int *)FUN_00041c54(*(undefined4 *)(param_1 + 0x18),iVar5);
            if (*piVar4 == 0x1b) {
              (*(code *)piVar4[1])(piVar4[2],*(undefined4 *)(param_1 + 4),0x1b,0,param_4);
            }
            iVar5 = iVar5 + -1;
          } while (iVar5 != -1);
        }
      }
    }
    break;
  case 0x1c:
  case 0x24:
    if (param_6 != 8) {
      return -0x2a63;
    }
    if (param_3 != 0) {
      return -0x2a72;
    }
    iStack_64 = *(int *)param_5;
    if (iStack_64 < 0) {
      if ((*(int *)(param_1 + 0xc) != 0) && (*(int *)(param_1 + 0x14) != _UNK_0036c574)) {
        if (*(int *)((int)param_5 + 4) == 0) {
          return -0x2a63;
        }
        iVar5 = _CFArrayGetCount(*(int *)(param_1 + 0xc));
        if (0 < iVar5) {
          iVar12 = 0;
          do {
            iVar6 = _CFArrayGetValueAtIndex(*(undefined4 *)(param_1 + 0xc),iVar12);
            iVar6 = _CFStringCompare(*(undefined4 *)((int)param_5 + 4),*(undefined4 *)(iVar6 + 4),1)
            ;
            if (iVar6 == 0) {
              iStack_64 = iVar12;
            }
            iVar12 = iVar12 + 1;
            if (-1 < iStack_64) goto code_r0x000062e6;
          } while (iVar5 != iVar12);
        }
      }
      uVar3 = *(undefined4 *)((int)param_5 + 4);
      *(undefined4 *)(param_1 + 0x10) = *(undefined4 *)param_5;
      *(undefined4 *)(param_1 + 0x14) = uVar3;
      _CFRetain(*(undefined4 *)(param_1 + 0x14));
      if (*(int *)(param_1 + 0x18) != 0) {
        iVar5 = FUN_00041be2(*(int *)(param_1 + 0x18));
        iVar5 = iVar5 + -1;
        if (-1 < iVar5) {
          do {
            piVar4 = (int *)FUN_00041c54(*(undefined4 *)(param_1 + 0x18),iVar5);
            if (param_2 == *piVar4) {
              (*(code *)piVar4[1])(piVar4[2],*(undefined4 *)(param_1 + 4),param_2,0,param_4);
            }
            iVar5 = iVar5 + -1;
          } while (iVar5 != -1);
        }
      }
    }
    else {
code_r0x000062e6:
      *(int *)(param_1 + 0x10) = iStack_64;
      uVar3 = (**(code **)(**(int **)(param_1 + 0x13c) + 0x2ec))
                        (*(int **)(param_1 + 0x13c),iStack_64);
      uVar3 = func_0x0000c426(uVar3);
      *(undefined4 *)(param_1 + 0x14) = uVar3;
      uVar3 = __Znwm(0x14);
      FUN_0001e688(uVar3);
      piVar4 = (int *)FUN_0002dfa6(uVar3);
      (**(code **)(**(int **)(param_1 + 0x13c) + 0x2f0))(*(int **)(param_1 + 0x13c),iStack_64);
      if (piVar4 != (int *)0x0) {
        (**(code **)(*piVar4 + 0x44))(piVar4);
      }
      if (*(int *)(param_1 + 0x18) != 0) {
        iVar5 = FUN_00041be2(*(int *)(param_1 + 0x18));
        iVar5 = iVar5 + -1;
        if (-1 < iVar5) {
          do {
            piVar4 = (int *)FUN_00041c54(*(undefined4 *)(param_1 + 0x18),iVar5);
            if (param_2 == *piVar4) {
              (*(code *)piVar4[1])(piVar4[2],*(undefined4 *)(param_1 + 4),param_2,0,param_4);
            }
            iVar5 = iVar5 + -1;
          } while (iVar5 != -1);
        }
      }
    }
    break;
  case 0x25:
    if (param_3 != 0) {
      return -0x2a72;
    }
    if (param_6 != 4) {
      return -0x2a63;
    }
    *(undefined4 *)(param_1 + 0x138) = *(undefined4 *)param_5;
    return 0;
  }
  return 0;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_0006f604(void)

{
  undefined4 uVar1;
  
  if (iRam003d4330 != 0) {
    return iRam003d4330;
  }
  uVar1 = FUN_00033b90("GNTimer");
  iRam003d4330 = FUN_0001ffde(uVar1,&UNK_00070038);
  return iRam003d4330;
}


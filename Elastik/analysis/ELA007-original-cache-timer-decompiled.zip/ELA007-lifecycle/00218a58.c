
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00218a58(void)

{
  undefined4 uVar1;
  
  if (iRam003d907c != 0) {
    return iRam003d907c;
  }
  uVar1 = FUN_00033b90("GNSoundFileCache");
  iRam003d907c = FUN_0001ffde(uVar1,&UNK_0021915e);
  return iRam003d907c;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00217fe2(int param_1)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 0x2c) != 0) {
    return;
  }
  piVar1 = (int *)FUN_00070218(&UNK_00217fd0,param_1,0x9999999a,0x3fc99999,1);
  *(int **)(param_1 + 0x2c) = piVar1;
  (**(code **)(*piVar1 + 0x40))(piVar1);
  return;
}


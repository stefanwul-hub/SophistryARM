
void FUN_002183d2(undefined4 param_1,undefined1 *param_2)

{
  *param_2 = 0;
  *(undefined4 *)(param_2 + 4) = 0xffffffff;
  *(undefined4 *)(param_2 + 8) = 0xffffffff;
  return;
}


002183d2  55  PUSH EBP
002183d3  89e5  MOV EBP,ESP
002183d5  8b450c  MOV EAX,dword ptr [EBP + 0xc]
002183d8  c60000  MOV byte ptr [EAX],0x0
002183db  c74004ffffffff  MOV dword ptr [EAX + 0x4],0xffffffff
002183e2  c74008ffffffff  MOV dword ptr [EAX + 0x8],0xffffffff
002183e9  5d  POP EBP
002183ea  c3  RET


/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0000acae(undefined4 param_1)

{
  undefined4 uVar1;
  undefined1 auStack_410 [1024];
  undefined1 *puStack_10;
  
  if (cRam003d3f10 == '\0') {
    cRam003d3f10 = '\x01';
    puStack_10 = &stack0x00000008;
    _vsprintf(auStack_410,param_1,puStack_10);
    FUN_0000ab14(auStack_410);
    if (pcRam003d3f04 != (code *)0x0) {
      (*pcRam003d3f04)(auStack_410);
    }
    if (pcRam003d3f00 != (code *)0x0) {
      (*pcRam003d3f00)();
    }
    if (cRam003d3f08 == '\0') {
      uVar1 = FUN_00084aa2();
      func_0x00084bb6(uVar1);
      return;
    }
  }
  return;
}


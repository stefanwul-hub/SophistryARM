
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_002182e0(int param_1)

{
  int iVar1;
  char *pcVar2;
  int iVar3;
  char *pcVar4;
  int iVar5;
  char *pcVar6;
  int iVar7;
  
  iVar1 = *(int *)(param_1 + 0x44);
  if (0 < iVar1) {
    pcVar2 = *(char **)(param_1 + 0x40);
    if (*pcVar2 == '\0') {
      iVar7 = 0;
      pcVar4 = pcVar2;
    }
    else {
      iVar5 = 0;
      iVar3 = 0xc;
      pcVar6 = pcVar2;
      do {
        iVar7 = iVar3;
        pcVar6 = pcVar6 + 0xc;
        iVar5 = iVar5 + 1;
        if (iVar5 == iVar1) goto LAB_002182fd;
        pcVar4 = pcVar2 + iVar7;
        iVar3 = iVar7 + 0xc;
      } while (*pcVar6 != '\0');
    }
    pcVar4[4] = -1;
    pcVar4[5] = -1;
    pcVar4[6] = -1;
    pcVar4[7] = -1;
    *(undefined4 *)(*(int *)(param_1 + 0x40) + 8 + iVar7) = 0xffffffff;
    *(undefined1 *)(*(int *)(param_1 + 0x40) + iVar7) = 1;
    return iVar7 + *(int *)(param_1 + 0x40);
  }
  iVar5 = 0;
LAB_002182fd:
  if (*(int *)(param_1 + 0x24) <= iVar1) {
    FUN_0000acae("GNFileCache: To many file requesters.");
  }
  iVar5 = iVar5 * 0xc;
  *(undefined4 *)(*(int *)(param_1 + 0x40) + 4 + iVar5) = 0xffffffff;
  *(undefined4 *)(iVar5 + 8 + *(int *)(param_1 + 0x40)) = 0xffffffff;
  *(undefined1 *)(iVar5 + *(int *)(param_1 + 0x40)) = 1;
  *(int *)(param_1 + 0x44) = *(int *)(param_1 + 0x44) + 1;
  return iVar5 + *(int *)(param_1 + 0x40);
}


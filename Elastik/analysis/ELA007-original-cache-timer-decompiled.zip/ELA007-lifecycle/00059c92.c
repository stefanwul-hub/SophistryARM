
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00059c92(void)

{
  float fVar1;
  undefined4 *puVar2;
  
  if (iRam003d4274 != 0) {
    return iRam003d4274;
  }
  puVar2 = (undefined4 *)__Znwm(0x38);
  func_0x0002dc66(puVar2);
  *puVar2 = &UNK_003700a8;
  puVar2[5] = 0;
  puVar2[4] = 0;
  puVar2[6] = 0;
  fVar1 = FLOAT_00365d0c;
  puVar2[7] = FLOAT_00365d0c;
  puVar2[8] = fVar1;
  puVar2[9] = 0;
  puVar2[10] = 1;
  puVar2[0xb] = 1;
  puVar2[0xd] = 0;
  *(undefined2 *)(puVar2 + 0xc) = 0;
  iRam003d4274 = FUN_0002dfa6(puVar2);
  *(undefined4 *)(iRam003d4274 + 0xc) = 3;
  return iRam003d4274;
}


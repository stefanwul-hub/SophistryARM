
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00059f14(int param_1)

{
  char cVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  
  if (cRam003d4280 != '\0') {
    return;
  }
  if ((param_1 == 0) ||
     (((iVar5 = *(int *)(param_1 + 0xc), iVar5 != 6 && (iVar5 != 1)) && (iVar5 != 5)))) {
    cRam003d4280 = 1;
    piVar2 = (int *)func_0x0000cfca();
    uVar4 = uRam003d4240;
  }
  else {
    uRam00366040 = *(undefined4 *)(param_1 + 0x1c);
    uRam00366044 = *(undefined4 *)(param_1 + 0x20);
    cRam003d4280 = 1;
    piVar2 = (int *)func_0x0000cfca();
    uVar4 = uRam003d4240;
  }
  uRam003d4240 = uVar4;
  if (((cRam003d4268 != '\0') && (iVar5 = FUN_00029ddc(uVar4), iVar5 != 0)) &&
     (iVar5 = iVar5 + -1, -1 < iVar5)) {
    do {
      uVar6 = FUN_0002a364(uVar4,iVar5);
      func_0x0006d5a6(uVar6,0);
      iVar5 = iVar5 + -1;
    } while (iVar5 != -1);
  }
  if (piVar2 != (int *)0x0) {
    (**(code **)(*piVar2 + 0x284))(piVar2);
  }
  uVar4 = uRam003d4244;
  if (((cRam003d4268 != '\0') && (iVar5 = FUN_00029ddc(uRam003d4244), iVar5 != 0)) &&
     (iVar5 = iVar5 + -1, -1 < iVar5)) {
    do {
      uVar6 = FUN_0002a364(uVar4,iVar5);
      func_0x0006d5a6(uVar6,1);
      iVar5 = iVar5 + -1;
    } while (iVar5 != -1);
  }
  piVar3 = (int *)func_0x0006d8fe();
  cVar1 = (**(code **)(*piVar3 + 0x1c4))(piVar3);
  uVar4 = uRam003d4248;
  if (cVar1 != '\0') {
    if (((cRam003d4268 != '\0') && (iVar5 = FUN_00029ddc(uRam003d4248), iVar5 != 0)) &&
       (iVar5 = iVar5 + -1, -1 < iVar5)) {
      do {
        uVar6 = FUN_0002a364(uVar4,iVar5);
        func_0x0006d5a6(uVar6,2);
        iVar5 = iVar5 + -1;
      } while (iVar5 != -1);
    }
    piVar3 = (int *)func_0x0006d8fe();
    (**(code **)(*piVar3 + 0x1c0))(piVar3);
    uVar4 = uRam003d424c;
    if (((cRam003d4268 != '\0') && (iVar5 = FUN_00029ddc(uRam003d424c), iVar5 != 0)) &&
       (iVar5 = iVar5 + -1, -1 < iVar5)) {
      do {
        uVar6 = FUN_0002a364(uVar4,iVar5);
        func_0x0006d5a6(uVar6,3);
        iVar5 = iVar5 + -1;
      } while (iVar5 != -1);
    }
  }
  uVar4 = uRam003d4250;
  if ((param_1 == 0) || (*(int *)(param_1 + 0xc) != 0xd)) {
    if (piVar2 != (int *)0x0) {
      if (((cRam003d4268 != '\0') && (iVar5 = FUN_00029ddc(uRam003d4250), iVar5 != 0)) &&
         (iVar5 = iVar5 + -1, -1 < iVar5)) {
        do {
          uVar6 = FUN_0002a364(uVar4,iVar5);
          func_0x0006d5a6(uVar6,4);
          iVar5 = iVar5 + -1;
        } while (iVar5 != -1);
      }
      cVar1 = func_0x00010f3e(piVar2);
      uVar4 = uRam003d4254;
      if (cVar1 != '\0') {
        if (((cRam003d4268 != '\0') && (iVar5 = FUN_00029ddc(uRam003d4254), iVar5 != 0)) &&
           (iVar5 = iVar5 + -1, -1 < iVar5)) {
          do {
            uVar6 = FUN_0002a364(uVar4,iVar5);
            func_0x0006d5a6(uVar6,5);
            iVar5 = iVar5 + -1;
          } while (iVar5 != -1);
        }
        (**(code **)(*piVar2 + 0x21c))(piVar2);
        uVar4 = uRam003d4258;
        if (((cRam003d4268 != '\0') && (iVar5 = FUN_00029ddc(uRam003d4258), iVar5 != 0)) &&
           (iVar5 = iVar5 + -1, -1 < iVar5)) {
          do {
            uVar6 = FUN_0002a364(uVar4,iVar5);
            func_0x0006d5a6(uVar6,6);
            iVar5 = iVar5 + -1;
          } while (iVar5 != -1);
        }
      }
    }
    if (param_1 == 0) {
      if (piVar2[0x13] != 0) {
        cRam003d4280 = 0;
        return;
      }
      iVar5 = func_0x00015622(piVar2);
      if (iVar5 != 0) {
        cRam003d4280 = 0;
        return;
      }
      iVar5 = func_0x0001e78e();
      if (iVar5 != 0) {
        uVar4 = func_0x0001e78e();
        FUN_0001ea42(uVar4);
      }
      (**(code **)(*piVar2 + 0x278))(piVar2);
      cRam003d4280 = 0;
      return;
    }
    iVar5 = *(int *)(param_1 + 0xc);
  }
  else {
    iVar5 = *(int *)(param_1 + 0xc);
  }
  if (iVar5 == 3) {
    iVar5 = *(int *)(param_1 + 0xc);
  }
  else {
    if ((((iVar5 != 1) && (iVar5 != 5)) && (iVar5 != 0xd)) &&
       ((piVar2[0x13] == 0 && (iVar5 = func_0x00015622(piVar2), iVar5 == 0)))) {
      iVar5 = func_0x0001e78e();
      uVar4 = uRam003d425c;
      if (iVar5 != 0) {
        if (((cRam003d4268 != '\0') && (iVar5 = FUN_00029ddc(uRam003d425c), iVar5 != 0)) &&
           (iVar5 = iVar5 + -1, -1 < iVar5)) {
          do {
            uVar6 = FUN_0002a364(uVar4,iVar5);
            func_0x0006d5a6(uVar6,7);
            iVar5 = iVar5 + -1;
          } while (iVar5 != -1);
        }
        uVar4 = func_0x0001e78e();
        FUN_0001ea42(uVar4);
        uVar4 = uRam003d4260;
        if (((cRam003d4268 != '\0') && (iVar5 = FUN_00029ddc(uRam003d4260), iVar5 != 0)) &&
           (iVar5 = iVar5 + -1, -1 < iVar5)) {
          do {
            uVar6 = FUN_0002a364(uVar4,iVar5);
            func_0x0006d5a6(uVar6,8);
            iVar5 = iVar5 + -1;
          } while (iVar5 != -1);
        }
      }
      uVar4 = uRam003d4264;
      if (((cRam003d4268 != '\0') && (iVar5 = FUN_00029ddc(uRam003d4264), iVar5 != 0)) &&
         (iVar5 = iVar5 + -1, -1 < iVar5)) {
        do {
          uVar6 = FUN_0002a364(uVar4,iVar5);
          func_0x0006d5a6(uVar6,9);
          iVar5 = iVar5 + -1;
        } while (iVar5 != -1);
      }
      (**(code **)(*piVar2 + 0x278))(piVar2);
      if (piRam003d426c != (int *)0x0) {
        FUN_0006f75c(piRam003d426c);
        if (piRam003d426c != (int *)0x0) {
          (**(code **)(*piRam003d426c + 0x44))(piRam003d426c);
        }
        piRam003d426c = (int *)0x0;
      }
    }
    iVar5 = *(int *)(param_1 + 0xc);
  }
  if (iVar5 == 0xd) {
    if (piRam003d426c != (int *)0x0) {
      FUN_0006f75c(piRam003d426c);
      if (piRam003d426c != (int *)0x0) {
        (**(code **)(*piRam003d426c + 0x44))(piRam003d426c);
      }
      piRam003d426c = (int *)0x0;
    }
    uVar4 = __Znwm(0x24);
    func_0x0006f652(uVar4);
    piRam003d426c = (int *)FUN_0002dfa6(uVar4);
    func_0x00070028(piRam003d426c,&UNK_0005877a,0,0x9999999a,0x3fb99999,0);
  }
  cRam003d4280 = 0;
  return;
}


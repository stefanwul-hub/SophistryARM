
bool FUN_0021806e(int param_1)

{
  return *(int *)(param_1 + 0x2c) != 0;
}


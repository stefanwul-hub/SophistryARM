
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0006faba(int *param_1,int *param_2,int *param_3,undefined8 param_4,char param_5)

{
  int *piVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  undefined8 uStack_34;
  int aiStack_20 [4];
  
  if (param_1 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xc2,uVar2,"this != 0");
  }
  if (param_2 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xc2,uVar2,"actionName != 0");
  }
  if (param_3 == (int *)0x0) {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xc2,uVar2,"handler != 0");
  }
  if (param_1 != (int *)0x0) {
    (**(code **)(*param_1 + 0x40))(param_1);
  }
  *(undefined1 *)(param_1 + 4) = 1;
  *(char *)((int)param_1 + 0x11) = param_5;
  piVar1 = (int *)param_1[5];
  if (param_2 != piVar1) {
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    param_1[5] = (int)param_2;
    if (param_2 != (int *)0x0) {
      (**(code **)(*param_2 + 0x40))(param_2);
    }
  }
  param_1[7] = 0;
  param_1[8] = 0;
  piVar1 = (int *)param_1[6];
  if (param_3 != piVar1) {
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
    param_1[6] = (int)param_3;
    if (param_3 != (int *)0x0) {
      (**(code **)(*param_3 + 0x40))(param_3);
    }
  }
  uVar2 = _NewEventLoopTimerUPP(FUN_0006fa3c);
  if (param_5 == '\0') {
    uStack_34 = 0;
  }
  else {
    uStack_34 = param_4;
  }
  uVar3 = _GetCurrentEventLoop();
  iVar4 = _InstallEventLoopTimer(uVar3,param_4,uStack_34,uVar2,param_1,aiStack_20);
  if (iVar4 == 0) {
    param_1[3] = aiStack_20[0];
  }
  else {
    uVar2 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                           );
    uVar3 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s. Error code: %i",0xe4,uVar2,iVar4);
    param_1[3] = aiStack_20[0];
  }
  if (aiStack_20[0] != 0) {
    uVar2 = FUN_00084aa2();
    FUN_00083b04(uVar2,FUN_0006f9be,param_1);
    return;
  }
  uVar2 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                         );
  uVar3 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar3,"Assertion failed in line %d of %s: %s.",0xe6,uVar2,"_private != 0");
  uVar2 = FUN_00084aa2();
  FUN_00083b04(uVar2,FUN_0006f9be,param_1);
  return;
}


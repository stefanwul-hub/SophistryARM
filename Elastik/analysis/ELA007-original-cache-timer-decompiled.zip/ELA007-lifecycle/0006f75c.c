
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0006f75c(int *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (param_1 == (int *)0x0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x8a,uVar1,"this != 0");
  }
  if ((char)param_1[4] != '\0') {
    (**(code **)(*param_1 + 0x48))(param_1);
  }
  *(undefined1 *)(param_1 + 4) = 0;
  if (param_1[3] != 0) {
    _RemoveEventLoopTimer(param_1[3]);
    param_1[3] = 0;
  }
  uVar1 = FUN_00084aa2();
  FUN_00083b2e(uVar1,FUN_0006f9be,param_1);
  return;
}


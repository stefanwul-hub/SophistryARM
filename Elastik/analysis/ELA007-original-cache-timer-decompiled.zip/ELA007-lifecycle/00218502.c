
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_00218502(int param_1)

{
  double dVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  longdouble lVar10;
  int *piStack_88;
  int iStack_60;
  int iStack_5c;
  char *pcStack_54;
  int iStack_4c;
  int *piStack_48;
  int iStack_30;
  int aiStack_20 [4];
  
  if (*(char *)(param_1 + 0x30) != '\0') {
    *(undefined1 *)(param_1 + 0x30) = 0;
  }
  if (*(char *)(param_1 + 0x31) != '\0') {
    dVar1 = *(double *)(param_1 + 0x34);
    lVar10 = (longdouble)func_0x0000a8fe();
    *(double *)(param_1 + 0x34) = dVar1 - (double)lVar10;
  }
  *(undefined1 *)(param_1 + 0x3c) = 1;
  pcStack_54 = *(char **)(param_1 + 0x40);
  if (0 < *(int *)(param_1 + 0x44)) {
    iStack_5c = 0;
    do {
      if (((*pcStack_54 != '\0') && (iVar2 = *(int *)(pcStack_54 + 4), iVar2 != -1)) &&
         (iVar3 = *(int *)(pcStack_54 + 8), iVar2 <= iVar3)) {
        iVar6 = iVar2 * 4;
        iVar7 = *(int *)(*(int *)(param_1 + 0x14) + iVar6);
        do {
          if (iVar7 == -1) {
LAB_002185f2:
            iVar9 = *(int *)(param_1 + 0x1c);
LAB_002185f5:
            if (iVar9 < 1) {
LAB_00218688:
              if (*(int *)(param_1 + 0x20) <= iVar9) {
                FUN_0000acae("GNFileCache: Buffer block count to low.");
                iVar9 = *(int *)(param_1 + 0x1c);
              }
              iVar7 = *(int *)(param_1 + 0x10);
              uVar5 = FUN_0000aecc(*(undefined4 *)(param_1 + 0x18));
              *(undefined4 *)(iVar7 + iVar9 * 8 + 4) = uVar5;
              iStack_60 = *(int *)(param_1 + 0x1c);
              *(int *)(param_1 + 0x1c) = iStack_60 + 1;
              piStack_88 = *(int **)(param_1 + 0x10);
LAB_002186be:
              iVar7 = piStack_88[iStack_60 * 2];
            }
            else {
              piStack_88 = *(int **)(param_1 + 0x10);
              iStack_4c = *piStack_88;
              if (iStack_4c == -1) {
                iStack_60 = 0;
                goto LAB_002186be;
              }
              if (*(int *)(param_1 + 0x44) < 1) {
                iStack_60 = 0;
              }
              else {
                iStack_60 = 0;
                piStack_48 = piStack_88;
                do {
                  piStack_48 = piStack_48 + 2;
                  iVar7 = 0;
                  pcVar4 = *(char **)(param_1 + 0x40);
                  while (((*pcVar4 == '\0' || (*(int *)(pcVar4 + 4) == -1)) ||
                         ((iStack_4c < *(int *)(pcVar4 + 4) || (*(int *)(pcVar4 + 8) < iStack_4c))))
                        ) {
                    pcVar4 = pcVar4 + 0xc;
                    iVar7 = iVar7 + 1;
                    if (iVar7 == *(int *)(param_1 + 0x44)) goto LAB_00218665;
                  }
                  iStack_60 = iStack_60 + 1;
                  if (iVar9 == iStack_60) goto LAB_00218688;
                  iStack_4c = *piStack_48;
                } while (iStack_4c != -1);
LAB_00218665:
                if (iStack_60 == -1) goto LAB_00218688;
              }
              iVar7 = piStack_88[iStack_60 * 2];
            }
            if (iVar7 != -1) {
              *(undefined4 *)(*(int *)(param_1 + 0x14) + iVar7 * 4) = 0xffffffff;
              piStack_88 = *(int **)(param_1 + 0x10);
            }
            piStack_88[iStack_60 * 2] = -1;
            iVar9 = iVar2 * *(int *)(param_1 + 0x18);
            iVar7 = (**(code **)(**(int **)(param_1 + 0xc) + 0x1b8))(*(int **)(param_1 + 0xc));
            if (iVar9 - iVar7 != 0) {
              (**(code **)(**(int **)(param_1 + 0xc) + 0x1c0))(*(int **)(param_1 + 0xc),iVar9);
            }
            aiStack_20[0] = *(int *)(param_1 + 0x18);
            if (*(int *)(param_1 + 0x28) < iVar9 + aiStack_20[0]) {
              aiStack_20[0] = *(int *)(param_1 + 0x28) - iVar9;
            }
            (**(code **)(**(int **)(param_1 + 0xc) + 0x1ac))
                      (*(int **)(param_1 + 0xc),
                       *(undefined4 *)(iStack_60 * 8 + 4 + *(int *)(param_1 + 0x10)),aiStack_20);
            *(int *)(iStack_60 * 8 + *(int *)(param_1 + 0x10)) = iVar2;
            *(int *)(*(int *)(param_1 + 0x14) + iVar6) = iStack_60;
          }
          else {
            piVar8 = *(int **)(param_1 + 0x10);
            if (iVar2 != piVar8[iVar7 * 2]) {
              iVar9 = *(int *)(param_1 + 0x1c);
              if (iVar9 < 1) goto LAB_00218688;
              if (iVar2 == *piVar8) {
                iStack_30 = 0;
              }
              else {
                iStack_30 = 0;
                do {
                  piVar8 = piVar8 + 2;
                  iStack_30 = iStack_30 + 1;
                  if (iVar9 == iStack_30) goto LAB_002185f5;
                } while (iVar2 != *piVar8);
              }
              FUN_0000ab14("_cache[%i].block = %i | _blocks[%i] = %i",iStack_30,iVar2,iVar2,iVar7);
              if (iStack_30 == -1) goto LAB_002185f2;
            }
          }
          iVar2 = iVar2 + 1;
          iVar6 = iVar6 + 4;
          if (iVar3 < iVar2) break;
          iVar7 = *(int *)(*(int *)(param_1 + 0x14) + iVar6);
        } while( true );
      }
      pcStack_54 = pcStack_54 + 0xc;
      iStack_5c = iStack_5c + 1;
    } while (iStack_5c < *(int *)(param_1 + 0x44));
  }
  *(undefined1 *)(param_1 + 0x3c) = 0;
  if (*(char *)(param_1 + 0x31) != '\0') {
    dVar1 = *(double *)(param_1 + 0x34);
    lVar10 = (longdouble)func_0x0000a8fe();
    *(double *)(param_1 + 0x34) = dVar1 + (double)lVar10;
  }
  return;
}


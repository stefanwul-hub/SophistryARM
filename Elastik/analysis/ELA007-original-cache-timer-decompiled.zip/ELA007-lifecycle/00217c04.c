
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

int FUN_00217c04(void)

{
  undefined4 uVar1;
  
  if (iRam003d9070 != 0) {
    return iRam003d9070;
  }
  uVar1 = FUN_00033b90("GNFileCache");
  iRam003d9070 = FUN_0001ffde(uVar1,&UNK_002189be);
  return iRam003d9070;
}



void FUN_0021803c(int param_1)

{
  if (*(int *)(param_1 + 0x2c) != 0) {
    FUN_0006f75c(*(int *)(param_1 + 0x2c));
    (**(code **)(**(int **)(param_1 + 0x2c) + 0x44))(*(int **)(param_1 + 0x2c));
    *(undefined4 *)(param_1 + 0x2c) = 0;
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0006fdb4(int *param_1,int param_2,int param_3,undefined8 param_4,char param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined8 uStack_34;
  int aiStack_20 [4];
  
  if (param_1 == (int *)0x0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0xf9,uVar1,"this != 0");
  }
  if (param_2 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0xf9,uVar1,"func != 0");
  }
  if (param_1 != (int *)0x0) {
    (**(code **)(*param_1 + 0x40))(param_1);
  }
  *(undefined1 *)(param_1 + 4) = 1;
  *(char *)((int)param_1 + 0x11) = param_5;
  param_1[5] = 0;
  param_1[7] = param_2;
  param_1[8] = param_3;
  uVar1 = _NewEventLoopTimerUPP(FUN_0006fa3c);
  if (param_5 == '\0') {
    uStack_34 = 0;
  }
  else {
    uStack_34 = param_4;
  }
  uVar2 = _GetCurrentEventLoop();
  iVar3 = _InstallEventLoopTimer(uVar2,param_4,uStack_34,uVar1,param_1,aiStack_20);
  if (iVar3 == 0) {
    param_1[3] = aiStack_20[0];
  }
  else {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s. Error code: %i",0x118,uVar1,iVar3);
    param_1[3] = aiStack_20[0];
  }
  if (aiStack_20[0] != 0) {
    uVar1 = FUN_00084aa2();
    FUN_00083b04(uVar1,FUN_0006f9be,param_1);
    return;
  }
  uVar1 = func_0x0000a930(
                         "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                         );
  uVar2 = FUN_00033b90("GNAssertionException");
  FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x11a,uVar1,"_private != 0");
  uVar1 = FUN_00084aa2();
  FUN_00083b04(uVar1,FUN_0006f9be,param_1);
  return;
}


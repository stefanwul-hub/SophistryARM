
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_0006f80a(int param_1)

{
  undefined4 uVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  
  if (param_1 == 0) {
    uVar1 = func_0x0000a930(
                           "/Volumes/CeleSVN/AppWork/XCode/GNUserInterface/../../GNUserInterface/GNTimer.cpp"
                           );
    uVar4 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar4,"Assertion failed in line %d of %s: %s.",0x6f,uVar1,"this != 0");
  }
  if (*(char *)(param_1 + 0x10) != '\0') {
    uVar1 = __Znwm(0x14);
    FUN_0001e688(uVar1);
    piVar2 = (int *)FUN_0002dfa6(uVar1);
    FUN_0001e860(piVar2,10);
    if (*(char *)(param_1 + 0x11) == '\0') {
      FUN_0006f75c(param_1);
    }
    if ((*(int *)(param_1 + 0x18) != 0) && (*(int *)(param_1 + 0x14) != 0)) {
      uVar1 = __Znwm(0x28);
      FUN_0013158c(uVar1);
      piVar3 = (int *)FUN_0002dfa6(uVar1);
      FUN_00131b4a(piVar3,*(undefined4 *)(param_1 + 0x14));
      (**(code **)(**(int **)(param_1 + 0x18) + 0x1b0))(*(int **)(param_1 + 0x18),piVar3);
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 0x44))(piVar3);
      }
    }
    if (*(code **)(param_1 + 0x1c) != (code *)0x0) {
      (**(code **)(param_1 + 0x1c))(*(undefined4 *)(param_1 + 0x20));
    }
    uVar1 = FUN_00059c92();
    FUN_00059f14(uVar1);
    if (piVar2 != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0006f900. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 0x44))();
      return;
    }
  }
  return;
}


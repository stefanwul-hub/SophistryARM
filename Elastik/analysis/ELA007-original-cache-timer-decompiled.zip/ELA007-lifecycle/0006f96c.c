
void FUN_0006f96c(int param_1)

{
  int *piVar1;
  
  if (*(int *)(param_1 + 0xc) != 0) {
    FUN_0006f75c(param_1);
  }
  piVar1 = *(int **)(param_1 + 0x14);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x44))(piVar1);
  }
  *(undefined4 *)(param_1 + 0x14) = 0;
  piVar1 = *(int **)(param_1 + 0x18);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x44))(piVar1);
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  return;
}



void FUN_00217edc(int param_1)

{
  int *piVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 0x2c) != 0) {
    FUN_0006f75c(*(int *)(param_1 + 0x2c));
    piVar1 = *(int **)(param_1 + 0x2c);
    if (piVar1 != (int *)0x0) {
      (**(code **)(*piVar1 + 0x44))(piVar1);
    }
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  piVar1 = *(int **)(param_1 + 0xc);
  if (piVar1 != (int *)0x0) {
    (**(code **)(*piVar1 + 0x44))(piVar1);
  }
  *(undefined4 *)(param_1 + 0xc) = 0;
  if (0 < *(int *)(param_1 + 0x1c)) {
    iVar2 = 0;
    do {
      FUN_0000b122(*(undefined4 *)(*(int *)(param_1 + 0x10) + 4 + iVar2 * 8));
      iVar2 = iVar2 + 1;
    } while (iVar2 < *(int *)(param_1 + 0x1c));
  }
  FUN_0000b122(*(undefined4 *)(param_1 + 0x10));
  FUN_0000b122(*(undefined4 *)(param_1 + 0x14));
  FUN_0000b122(*(undefined4 *)(param_1 + 0x40));
  return;
}


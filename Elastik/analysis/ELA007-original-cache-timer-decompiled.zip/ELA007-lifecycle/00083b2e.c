
void FUN_00083b2e(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uStack_14;
  undefined4 uStack_10;
  
  uStack_14 = param_2;
  uStack_10 = param_3;
  func_0x000424ac(*(undefined4 *)(param_1 + 0xc),&uStack_14);
  return;
}


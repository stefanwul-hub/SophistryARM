
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001f35c4(int *param_1)

{
  float fVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  int iStack_20;
  
  iVar5 = func_0x0001c8ce(param_1);
  iVar3 = iVar5 * 3;
  iVar5 = FUN_0000aecc(iVar5 * 0xc);
  param_1[0x31] = iVar5;
  if (0 < iVar3) {
    iStack_20 = 0;
    do {
      iVar5 = param_1[0x31];
      uVar4 = FUN_0000aecc(0x5c);
      *(undefined4 *)(iVar5 + iStack_20 * 4) = uVar4;
      iStack_20 = iStack_20 + 1;
    } while (iVar3 != iStack_20);
  }
  fVar7 = FLOAT_00365e54 * (float)param_1[0x21];
  param_1[0x2d] = (int)fVar7;
  fVar7 = FLOAT_00365e58 - fVar7;
  fVar7 = fVar7 * fVar7 * fVar7 * FLOAT_00365e5c;
  param_1[0x22] = (int)fVar7;
  param_1[0x28] = (int)(fVar7 * (float)param_1[0x23]);
  fVar7 = (float)((double)(float)param_1[0x2d] * (DOUBLE_00364910 / *(double *)(param_1 + 0x13))) *
          FLOAT_00365e60;
  uVar6 = -(uint)(fVar7 <= FLOAT_00365e60);
  fVar9 = (float)(~uVar6 & (uint)FLOAT_00365e60 | (uint)fVar7 & uVar6);
  param_1[0x2d] = (int)fVar9;
  param_1[0x20] = (int)fVar9;
  fVar1 = FLOAT_00365ce8;
  fVar8 = (fVar9 * FLOAT_00365e64 + fVar9 * FLOAT_00365e68 * fVar9) - FLOAT_00365ce8;
  param_1[0x29] = (int)fVar8;
  fVar7 = FLOAT_00365cd0;
  param_1[0x2a] = (int)((fVar8 + fVar1) * FLOAT_00365cd0);
  param_1[0x2c] = (int)(fVar9 * fVar9 * FLOAT_00365e6c + fVar1);
  param_1[0x2b] =
       (int)((float)param_1[0x27] * fVar7 *
             (fVar9 * FLOAT_00365e70 + FLOAT_00365d84 + fVar9 * fVar9 * fVar9 * FLOAT_00365e74) *
            ((float)param_1[0x23] * fVar7 + fVar7));
  param_1[0x39] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = param_1[0x12];
  cVar2 = (**(code **)(*param_1 + 0x344))(param_1);
  if (cVar2 != '\0') {
    uVar6 = param_1[0x15];
    if ((uVar6 & 0x100) != 0) {
      uVar6 = uVar6 & 0xff;
    }
    iVar3 = FUN_0000aecc(uVar6 << 2);
    param_1[0x10] = iVar3;
    iVar3 = 0;
    while( true ) {
      uVar6 = param_1[0x15];
      if ((uVar6 & 0x100) != 0) {
        uVar6 = uVar6 & 0xff;
      }
      if ((int)uVar6 <= iVar3) break;
      iVar5 = param_1[0x10];
      uVar4 = FUN_0000aecc(param_1[0x12] << 2);
      *(undefined4 *)(iVar3 * 4 + iVar5) = uVar4;
      func_0x0016251a(*(undefined4 *)(iVar3 * 4 + param_1[0x10]),0x44,param_1[0x12]);
      iVar3 = iVar3 + 1;
    }
  }
  return;
}


001f2cea  55  PUSH EBP
001f2ceb  89e5  MOV EBP,ESP
001f2ced  8b5508  MOV EDX,dword ptr [EBP + 0x8]
001f2cf0  8b450c  MOV EAX,dword ptr [EBP + 0xc]
001f2cf3  3982bc000000  CMP dword ptr [EDX + 0xbc],EAX
001f2cf9  741b  JZ 0x001f2d16
001f2cfb  8982bc000000  MOV dword ptr [EDX + 0xbc],EAX
001f2d01  c682c900000001  MOV byte ptr [EDX + 0xc9],0x1
001f2d08  8b02  MOV EAX,dword ptr [EDX]
001f2d0a  895508  MOV dword ptr [EBP + 0x8],EDX
001f2d0d  8b884c020000  MOV ECX,dword ptr [EAX + 0x24c]
001f2d13  5d  POP EBP
001f2d14  ffe1  JMP ECX
001f2d16  5d  POP EBP
001f2d17  c3  RET

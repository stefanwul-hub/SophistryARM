
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001565de(int *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  
  func_0x0001ddfc(param_1);
  if ((param_1[0x20] != 0) && (*(char *)(param_1[0x20] + 0xb8) != '\0')) {
    if (param_1[0x25] != 0) {
      uVar1 = func_0x0000a930(
                             "/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNPolyMidiInstrument.cpp"
                             );
      uVar2 = FUN_00033b90("GNAssertionException");
      FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x17e,uVar1,"_voiceBuffers == 0");
    }
    uVar1 = func_0x0001ce36(param_1);
    uVar2 = (**(code **)(*param_1 + 0x260))(param_1);
    iVar3 = func_0x001625f0(0x44,uVar2,uVar1);
    param_1[0x25] = iVar3;
  }
  return;
}



/* WARNING: Function: __i686.get_pc_thunk.cx replaced with injection: get_pc_thunk_cx */

longdouble FUN_0014a14e(int param_1)

{
  return (longdouble)
         (((float)*(int *)(param_1 + 0x40) * FLOAT_00365dd0 + FLOAT_00365ce8) *
         *(float *)(param_1 + 0x38));
}



/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001564aa(undefined4 *param_1)

{
  FUN_0001bfca(param_1);
  *param_1 = &UNK_0038bca8;
  param_1[0x22] = 0;
  param_1[0x20] = 0;
  *(undefined1 *)(param_1 + 0x21) = 0x80;
  *(undefined1 *)((int)param_1 + 0x91) = 0;
  *(undefined1 *)((int)param_1 + 0x92) = 0;
  param_1[0x25] = 0;
  return;
}


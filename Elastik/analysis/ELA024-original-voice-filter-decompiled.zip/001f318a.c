
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */

void FUN_001f318a(int param_1,float *param_2,float *param_3,uint param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longdouble lVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  float fVar7;
  
  if (1 < param_4) {
    uVar1 = func_0x0000a930("/Volumes/CeleSVN/AppWork/XCode/GNAudio/../../GNAudio/GNAudioFilter.cpp"
                           );
    uVar2 = FUN_00033b90("GNAssertionException");
    FUN_0000bfd6(uVar2,"Assertion failed in line %d of %s: %s.",0x153,uVar1,
                 "fltSlope == 0 || fltSlope == 1");
  }
  fVar5 = *param_2;
  fVar4 = param_3[3];
  lVar3 = (longdouble)
          FUN_00227dae((fVar4 + fVar4 * fVar4 * fVar4 * FLOAT_00365e7c) * *(float *)(param_1 + 0xa0)
                       ,*(undefined4 *)(param_1 + 0x98),0);
  param_3[4] = fVar5 - (float)lVar3;
  uRam0036704c = uRam0036704c * 0xbb38435 + 0x3619636b;
  fVar4 = ((float)uRam0036704c * FLOAT_00365e78 - FLOAT_00365ce8) * *(float *)(param_1 + 0xd4) +
          FLOAT_00365ce8;
  fVar7 = fVar4 * *(float *)(param_1 + 0xcc);
  fVar4 = fVar4 * *(float *)(param_1 + 0xd0);
  fVar5 = ((fVar5 - (float)lVar3) + param_3[9]) * fVar4 - fVar7 * *param_3;
  *param_3 = fVar5;
  fVar6 = (fVar5 + param_3[5]) * fVar4 - fVar7 * param_3[1];
  param_3[1] = fVar6;
  fVar5 = (fVar6 + param_3[6]) * fVar4 - fVar7 * param_3[2];
  param_3[2] = fVar5;
  fVar4 = (fVar5 + param_3[7]) * fVar4 - fVar7 * param_3[3];
  param_3[3] = fVar4;
  param_3[5] = *param_3;
  param_3[6] = param_3[1];
  param_3[7] = param_3[2];
  param_3[8] = param_3[3];
  param_3[9] = param_3[4];
  param_3[0xf] = fVar6;
  param_3[0x10] = fVar4;
  fVar5 = param_3[4];
  param_3[0x11] = fVar5 - fVar6;
  param_3[0x12] = fVar5 - fVar4;
  param_3[0x13] = (fVar4 + (fVar4 - fVar6)) - fVar6;
  param_3[0x14] = ((fVar5 - fVar6) + param_3[2]) - *param_3;
  param_3[0x15] = fVar5 + param_3[2];
  param_3[0x16] = fVar5 + *param_3;
  *param_2 = param_3[param_4 + *(int *)(param_1 + 0xc0) * 2 + 0xf];
  return;
}


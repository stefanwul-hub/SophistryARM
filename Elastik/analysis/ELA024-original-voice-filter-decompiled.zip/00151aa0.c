
void FUN_00151aa0(int *param_1)

{
  code *pcVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  longdouble lVar5;
  
  FUN_001565de(param_1);
  if (param_1[0x2e] == 0) {
    uVar2 = __Znwm(0xe8);
    FUN_001f351c(uVar2);
    piVar3 = (int *)FUN_0002dfa6(uVar2);
    piVar4 = (int *)(**(code **)(*piVar3 + 0x48))(piVar3);
    piVar3 = (int *)param_1[0x2e];
    if (piVar4 != piVar3) {
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 0x44))(piVar3);
      }
      param_1[0x2e] = (int)piVar4;
      if (piVar4 == (int *)0x0) {
        piVar3 = (int *)0x0;
      }
      else {
        (**(code **)(*piVar4 + 0x40))(piVar4);
        piVar3 = (int *)param_1[0x2e];
      }
    }
    func_0x001f2cae(piVar3,0);
    FUN_0001cd38(param_1[0x2e],2);
    FUN_0001ce42(param_1[0x2e],2);
    pcVar1 = *(code **)(*(int *)param_1[0x2e] + 0x254);
    lVar5 = (longdouble)(**(code **)(*param_1 + 600))(param_1);
    (*pcVar1)(param_1[0x2e],(double)lVar5);
    pcVar1 = *(code **)(*(int *)param_1[0x2e] + 0x25c);
    uVar2 = (**(code **)(*param_1 + 0x260))(param_1);
    (*pcVar1)(param_1[0x2e],uVar2);
    (**(code **)(*(int *)param_1[0x2e] + 0x23c))((int *)param_1[0x2e]);
  }
  if (param_1[0x2f] == 0) {
    uVar2 = __Znwm(0xe8);
    FUN_001f351c(uVar2);
    piVar3 = (int *)FUN_0002dfa6(uVar2);
    piVar4 = (int *)(**(code **)(*piVar3 + 0x48))(piVar3);
    piVar3 = (int *)param_1[0x2f];
    if (piVar4 != piVar3) {
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 0x44))(piVar3);
      }
      param_1[0x2f] = (int)piVar4;
      if (piVar4 == (int *)0x0) {
        piVar3 = (int *)0x0;
      }
      else {
        (**(code **)(*piVar4 + 0x40))(piVar4);
        piVar3 = (int *)param_1[0x2f];
      }
    }
    func_0x001f2cae(piVar3,1);
    FUN_0001cd38(param_1[0x2f],2);
    FUN_0001ce42(param_1[0x2f],2);
    pcVar1 = *(code **)(*(int *)param_1[0x2f] + 0x254);
    lVar5 = (longdouble)(**(code **)(*param_1 + 600))(param_1);
    (*pcVar1)(param_1[0x2f],(double)lVar5);
    pcVar1 = *(code **)(*(int *)param_1[0x2f] + 0x25c);
    uVar2 = (**(code **)(*param_1 + 0x260))(param_1);
    (*pcVar1)(param_1[0x2f],uVar2);
    (**(code **)(*(int *)param_1[0x2f] + 0x23c))((int *)param_1[0x2f]);
  }
  if (param_1[0x30] == 0) {
    uVar2 = __Znwm(0xe8);
    FUN_001f351c(uVar2);
    piVar3 = (int *)FUN_0002dfa6(uVar2);
    piVar4 = (int *)(**(code **)(*piVar3 + 0x48))(piVar3);
    piVar3 = (int *)param_1[0x30];
    if (piVar4 != piVar3) {
      if (piVar3 != (int *)0x0) {
        (**(code **)(*piVar3 + 0x44))(piVar3);
      }
      param_1[0x30] = (int)piVar4;
      if (piVar4 == (int *)0x0) {
        piVar3 = (int *)0x0;
      }
      else {
        (**(code **)(*piVar4 + 0x40))(piVar4);
        piVar3 = (int *)param_1[0x30];
      }
    }
    func_0x001f2cae(piVar3,2);
    FUN_0001cd38(param_1[0x30],2);
    FUN_0001ce42(param_1[0x30],2);
    pcVar1 = *(code **)(*(int *)param_1[0x30] + 0x254);
    lVar5 = (longdouble)(**(code **)(*param_1 + 600))(param_1);
    (*pcVar1)(param_1[0x30],(double)lVar5);
    pcVar1 = *(code **)(*(int *)param_1[0x30] + 0x25c);
    uVar2 = (**(code **)(*param_1 + 0x260))(param_1);
    (*pcVar1)(param_1[0x30],uVar2);
    (**(code **)(*(int *)param_1[0x30] + 0x23c))((int *)param_1[0x30]);
  }
  if (param_1[0x31] != 0) {
    return;
  }
  uVar2 = __Znwm(0xe8);
  FUN_001f351c(uVar2);
  piVar3 = (int *)FUN_0002dfa6(uVar2);
  piVar4 = (int *)(**(code **)(*piVar3 + 0x48))(piVar3);
  piVar3 = (int *)param_1[0x31];
  if (piVar4 != piVar3) {
    if (piVar3 != (int *)0x0) {
      (**(code **)(*piVar3 + 0x44))(piVar3);
    }
    param_1[0x31] = (int)piVar4;
    if (piVar4 == (int *)0x0) {
      piVar3 = (int *)0x0;
    }
    else {
      (**(code **)(*piVar4 + 0x40))(piVar4);
      piVar3 = (int *)param_1[0x31];
    }
  }
  func_0x001f2cae(piVar3,3);
  FUN_0001cd38(param_1[0x31],2);
  FUN_0001ce42(param_1[0x31],2);
  pcVar1 = *(code **)(*(int *)param_1[0x31] + 0x254);
  lVar5 = (longdouble)(**(code **)(*param_1 + 600))(param_1);
  (*pcVar1)(param_1[0x31],(double)lVar5);
  pcVar1 = *(code **)(*(int *)param_1[0x31] + 0x25c);
  uVar2 = (**(code **)(*param_1 + 0x260))(param_1);
  (*pcVar1)(param_1[0x31],uVar2);
                    /* WARNING: Could not recover jumptable at 0x00151beb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(int *)param_1[0x31] + 0x23c))();
  return;
}



void FUN_001f2f6a(int param_1)

{
  int iVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 0xc4) != 0) {
    iVar2 = 0;
    iVar1 = func_0x0001c8ce(param_1);
    if (0 < iVar1 * 3) {
      do {
        iVar1 = *(int *)(*(int *)(param_1 + 0xc4) + iVar2 * 4);
        if (iVar1 != 0) {
          _memset(iVar1,0,0x5c);
        }
        iVar2 = iVar2 + 1;
        iVar1 = func_0x0001c8ce(param_1);
      } while (iVar2 < iVar1 * 3);
    }
  }
  return;
}


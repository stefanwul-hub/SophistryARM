
/* WARNING: Function: __i686.get_pc_thunk.bx replaced with injection: get_pc_thunk_bx */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_001f379e(int param_1,int param_2,int param_3,int param_4)

{
  float fVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  float fVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  uint uStack_44;
  int iStack_40;
  undefined4 *puStack_38;
  char cStack_31;
  float fStack_30;
  float fStack_2c;
  float fStack_28;
  int iStack_24;
  int iStack_20;
  
  iVar2 = func_0x0001c8ce(param_1);
  cStack_31 = *(char *)(param_1 + 200);
  if (*(char *)(param_1 + 0xc9) == '\0') {
    iStack_24 = *(int *)(param_1 + 0xe4);
    if (iStack_24 != 0) goto LAB_001f394d;
LAB_001f3b68:
    if (cStack_31 == '\0') {
      *(undefined4 *)(param_1 + 0xcc) = *(undefined4 *)(param_1 + 0xa4);
      *(undefined4 *)(param_1 + 0xd0) = *(undefined4 *)(param_1 + 0xa8);
      *(undefined4 *)(param_1 + 0xd4) = *(undefined4 *)(param_1 + 0xac);
      fStack_2c = 0.0;
      fStack_30 = 0.0;
      fStack_28 = 0.0;
      iVar3 = *(int *)(param_1 + 0xbc);
      goto joined_r0x001f3bbc;
    }
    *(undefined1 *)(param_1 + 200) = 0;
    fStack_30 = *(float *)(param_1 + 0xa4);
    fStack_2c = *(float *)(param_1 + 0xa8);
    fStack_28 = *(float *)(param_1 + 0xac);
    fVar6 = FLOAT_00365e54 * *(float *)(param_1 + 0x84);
    *(float *)(param_1 + 0xb4) = fVar6;
    fVar6 = FLOAT_00365e58 - fVar6;
    fVar6 = fVar6 * fVar6 * fVar6 * FLOAT_00365e5c;
    *(float *)(param_1 + 0x88) = fVar6;
    *(float *)(param_1 + 0xa0) = fVar6 * *(float *)(param_1 + 0x8c);
    fVar6 = (float)((double)*(float *)(param_1 + 0xb4) *
                   (DOUBLE_00364910 / *(double *)(param_1 + 0x4c))) * FLOAT_00365e60;
    uVar5 = -(uint)(fVar6 <= FLOAT_00365e60);
    fVar8 = (float)(~uVar5 & (uint)FLOAT_00365e60 | (uint)fVar6 & uVar5);
    *(float *)(param_1 + 0xb4) = fVar8;
    *(float *)(param_1 + 0x80) = fVar8;
    fVar1 = FLOAT_00365ce8;
    fVar9 = (fVar8 * FLOAT_00365e64 + fVar8 * FLOAT_00365e68 * fVar8) - FLOAT_00365ce8;
    *(float *)(param_1 + 0xa4) = fVar9;
    fVar6 = FLOAT_00365cd0;
    fVar7 = (fVar9 + fVar1) * FLOAT_00365cd0;
    *(float *)(param_1 + 0xa8) = fVar7;
    *(float *)(param_1 + 0xb0) = fVar8 * fVar8 * FLOAT_00365e6c + fVar1;
    fVar6 = *(float *)(param_1 + 0x9c) * fVar6 *
            (fVar8 * FLOAT_00365e70 + FLOAT_00365d84 + fVar8 * fVar8 * fVar8 * FLOAT_00365e74) *
            (*(float *)(param_1 + 0x8c) * fVar6 + fVar6);
    *(float *)(param_1 + 0xac) = fVar6;
    *(undefined4 *)(param_1 + 0xe4) = 0x40;
    *(float *)(param_1 + 0xd8) = fVar9 - fStack_30;
    fVar7 = fVar7 - fStack_2c;
    *(float *)(param_1 + 0xdc) = fVar7;
    *(float *)(param_1 + 0xe0) = fVar6 - fStack_28;
    fVar6 = (float)((uint)(fVar9 - fStack_30) & _UNK_00365780);
    fVar7 = (float)(_UNK_00365780 & (uint)fVar7);
    if (fVar6 <= fVar7) {
      *(int *)(param_1 + 0xe4) = (int)((double)fVar7 / DOUBLE_003649c0);
    }
    else {
      *(int *)(param_1 + 0xe4) = (int)((double)fVar6 / DOUBLE_003649c0);
    }
    iStack_24 = *(int *)(param_1 + 0xe4);
    if (iStack_24 < 1) {
      iStack_24 = 0;
    }
    else {
      *(float *)(param_1 + 0xd8) = *(float *)(param_1 + 0xd8) / (float)iStack_24;
      *(float *)(param_1 + 0xdc) = *(float *)(param_1 + 0xdc) / (float)*(int *)(param_1 + 0xe4);
      *(float *)(param_1 + 0xe0) = *(float *)(param_1 + 0xe0) / (float)*(int *)(param_1 + 0xe4);
    }
  }
  else {
    fVar6 = FLOAT_00365e54 * *(float *)(param_1 + 0x84);
    *(float *)(param_1 + 0xb4) = fVar6;
    fVar6 = FLOAT_00365e58 - fVar6;
    fVar6 = fVar6 * fVar6 * fVar6 * FLOAT_00365e5c;
    *(float *)(param_1 + 0x88) = fVar6;
    *(float *)(param_1 + 0xa0) = fVar6 * *(float *)(param_1 + 0x8c);
    fVar6 = (float)((double)*(float *)(param_1 + 0xb4) *
                   (DOUBLE_00364910 / *(double *)(param_1 + 0x4c))) * FLOAT_00365e60;
    uVar5 = -(uint)(fVar6 <= FLOAT_00365e60);
    fVar8 = (float)(~uVar5 & (uint)FLOAT_00365e60 | (uint)fVar6 & uVar5);
    *(float *)(param_1 + 0xb4) = fVar8;
    *(float *)(param_1 + 0x80) = fVar8;
    fVar1 = FLOAT_00365ce8;
    fVar7 = (fVar8 * FLOAT_00365e64 + fVar8 * FLOAT_00365e68 * fVar8) - FLOAT_00365ce8;
    *(float *)(param_1 + 0xa4) = fVar7;
    fVar6 = FLOAT_00365cd0;
    *(float *)(param_1 + 0xa8) = (fVar7 + fVar1) * FLOAT_00365cd0;
    *(float *)(param_1 + 0xb0) = fVar8 * fVar8 * FLOAT_00365e6c + fVar1;
    *(float *)(param_1 + 0xac) =
         *(float *)(param_1 + 0x9c) * fVar6 *
         (fVar8 * FLOAT_00365e70 + FLOAT_00365d84 + fVar8 * fVar8 * fVar8 * FLOAT_00365e74) *
         (*(float *)(param_1 + 0x8c) * fVar6 + fVar6);
    *(undefined1 *)(param_1 + 0xc9) = 0;
    *(undefined1 *)(param_1 + 200) = 0;
    cStack_31 = '\0';
    iStack_24 = *(int *)(param_1 + 0xe4);
    if (iStack_24 == 0) goto LAB_001f3b68;
LAB_001f394d:
    fStack_30 = *(float *)(param_1 + 0xcc);
    fStack_2c = *(float *)(param_1 + 0xd0);
    fStack_28 = *(float *)(param_1 + 0xd4);
  }
  iVar3 = *(int *)(param_1 + 0xbc);
joined_r0x001f3bbc:
  uStack_44 = iVar3 - 1U & 0x80000001;
  if ((int)uStack_44 < 0) {
    uStack_44 = (uStack_44 - 1 | 0xfffffffe) + 1;
  }
  if (0 < iVar2) {
    iStack_40 = 0;
    do {
      if (cStack_31 == '\0') {
        if (iStack_24 != 0) {
          *(float *)(param_1 + 0xcc) = fStack_30;
          *(float *)(param_1 + 0xd0) = fStack_2c;
          *(float *)(param_1 + 0xd4) = fStack_28;
          *(int *)(param_1 + 0xe4) = iStack_24;
        }
      }
      else {
        *(float *)(param_1 + 0xcc) = fStack_30;
        *(float *)(param_1 + 0xd0) = fStack_2c;
        *(float *)(param_1 + 0xd4) = fStack_28;
        *(int *)(param_1 + 0xe4) = iStack_24;
      }
      puStack_38 = *(undefined4 **)(param_3 + iStack_40 * 4);
      *puStack_38 = **(undefined4 **)(param_2 + iStack_40 * 4);
      iStack_20 = 0;
      if (param_4 != 0) {
        do {
          iVar3 = (*(int *)(param_1 + 0xbc) + -1) / 2;
          if (0 < iVar3) {
            iVar4 = 0;
            do {
              FUN_001f318a(param_1,puStack_38,
                           *(undefined4 *)
                            (*(int *)(param_1 + 0xc4) + ((iVar3 - iVar4) * iVar2 + iStack_40) * 4),1
                          );
              iVar4 = iVar4 + 1;
            } while (iVar4 != iVar3);
          }
          FUN_001f318a(param_1,puStack_38,*(undefined4 *)(*(int *)(param_1 + 0xc4) + iStack_40 * 4),
                       uStack_44);
          puStack_38 = puStack_38 + 1;
          if (*(int *)(param_1 + 0xe4) != 0) {
            *(float *)(param_1 + 0xcc) = *(float *)(param_1 + 0xcc) + *(float *)(param_1 + 0xd8);
            *(float *)(param_1 + 0xd0) = *(float *)(param_1 + 0xd0) + *(float *)(param_1 + 0xdc);
            *(float *)(param_1 + 0xd4) = *(float *)(param_1 + 0xd4) + *(float *)(param_1 + 0xe0);
            *(int *)(param_1 + 0xe4) = *(int *)(param_1 + 0xe4) + -1;
          }
          iStack_20 = iStack_20 + 1;
        } while (iStack_20 != param_4);
      }
      iStack_40 = iStack_40 + 1;
    } while (iVar2 != iStack_40);
  }
  return;
}


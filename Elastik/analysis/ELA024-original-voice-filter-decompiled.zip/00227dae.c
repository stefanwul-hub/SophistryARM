
/* WARNING: Function: __i686.get_pc_thunk.cx replaced with injection: get_pc_thunk_cx */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longdouble FUN_00227dae(float param_1,float param_2)

{
  bool bVar1;
  
  bVar1 = param_1 < FLOAT_00365cf4;
  if (bVar1) {
    param_1 = (float)((uint)param_1 ^ _UNK_00365840);
  }
  if (param_2 < param_1) {
    param_1 = (FLOAT_00365d0c /
               ((param_1 - param_2) * (FLOAT_00365ce8 / (FLOAT_00365ce8 - param_2)) + FLOAT_00365ce8
               ) + FLOAT_00365ce8) * (FLOAT_00365ce8 - param_2) + param_2;
  }
  if (bVar1) {
    param_1 = (float)((uint)param_1 ^ _UNK_00365840);
  }
  return (longdouble)param_1;
}


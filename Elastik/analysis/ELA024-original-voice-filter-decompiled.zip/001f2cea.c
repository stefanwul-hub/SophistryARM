
void FUN_001f2cea(int *param_1,int param_2)

{
  if (param_1[0x2f] != param_2) {
    param_1[0x2f] = param_2;
    *(undefined1 *)((int)param_1 + 0xc9) = 1;
                    /* WARNING: Could not recover jumptable at 0x001f2d14. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_1 + 0x24c))();
    return;
  }
  return;
}


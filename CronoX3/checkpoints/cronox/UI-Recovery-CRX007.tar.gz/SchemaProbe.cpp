#include <bits/stdc++.h>
#define private public
#include "../../src/engine/LegacyEngine.h"
#undef private
#include "../../src/engine/LegacyEngine.cpp"
using namespace sophistry;
int main(){try {
 LegacyEngineConfig cfg;cfg.audioUnitMode=true;cfg.recycleFreedBlocks=true;cfg.collectDiagnostics=false;cfg.assetDirectories={"reference/Samples"};LegacyEngine e(cfg);e.initialize();
 auto& h=*e.impl_;const unsigned obj=0x1000000,slot=0x5d6000,text=0x5d8000;unsigned ctor=0,dtor=0;
 for(auto [pc,name]:h.imports){if(name=="__ZNSsC1Ev")ctor=pc;if(name=="__ZNSsD1Ev")dtor=pc;}
 auto display=[&](unsigned tag){h.run(ctor,{slot});h.run(0x1c6cc,{obj,tag,slot});auto value=h.string(h.word(slot));h.run(dtor,{slot});return value;};
 auto f32=[&](unsigned pc,std::initializer_list<unsigned> args){std::array<unsigned char,128> old{};memcpy(old.data(),h.cpu->reg+0x1100,128);h.run(pc,args);SlU bits=0;memcpy(&bits,h.cpu->reg+0x1100,10);auto value=sl_float<float>(sl_ext80_to_f32(bits));memcpy(h.cpu->reg+0x1100,old.data(),128);return value;};
 auto hex=[](const std::string& s){static const char* d="0123456789abcdef";std::string out;for(unsigned char c:s){out+=d[c>>4];out+=d[c&15];}return out;};
 auto ids=e.auParameterIds();std::map<std::array<unsigned,4>,std::vector<unsigned>> aliases;unsigned table=h.word(obj+0xc610),total=h.word(obj+0xcf10);std::cerr<<"Count "<<total<<" public "<<ids.size()<<" table "<<std::hex<<table<<std::dec<<"\n";
 auto key=[&](unsigned t){return std::array<unsigned,4>{h.word(table+t*52+0x10),h.word(table+t*52+0x14),h.word(table+t*52+0x1c),h.word(table+t*52+0x20)};};
 for(auto id:ids)aliases[key(id)].push_back(id);
 std::cout<<"[";bool first=true;
 for(unsigned tag=0;tag<total;++tag){if(tag==766)continue;auto p=h.run(0x1b16e,{obj,tag});if(!p)continue;auto def=h.word(p+0x10);if(!def)continue;auto type=h.word(def);int lo=int(h.word(def+12)),hi=int(h.word(def+16)),dflt=int(h.word(def+20));auto precision=h.read<short>(def+36);auto curve=h.read<float>(def+24);auto value=int(h.run(0x1ade8,{obj,tag}));auto name=h.string(h.word(table+tag*52+8));auto label=display(tag);auto norm=f32(0x1c5f2,{obj,tag,0});
 if(!first)std::cout<<",";first=false;std::cout<<"{\"tag\":"<<tag<<",\"kind\":"<<type<<",\"minimum\":"<<lo<<",\"maximum\":"<<hi<<",\"default\":"<<dflt<<",\"decimals\":"<<precision<<",\"curve\":"<<curve<<",\"value\":"<<value<<",\"normalized\":"<<norm<<",\"name_hex\":\""<<hex(name)<<"\",\"text_hex\":\""<<hex(label)<<"\",\"aliases\":[";bool a=false;for(auto id:aliases[key(tag)]){if(a)std::cout<<",";std::cout<<id;a=true;}std::cout<<"],\"labels\":[";
 auto labels=h.word(def+28);if(type==2&&labels&&precision>0&&precision<=128&&hi>=lo&&hi-lo<256){for(int v=lo;v<=hi;++v){if(v>lo)std::cout<<",";std::cout<<"\""<<hex(std::string(reinterpret_cast<const char*>(h.data(labels+(v-lo)*precision,precision)),strnlen(reinterpret_cast<const char*>(h.data(labels+(v-lo)*precision,precision)),precision)))<<"\"";}}
 std::cout<<"]}";
 }std::cout<<"]\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}}
